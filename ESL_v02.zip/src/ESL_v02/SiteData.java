package ESL_v02;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class SiteData {

	InputOption OPT;
	double[][][] dataMat; //[gene][tree][site]
	double[][] muHat; //[new, sum, average criteria][tree][tree]
	double[][] muHatCenter;  //[new, sum, average criteria][tree][tree]
	double[][] sigmaSqHat; //[new, sum, average criteria][tree][tree]
	double[][] SHStat; //[new, sum, average criteria][tree][tree]
	double[][][] KHStat; // [new, sum, average criteria][tree][tree]

	double[][] meanSave; //[treeNum][geneNum];
	double[][] varSave; //[treeNum][geneNum];
	double[] varAmongGene; //[treeNum];

	
	double[][] scoreSave; //[new,sum,average][treeid]
	int[][] treeRank; //[new,sum,average][ordered treeid]
	
	public void simulation20200712()  {
		
	}
	
	public void simulateData(double[] oriMu, double sigsqI, double[] sigsq, int[] L) {
		
		int i, j, k;
		int treeNum, geneNum;
		double d1, d2;
		treeNum = dataMat[0].length;
		geneNum = dataMat.length;
		

		for (i=0;i<treeNum;i++) {
			for (j=0;j<geneNum;j++) {
				d1 = myFunc.myRand.nextGaussian()*Math.sqrt(sigsqI) + oriMu[i];
				for (k=0;k<L[j];k++) {
					d2 = myFunc.myRand.nextGaussian()*Math.sqrt(sigsq[j]) + d1;
					dataMat[j][i][k] = d2;
				}
			}
		}
		
	}
	
	public void sitewiseLogLikeTest() {
		
		OPT = new InputOption(); 
		OPT.LoadInputOption();
		
		//checking
		if (OPT.myJob != JobType.SITEWISE_LOGLIKE_ANAL) {
			System.err.print(String.format("\nJobType is wrong!"));
			System.exit(0);
		}
		
		this.readData();
		
		int geneNum, treeNum;
		geneNum = dataMat.length;
		treeNum = dataMat[0].length;
		

		this.calcScore();
		
		muHat = new double[3][treeNum];
		muHatCenter = new double[3][treeNum];
		this.calcSHStat();
		
		this.printData();
		
	}

	public void calcKHStat() {
		int i,ii,j, k, L, l;
		int treeNum, geneNum;
		
		treeNum = dataMat[0].length;
		geneNum = dataMat.length;
		
		KHStat = new double[3][treeNum][treeNum];

		double[] ret, tmpSave, tmpSave2;
		double[] varWithinGene = new double[geneNum];
		tmpSave2 = new double[geneNum];
		ret = new double[2];
		
		double varAmongGeneLocal; 
		
		for (ii=0;ii<3;ii++) {
			for (i=0;i<treeNum;i++) {
				for (j=i+1;j<treeNum;j++) {
					for (k=0;k<geneNum;k++) {
						L = dataMat[k][j].length;
						tmpSave = new double[L];
						for (l=0;l<L;l++) {
							tmpSave[l] = dataMat[k][i][l]-dataMat[k][j][l];
						}
						myFunc.calcMeanVar(ret, tmpSave);
						if (ii==0) { // new criterion
							varWithinGene[k] = ret[1]/L;
							tmpSave2[k] = ret[0];
						}
						else if (ii==1) { //sum criterion
							tmpSave2[k] = ret[0]*L;
						}
						else if (ii==2) { // average criterion
							tmpSave2[k] = ret[0];
						}
					}
					
					myFunc.calcMeanVar(ret, tmpSave2);
					
					
					if (ii==0) { // new criterion
						varAmongGeneLocal = ret[1];
						myFunc.calcMeanVar(ret, varWithinGene);
						varAmongGeneLocal -= ret[0];
						if (varAmongGeneLocal < 0.0)
							varAmongGeneLocal = 0.0;
						
						this.KHStat[ii][i][j] = 0.0;
						this.KHStat[ii][j][i] = 0.0; // variance
						for (k=0;k<geneNum;k++) {
							L = dataMat[k][j].length;
							tmpSave = new double[L];
							for (l=0;l<L;l++) {
								tmpSave[l] = dataMat[k][i][l]-dataMat[k][j][l];
							}
							myFunc.calcMeanVar(ret, tmpSave);
							KHStat[ii][i][j] += ret[0]/(varAmongGeneLocal + ret[1]/L);
							KHStat[ii][j][i] += 1.0/(varAmongGeneLocal + ret[1]/L);
						}
					}
					else if (ii==1) {//sum average criterion
						KHStat[ii][i][j] = ret[0]*tmpSave2.length;
						KHStat[ii][j][i] = ret[1]*tmpSave2.length;
					}
					else { //average criterion
						KHStat[ii][i][j] = ret[0];
						KHStat[ii][j][i] = ret[1]/geneNum;
					}
					
					
				}
			}
			
		} // end of for (ii=0;ii<3;ii++) {
		
		
	}

	
	public void calcSHStat() { // double[][][] shStat, double[][][] mHat, double[][][]sSqHat,  double[][][] dMat) {
		//optimalTree[] should be determined before this
		int i,j,k,l, L;
		int treeA, treeB, treeNum, geneNum;
		
		double numerator, denominator;
		double[] ret, tmpSave, tmpSave2;
	
		treeNum = dataMat[0].length;
		geneNum = dataMat.length;
		
		double[] varWithinGene = new double[geneNum];
		double varAmongGeneLocal; 
		

		
		SHStat = new double[3][treeNum];
		sigmaSqHat = new double[3][treeNum];
		
		ret = new double[2];
		tmpSave = new double[dataMat[0][0].length];
		tmpSave2 = new double[geneNum];
		
		for (i=0;i<SHStat.length;i++) {
			treeA = treeRank[i][0];
			for (j=1;j<treeRank[i].length;j++) {
				treeB = treeRank[i][j];
				numerator = 0.0;
				for (k=0;k<geneNum;k++) {
					L = dataMat[k][j].length;
					tmpSave = new double[L];
					for (l=0;l<L;l++) {
						tmpSave[l] = dataMat[k][treeA][l]-dataMat[k][treeB][l];
					}
					myFunc.calcMeanVar(ret, tmpSave);
					if (i==0) { // new criterion
						varWithinGene[k] = ret[1]/L;
						tmpSave2[k] = ret[0];
					}
					else if (i==1) { //sum criterion
						numerator += ret[0]*L;
						tmpSave2[k] = ret[0]*L;
					}
					else if (i==2) { // average criterion
						numerator += ret[0];
						tmpSave2[k] = ret[0];
					}
				}
				
				myFunc.calcMeanVar(ret, tmpSave2);
				if (i==0) { // new criterion
					varAmongGeneLocal = ret[1];
					myFunc.calcMeanVar(ret, varWithinGene);
					varAmongGeneLocal -= ret[0];
					if (varAmongGeneLocal < 0.0)
						varAmongGeneLocal = 0.0;
					
					muHat[i][j] = 0.0;
					sigmaSqHat[i][j] = 0.0;
					for (k=0;k<geneNum;k++) {
						L = dataMat[k][j].length;
						tmpSave = new double[L];
						for (l=0;l<L;l++) {
							tmpSave[l] = dataMat[k][treeA][l]-dataMat[k][treeB][l];
						}
						myFunc.calcMeanVar(ret, tmpSave);
						muHat[i][j] += ret[0]/(varAmongGeneLocal + ret[1]/L);
						sigmaSqHat[i][j] += 1.0/(varAmongGeneLocal + ret[1]/L);
					}
				}
				else if (i==1) {//sum average criterion
					muHat[i][j] = ret[0]*tmpSave2.length;
					sigmaSqHat[i][j] = ret[1]*tmpSave2.length;
				}
				else { //average criterion
					muHat[i][j] = ret[0];
					sigmaSqHat[i][j] = ret[1]/geneNum;
				}

				SHStat[i][j] = (muHat[i][j] - muHatCenter[i][j])/Math.sqrt(sigmaSqHat[i][j]);
			}
		}
		
	
		
	}
	
	public void calcScore() { 
		// scoreSave[new,sum,average][treeid]
		// dMat[gene][tree][site]
		
		int i,j,id, k, geneNum, treeNum, L, totL;
		geneNum = dataMat.length;
		treeNum = dataMat[0].length;
	
		scoreSave = new double[3][treeNum]; //[new,sum,average][treeid]
		
		meanSave = new double[treeNum][geneNum];
		varSave = new double[treeNum][geneNum];
		varAmongGene = new double[treeNum];
		
		
		double[] ret = new double[2];
		double d;
		
		
		//Arrays.fill(meanSave, 0.0);
		//Arrays.fill(scoreSave, 0.0);
		//Arrays.fill(varAmongGene, 0.0);				
		
		
		for (j=0;j<treeNum;j++) {	
			totL = 0;
			double sum = 0.0;
			double sumInvL = 0;
			for (i=0;i<geneNum;i++) {
				L = dataMat[i][0].length;
				totL += L;
				myFunc.calcMeanVar(ret, dataMat[i][j]);
				meanSave[j][i] = ret[0];
				varSave[j][i] = ret[1];
				sum += ret[1]/L;
				sumInvL += 1.0/L;
				scoreSave[1][j] += ret[0]*L;  // sum criterion
				scoreSave[2][j] += ret[0]; // average criterion
			}
			//scoSave[1][j] /= totL; // sum criterion
			scoreSave[2][j] /= geneNum; //average criterion
			myFunc.calcMeanVar(ret, meanSave[j]);
			varAmongGene[j] = ret[1] - (sum/sumInvL)*sumInvL/geneNum; //sum/geneNum;
			if (varAmongGene[j]<0.0)
				varAmongGene[j] = 0.0;
			
		}
		
		double w, sumW;
		sumW = 0.0;
		
		for (j=0;j<treeNum;j++) {	
			sumW = 0.0;
			for (i=0;i<geneNum;i++) {
				L = dataMat[i][0].length;
				w = 1.0/(varAmongGene[j] + varSave[j][i]/L);
				sumW += w;
				scoreSave[0][j] += w*meanSave[j][i];
			}
			scoreSave[0][j] /= sumW;
		}

		this.treeRank = new int[3][treeNum];
		for (i=0;i<treeRank.length;i++) {
			for (j=0;j<treeRank[i].length;j++) {
				treeRank[i][j] = j;
			}
		}
		
		double[] tmpSave = new double[treeNum];
		
		for (i=0;i<treeRank.length;i++) {
			for (j=0;j<tmpSave.length;j++) {
				tmpSave[j] = scoreSave[i][j];
			}
			for (j=0;j<tmpSave.length;j++) {
				d = tmpSave[j];
				for (k=j+1;k<tmpSave.length;k++) {
					if (d<tmpSave[k]) {
						id = treeRank[i][j];
						treeRank[i][j] = treeRank[i][k];
						treeRank[i][k] = id;
						tmpSave[j] = tmpSave[k];
						tmpSave[k] = d;
						d = tmpSave[j];
					}
				}

			}
		}
		
	}
	
	public void printData() {
		
		// checking
		int i, j, k, treeNum, geneNum;
		String str;
		treeNum = dataMat[0].length;
		geneNum = dataMat.length; 
		
		boolean debug = false;
		
		if (debug) {
			for (i=0;i<geneNum;i++) {
				System.out.print(String.format("\n%dth gene", i));
				for (j=0;j<treeNum;j++) {
					System.out.print(String.format("\n    %dth tree  : ", j));
					for (k=0;k<dataMat[i][j].length;k++) {
						System.out.print(String.format("%f  ", dataMat[i][j][k]));
					}
				}
			}
	
			System.out.print(String.format("\n\nloglike_tree_gene"));
			for (j=0;j<treeNum;j++) {
				for (i=0;i<geneNum;i++) {
					str = String.format("loglike_%d_%d",j,i);
					myFunc.printArrayRstyle(dataMat[i][j], str);
				}
			}
			System.out.print(String.format("\n\n"));
		}
		

		
		// checking 

		System.out.print(String.format("scoreSave[new,sum,average][treeid]"));
		for (i=0;i<scoreSave.length;i++) {
			for (j=0;j<scoreSave[i].length;j++) {
				System.out.print(String.format("\nscoreSave[%d][%d]= %f", i,j,scoreSave[i][j]));
			}
		}

		System.out.print(String.format("\n\n"));
		
		myFunc.printArrayRstyle(scoreSave[0], "scoSave_new");
		myFunc.printArrayRstyle(scoreSave[1], "scoSave_sum");	
		myFunc.printArrayRstyle(scoreSave[2], "scoSave_ave");	
		
		System.out.print(String.format("\n\n"));
		
		System.out.print(String.format("meanSave[tree][gene]"));
		for (i=0;i<treeNum;i++) {
			for (j=0;j<geneNum;j++) {
				System.out.print(String.format("\nmeanSave[%d][%d]= %f", i,j,meanSave[i][j]));
			}
		}
		
		System.out.print(String.format("\n\n"));
		
		System.out.print(String.format("varSave[tree][gene]"));
		for (i=0;i<treeNum;i++) {
			for (j=0;j<geneNum;j++) {
				System.out.print(String.format("\nvarSave[%d][%d]= %f", i,j,varSave[i][j]));
			}
		}
		
		System.out.print(String.format("\n\n"));
		
		System.out.print(String.format("varAmongGene(new criterion)"));
		for (i=0;i<treeNum;i++) {
			System.out.print(String.format("\nvarAmongGene[tree%d]= %f", i,varAmongGene[i]));
		}
		
		System.out.print(String.format("\n\n"));
		k = this.treeRank[0][0];
		System.out.print(String.format("Optimal tree: tree%d from new criterion", k ));
		myFunc.printArrayRstyle(meanSave[k], String.format("meanSave_tree%d", k));
		myFunc.printArrayRstyle(varSave[k], String.format("varSave_tree%d", k));	
		System.out.print(String.format("\nvarAmongGene[tree%d]= %f", k,varAmongGene[k]));
		
	
		
		
		for (i=0;i<this.treeRank.length;i++) {
			if (i==0) 
				System.out.print(String.format("\nNew Criterion, tree order : "));
			else if (i==1)
				System.out.print(String.format("\nSum Criterion, tree order : "));
			else if (i==2)
				System.out.print(String.format("\nAverage Criterion, tree order : "));
			for (j=0;j<treeRank[i].length;j++) {
				System.out.print(String.format("  %d", treeRank[i][j]));
			}
		}
		
		System.out.print(String.format("\n\nmuHat..."));
		for (i=0;i<muHat.length;i++) {
			for (j=0;j<muHat[i].length;j++) {
				System.out.print(String.format("\nmuHat[%d][%d]=muHat[tree%d - tree%d]=  %f", i, j,treeRank[i][0], treeRank[i][j], muHat[i][j]));
			}
		
		}
		
		System.out.print(String.format("\n\nsigmaSqHat..."));
		for (i=0;i<sigmaSqHat.length;i++) {
			for (j=0;j<sigmaSqHat[i].length;j++) {
				System.out.print(String.format("\nsigmaSqHat[%d][%d]=sigmaSqHat[tree%d - tree%d]=  %f", i, j,treeRank[i][0], treeRank[i][j], sigmaSqHat[i][j]));
			}			
		}
		
		System.out.print(String.format("\n\nSHStat..."));
		for (i=0;i<SHStat.length;i++) {
			for (j=0;j<SHStat[i].length;j++) {
				System.out.print(String.format("\nSHStat[%d][%d]=SHStat[tree%d - tree%d]=  %f", i, j,treeRank[i][0], treeRank[i][j], SHStat[i][j]));
			}			
		}
		
		
		// check
		boolean debug2 = true;
		if (debug2) {
			System.out.print(String.format("\n\n####checking input.txt (input1.txt, input2.txt, input3.txt)"));
			
			System.out.print(String.format("\n\na <- c(sum(loglike_2_0-loglike_1_0), sum(loglike_2_1-loglike_1_1),sum(loglike_2_2-loglike_1_2))"));
			System.out.print(String.format("\nsum(a)"));
			System.out.print(String.format("\nvar(a)*length(a)"));
			

			System.out.print(String.format("\n\na <- c(mean(loglike_2_0-loglike_1_0), mean(loglike_2_1-loglike_1_1),mean(loglike_2_2-loglike_1_2))"));
			System.out.print(String.format("\nmean(a)"));
			System.out.print(String.format("\nvar(a)/length(a)"));

			System.out.print(String.format("\n\ns0 <- var(loglike_2_0-loglike_1_0)/length(loglike_2_0)"));
			System.out.print(String.format("\ns1 <- var(loglike_2_1-loglike_1_1)/length(loglike_2_1)"));
			System.out.print(String.format("\ns2 <- var(loglike_2_2-loglike_1_2)/length(loglike_2_2)"));

			
			System.out.print(String.format("\n\nsg<-var(a) - mean(c(s0,s1,s2))"));
			
			
			System.out.print(String.format("\n\nd <- c(mean(loglike_2_0-loglike_1_0)/(sg+s0), mean(loglike_2_1-loglike_1_1)/(sg+s1), mean(loglike_2_2-loglike_1_2)/(sg+s2))"));
			System.out.print(String.format("\nsum(d)"));


			System.out.print(String.format("\n\ne <- c(1.0/(sg+s0), 1.0/(sg+s1), 1.0/(sg+s2))"));
			System.out.print(String.format("\nsum(e)"));

			System.out.print(String.format("\n\nsum(d)/sqrt(sum(e))"));
			
			System.out.print(String.format("\n\n\n"));
		}

		
		
		
	}
	
	public void readData(String fileName, int id) {
		FileInputStream fis = null;
		int i, j, T,L;
		double d;
		try {
			fis = new FileInputStream(fileName);
			Scanner scanner = new Scanner(fis);

			String s = scanner.nextLine();
			String[] splitStr = s.split("\\s+");
			s = splitStr[0]; 
			T = Integer.valueOf(s); 
			dataMat[id] = new double[T][];
			s = splitStr[1];
			L = Integer.valueOf(s); 
			for (i=0;i<dataMat[id].length;i++) {
				dataMat[id][i] = new double[L];
			}
			
			for (i=0;i<T;i++) {
				s = scanner.nextLine(); // remove "# XX" line
				for (j=0;j<L;j++) {
					d = scanner.nextDouble();
					dataMat[id][i][j] = d;
				}
				s = scanner.nextLine(); // remove remaining line after last item
			}

		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
	}
	
	public void readData() {
		
		FileInputStream fis = null;
		String[] fileNameList;
		int i;
		String s;
		
		try {
			fis = new FileInputStream(OPT.oriSeqFile);
			Scanner scanner = new Scanner(fis);

			s = scanner.nextLine();
			String[] splitStr = s.split("\\s+");
			s = splitStr[0]; 
			
			i = Integer.valueOf(s); 
			
			fileNameList = new String[i];
			dataMat = new double[i][][];
			
			for (i=0;i<fileNameList.length;i++) {
				s = scanner.nextLine();
				splitStr = s.split("\\s+");
				s = splitStr[0]; 
				fileNameList[i] = s;
				readData(s,i);
			}
		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
		

		
	}


	
	
	
}








