package ESL_v02;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;


public class MyTools {
	
	int version;
	int taxaNum, seqLength;
	
	char[][][] AllAlphabetData; 
	String[][] AllTaxaNameList;
	
	public void FindFilteredPosition() {
		String fileA, fileB;
		
		fileA = new String();
		fileB = new String();
		
		/*
		fileA = "nad3.pir.txt";
		fileB = "nad3.pir-gb.txt";
		*/		

		/*		
		fileA = "big_file.txt";
		fileB = "small_file.txt";

		 * 	
		 * bif_file.txt
		 * 	4 10
			T3 AAAAAAAAAA
			T4 AAAAAAAAAA
			T1 ABCDEFGHIJ
			T2 AAAAAAAAAA
		 * 
		 * small_file.txt
		 * 	4 5
			T3 AAAAA
			T4 AAAAA
			T1 CEHIJ
			T2 AAAAA
		 * 
		 * result
		 * seqColumns <- c(rep("removed",2),rep("selected",1),rep("removed",1),rep("selected",1),rep("removed",2),rep("selected",3))

		 */
		

		fileA = "euk_data_full.txt";
		fileB = "euk_data_filtered.txt";
		
		

		
		AllAlphabetData = new char[2][][];
		AllTaxaNameList = new String[2][];
		
		LoadSeqFile(fileA, 0);
		if (this.seqLength!=AllAlphabetData[0][0].length) {
			System.err.print(String.format("\n%s's number of columns and sequence length are different", fileA));
			System.exit(0);
		}
		LoadSeqFile(fileB, 1);
		if (this.seqLength!=AllAlphabetData[1][0].length) {
			System.err.print(String.format("\n%s's number of columns and sequence length are different", fileB));
			System.exit(0);
		}
		
		if (this.AllTaxaNameList[0].length != this.AllTaxaNameList[1].length) {
			System.err.print("\nTaxa number should be same.");
			System.exit(0);
		}
		
		
		// if order is different change it.
		int i, j,k, id;
		for (i=0;i<this.AllTaxaNameList[0].length;i++) {
			if (!this.AllTaxaNameList[0][i].equals(AllTaxaNameList[1][i])) {
				System.out.print(String.format("\n%s, %s", AllTaxaNameList[0][i], AllTaxaNameList[1][i]));
				id = -1;
				for (j=i;j<AllTaxaNameList[1].length;j++) {
					if (AllTaxaNameList[0][i].equals(AllTaxaNameList[1][j])) {
						id = j;
						break;
					}
				}
				String str = new String();
				char c;
				str = AllTaxaNameList[1][i];
				AllTaxaNameList[1][i] = AllTaxaNameList[1][id];
				AllTaxaNameList[1][id] = str;
				for (j=0;j<AllAlphabetData[1][0].length;j++) {
					c = AllAlphabetData[1][i][j];
					AllAlphabetData[1][i][j] = AllAlphabetData[1][id][j];
					AllAlphabetData[1][id][j] = c;
				}
			}
		}
		
		
		//////
		// determining "selected" or "removed"
		
		boolean[] selected = new boolean[AllAlphabetData[0][0].length];
		for (i=0;i<AllAlphabetData[0][0].length;i++) {
			selected[i] = false;
		}
		
		int curr;
		
		curr = 0;
		boolean allSame;
		for (i=0;i<AllAlphabetData[0][0].length;i++) {
			allSame = true;
			for (k=0;k<AllAlphabetData[0].length;k++) {
				if (AllAlphabetData[0][k][i] != AllAlphabetData[1][k][curr]) {
					allSame = false;
					break;
				}
			}
			if (allSame) {
				selected[i] = true;
				curr++;
			}
			else {
				;
			}
			if (curr == AllAlphabetData[1][0].length)
				break;
		}
		
		if (curr != AllAlphabetData[1][0].length) {
			System.err.print(String.format("\n%s contains columns which are not in %s after %dth sites", fileB, fileA, curr));
			System.exit(0);
		}

		
		for (i=0;i<AllAlphabetData[0][0].length;i++) {
			System.out.print(String.format("\n%dth site : %b", i, selected[i]));
		}
		
		System.out.print(String.format("\nseqColumns <- c("));
		
		String currStr = new String();
		

		boolean updated;
		
		
		curr = 0;		
		if (selected[curr] == true) {
			System.out.print(String.format("rep(\"selected\","));
		}
		else 
			System.out.print(String.format("rep(\"removed\","));
		
		int identical = 1;
		int printCnt = 0;
		for (curr=1;curr<selected.length-1;curr++) {
			if (selected[curr] == selected[curr-1]) {
				identical++;
			}
			else {
				System.out.print(String.format("%d)",identical));
				printCnt++;
				if (printCnt%20==0)
					System.out.print(String.format("\n"));
				identical=1;
				if (selected[curr] == true) {
					System.out.print(String.format(",rep(\"selected\","));
				}
				else 
					System.out.print(String.format(",rep(\"removed\","));

			}
		}
		if (selected[curr] == selected[curr-1]) {
			identical++;
			System.out.print(String.format("%d))",identical));
		}
		else {
			System.out.print(String.format("%d)",identical));
			if (selected[curr] == true) {
				System.out.print(String.format(",rep(\"selected\",1))"));
			}
			else 
				System.out.print(String.format(",rep(\"removed\",1))"));
		}
		
		System.out.print(String.format("\n\n"));
		

		
		
	}
	
	
	
	public void LoadSeqFile(String filename,int id) {
		
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			Scanner scanner = new Scanner(fis);
			
			String[] splitStr;
			
			String s = scanner.nextLine();
			s = s.trim();
			while (s == null) {
				s = scanner.nextLine();
				s = s.trim();
			}
			
			splitStr = s.split("\\s+");
			taxaNum = Integer.valueOf(splitStr[0]); 
			seqLength = Integer.valueOf(splitStr[1]);
			
			AllAlphabetData[id] = new char[taxaNum][seqLength];
			AllTaxaNameList[id] = new String[taxaNum];
			

			int i;
			for (i=0; i<taxaNum; i++) {
				s = scanner.nextLine();
				s = s.trim();
				splitStr = s.split("\\s+");
				AllTaxaNameList[id][i] = splitStr[0];
				AllAlphabetData[id][i] = splitStr[1].toCharArray();
			}
			
			scanner.close();
			

			
		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
	}

}



