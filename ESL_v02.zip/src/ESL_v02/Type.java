package ESL_v02;

enum ModelType {
    JC, TN93, GTR, WAG, MTREV24, LG, JONES, DAYHOFF
}

enum JobType {
	CLUSTERING,
	ML_TREE_EST,
	SITEWISE_LOGLIKE_ANAL, 
	INDEL_SUBS_DEPENDENCY, 
	EST_BR_HESS, 
	EST_HESS_ESL, 
	EST_BR_HESS_ESL, 
	READ_INFO, 
	READ_INFO_PAML, 
	SIMUL, 
	INDEL_SUBS_TEST
}

enum FreqType {
	DATAFREQ, MODELFREQ
}
//0: EstBrHess, 1: EstHess, 2:EstPSL, 3: Simul

enum BootstrapType {
	RELLBoot, FullBoot
}

enum GapPropMultFactorType {
	NocalcGapPropMultFactor, CalcGapPropMultFactor
}

public class Type { 

}
