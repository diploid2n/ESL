package ESL_v02;

import java.io.File;
import java.io.FileInputStream;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Vector;

import java.util.Random;
import java.util.Scanner;

import java.util.ArrayList;
import java.util.Arrays;

public class TreeML extends Tree implements Analysis {

	double[] brParamHess, brParamHessOri, JMatrix;
	double alphaHess;
	double[][] simulGappyFisherInfoInvCov;
	
	double[] rateParam;
	
	double[] oriFisherInfo ; 
	double[][] simulFisherInfo;  //[0] complete, [1] gappy
	
	double[] sitewiseLike; // temporal space for calculating derivative of br
	double[][] sitewiseTemp;  // temporal space for calculating derivative of br
	
	boolean mlFineTuning; 
	double mlFineTuningMultFactor;
	
	DerivativeData MyDerivative;
	
	String nameTag;
	
	//boolean[] valid; //moved to Tree.java
	
	int bootedBetaAlreadyPrinted;
	boolean bootedRhoAlreadyPrinted;
	
	int NNI_sub_R; 
	int NNI_success;
	int NNI_success_max;
	double maxScore;
	String maxPhylogeny, maxPhylogenyPrev, maxTopo, maxTopoPrev;
	double NNITemp;
	double[] brParamBackupMax;
	int RelocateTipDone; 
	boolean topologyUpdated;
	boolean topologyUpdatedDuringNNI;
	Node maxPhylogenyStartNode;
	String NJTree;
	String[] prunnedTaxa;
	char[][] prunnedAlphabet;
	String[] candidatePhylogeny;
	String[] candidateTopology;
	String TRUEML;
	int pruneRelocateCnt, pruneRelocateCnt2;
	
	
	public void deleteIdenticalSequencesFromTree() {
		int i,k;
		Node pNode;
		for (i=0;i<taxaNameListIdenticalB.length;i++) {
			pNode = this.findNode(taxaNameListIdenticalB[i]);
			myFunc.print(String.format("\n%s removed",taxaNameListIdenticalB[i]));
			pNode = pNode.desNd.isoNd.desNd;
			this.deleteBr(pNode, true);
		}
		
		char[][] dataTmp = new char[alphabetData.length][alphabetData[0].length];
		String[] NamesTmp = new String[alphabetData.length];
		for (i=0;i<alphabetData.length;i++) {
			NamesTmp[i] = this.taxaNameList[i];
			for (k=0;k<alphabetData[0].length;k++) {
				dataTmp[i][k] = alphabetData[i][k];
			}
		}
		
		this.alphabetData = new char[dataTmp.length - taxaNameListIdenticalB.length][dataTmp[0].length];
		this.taxaNameList = new String[dataTmp.length - taxaNameListIdenticalB.length];

		// copy only first 'dataTmp.length - taxaNameListIdenticalB.length' items
		for (i=0;i<alphabetData.length;i++) {
			taxaNameList[i] = NamesTmp[i];
			for (k=0;k<alphabetData[0].length;k++) {
				alphabetData[i][k] = dataTmp[i][k];
			}
		}	
		
		this.taxaNum = this.alphabetData.length;
		
		this.InitML();
		
		
	}
	
	public void insertIdenticalSequencesToTree() {
		int i, k;
		Node pNode, pNode2;
		String[] topo;
		topo = new String[4];
		
		for (i=0;i<taxaNameListIdenticalB.length;i++) {
			pNode = this.findNode(taxaNameListIdenticalA[i]);
			pNode = pNode.desNd;
			
			pNode2 = generateDoubleBr(taxaNameListIdenticalB[i]);

			this.insertBr(pNode, pNode2, true);
			myFunc.print(String.format("\n%s inserted to the neighbor of %s",taxaNameListIdenticalB[i], taxaNameListIdenticalA[i] ));
			
			//pNode2.branchLength = pNode2.desNd.branchLength = pNode.branchLength;
			//pNode.branchLength = pNode.desNd.branchLength = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
			
			this.getTree(topo);
			//myFunc.print(String.format("\nAfter insertion, topo: %s",topo[0]));
		}
		
		char[][] dataTmp = new char[alphabetData.length + taxaNameListIdenticalB.length][alphabetData[0].length];
		
		for (i=0;i<alphabetData.length;i++) {
			for (k=0;k<alphabetData[0].length;k++) {
				dataTmp[i][k] = alphabetData[i][k];
			}
		}
		
		for (i=0;i<taxaNameListIdenticalB.length;i++) {
			this.taxaNameList = myFunc.addToEnd(this.taxaNameList, taxaNameListIdenticalB[i]);
			for (k=0;k<alphabetData[0].length;k++) {
				dataTmp[i+alphabetData.length][k] = this.alphabetDataIdentical[i][k];
			}
		}
		
		this.alphabetData = new char[dataTmp.length][dataTmp[0].length];
		for (i=0;i<alphabetData.length;i++) {
			for (k=0;k<alphabetData[0].length;k++) {
				alphabetData[i][k] = dataTmp[i][k];
			}
		}	
		
		this.taxaNum = this.alphabetData.length;
		
		this.InitML();
	}
	
	public void handleIdenticalSequences() {
		int i,j, k, n;
		char[][] dataTmp = new char[alphabetData.length][alphabetData[0].length];
		String[] namesA = new String[alphabetData.length];
		String[] namesB = new String[alphabetData.length];
		int identicalSeq;
		boolean identical;
		
		
		n = this.alphabetData.length;
		identicalSeq = 0;
		boolean[] iden = new boolean[n];
		iden[0] = false;
		for (i=0;i<n-1;i++) {
			for (j=i+1;j<n;j++) {
				identical = true;
				for (k=0;k<alphabetData[i].length;k++) {
					if (alphabetData[i][k] != alphabetData[j][k])
						identical = false;
				}
				if (identical && iden[i] == false && iden[j] == false) {
					namesA[identicalSeq] = this.taxaNameList[i];
					namesB[identicalSeq] = this.taxaNameList[j];
					for (k=0;k<alphabetData[i].length;k++) {
						dataTmp[identicalSeq][k] = alphabetData[j][k];
					}
					identicalSeq++;
					iden[j] = true;
					myFunc.print(String.format("\n%s is identical to %s", taxaNameList[i], taxaNameList[j]));
				}
			}
		}
		
		n = alphabetData.length - identicalSeq;

		
		char[][] dataTmp2 = new char[n][alphabetData[0].length];
		
		j = 0;
		for (i=0;i<alphabetData.length;i++) {
			if (iden[i] == false) {
				for (k=0;k<dataTmp2[j].length;k++) {
					dataTmp2[j][k] = alphabetData[i][k];
				}
				j++;
			}
		}
		
		alphabetData = new char[dataTmp2.length][dataTmp2[0].length];
		for (i=0;i<dataTmp2.length;i++) {
			for (k=0;k<dataTmp2[i].length;k++) {
				alphabetData[i][k] = dataTmp2[i][k];
			}
		}		
		String[] namesTmp = new String[alphabetData.length];
		j = 0;
		for (i=0;i<taxaNameList.length;i++) {
			if (iden[i] == false) {
				namesTmp[j] = taxaNameList[i];
				j++;
			}

		}
		taxaNameList = new String[alphabetData.length];
		j=0;
		for (i=0;i<namesTmp.length;i++) {
			taxaNameList[i] = namesTmp[i];
		}
		
		this.taxaNum = this.alphabetData.length;
		
		this.alphabetDataIdentical = new char[identicalSeq][alphabetData[0].length];
		this.taxaNameListIdenticalA = new String[identicalSeq];
		this.taxaNameListIdenticalB = new String[identicalSeq];
		for (i=0;i<identicalSeq;i++) {
			taxaNameListIdenticalA[i] = namesA[i];
			taxaNameListIdenticalB[i] = namesB[i];
			for (k=0;k<alphabetData[0].length;k++) {
				alphabetDataIdentical[i][k] = dataTmp[i][k];
			}
		}
		
		this.firstTaxon = this.taxaNameList[0];


		
	}
	
	public void estMLTopology() {
		
	}
	
	public void saveLocalBrL(Node ptr, double[] save) {
		// ptr should be internal
		save[0] = ptr.desNd.isoNd.branchLength; // left wing
		save[1] = ptr.desNd.isoNd.isoNd.branchLength; // right wing		
		save[2] = ptr.isoNd.branchLength; // right descendant
		save[3] = ptr.isoNd.isoNd.branchLength; // left descendant
		save[4] = ptr.branchLength;
	}
	public void recoverLocalBr(Node ptr, double[] save) {
		// ptr should be internal
		ptr.desNd.isoNd.branchLength = ptr.desNd.isoNd.desNd.branchLength = save[0]; // left wing
		ptr.desNd.isoNd.isoNd.branchLength = ptr.desNd.isoNd.isoNd.desNd.branchLength = save[1]; // right wing		
		ptr.isoNd.branchLength = ptr.isoNd.desNd.branchLength = save[2]; // right descendant
		ptr.isoNd.isoNd.branchLength = ptr.isoNd.isoNd.desNd.branchLength = save[3]; // left descendant
		ptr.branchLength = ptr.desNd.branchLength = save[4];
	}
	public void NNI_logcalRearrangement(Node ptr, int idx) {
		Node pNode, pNode2;
		if (idx == 0) { // group left wing and right descendant
			pNode = ptr.isoNd.isoNd;
			pNode2 = ptr.isoNd;
			ptr.isoNd = ptr.desNd.isoNd.isoNd;
			ptr.isoNd.isoNd = pNode;
			
			ptr.desNd.isoNd.isoNd = pNode2;
			ptr.desNd.isoNd.isoNd.isoNd = ptr.desNd;
			
			ptr.recalNeeded = ptr.desNd.recalNeeded = true;
			ptr.desNd.isoNd.recalNeeded = true;
			ptr.desNd.isoNd.isoNd.recalNeeded = true;
			ptr.isoNd.recalNeeded = true;
			ptr.isoNd.isoNd.recalNeeded = true;
			
		}
		if (idx == 1) { // group left wing and left descendant
			// swap left descent and right descent
			pNode = ptr.isoNd.isoNd;
			pNode2 = ptr.isoNd;
			ptr.isoNd = pNode;
			ptr.isoNd.isoNd = pNode2;
			ptr.isoNd.isoNd.isoNd = ptr;
			
			NNI_logcalRearrangement(ptr, 0);
			
			// swap left descent and right descent
			pNode = ptr.isoNd.isoNd;
			pNode2 = ptr.isoNd;
			ptr.isoNd = pNode;
			ptr.isoNd.isoNd = pNode2;
			ptr.isoNd.isoNd.isoNd = ptr;
			
			ptr.recalNeeded = ptr.desNd.recalNeeded = true;
			ptr.desNd.isoNd.recalNeeded = true;
			ptr.desNd.isoNd.isoNd.recalNeeded = true;
			ptr.isoNd.recalNeeded = true;
			ptr.isoNd.isoNd.recalNeeded = true;
			
		}
	}
	
	public void saveMLPhylogeny() {
		String[] topo;
		topo = new String[4];
		maxScore = this.logLike;
		Node oriStart, pNode;
		oriStart = this.startNode;
		pNode = this.findNode(this.firstTaxon);
		this.startNode = pNode.desNd;
		
		//adjustLeftRightWing(); this should not run within saveMLPhylogeny()
		
		this.getTree(topo);

		if (maxTopo.equals(topo[3])) {
			this.topologyUpdated = false;
		}
		else {
			this.topologyUpdated = true;
			topologyUpdatedDuringNNI = true;			
			maxTopoPrev = maxTopo;
			maxTopo = topo[3];
			if (maxPhylogeny == null) // initial running
				maxPhylogenyPrev = topo[0];
			else
				maxPhylogenyPrev = maxPhylogeny;
			
			//this.candidatePhylogeny = myFunc.addToEnd(this.candidatePhylogeny, topo[0]);
			//this.candidateTopology = myFunc.addToEnd(this.candidateTopology, topo[3]);
			
		}
		
		maxPhylogeny = topo[0];
		

		
		this.startNode = oriStart;
		
		//System.out.print("");
	}
	
	public void recoverMLPhylogeny(String phylogeny) {

		this.buildTree(phylogeny);
		this.backupBrParam(this.brParam);
		this.InitML();
		this.setRecalNeeded();
		this.calcLogLike();
		
		//System.out.print("");
		
		System.gc();
	}
	
	
	public void NNI(long time_start, boolean print2screen) {
	}
	

	public void NNI_sub_shuffle() {
	}
	

	
	
	public void NNI_sub(long time_start, boolean print2screen) {
		
	}
	
	public void subtreeShuffle() {
		// this functions incorrectly
		// subtreeExchange(..) may be okay.
		
		int i;
		String[] topo;
		topo = new String[4];
		
		Node ndA, ndB;
		for (i=0;i<brPos.length/2;i++) {
			ndA = brPos[i];
			ndB = brPos[brPos.length/2+i];
			if (!(ndA.isoNd == ndB || ndA.isoNd.isoNd == ndB)) {
				subtreeExchange(ndA,ndB );
				this.getTree(topo);
				myFunc.print(String.format("\n\n after subtreeExchange(..)"));
				myFunc.print(String.format("\n topo:%s",topo[0]));	
			}
		}
	}
	
	public void subtreeExchange(Node ptr, Node ptr2) {
		Node ptrPrev, ptrNext, ptr2Prev, ptr2Next;
		
		ptrPrev = ptr.isoNd.isoNd;
		ptrNext = ptr.isoNd;
		ptr2Prev = ptr2.isoNd.isoNd;
		ptr2Next = ptr2.isoNd;	

		ptrPrev.isoNd = ptr2;
		ptrPrev.isoNd.isoNd = ptrNext;
		ptr2Prev.isoNd = ptr;
		ptr2Prev.isoNd.isoNd = ptr2Next;		
		
	}
	
	public void MLNJ(long time_start) {
		//ML reconstruction similar to NJ
		//that is, start from start topology
		//loglike calculation unstable
		//being under development...
		Node[] ndSave = new Node[this.taxaNameList.length];
		
		int i;
		brPos = null;
		brParam = null;
		
		for (i=0;i<ndSave.length;i++) {
			ndSave[i] = this.generateBr(taxaNameList[i]);
			brPos = myFunc.addToEnd(brPos, ndSave[i]);
			brParam = myFunc.addToEnd(brParam, ndSave[i].branchLength);			
			if (i>0) 
				ndSave[i-1].isoNd = ndSave[i];
		}
		ndSave[ndSave.length-1].isoNd = ndSave[0];
		
		this.startNode = ndSave[0];
		
		this.InitML();
		this.setRecalNeeded();
		this.calcLogLike();
		myFunc.print(String.format("loglike=%f", this.logLike));
		
		this.optimizeSub_pruning(true);
		
		System.exit(0);
		
	}
	
	public void randomAddtion(long time_start) {
		
		int[] idx = new int[taxaNameList.length];
		myFunc.permute(idx.length, idx);
		
		this.startNode = this.generateBr(this.taxaNameList[idx[0]]);
		startNode.isoNd = generateBr(taxaNameList[idx[1]]);
		startNode.isoNd.isoNd =  generateBr(taxaNameList[idx[2]]);		
		startNode.isoNd.isoNd.isoNd = startNode;
	
		brPos = null;
		brParam = null;
		
		brPos = myFunc.addToEnd(brPos, startNode);
		brPos = myFunc.addToEnd(brPos, startNode.isoNd);
		brPos = myFunc.addToEnd(brPos, startNode.isoNd.isoNd);
		
		brParam = myFunc.addToEnd(brParam, startNode.branchLength);
		brParam = myFunc.addToEnd(brParam, startNode.isoNd.branchLength);
		brParam = myFunc.addToEnd(brParam, startNode.isoNd.isoNd.branchLength);
		
		int i, r;
		for (i=0;i<brParam.length;i++) {
			brPos[i].branchLength = brPos[i].desNd.branchLength = brParam[i] = 0.1;
		}
		this.backupBrParam(brParam);
		
		Node pNode;
		
		for (i=3;i<this.taxaNameList.length;i++) { //for (i=3;i<4;i++) {
			
			pNode = generateDoubleBr(taxaNameList[idx[i]]);
			r = myFunc.myRand.nextInt(brPos.length);
			this.insertBr(brPos[r], pNode, true);	
			
			// to prevent -infinity log-likelihood initial distance should be set 0.1 instead of myFunc.BRANCH_LENGTH_LOWER_LIMIT 
			pNode.branchLength = pNode.desNd.branchLength = 0.1;
			pNode.desNd.isoNd.isoNd.branchLength = pNode.desNd.isoNd.isoNd.desNd.branchLength = 0.1;
			this.backupBrParam(brParam);
		}
		
		this.InitML(); 
		this.setRecalNeeded();
		this.calcLogLike();
	
		String[] topo;
		topo = new String[4];
		
		this.getTree(topo);
		myFunc.print(String.format("\n\nAfter random addtion"));
		myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
		
		
	}
	
	public boolean checkExistenceSub(String topoStr, Node ptr) {
		boolean found = false;
		ptr.getTreeTopo();
		
		if (ptr.desNd.isoNd != null) {
			found = checkExistenceSub(topoStr, ptr.desNd.isoNd);
			if (found) 
				return true;
			found = checkExistenceSub(topoStr, ptr.desNd.isoNd.isoNd);
			if (found) 
				return true;
		}
		else {
			if (topoStr.equals(ptr.desNd.taxonName))
				return true;
		}
		

		if (ptr.treeTopo.equals(topoStr)) {
			return true;
		}
		else 
			return false;
	}
	
	public boolean checkExistence(String topo, Node totTree) {
		boolean found = false;
		
		found = checkExistenceSub(topo, totTree);
		if (found) 
			return true;
		
		found = checkExistenceSub(topo, totTree.isoNd);
		if (found) 
			return true;
		
		found = checkExistenceSub(topo, totTree.isoNd.isoNd);
		if (found) 
			return true;
		
		return false;
	}
	
	public Node findSmallestNonExistentSubtreeSub(Node ptr, Node copiedTreeNode) {
		Node pNode = null;
		boolean found = false;
		
		String[] topo = new String[4];
		this.getTree2(ptr, topo);
		found = checkExistence(topo[3], copiedTreeNode);
		
		String strTot, strLeftWing, strRightWing;
		ptr.getTreeTopo();
		strTot = ptr.treeTopo;
		copiedTreeNode.getTreeTopo();
		
		if (strTot.equals(copiedTreeNode.treeTopo)) {
			pNode = null;
			return pNode;
		}
		else {
			if (ptr.desNd.isoNd != null) {
				//iso part
				ptr.desNd.isoNd.getTreeTopo();
				strLeftWing = ptr.desNd.isoNd.treeTopo;
				if (copiedTreeNode.desNd.isoNd != null) {
					copiedTreeNode.desNd.isoNd.getTreeTopo();
					if (strLeftWing.equals(copiedTreeNode.desNd.isoNd.treeTopo)) {
						pNode = null;
					}
					else {
						// find shallow inconsistent subgroup
						pNode = findSmallestNonExistentSubtreeSub(ptr.desNd.isoNd, copiedTreeNode.desNd.isoNd);
						return pNode;
					}
				}
				else {
					pNode = ptr.desNd.isoNd;
					return pNode;
				}
				
				//isoiso part
				ptr.desNd.isoNd.isoNd.getTreeTopo();
				strRightWing = ptr.desNd.isoNd.isoNd.treeTopo;
				if (copiedTreeNode.desNd.isoNd != null) {
					copiedTreeNode.desNd.isoNd.isoNd.getTreeTopo();
					if (strRightWing.equals(copiedTreeNode.desNd.isoNd.isoNd.treeTopo)) {
						pNode = null;
					}
					else {
						// find shallow inconsistent subgroup
						pNode = findSmallestNonExistentSubtreeSub(ptr.desNd.isoNd.isoNd, copiedTreeNode.desNd.isoNd.isoNd);
						return pNode;
					}
				}
				else {
					pNode = ptr.desNd.isoNd;
					return pNode;
				}
			}
			else { // terminal
				ptr.getTreeTopo();
				copiedTreeNode.getTreeTopo();
				if (ptr.treeTopo.equals(copiedTreeNode.treeTopo)) {
					pNode = null;
					return pNode;
				}
				else {
					pNode = ptr;
					return pNode;
				}
			}
			return pNode;
		}

	}

	public Node findSmallestNonExistentSubtree(Node totTree) {
		Node pNode = null;
		
		pNode = findSmallestNonExistentSubtreeSub(this.startNode, totTree);
		if (pNode != null)
			return pNode;
		
		pNode = findSmallestNonExistentSubtreeSub(this.startNode.isoNd, totTree.isoNd);
		if (pNode != null)
			return pNode;		
		
		pNode = findSmallestNonExistentSubtreeSub(this.startNode.isoNd.isoNd, totTree.isoNd.isoNd);
		if (pNode != null)
			return pNode;		
		
		return pNode;
		
	}
	
	public void adjustAlphabetDataWithPrunnedTaxa() {
		
		int i, j,jj, k;
		int n = alphabetData.length;
		
		char[][] dataTmp2 = new char[n][alphabetData[0].length];
		String[] taxaNameListTmp = new String[this.taxaNameList.length];
		

		for (i=0;i<alphabetData.length;i++) {
			taxaNameListTmp[i] = this.taxaNameList[i];
			for (k=0;k<dataTmp2[i].length;k++) {
				dataTmp2[i][k] = alphabetData[i][k];
			}
		}
		n = n-this.prunnedTaxa.length;
		this.alphabetData = new char[n][alphabetData[0].length];
		this.taxaNameList = new String[n];
		this.prunnedAlphabet = new char[prunnedTaxa.length][alphabetData[0].length];
		
		j = 0;
		jj=0;
		for (i=0;i<dataTmp2.length;i++) {
			boolean prunned = false;
			int id = -1;
			for (k=0;k<this.prunnedTaxa.length;k++) {
				if (taxaNameListTmp[i].equals(prunnedTaxa[k])) {
					id = k;
					break;
				}
			}
			if (id == -1) { // not prunned
				for (k=0;k<alphabetData[0].length;k++) {
					this.alphabetData[j][k] = dataTmp2[i][k];
					System.out.print("");
				}
				this.taxaNameList[j] = taxaNameListTmp[i];
				j++;
			}
			else { // prunned
				for (k=0;k<alphabetData[0].length;k++) {
					this.prunnedAlphabet[jj][k] = dataTmp2[i][k];
				}
				jj++;
			}
		}
		
		
		this.taxaNum = this.alphabetData.length;
		
		
		
	}
	
	public void seqAddPrunnedTaxa(boolean print2screen) {
		int i, j, kk;
		Node pNode;
		String[] topo;
		topo = new String[4];
		boolean debug = false;
		
		myFunc.errPrint(String.format("\nseqAddPrunnedTaxa(..)"));
		
		this.InitML();
		this.setRecalNeeded();
		//optimizeSub_pruning(print2screen);
		optimizeSub_pruning_paramSets(print2screen);
		
		for (i=0;i<this.prunnedTaxa.length;i++) {
			myFunc.errPrint(String.format("*"));
			pNode = generateDoubleBr(this.prunnedTaxa[i]);
			int maxID = -1;
			double maxLoglk = -1.0e100;
			kk = brPos.length;
			double tmpLength[] = new double[kk];
			this.backupBrParam(tmpLength);
			if (debug) {
				this.getTree(topo);
				myFunc.print(String.format("\n\nBefore inserting %s", prunnedTaxa[i]));
				myFunc.errPrint(String.format("\n\nBefore inserting %s", prunnedTaxa[i]));
				myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
			}
			
			int[] idx = new int[brParam.length];
			int[] idx2 = new int[brParam.length];
			for (j=0;j<brParam.length;j++) {
				brParam[j] = brPos[j].branchLength;
			}
			
			idx = myFunc.doubleArraySort(brParam);
			myFunc.permute(idx2.length, idx2);
			
			for (int k=0;k<kk;k++) {
				//j = idx[k]; // brlength ascending order
				//j = idx[brPos.length-1-k]; // decending order
				//j = idx2[k]; // random order
				j = k; // normal order
				/*
				if (NNI_sub_R%2==0) {
					j = idx[k]; // brlength ascending order
				}
				else {
					j = idx2[k]; // random order
				}
				*/
				
				
				//myFunc.errPrint(String.format("."));
				this.insertBr(brPos[j], pNode, true);
				if (k==0) 
					this.InitML(); // only first round needs this. 
				this.setRecalNeeded();
				this.calcLogLike();
				
				this.optimizeSub_localBr(pNode, print2screen);
				//optimizeSub_pruning(print2screen);
				//optBranchLengthOnly(false);
				
				if (debug) {
					this.getTree(topo);
					myFunc.print(String.format("\n\nAfter inserting %s", prunnedTaxa[i]));
					myFunc.errPrint(String.format("\n\nAfter inserting %s", prunnedTaxa[i]));
					myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
				}
				else {
					myFunc.errPrint(String.format("%f, ",this.logLike));
				}
				
			
				if (maxLoglk < this.logLike) {
					maxID = j;
					maxLoglk = this.logLike;
					pNode = this.deleteBr(pNode, true);
					//break;
				}
				else 
					pNode = this.deleteBr(pNode, true);
				
				this.recoverBrParam(tmpLength);
				
				this.setRecalNeeded();
				this.calcLogLike();
			}
			if (debug) {
				this.getTree(topo);				
				myFunc.print(String.format("\n after searching postions, original state recovered checking..."));
				myFunc.errPrint(String.format("\n after searching postions, original state recovered checking..."));
				myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
				myFunc.print(String.format("\n best postion is %dth brPos[]",maxID));
			}
			
			this.insertBr(brPos[maxID], pNode, true);
			this.InitML();
			
			//optimizeSub_pruning(false);
			//this.optBranchLengthOnly(true);
			optimizeSub_pruning_paramSets(print2screen);
				
			if (debug) {
				this.getTree(topo);
				myFunc.print(String.format("\n\nAfter adding %s",prunnedTaxa[i]));		
				myFunc.print(String.format("\n%s",topo[0]));
				myFunc.print(String.format("\n  loglike=%f \n\n",this.logLike));	
			}
		}
	}
	
	
	
	///////////////////////////////////////////////
	
	public void destroySubtree(Node ptr) {
		// for debuging
		ptr.getTreeTopo();
		
		if (ptr.desNd.isoNd == null) {
			if (ptr.isoNd.desNd.isoNd == null) {
				// do not remove
			}
			else {
				; //prunnedTaxa = myFunc.addToEnd(prunnedTaxa, ptr.desNd.taxonName);
			}

		}
		else {
			destroySubtree(ptr.desNd.isoNd.isoNd);
			destroySubtree(ptr.desNd.isoNd);
			if (ptr.desNd.isoNd.isoNd.desNd.isoNd == null) { // if right wing is terminal
				prunnedTaxa = myFunc.addToEnd(prunnedTaxa, ptr.desNd.isoNd.isoNd.desNd.taxonName);
			}
			this.deleteBr(ptr, true);
		}
		

	}
	
	public void destroySubtree() {
		Node pNode, oldStart;
		
		prunnedTaxa = null;
		
		String[] topo = new String[4];
		this.getTree(topo);  
		
		// when pruningAndRelocating()/destroySubtree() is run, current tree is maxPhylogeny
		//this.buildTree(this.maxPhylogenyPrev);
		
		//this.buildTree(this.maxPhylogeny);
		this.buildTree(this.TRUEML);
		pNode = this.findNode(this.firstTaxon);
		this.startNode = pNode.desNd;
		adjustLeftRightWing();			
		oldStart = this.startNode;
		
		this.buildTree(topo[0]); // recover original tree
		pNode = this.findNode(this.firstTaxon);
		this.startNode = pNode.desNd;
		adjustLeftRightWing();
		this.backupBrParam(this.brParam);

		
		pNode = findSmallestNonExistentSubtree(oldStart);
		if (pNode == null) 
			return;
		Node prevIso = pNode.isoNd.isoNd;
		destroySubtree(pNode);
		
		// pNode is contaminated after destroySubtree(pNode)
		pNode = prevIso.isoNd;
		if (pNode.isoNd.desNd.isoNd != null) { // if ancestor of ptr is not terminal
			if (pNode.desNd.isoNd == null) { // if right wing is terminal
				prunnedTaxa = myFunc.addToEnd(prunnedTaxa, pNode.desNd.taxonName);
			}
			this.deleteBr(pNode.isoNd.desNd, true);
		}
		

		
	}
	
	public void adjustLeftRightWing(Node ptr) {
		if (ptr.desNd.isoNd != null) {
			adjustLeftRightWing(ptr.desNd.isoNd);
			adjustLeftRightWing(ptr.desNd.isoNd.isoNd);
			ptr.desNd.isoNd.getTreeTopo();
			ptr.desNd.isoNd.isoNd.getTreeTopo();
			if (ptr.desNd.isoNd.treeTopo.compareTo(ptr.desNd.isoNd.isoNd.treeTopo)<0) 
				;
			else {
				Node isoNd = ptr.desNd.isoNd;
				Node isoIsoNd = ptr.desNd.isoNd.isoNd;
				ptr.desNd.isoNd = isoIsoNd;
				ptr.desNd.isoNd.isoNd = isoNd;
				ptr.desNd.isoNd.isoNd.isoNd = ptr.desNd;
				this.setRecalNeeded(ptr.desNd);
			}
		}
		else { // terminal
			
		}
		
	}
	
	public void adjustLeftRightWing() {
		// this.startNode points to this.firstTaxon
		
		adjustLeftRightWing(startNode.isoNd);
		adjustLeftRightWing(startNode.isoNd.isoNd);	
		startNode.isoNd.getTreeTopo();
		startNode.isoNd.isoNd.getTreeTopo();
		String strA = startNode.isoNd.treeTopo;
		String strB = startNode.isoNd.isoNd.treeTopo;
		if (strA.compareTo(strB)<0) {
			;
		}
		else {
			Node isoNd = startNode.isoNd;
			Node isoIsoNd = startNode.isoNd.isoNd;
			startNode.isoNd = isoIsoNd;
			startNode.isoNd.isoNd = isoNd;
			startNode.isoNd.isoNd.isoNd = startNode;
		}
		
		/// 
		// subLikelihood[] of each Node may not be initialized when reading-in tree
		// Thus, the following may not be able to be run
		//this.setRecalNeeded();
		//this.calcLogLike();
		
	}
	
	public boolean findInconsistentTerminal(Node startA, Node ndA, Node startB, Node ndB) {
		// traverse to leftWing of ndA and leftWing of ndB
		// find inconsistent terminal taxa
		// inconsistent taxa are stored in prunnedTaxa[]
		String strA = ndA.getTreeTopo();
		String strB = ndB.getTreeTopo();
		boolean res;
		res = false;
		if (strA.equals(strB)) {
			return res; // do nothing
		}
		else {
			if (ndA.desNd.isoNd != null) {
				if (ndB.desNd.isoNd != null) {
					res = findInconsistentTerminal(startA, ndA.desNd.isoNd, startB, ndB.desNd.isoNd);
					if (res) 
						return true;
					res = findInconsistentTerminal(startA, ndA.desNd.isoNd.isoNd, startB, ndB.desNd.isoNd.isoNd);
					if (res) 
						return true;
				}
				else { // if ndB is terminal
					if (this.pruneRelocateCnt2 < this.pruneRelocateCnt) {
						pruneRelocateCnt2++;
					}
					else {
						this.prunnedTaxa = myFunc.addToEnd(this.prunnedTaxa, ndB.desNd.taxonName);
						return true;
					}
				}
			}
			else { // if ndA is terminal
				if (ndB.desNd.isoNd != null) {
					if (this.pruneRelocateCnt2 < this.pruneRelocateCnt) {
						pruneRelocateCnt2++;
					}
					else {
						this.prunnedTaxa = myFunc.addToEnd(this.prunnedTaxa, ndA.desNd.taxonName);
						return true;
					}

				}
				else { // naA and naB are both terminal
					if (this.pruneRelocateCnt2 < this.pruneRelocateCnt) {
						pruneRelocateCnt2++;
					}
					else {
						this.prunnedTaxa = myFunc.addToEnd(this.prunnedTaxa, ndA.desNd.taxonName);
						this.prunnedTaxa = myFunc.addToEnd(this.prunnedTaxa, ndB.desNd.taxonName);
						return true;
					}
				}
			}
			return false; 
		}
	}
	
	public void removeInconsistentGroup(boolean print2screen) {
		
		
	}
	
	public boolean removeInconsistentTerminal(boolean print2screen) {
		
		this.prunnedTaxa = null;
		int i;
		
		boolean res = false;
		String tNameList[] = null;
		
		Node pNode, oldStart;
		String[] topo = new String[4];
		this.getTree(topo);  
		String localOriPhylo = topo[0];
		String localOriTopo = topo[3];
		
		//this.buildTree(this.maxPhylogeny);
		this.buildTree(this.TRUEML);
		pNode = this.findNode(this.firstTaxon);
		this.startNode = pNode.desNd;
		adjustLeftRightWing();		
		this.getTree(topo);  
		oldStart = this.startNode;
		if (localOriTopo.equals(topo[3])) {
			res = false;
		}		
		
		this.buildTree(localOriPhylo); // recover original tree
		pNode = this.findNode(this.firstTaxon);
		this.startNode = pNode.desNd;
		this.getTree(topo); 
		adjustLeftRightWing();
		
		this.pruneRelocateCnt2 = 0;
		
		// do {} while loop should be modified 
		// because do {} while is done outside
		
		// if prunedTaxa is found
		// relocate it immediately
		do {
			res = findInconsistentTerminal(this.startNode, this.startNode.isoNd, oldStart, oldStart.isoNd);
			if (prunnedTaxa != null) {
				for (i=0;i<this.prunnedTaxa.length;i++) {
					tNameList = myFunc.addToEnd(tNameList, prunnedTaxa[i]);
					this.deleteTaxon(this.prunnedTaxa[i], true);
					this.deleteTaxon(oldStart.isoNd, prunnedTaxa[i], false);
					this.deleteTaxon(oldStart.isoNd.isoNd, prunnedTaxa[i], false);
				}
				//prunnedTaxa = null;
				adjustLeftRightWing(startNode.isoNd);
				adjustLeftRightWing(startNode.isoNd.isoNd);
				adjustLeftRightWing(oldStart.isoNd);
				adjustLeftRightWing(oldStart.isoNd.isoNd);
			}
			if (res) {
				return true;
			}

		} while (res == true);

		do {
			res = findInconsistentTerminal(this.startNode, this.startNode.isoNd.isoNd, oldStart, oldStart.isoNd.isoNd);
			if (prunnedTaxa != null) {
				for (i=0;i<this.prunnedTaxa.length;i++) {
					tNameList = myFunc.addToEnd(tNameList, prunnedTaxa[i]);
					this.deleteTaxon(this.prunnedTaxa[i], true);
					this.deleteTaxon(oldStart.isoNd, prunnedTaxa[i], false);
					this.deleteTaxon(oldStart.isoNd.isoNd, prunnedTaxa[i], false);
				}
				//prunnedTaxa = null;
				adjustLeftRightWing(startNode.isoNd);
				adjustLeftRightWing(startNode.isoNd.isoNd);
				adjustLeftRightWing(oldStart.isoNd);
				adjustLeftRightWing(oldStart.isoNd.isoNd);
			}
			if (res) {
				return true;
			}
		} while (res == true);
		
		/*
		prunnedTaxa = null;
		for (i=0;i<tNameList.length;i++) {
			prunnedTaxa = myFunc.addToEnd(prunnedTaxa, tNameList[i]);
		}
		*/
		
		return res;
		
	}
	
	public void pruningAndRelocating2(boolean print2screen) {

	}

	public void collapseShortBr(Node ptr) {
		Node pNode, pPrev, pNext, pDesPrev;
		if (ptr.desNd.isoNd == null) { // if terminal
			; // do nothing
		}
		else {
			pNode = ptr.desNd.isoNd;
			do {
				collapseShortBr(pNode);
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
			
			if (Math.abs(ptr.branchLength - myFunc.BRANCH_LENGTH_LOWER_LIMIT) < myFunc.EPSILON) {
			//if (ptr.branchLength < 1.0/this.seqLength) {
				pNode = ptr;
				do {
					pNode = pNode.isoNd;
				} while (pNode.isoNd != ptr);
				pPrev = pNode;
				pNext = ptr.isoNd;
				
				pNode = ptr.desNd;
				do {
					pNode = pNode.isoNd;
				} while (pNode.isoNd != ptr.desNd);
				pDesPrev = pNode;
				
				pPrev.isoNd = ptr.desNd.isoNd;
				pDesPrev.isoNd = pNext;
				
				int[] deletedID = new int[1];
				deletedID[0] = -1;

				brPos = myFunc.deleteElement(brPos, ptr, deletedID);
				brParam = myFunc.deleteElement(brParam, deletedID);	

			}
		}
	}

	public void rearrangeShortBr(Node ptr, boolean print2screen) {
		if (ptr.desNd.isoNd == null) 
			return;
		else {
			Node pNode = ptr.desNd.isoNd;
			do {
				rearrangeShortBr(pNode, print2screen);
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
			if (ptr.desNd.isoNd.isoNd.isoNd != ptr.desNd) {
				//do {
					rearrangeShortBrSub(ptr, print2screen);
				//} while (ptr.desNd.isoNd.isoNd.isoNd != ptr.desNd);		
			}
				
		}
	}
	
	public void rearrangeShortBrSub(Node ptr, boolean print2screen) {
		// ptr.desNd is multifurcating
		
		if (ptr.desNd.isoNd.isoNd.isoNd == ptr.desNd)
			return;
		
		boolean debug = false;
		
		Node oriStart = this.startNode;
		this.startNode = ptr.desNd;
		this.calcLogLike();
	
		int i,j,k;
		do {  // 		} while (k > 3);		
			k = 0;
			Node pNode;
			pNode = this.startNode;
			do {
				pNode = pNode.isoNd;
				k++;
			} while (pNode != startNode);
			
			Node ndSave[] = new Node[k]; // there are k-branches connected to ptr.desNd
			if (debug) {
				myFunc.errPrint(String.format("\n####### %d branches ###########", k));
				myFunc.print(String.format("\n####### %d branches ###########", k));	
			}
			
			//if (k==7) 
				//System.out.print("");
			
			pNode = startNode;
			i = 0;
			do {
				ndSave[i] = pNode;
				pNode = pNode.isoNd;
				i++;
			} while (pNode != startNode);
			
			Node tmpOri = ndSave[0];
			this.startNode = tmpOri;
			this.calcLogLike();
			
			if (debug) {
				myFunc.errPrint(String.format("\n%f", this.logLike));
				myFunc.print(String.format("\n%f", this.logLike));		
			}

			
			int maxId1, maxId2;
			double maxV;
			maxId1 = maxId2 = -1;
			maxV = -1.0e100;
			for (i=0;i<ndSave.length-1;i++) {
				for (j=i+1;j<ndSave.length;j++) {
					pNode = this.generateBr("");
					pNode.desNd.isoNd = ndSave[i];
					pNode.desNd.isoNd.isoNd = ndSave[j];
					pNode.desNd.isoNd.isoNd.isoNd = pNode.desNd;
					this.startNode = pNode;
					for (k=0;k<ndSave.length;k++) {
						if (k!=i && k!= j) {
							pNode.isoNd = ndSave[k];
							pNode = pNode.isoNd;
						}
					}
					pNode.isoNd = this.startNode;
					this.calcLogLike();
					if (debug) {
						myFunc.errPrint(String.format("\n(%d,%d) %f", i, j, this.logLike));
						myFunc.print(String.format("\n(%d,%d) %f", i, j, this.logLike));
					}
					//this.optBranchLength(this.startNode, print2screen);
					this.startNode.branchLength = this.startNode.desNd.branchLength = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
					if (this.logLike > maxV) {
						maxId1 = i;
						maxId2 = j;
						maxV = this.logLike;
					}
				}
			}	
			
			pNode = this.generateBr("");
			pNode.desNd.isoNd = ndSave[maxId1];
			pNode.desNd.isoNd.isoNd = ndSave[maxId2];
			pNode.desNd.isoNd.isoNd.isoNd = pNode.desNd;
			this.startNode = pNode;
			for (k=0;k<ndSave.length;k++) {
				if (k!=maxId1 && k!= maxId2) {
					pNode.isoNd = ndSave[k];
					pNode = pNode.isoNd;
				}
			}
			pNode.isoNd = this.startNode;
			//this.optBranchLength(this.startNode, print2screen);
			this.startNode.branchLength = this.startNode.desNd.branchLength = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
			
			brPos = myFunc.addToEnd(brPos, this.startNode);
			brParam = myFunc.addToEnd(brParam, this.startNode.branchLength);
			
			if (debug) {
				myFunc.errPrint(String.format("\nMerged(%d,%d); %f", maxId1, maxId2, this.logLike));
				myFunc.print(String.format("\nMerged(%d,%d); %f", maxId1, maxId2, this.logLike));
			}
			
			k--;
			
		} while (k > 3);

		//if (startNode.isoNd.isoNd.isoNd != startNode)
			//rearrangeShortBrSub(startNode.desNd, print2screen);
		
		this.startNode = oriStart;
		

	}
	
	public void mergeNodes(Node ptrA, Node ptrB) {
		
	}
	
	public void rearrangeShortBr(boolean print2screen) {
		Node pNode;
		pNode = this.startNode;
		do {
			rearrangeShortBr(pNode, print2screen);
			pNode = pNode.isoNd;
		} while (pNode != this.startNode);
	}
	
	public void collapseShortBr() {
		// 2020.08.16
		// if br length is 	myFunc.BRANCH_LENGTH_LOWER_LIMIT
		// collapse bifurcating to multifurcating
		// this seems to work, but run time error occurs in this.buildTree(str) because only bifurcating string is accepted
		
		Node pNode;
		pNode = this.findNode(this.firstTaxon);
		this.startNode = pNode.desNd;
		
		pNode = this.startNode;
		do {
			collapseShortBr(pNode);
			pNode = pNode.isoNd;
		} while (pNode != this.startNode);
		
	}
	
	
	public void pruningAndRelocating(boolean print2screen) {
		// performance is not satisfactory
			
	}
	
	public void RelocateTip(long time_start) {
		
		int i,j,k;
		long time_end, ElapsedSec;
		
		this.buildTree(maxPhylogeny);
		this.InitML();
		this.setRecalNeeded();
		this.calcLogLike();
		optimizeSub_pruning_paramSets(false);
		
		
		int[] idx = new int[brParam.length];
		for (i=0;i<brParam.length;i++) {
			brParam[i] = brPos[i].branchLength;
		}
		
		double tmpLength[] = new double[brParam.length];
		this.backupBrParam(tmpLength);
		
		String[] topo;
		topo = new String[4];
		String str, str2;
		
		Node pNode;
		
		idx = myFunc.doubleArraySort(brParam);
		
		int maxID = -1;
		double maxLoglk = -1.0e100;
		
		int doneTerminal = 0;
		
		saveMLPhylogeny();
		String oriMaxTopo = this.maxTopo;
		
		boolean printout = false;
		
		int relocSize =  brPos.length/10; // 10; // brPos.length/20; //
		if (relocSize > brPos.length)
			relocSize = brPos.length;
		
		Node[] longTipBrNode = new Node[relocSize];
		
		Node maxPos;
		
		for (k=0;k<brPos.length && doneTerminal < relocSize ;k++) {
			i = idx[brPos.length-1-k];
			if (brPos[i].desNd.isoNd == null) { 
				longTipBrNode[doneTerminal] = brPos[i];
				doneTerminal++;
			}
			else 
				; // do nothing
		}
		
		for (i=0;i<longTipBrNode.length;i++) {
			pNode = longTipBrNode[i];
			
			str = pNode.desNd.taxonName;
			myFunc.print(String.format("\n%s is relocating from the last ml value %f (%f)", str, this.logLike, this.maxScore));
			myFunc.errPrint(String.format("\n%s is relocating from the last ml value %f (%f)", str, this.logLike, this.maxScore));
			
			Node prevLeftWing; 
			//initialIsoIso: when deleting tip, 
			//prevLeftWing: when removing tip and moving to another place, previous IsoIso need to be optimized. 
			
			if (pNode.isoNd.desNd.isoNd != null) {
				maxPos = pNode.isoNd.isoNd;
				pNode = pNode.isoNd.desNd;
			}
			else {
				// exchange
				Node IS, ISIS;
				IS = pNode.isoNd;
				ISIS = pNode.isoNd.isoNd;
				pNode.isoNd = ISIS;
				pNode.isoNd.isoNd = IS;
				pNode.isoNd.isoNd.isoNd = pNode;
				
				maxPos = pNode.isoNd.isoNd;
				pNode = pNode.isoNd.desNd;
			}
			prevLeftWing = pNode.isoNd.isoNd;
			if (pNode.isoNd != null) {
				pNode = this.deleteBr(pNode, true);
				int kk;
				kk = brParam.length;
				
				for (k=0;k<kk;k++) {
					
					if (brPos[k].desNd.isoNd == null) { // connect only to tip
						str2 = brPos[k].desNd.taxonName;
						
						/*
						myFunc.errPrint(String.format("\n%s is connected to the neighbor of %s",str, str2));	
						myFunc.print(String.format("\n%s is connected to the neighbor of %s",str, str2));
						*/
						
						/*
						// for debugging
						if (str.equals("B.spAF376") && str2.equals("P.spGU415")) {
							System.out.print(" ");
							printout = true;
						}
						*/

						
						this.insertBr(brPos[k], pNode, true);

						//if (k==0) 
							//this.InitML(); // only first round needs this. 
						this.setRecalNeeded();
						this.calcLogLike();
						
						/*
						this.getTree(topo);	
						myFunc.print(String.format("\n inserting at %dth postion", j));
						myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
						*/
						
						
						//optimizeSub_pruning();
						//optimizeSub_pruning_paramSets();
						//optimizeSub_pruning_paramSets();
						
						/*
						optAllBranches(false);
						optAllBranches(false);
						*/
						
						/*
						optBranchLength(pNode,false);
						optBranchLength(pNode.desNd.isoNd,false);
						optBranchLength(pNode.desNd.isoNd.isoNd,false);
						optBranchLength(pNode,false);
						optBranchLength(pNode.desNd.isoNd,false);
						optBranchLength(pNode.desNd.isoNd.isoNd,false);
						*/
						
						this.optimizeSub_localBr(pNode, printout);
						this.optBranchLength(prevLeftWing, printout);
						
						/*
						this.getTree(topo);				
						myFunc.print(String.format("\n after inserting at %dth postion and optimization", j));
						myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
						*/
						
					
						/*
						if (maxLoglk < this.logLike) {
							maxID = k;
							maxLoglk = this.logLike;
						}
						*/
						

						
						if ( maxScore < this.logLike) {
							saveMLPhylogeny();
							maxPos = brPos[k];
							myFunc.errPrint(String.format("\n%s is connected to the neighbor of %s",str, str2));	
							myFunc.print(String.format("\n%s is connected to the neighbor of %s",str, str2));
							myFunc.errPrint(String.format(", %f (%f) ",this.logLike, maxScore));
							myFunc.print(String.format(", %f (%f) ",this.logLike, maxScore));
						}
						
						/*
						myFunc.errPrint(String.format(", %f (%f) ",this.logLike, maxScore));
						myFunc.print(String.format(", %f (%f) ",this.logLike, maxScore));
						 */
						
						prevLeftWing = pNode.desNd.isoNd;
						pNode = this.deleteBr(pNode, true);
						//this.recoverBrParam(tmpLength);
						
						/*
						this.setRecalNeeded();
						this.calcLogLike();
						*/
						
						/*
						this.getTree(topo);				
						myFunc.print(String.format("\n deleting from %dth postion",j));
						myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
						*/
						
						
					} //if (brPos[k].desNd.isoNd == null) { // connect only to tip
					else 
						; // do nothing
					
				} // end of for (k=0;k<kk;k++) {
				
				this.insertBr(maxPos, pNode, true);
				this.optimizeSub_localBr(pNode, false);
				this.optBranchLength(prevLeftWing, false);		
				
				this.optBranchLengthOnly(false);
				
				/*
				this.optAllBranches(false);
				this.optAllBranches(false);
				*/
				/*
				this.InitML();
				this.setRecalNeeded();
				this.calcLogLike();
				*/
	
					
				this.getTree(topo);
				myFunc.print(String.format("\nAfter relocating %s to %s",str, maxPos.desNd.taxonName));		
				myFunc.print(String.format("\n%s",topo[0]));
				myFunc.print(String.format("\nloglike=%f ",this.logLike));	
		
				myFunc.errPrint(String.format("\nAfter relocating %s to %s",str, maxPos.desNd.taxonName));			
				myFunc.errPrint(String.format("\nloglike=%f ",this.logLike));	

				
				if ( maxScore < this.logLike) {
					saveMLPhylogeny();
				}				
				
				
				time_end = System.currentTimeMillis();
				ElapsedSec = (time_end - time_start)/1000;
				String message = String.format("\n%02d:%02d:%02d elapsed since starting estMLTopology()", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
				System.out.print(message);
				System.err.print(message);
				if (!this.maxTopo.equals(oriMaxTopo)) {
					message = String.format("\nTopology updated");
					System.out.print(message);
					System.err.print(message);
					
					//return; 
				}
				else {
					message = String.format("\nTopology not updated");
					System.out.print(message);
					System.err.print(message);
				}
				
				message = String.format("\n", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
				System.out.print(message);
				System.err.print(message);
			}
		
		} //for (i=0;i<longTipBrNode.length;i++) {
		


		
	}
	
	

	
	public void sequentialAddtion(long time_start, boolean print2screen) {
		
		brPos = null;
		brParam = null;
		
		int[] idx = new int[taxaNameList.length];
		myFunc.permute(taxaNameList.length, idx);
		
		Node pNode;
		
		long time_end, ElapsedSec;
		
		this.startNode = this.generateBr(this.taxaNameList[idx[0]]);
		startNode.isoNd = generateBr(taxaNameList[idx[1]]);
		startNode.isoNd.isoNd =  generateBr(taxaNameList[idx[2]]);		
		startNode.isoNd.isoNd.isoNd = startNode;
	
		brPos = myFunc.addToEnd(brPos, startNode);
		brPos = myFunc.addToEnd(brPos, startNode.isoNd);
		brPos = myFunc.addToEnd(brPos, startNode.isoNd.isoNd);
		
		brParam = myFunc.addToEnd(brParam, 0.1);
		brParam = myFunc.addToEnd(brParam, 0.1);
		brParam = myFunc.addToEnd(brParam, 0.1);
		
		int i, j, k;
		for (i=0;i<brParam.length;i++) {
			brPos[i].branchLength = brPos[i].desNd.branchLength = brParam[i];
		}
		
		
		this.InitML();
		/*
		sitewiseLogLike = new double[alphabetDataPatternNum.length];
		sitewiseLogLike_deriv = new double[alphabetDataPatternNum.length];
		sitewiseLogLike_deriv2 = new double[alphabetDataPatternNum.length];
		sitewiseLike = new double[this.sitewiseLogLike_deriv.length];
		sitewiseTemp = new double[2][this.sitewiseLogLike_deriv.length];
		*/
		
		
		
		optimizeSub_pruning(print2screen);
		
		String[] topo;
		topo = new String[4];
		this.getTree(topo);
		myFunc.print(String.format("\n%s",topo[0]));
		

		
		for (k=3;k<this.taxaNameList.length;k++) { //for (i=3;i<4;i++) {
			i = idx[k];
			//if (taxaNameList[i].equals("B.veEU022"))
				//topo[0] = "";
			pNode = generateDoubleBr(taxaNameList[i]);
			int maxID = -1;
			double maxLoglk = -1.0e100;
			int kk = brPos.length;
			double tmpLength[] = new double[kk];
			this.backupBrParam(tmpLength);
			
			this.getTree(topo);
			myFunc.print(String.format("\n\nBefore inserting %s (idx[%d/%d]=%d th)", taxaNameList[i], k,taxaNameList.length, i));
			myFunc.errPrint(String.format("\n\nBefore inserting %s (idx[%d/%d]=%d th)", taxaNameList[i], k,taxaNameList.length, i));
			myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
			
			for (j=0;j<kk;j++) {
				
				this.insertBr(brPos[j], pNode, true);

				//pNode = this.deleteBr(pNode);

				
				// do something
				
				if (j==0) 
					this.InitML(); // only first round needs this. 
				this.setRecalNeeded();
				this.calcLogLike();
				
	
				/*
				this.getTree(topo);	
				myFunc.print(String.format("\n inserting at %dth postion", j));
				myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
				*/
				
				
				this.optimizeSub_localBr(pNode, print2screen);
				//optimizeSub_pruning();
				
				/*
				this.getTree(topo);				
				myFunc.print(String.format("\n after inserting at %dth postion and optimization", j));
				myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
				*/
				
			
				if (maxLoglk < this.logLike) {
					maxID = j;
					maxLoglk = this.logLike;
				}
				
				pNode = this.deleteBr(pNode, true);
				this.recoverBrParam(tmpLength);
				
				this.setRecalNeeded();
				this.calcLogLike();
				
				/*
				this.getTree(topo);				
				myFunc.print(String.format("\n deleting from %dth postion",j));
				myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
				*/
				
			}
				
			this.getTree(topo);				
			myFunc.print(String.format("\n after searching postions, original state recovered checking..."));
			myFunc.errPrint(String.format("\n after searching postions, original state recovered checking..."));

			myFunc.print(String.format("\n loglike=%f, topo:%s",this.logLike, topo[0]));
			myFunc.print(String.format("\n best postion is %dth brPos[]",maxID));
			
			this.insertBr(brPos[maxID], pNode, true);
			this.InitML();
			//optimizeSub_pruning();
			optimizeSub_pruning_paramSets(false);
				
			this.getTree(topo);
			myFunc.print(String.format("\n\nAfter adding %s",taxaNameList[i]));		
			myFunc.print(String.format("\n%s",topo[0]));
			myFunc.print(String.format("\n  loglike=%f \n\n",this.logLike));		
			
			
			time_end = System.currentTimeMillis();
			ElapsedSec = (time_end - time_start)/1000;
			String message = String.format("\n  %02d:%02d:%02d elapsed since starting estMLTopology()", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
			System.out.print(message);
			
		}
		
		
	}
	
	public Node generateNode() {
		return new Node();
	}
	
	public Node generateBr(String tname) {
		
		Node pNode;
		pNode = generateNode();
		pNode.desNd = generateNode();
		pNode.desNd.isoBig = pNode.desNd;
		pNode.desNd.desNd = pNode;
		pNode.desNd.taxonName = tname;
		pNode.desNd.isoNd = null;
		pNode.recalNeeded = true;
		pNode.desNd.recalNeeded = true;
		
		int patt_size = alphabetDataPatternNum.length;
		pNode.subLikelihood = new double[gammaCateNum*patt_size*stateDim];
		pNode.desNd.subLikelihood = new double[gammaCateNum*patt_size*stateDim];
		
		return pNode;
	}
	

	
	public void deleteTaxon(String tname, boolean updateBrPos) {
		deleteTaxon(this.startNode, tname, updateBrPos);
		deleteTaxon(this.startNode.isoNd, tname, updateBrPos);		
		deleteTaxon(this.startNode.isoNd.isoNd, tname, updateBrPos);			
	}
	
	public void deleteTaxon(Node ptr, String tname, boolean updateBrPos) {
		if (ptr.desNd.isoNd != null) {
			deleteTaxon(ptr.desNd.isoNd, tname, updateBrPos);
			deleteTaxon(ptr.desNd.isoNd.isoNd, tname, updateBrPos);
		}
		else {
			if (ptr.desNd.taxonName.equals(tname)) {
				if (ptr.isoNd.desNd.isoNd == null) {
					// if neighboring br (to be removed together) is terminal,
					// swap two br
					Node prev, next;
					prev = ptr.isoNd.isoNd;
					next = ptr.isoNd;
					prev.isoNd = next;
					prev.isoNd.isoNd = ptr;
					prev.isoNd.isoNd.isoNd = prev;
					this.deleteBr(ptr.isoNd.desNd, updateBrPos);
				}
				else {
					this.deleteBr(ptr.isoNd.desNd, updateBrPos);
				}


			}
			else 
				; // do nothing
		}
	}
	
	
	public void IndelSubsDependencyTestDatabase() {
	}
	
	public void IndelSubsDependencyTestDatabase(int db) {
		
	}
	
	public boolean IndelSubsDependencyTest_Mattbench(double[] ret, String fileName) {
		return true;
	}
	
	
	public boolean IndelSubsDependencyTest_Homstrad(double[] ret, String fileName) {
		return true;
	}
	
	public boolean IndelSubsDependencyTest_Balibase(double[] ret, String fileName) {
			return true;
		
	}
	
	
	
	public void IndelSubsDependencyTestJob() {
		
	}
	
	
	public void IndelSubsDependencyTestJobSub2(int tag) {
		
	}
	
	public void mergeMuscleResults(int iter, String winPath, int numTaxa) {
	}
	
	public void mergeClustalOmegaResults(int iter, String winPath, int numTaxa) {
	}
	
	public void mergePrankResults(int iter, String winPath, int numTaxa) {
	}
	
	public void mergeMAFFTResults(int iter, String winPath, int numTaxa) {
	}
	
	
	public void IndelSubsDependencyTestJobSub() {
	}

	public void calcIndTestStatCheck() {
		
		char[][] data = new char[5][20];
		int i,j, a, b;


		
		
		String 
		str = "AAAAAAAAAAAAAAA--";
		data[0] = str.toCharArray();
		str = "AATATATAA-TAAT---";
		data[1] = str.toCharArray();
		str = "ATTATATTTATA-TA--";
		data[2] = str.toCharArray();
		str = "TTAAATTATT-------";
		data[3] = str.toCharArray();
		str = "TAAA--------T-AAA";
		data[4] = str.toCharArray();	
		
		////////
		/*
		str = "AAAAAAAAAAAAAAA";
		data[0] = str.toCharArray();
		str = "-TAAT-AATATATAA";
		data[1] = str.toCharArray();
		str = "ATA-TAATTATATTT";
		data[2] = str.toCharArray();
		str = "T-----TTAAATTAT";
		data[3] = str.toCharArray();
		str = "---T-ATAAA-----";
		data[4] = str.toCharArray();	
	
		str = "AAAAAAAAAAAAAAA----";
		data[0] = str.toCharArray();
		str = "-TAAT-AATATATAA----";
		data[1] = str.toCharArray();
		str = "ATA-TAATTATATTT----";
		data[2] = str.toCharArray();
		str = "T-----TTAAATTAT----";
		data[3] = str.toCharArray();
		str = "---T-ATAAA-----AAAA";
		data[4] = str.toCharArray();	
		
		//////
		
		
		str = "AAAAAAAAAAAAAAA";
		data[0] = str.toCharArray();
		str = "A-TAAT-AATATATA";
		data[1] = str.toCharArray();
		str = "TATA-TAATTATATT";
		data[2] = str.toCharArray();
		str = "TT-----TTAAATTA";
		data[3] = str.toCharArray();
		str = "----T-ATAAA----";
		data[4] = str.toCharArray();	
		
		str = "AAAAAAAAAAAAAAA----";
		data[0] = str.toCharArray();
		str = "A-TAAT-AATATATA----";
		data[1] = str.toCharArray();
		str = "TATA-TAATTATATT----";
		data[2] = str.toCharArray();
		str = "TT-----TTAAATTA----";
		data[3] = str.toCharArray();
		str = "----T-ATAAA------AA";
		data[4] = str.toCharArray();	
		
		str = "AAAA----AAAAAAAAAAA";
		data[0] = str.toCharArray();
		str = "A-TA----AT-AATATATA";
		data[1] = str.toCharArray();
		str = "TATA-----TAATTATATT";
		data[2] = str.toCharArray();
		str = "TT---------TTAAATTA";
		data[3] = str.toCharArray();
		str = "------AAT-ATAAA----";
		data[4] = str.toCharArray();	
		
		str = "AAAA--AAAAAAA--AAAA";
		data[0] = str.toCharArray();
		str = "A-TA--AT-AATA--TATA";
		data[1] = str.toCharArray();
		str = "TATA---TAATTA--TATT";
		data[2] = str.toCharArray();
		str = "TT-------TTAA--ATTA";
		data[3] = str.toCharArray();
		str = "------T-ATAAAAA----";
		data[4] = str.toCharArray();	
		*/
		
		
		int tNum = data.length;

		double[] lessGappyColRatio = new double[1];
		double[] lsResutl = new double[2];
		double[] testResult = new double[1];
		double[] ret = new double[3];
		
		int k = getLessMoreGappySiteCnt(0, data);
		int[] less_gappy_idx = new int[k]; // 
		k = getLessMoreGappySiteCnt(1, data);
		int[] more_gappy_idx = new int[k]; // 
		k = getLessMoreGappySiteCnt(2, data);
		int[][] numData = new int[tNum*(tNum-1)/2][k];
		
		
		boolean isValid; 
		isValid = calcIndTestStat(testResult, lsResutl, lessGappyColRatio, less_gappy_idx, more_gappy_idx, numData, data);
		if (isValid) {
			ret[0] = testResult[0];
			ret[1] = calcIndTestStatPVal(ret[0], less_gappy_idx, more_gappy_idx, numData, data);
			ret[2] = data[0].length;
		}
		
		myFunc.print(String.format("\n*** stat=%f, p-value=%f, length=%f ",ret[0], ret[1], ret[2]));
	}
	
	public double calcIndTestStatPVal(double T,  int[] less_gappy_idx, int[] more_gappy_idx, int[][] numData, char[][] data) {
		
		//return calcIndTestStatPValBoot(T, data);
		return calcIndTestStatPValPermu(T, less_gappy_idx, more_gappy_idx, numData);
		
	}
	
	
	public boolean calcIndTestStatWithConvertedData(double[] stat, int[] less_gappy_idx, int[] more_gappy_idx, int[][] numData) {
		
		boolean debug = true;
		debug = false;
		
		int i,j,k,idx;
		idx = 0;
		double[] pDottmp, qDottmp, pDot, qDot;
		pDottmp = new double[numData.length];
		qDottmp = new double[numData.length];
		for (i=0;i<numData.length;i++) {
			int cntOne, cntZero;
			double a, b;
			cntOne=cntZero=0;
			for (k=0;k<less_gappy_idx.length;k++) {
				if (numData[i][less_gappy_idx[k]]==0)
					cntZero++;
				else if (numData[i][less_gappy_idx[k]]==1)
					cntOne++;
			}
			if (cntZero + cntOne > 0) {
				a = 1.0 * cntOne / (cntZero + cntOne);
				cntOne=cntZero=0;
				for (k=0;k<more_gappy_idx.length;k++) {
					if (numData[i][more_gappy_idx[k]]==0)
						cntZero++;
					else if (numData[i][more_gappy_idx[k]]==1)
						cntOne++;
				}
				if (cntZero + cntOne > 0) {
					b = 1.0 * cntOne / (cntZero + cntOne);
					//totSum += a - b;
					pDottmp[idx] = a;
					qDottmp[idx] = b;
					idx++;
				}
				else {
				}
			}
			else {
			}
		}
		
	
		if (idx == numData.length) {
			pDot = pDottmp;
			qDot = qDottmp;
		}
		else {
			if (idx==0) 
				return false;
			
			pDot = new double[idx];
			qDot = new double[idx];
			for (k=0;k<idx;k++) {
				pDot[k] = pDottmp[k];
				qDot[k] = qDottmp[k];
			}
		}
		
		double totSum;
		totSum = 0.0;
		for(i=0;i<pDot.length;i++) {
			totSum += qDot[i] - pDot[i];
		}
		totSum /= pDot.length;
		

		if (debug) {
			myFunc.print(String.format("\nless_gappy_idx\n"));
			for (i=0;i<less_gappy_idx.length;i++) {
				myFunc.print(String.format(" %f",less_gappy_idx[i]));
			}
			
			myFunc.print(String.format("\nmore_gappy_idx\n"));
			for (i=0;i<more_gappy_idx.length;i++) {
				myFunc.print(String.format(" %f",more_gappy_idx[i]));
			}
			
			
			myFunc.print(String.format("\n\n"));
			
			
		}


		stat[0] = totSum;
		return true;
		

	}
	
	public double calcIndTestStatPValPermu(double T,  int[] less_gappy_idx, int[] more_gappy_idx, int[][] numData) {
		
		// code check
		if (less_gappy_idx.length + more_gappy_idx.length != numData[0].length) {
			myFunc.print(String.format("\nless_gappy_idx.length + more_gappy_idx.length != numData[0].length\n"));
			System.exit(0);
		}
		
		boolean debug = true;
		debug = false;
		
		int iter, n;
		iter = 200;
		int i,k;
		
		n = numData[0].length;
		int[] permuIdx = new int[n];
		
		int[] lessIdx = new int[less_gappy_idx.length];
		int[] moreIdx = new int[more_gappy_idx.length];
		
		double[] permuStatTmp = new double[iter];
		double[] ret = new double[2];
		
		boolean isValid;
		
		int permuStatTmpIdx = 0;
		
		
		
		for (i=0;i<iter;i++) {
			myFunc.permute(n, permuIdx);
			for (k=0;k<lessIdx.length;k++)  {
				lessIdx[k] = permuIdx[k];
			}
			for (k=0;k<moreIdx.length;k++) 
				moreIdx[k] = permuIdx[lessIdx.length + k];
			
			isValid = this.calcIndTestStatWithConvertedData(ret, lessIdx, moreIdx, numData);
			if (isValid) {
				permuStatTmp[i] = ret[0];
				permuStatTmpIdx++;
			}
		}
		

		
		double[] permuStat = new double[permuStatTmpIdx];
		for (i=0;i<permuStat.length;i++) 
			permuStat[i] = permuStatTmp[i];
		
		int cnt = 0;
		for (i=0;i<permuStat.length;i++) {
			if (permuStat[i]  < T) 
				cnt++;
		}
		
		if (debug) {
			myFunc.print(String.format("\n\ntestStat=%f", T));
			myFunc.printArrayRstyle(permuStat, "permuStat");
		}
		
		return 1.0*cnt/permuStat.length;
		
	
	}
	
	
	public double calcIndTestStatPValBoot(double T, char[][] data) {
		
		int nTaxa = data.length;
		double[] lessGappyColRatio = new double[1];
		
		char[][] bootData = new char[data.length][data[0].length];
		
		int iter;
		iter = 200;
		int i;
		
		boolean debug = true;
		debug = false;
		
		double[] bootStatTmp = new double[iter];
		double[] ret = new double[2];
		double[] lsResult = new double[2];
		double[] testResult = new double[1];
		
		int k = getLessMoreGappySiteCnt(0, data);
		int[] less_gappy_idx = new int[k]; // 
		k = getLessMoreGappySiteCnt(1, data);
		int[] more_gappy_idx = new int[k]; // 
		k = getLessMoreGappySiteCnt(2, data);
		int[][] numData = new int[nTaxa*(nTaxa-1)/2][k];
		
		
		boolean isValid;
		
		int bootStatTmpIdx = 0;
		
		for (i=0;i<iter;i++) {
			myFunc.bootstrapSeqData(bootData, data);
			isValid = this.calcIndTestStat(testResult, lsResult,lessGappyColRatio, less_gappy_idx, more_gappy_idx, numData, bootData);
			if (isValid) {
				bootStatTmp[i] = testResult[0];
				bootStatTmpIdx++;
			}
		}
		
		double[] bootStat = new double[bootStatTmpIdx];
		for (i=0;i<bootStat.length;i++) 
			bootStat[i] = bootStatTmp[i];
		
		
		myFunc.calcMeanVar(ret, bootStat);
		
		int cnt = 0;
		for (i=0;i<bootStat.length;i++) {
			if (bootStat[i] - ret[0] < T) 
				cnt++;
		}
		
		if (debug) {
			myFunc.print(String.format("\n\ntestStat=%f", T));
			myFunc.printArrayRstyle(bootStat, "bootStat");
		}
		
		return 1.0*cnt/bootStat.length;
		
	
	}
	
	public int getLessMoreGappySiteCnt(int tag, char[][] data) {
		//tag ==0; less
		//tag == 1; more
		//tag == 2; size after removing meaningless from data
		
		int tNum = data.length;
		int L = data[0].length;
		

		boolean debug = false;
		//debug = true;
		
		int i, j, k, idx, gCount, oneCount;
		double sum;
		
		char[][] data_tmp = new char[data.length][data[0].length];
		int data_tmp_idx;
		
		int[] allGapCol = new int[data[0].length];
		int allGapCol_idx;
		
		int[] singleNucCol = new int[data[0].length];
		int singleNucCol_idx;
		
		data_tmp_idx = 0;
		allGapCol_idx = 0;
		singleNucCol_idx = 0;
		for (k=0;k<data[0].length;k++) {
			gCount = 0;
			for (i=0;i<data.length;i++) {
				if (data[i][k] == '-' || data[i][k] == '.' || data[i][k] == '?' )
					gCount++;
			}
			if (gCount == data.length) {
				allGapCol[allGapCol_idx++] = k;
			}
			else if (gCount == data.length - 1) {
				singleNucCol[singleNucCol_idx++] = k;
			}
			else {
				for (i=0;i<data.length;i++) {
					data_tmp[i][data_tmp_idx] = data[i][k];
				}
				data_tmp_idx++;
			}
		}
		
		if (data_tmp_idx == 0) 
			return -1;
		
		if (tag == 2) 
			return data_tmp_idx;
		
		double[] gFreq = new double[data_tmp_idx];
		for (k=0;k<data_tmp_idx;k++) {
			sum = 0.0;
			for (i=0;i<data.length;i++) {
				if (!myFunc.isMeaningful(data_tmp[i][k])) 
					sum += 1.0;
			}
			gFreq[k] = sum / data.length;
		}
		
		
		int[] idV = myFunc.doubleArraySort(gFreq);
		
		int center = idV.length/2;
		int left, right;
		
		left=center;
		while (left >= 0  && Math.abs(gFreq[idV[center]] - gFreq[idV[left]]) < myFunc.EPSILON) {
			left--;
		}
		left++;
		
		right=center;
		while (right < idV.length && Math.abs(gFreq[idV[center]] - gFreq[idV[right]]) < myFunc.EPSILON  ) {
			right++;
		}
		right--;		
		
		if (center-left<right-center)
			center = left;
		else
			center = right + 1;
	
		if (center == gFreq.length) 
			return -1;
		
		
		if (debug) {
			myFunc.print(String.format("\nOriData"));
			for (i=0;i<data.length;i++) {
				myFunc.print(String.format("\n"));
				for (j=0;j<data[0].length;j++) {
					myFunc.print(String.format("%c",data[i][j]));
				}
			}
			
			myFunc.print(String.format("\n"));
			myFunc.printArrayRstyle(allGapCol, "allGapColInOriData", allGapCol_idx);
			myFunc.printArrayRstyle(singleNucCol, "singleNucColInOriData", singleNucCol_idx);
			
			myFunc.print(String.format("\ngFreq of groupA (size=%d)\n", center));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngFreq of groupB (size=%d)\n", idV.length-center));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngid of groupA (size=%d)\n", center));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			myFunc.print(String.format("\ngid of groupB (size=%d)\n", idV.length-center));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			
			myFunc.printArrayRstyle(gFreq, "gFreq");
			myFunc.printArrayRstyle(idV, "idV");
			
			
			
			myFunc.print(String.format("\n\n"));
			
		}
		
		
		if (tag==0)
			return center;
		else
			return gFreq.length - center;
		
	}
	
	
	public boolean calcIndTestStat(double[] testResult, double[] lsResult, double[] lessGappyColRatio, int[] less_gappy_idx, int[] more_gappy_idx, int[][] numData, char[][] data) {
		
		//return calcIndTestStatSub(sdotj,numData,data);
		

		//return calcIndTestStatSub2(lsResult,lessGappyColRatio,numData,data);
		
		//return calcIndTestStatSub3(testResult, lsResult,lessGappyColRatio,numData,data);
		
		return calcIndTestStatSub4(testResult,  lessGappyColRatio, less_gappy_idx, more_gappy_idx, numData,data);
	}
	
	
	boolean calcIndTestStatSub4(double[] testResult,  double[] lessGappyColRatio, int[] less_gappy_idx, int[] more_gappy_idx, int[][] numData, char[][] data) {
		// Eq(1) of ind20210128.tex
		// Separating less-gappy and more-gappy columns is bad when there are many columns with single nucleotide
		// It is required to remove single-nucleotide columns and generate numData
		
		int tNum = data.length;
		int L = data[0].length;
		

		boolean debug = false;
		//debug = true;
		
		int i, j, k, idx, gCount, oneCount;
		double sum;
		
		char[][] data_tmp = new char[data.length][data[0].length];
		int data_tmp_idx;
		
		int[] allGapCol = new int[data[0].length];
		int allGapCol_idx;
		
		int[] singleNucCol = new int[data[0].length];
		int singleNucCol_idx;
		
		data_tmp_idx = 0;
		allGapCol_idx = 0;
		singleNucCol_idx = 0;
		for (k=0;k<data[0].length;k++) {
			gCount = 0;
			for (i=0;i<data.length;i++) {
				if (data[i][k] == '-' || data[i][k] == '.' || data[i][k] == '?' )
					gCount++;
			}
			if (gCount == data.length) {
				allGapCol[allGapCol_idx++] = k;
			}
			else if (gCount == data.length - 1) {
				singleNucCol[singleNucCol_idx++] = k;
			}
			else {
				for (i=0;i<data.length;i++) {
					data_tmp[i][data_tmp_idx] = data[i][k];
				}
				data_tmp_idx++;
			}
		}
		
		if (data_tmp_idx == 0) 
			return false;
		
		idx = 0;
		for (i=0;i<data_tmp.length-1;i++) {
			for (j=i+1;j<data_tmp.length;j++) {
				gCount = oneCount = 0;
				for (k=0;k<data_tmp_idx;k++) {
					if (myFunc.isMeaningful(data_tmp[i][k]) && myFunc.isMeaningful(data_tmp[j][k]) ) { 
						if (data_tmp[i][k] == data_tmp[j][k])
							numData[idx][k] = 0;
						else
							numData[idx][k] = 1;
						oneCount += numData[idx][k];
					}
					else {
						numData[idx][k] = -1;
						gCount++;
					}
				}
				for (k=data_tmp_idx;k<numData[0].length;k++) {
					numData[idx][k] = -1;
				}
				idx++;
			}
		}
		
		
		double[] gFreq = new double[data_tmp_idx];
		for (k=0;k<data_tmp_idx;k++) {
			sum = 0.0;
			for (i=0;i<data.length;i++) {
				if (!myFunc.isMeaningful(data_tmp[i][k])) 
					sum += 1.0;
			}
			gFreq[k] = sum / data.length;
		}
		
		
		int[] idV = myFunc.doubleArraySort(gFreq);
		
		int center = idV.length/2;
		int left, right;
		
		left=center;
		while (left >= 0  && Math.abs(gFreq[idV[center]] - gFreq[idV[left]]) < myFunc.EPSILON) {
			left--;
		}
		left++;
		
		right=center;
		while (right < idV.length && Math.abs(gFreq[idV[center]] - gFreq[idV[right]]) < myFunc.EPSILON  ) {
			right++;
		}
		right--;		
		
		if (center-left<right-center)
			center = left;
		else
			center = right + 1;
	
		if (center == gFreq.length) 
			return false;

		idx = 0;
		double[] pDottmp, qDottmp, pDot, qDot;
		pDottmp = new double[numData.length];
		qDottmp = new double[numData.length];
		for (i=0;i<numData.length;i++) {
			int cntOne, cntZero;
			double a, b;
			cntOne=cntZero=0;
			for (k=0;k<center;k++) {
				if (numData[i][idV[k]]==0)
					cntZero++;
				else if (numData[i][idV[k]]==1)
					cntOne++;
			}
			if (cntZero + cntOne > 0) {
				a = 1.0 * cntOne / (cntZero + cntOne);
				cntOne=cntZero=0;
				for (k=center;k<idV.length;k++) {
					if (numData[i][idV[k]]==0)
						cntZero++;
					else if (numData[i][idV[k]]==1)
						cntOne++;
				}
				if (cntZero + cntOne > 0) {
					b = 1.0 * cntOne / (cntZero + cntOne);
					//totSum += a - b;
					pDottmp[idx] = a;
					qDottmp[idx] = b;
					idx++;
				}
				else {
				}
			}
			else {
				
			}
		}
		
		lessGappyColRatio[0] = 1.0 * center / (idV.length);
		
		//less_gappy_idx = new int[center];
		//more_gappy_idx = new int[idV.length-center];
		int[] less_gappy_idx_tmp = new int[center];
		int[] more_gappy_idx_tmp = new int[idV.length-center];
		
		for (k=0;k<center;k++) {
			less_gappy_idx_tmp[k] = idV[k];
			less_gappy_idx[k] = idV[k];
		}
		for (k=0;k<more_gappy_idx.length;k++) {
			more_gappy_idx_tmp[k] = idV[center + k];
			more_gappy_idx[k] = idV[center + k];
		}
		
		//System.arraycopy(less_gappy_idx_tmp, 0, less_gappy_idx, 0, less_gappy_idx_tmp.length);
		//System.arraycopy(more_gappy_idx_tmp, 0, more_gappy_idx, 0, more_gappy_idx_tmp.length);
		
		//less_gappy_idx = less_gappy_idx_tmp;
		//more_gappy_idx = more_gappy_idx_tmp;
		
		if (idx == numData.length) {
			pDot = pDottmp;
			qDot = qDottmp;
		}
		else {
			pDot = new double[idx];
			qDot = new double[idx];
			for (k=0;k<idx;k++) {
				pDot[k] = pDottmp[k];
				qDot[k] = qDottmp[k];
			}
		}
		
		double totSum;
		totSum = 0.0;
		for(i=0;i<pDot.length;i++) {
			totSum += qDot[i] - pDot[i];
		}
		totSum /= pDot.length;
		
		
		
		if (debug) {
			myFunc.print(String.format("\nOriData"));
			for (i=0;i<data.length;i++) {
				myFunc.print(String.format("\n"));
				for (j=0;j<data[0].length;j++) {
					myFunc.print(String.format("%c",data[i][j]));
				}
			}
			
			myFunc.print(String.format("\n"));
			myFunc.printArrayRstyle(allGapCol, "allGapColInOriData", allGapCol_idx);
			myFunc.printArrayRstyle(singleNucCol, "singleNucColInOriData", singleNucCol_idx);
			
			myFunc.print(String.format("\nnumData Rearranged (allGapCol, singleNucCol are located in later part)"));
			for (i=0;i<numData.length;i++) {
				myFunc.print(String.format("\n"));
				for (j=0;j<numData[0].length;j++) {
					myFunc.print(String.format(" %d",numData[i][j]));
				}
			}
			myFunc.print(String.format("\ngFreq of groupA (size=%d)\n", center));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngFreq of groupB (size=%d)\n", idV.length-center));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngid of groupA (size=%d)\n", center));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			myFunc.print(String.format("\ngid of groupB (size=%d)\n", idV.length-center));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			
			myFunc.print(String.format("\nstat=%f\n",totSum));
			
			myFunc.printArrayRstyle(gFreq, "gFreq");
			myFunc.printArrayRstyle(idV, "idV");
			
			
			
			myFunc.print(String.format("\n\n"));
			
			
			
			
		}
		

		testResult[0] = totSum;
		return true;
		
		
		
		
	
	}
	
	
	
	
	boolean calcIndTestStatSub3(double[] testResult, double[] lsResult, double[] lessGappyColRatio, int[][] numData, char[][] data) {
		// Eq(1) of ind20210128.tex
		// Separating less-gappy and more-gappy columns is bad when there are many columns with single nucleotide
		// It is required to remove single-nucleotide columns and generate numData
		
		int tNum = data.length;
		int L = data[0].length;
		

		boolean debug = false;
		debug = true;
		
		int i, j, k, idx, gCount, oneCount;
		double sum;
		
		char[][] data_tmp = new char[data.length][data[0].length];
		int data_tmp_idx;
		
		int[] allGapCol = new int[data[0].length];
		int allGapCol_idx;
		
		int[] singleNucCol = new int[data[0].length];
		int singleNucCol_idx;
		
		data_tmp_idx = 0;
		allGapCol_idx = 0;
		singleNucCol_idx = 0;
		for (k=0;k<data[0].length;k++) {
			gCount = 0;
			for (i=0;i<data.length;i++) {
				if (data[i][k] == '-' || data[i][k] == '.' || data[i][k] == '?' )
					gCount++;
			}
			if (gCount == data.length) {
				allGapCol[allGapCol_idx++] = k;
			}
			else if (gCount == data.length - 1) {
				singleNucCol[singleNucCol_idx++] = k;
			}
			else {
				for (i=0;i<data.length;i++) {
					data_tmp[i][data_tmp_idx] = data[i][k];
				}
				data_tmp_idx++;
			}
		}
		
		if (data_tmp_idx == 0) 
			return false;
		
		idx = 0;
		for (i=0;i<data.length-1;i++) {
			for (j=i+1;j<data.length;j++) {
				gCount = oneCount = 0;
				for (k=0;k<data_tmp_idx;k++) {
					if (myFunc.isMeaningful(data_tmp[i][k]) && myFunc.isMeaningful(data_tmp[j][k]) ) { 
						if (data_tmp[i][k] == data_tmp[j][k])
							numData[idx][k] = 0;
						else
							numData[idx][k] = 1;
						oneCount += numData[idx][k];
					}
					else {
						numData[idx][k] = -1;
						gCount++;
					}
				}
				for (k=data_tmp_idx;k<numData[0].length;k++) {
					numData[idx][k] = -1;
				}
				idx++;
			}
		}
		
		
		double[] gFreq = new double[data_tmp_idx];
		for (k=0;k<data_tmp_idx;k++) {
			sum = 0.0;
			for (i=0;i<data.length;i++) {
				if (!myFunc.isMeaningful(data_tmp[i][k])) 
					sum += 1.0;
			}
			gFreq[k] = sum / data.length;
		}
		
		
		int[] idV = myFunc.doubleArraySort(gFreq);
		
		int center = idV.length/2;
		int left, right;
		
		left=center;
		while (left >= 0  && Math.abs(gFreq[idV[center]] - gFreq[idV[left]]) < myFunc.EPSILON) {
			left--;
		}
		left++;
		
		right=center;
		while (right < idV.length && Math.abs(gFreq[idV[center]] - gFreq[idV[right]]) < myFunc.EPSILON  ) {
			right++;
		}
		right--;		
		
		if (center-left<right-center)
			center = left;
		else
			center = right + 1;
	
		if (center == gFreq.length) 
			return false;

		idx = 0;
		double[] pDottmp, qDottmp, pDot, qDot;
		pDottmp = new double[numData.length];
		qDottmp = new double[numData.length];
		for (i=0;i<numData.length;i++) {
			int cntOne, cntZero;
			double a, b;
			cntOne=cntZero=0;
			for (k=0;k<center;k++) {
				if (numData[i][idV[k]]==0)
					cntZero++;
				else if (numData[i][idV[k]]==1)
					cntOne++;
			}
			if (cntZero + cntOne > 0) {
				a = 1.0 * cntOne / (cntZero + cntOne);
				cntOne=cntZero=0;
				for (k=center;k<idV.length;k++) {
					if (numData[i][idV[k]]==0)
						cntZero++;
					else if (numData[i][idV[k]]==1)
						cntOne++;
				}
				if (cntZero + cntOne > 0) {
					b = 1.0 * cntOne / (cntZero + cntOne);
					//totSum += a - b;
					pDottmp[idx] = a;
					qDottmp[idx] = b;
					idx++;
				}
				else {
				}
			}
			else {
				
			}
		}
		
		
		if (idx == numData.length) {
			pDot = pDottmp;
			qDot = qDottmp;
		}
		else {
			pDot = new double[idx];
			qDot = new double[idx];
			for (k=0;k<idx;k++) {
				pDot[k] = pDottmp[k];
				qDot[k] = qDottmp[k];
			}
		}
		
		//Eq(3) of ind20210128.tex
		// Eq(3) does not properly work under alternative hypothesis
		// under null hypothesis, it works (827 out of 1000 random data show S score is smaller than S's derived from ClusterOmega alignment
		// However, under alternative, only 380 cases show smaller S's. 
		// linear assumption is not good under alternative hypothesis. 
		double leastSqC, leastSqCNume, leastSqCDeno;
		leastSqC = leastSqCNume = leastSqCDeno = 0.0;
		double totSum;
		totSum = 0.0;
		for(i=0;i<pDot.length;i++) {
			totSum += qDot[i] - pDot[i];
			leastSqCDeno +=  pDot[i] *  pDot[i];
			leastSqCNume +=  pDot[i] * qDot[i];
		}
		totSum /= pDot.length;
		leastSqC = leastSqCNume/leastSqCDeno;
		
		lsResult[0] = 0.0; //sScore
		lsResult[1] = leastSqC;
		for(i=0;i<pDot.length;i++) {
			lsResult[0] += (qDot[i] - leastSqC * pDot[i]) * (qDot[i] - leastSqC * pDot[i]);
		}
		lsResult[0] /= pDot.length;
		
		
		
		lessGappyColRatio[0] = 1.0 * center / (idV.length);
		
		
		if (debug) {
			myFunc.print(String.format("\nOriData"));
			for (i=0;i<data.length;i++) {
				myFunc.print(String.format("\n"));
				for (j=0;j<data[0].length;j++) {
					myFunc.print(String.format("%c",data[i][j]));
				}
			}
			
			myFunc.print(String.format("\n"));
			myFunc.printArrayRstyle(allGapCol, "allGapColInOriData", allGapCol_idx);
			myFunc.printArrayRstyle(singleNucCol, "singleNucColInOriData", singleNucCol_idx);
			
			myFunc.print(String.format("\nnumData Rearranged (allGapCol, singleNucCol are located in later part)"));
			for (i=0;i<numData.length;i++) {
				myFunc.print(String.format("\n"));
				for (j=0;j<numData[0].length;j++) {
					myFunc.print(String.format(" %d",numData[i][j]));
				}
			}
			myFunc.print(String.format("\ngFreq of groupA (size=%d)\n", center));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngFreq of groupB (size=%d)\n", idV.length-center));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngid of groupA (size=%d)\n", center));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			myFunc.print(String.format("\ngid of groupB (size=%d)\n", idV.length-center));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			
			myFunc.print(String.format("\nstat=%f\n",totSum));
			myFunc.print(String.format("\nleastSqC=%f\n",leastSqC));
			myFunc.print(String.format("\nsScore=%f\n",lsResult[0]));
			
			myFunc.printArrayRstyle(gFreq, "gFreq");
			myFunc.printArrayRstyle(idV, "idV");
			
			
			
			myFunc.print(String.format("\n\n"));
			
			
			
			
		}
		

		testResult[0] = totSum;
		return true;
		
		
		
		
	
	}
	
	
	
	public double calcIndTestStatSub2(double[] lsResult, double[] lessGappyColRatio, int[][] numData, char[][] data) {
		// Eq(1) of ind20210128.tex
		
		int tNum = data.length;
		int L = data[0].length;
		

		boolean debug = false;
		debug = true;
		
		int i, j, k, idx, gCount, oneCount;
		double sum;
		
		
		idx = 0;
		for (i=0;i<data.length-1;i++) {
			for (j=i+1;j<data.length;j++) {
				gCount = oneCount = 0;
				for (k=0;k<L;k++) {
					if (data[i][k]!='-' && data[j][k] != '-') {
						if (data[i][k] == data[j][k])
							numData[idx][k] = 0;
						else
							numData[idx][k] = 1;
						oneCount += numData[idx][k];
					}
					else {
						numData[idx][k] = -1;
						gCount++;
					}
				}
				idx++;
			}
		}
		

		
		double[] gFreq = new double[data[0].length];
		for (k=0;k<L;k++) {
			sum = 0.0;
			for (i=0;i<data.length;i++) {
				if (data[i][k]=='-') 
					sum += 1.0;
			}
			gFreq[k] = sum / data.length;
		}
		
		
		int[] idV = myFunc.doubleArraySort(gFreq);
		
		int center = idV.length/2;
		int left, right;
		
		left=center;
		while (left >= 0  && Math.abs(gFreq[idV[center]] - gFreq[idV[left]]) < myFunc.EPSILON) {
			left--;
		}
		left++;
		
		right=center;
		while (right < idV.length && Math.abs(gFreq[idV[center]] - gFreq[idV[right]]) < myFunc.EPSILON  ) {
			right++;
		}
		right--;		
		
		if (center-left<right-center)
			center = left;
		else
			center = right + 1;
	

		idx = 0;
		double[] pDottmp, qDottmp, pDot, qDot;
		pDottmp = new double[numData.length];
		qDottmp = new double[numData.length];
		for (i=0;i<numData.length;i++) {
			int cntOne, cntZero;
			double a, b;
			cntOne=cntZero=0;
			for (k=0;k<center;k++) {
				if (numData[i][idV[k]]==0)
					cntZero++;
				else if (numData[i][idV[k]]==1)
					cntOne++;
			}
			if (cntZero + cntOne > 0) {
				a = 1.0 * cntOne / (cntZero + cntOne);
				cntOne=cntZero=0;
				for (k=center;k<idV.length;k++) {
					if (numData[i][idV[k]]==0)
						cntZero++;
					else if (numData[i][idV[k]]==1)
						cntOne++;
				}
				if (cntZero + cntOne > 0) {
					b = 1.0 * cntOne / (cntZero + cntOne);
					//totSum += a - b;
					pDottmp[idx] = a;
					qDottmp[idx] = b;
					idx++;
				}
				else {
				}
			}
			else {
				
			}
		}
		//totSum /= idx;
		
		
		if (idx == numData.length) {
			pDot = pDottmp;
			qDot = qDottmp;
		}
		else {
			pDot = new double[idx];
			qDot = new double[idx];
			for (k=0;k<idx;k++) {
				pDot[k] = pDottmp[k];
				qDot[k] = qDottmp[k];
			}
		}
		
		//Eq(3) of ind20210128.tex
		// Eq(3) does not properly work under alternative hypothesis
		// under null hypothesis, it works (827 out of 1000 random data show S score is smaller than S's derived from ClusterOmega alignment
		// However, under alternative, only 380 cases show smaller S's. 
		// linear assumption is not good under alternative hypothesis. 
		double leastSqC, leastSqCNume, leastSqCDeno;
		leastSqC = leastSqCNume = leastSqCDeno = 0.0;
		double totSum;
		totSum = 0.0;
		for(i=0;i<pDot.length;i++) {
			totSum += pDot[i] - qDot[i];
			leastSqCDeno +=  pDot[i] *  pDot[i];
			leastSqCNume +=  pDot[i] * qDot[i];
		}
		totSum /= pDot.length;
		leastSqC = leastSqCNume/leastSqCDeno;
		
		lsResult[0] = 0.0; //sScore
		lsResult[1] = leastSqC;
		for(i=0;i<pDot.length;i++) {
			lsResult[0] += (qDot[i] - leastSqC * pDot[i]) * (qDot[i] - leastSqC * pDot[i]);
		}
		lsResult[0] /= pDot.length;
		
		
		
		lessGappyColRatio[0] = 1.0 * center / (idV.length);
		
		
		if (debug) {
			for (i=0;i<data.length;i++) {
				myFunc.print(String.format("\n"));
				for (j=0;j<data[0].length;j++) {
					myFunc.print(String.format("%c",data[i][j]));
				}
			}
			for (i=0;i<numData.length;i++) {
				myFunc.print(String.format("\n"));
				for (j=0;j<numData[0].length;j++) {
					myFunc.print(String.format(" %d",numData[i][j]));
				}
			}
			myFunc.print(String.format("\ngFreq of groupA (size=%d)\n", center));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngFreq of groupB (size=%d)\n", idV.length-center));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngid of groupA (size=%d)\n", center));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			myFunc.print(String.format("\ngid of groupB (size=%d)\n", idV.length-center));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			
			myFunc.print(String.format("\nstat=%f\n",totSum));
			myFunc.print(String.format("\nleastSqC=%f\n",leastSqC));
			myFunc.print(String.format("\nsScore=%f\n",lsResult[0]));
			
			myFunc.printArrayRstyle(gFreq, "gFreq");
			myFunc.printArrayRstyle(idV, "idV");
			
			
			
			myFunc.print(String.format("\n\n"));
			
			
			
			
		}
		

		
		
		return totSum;
		
		
		
	
	}
	
	
	public double calcIndTestStatSub(double[] sdotj, double[][] numData, char[][] data) {
		// Eq(1) of ind20210117.tex
		
		int tNum = data.length;
		int L = data[0].length;
		

		boolean debug = false;
		//debug = true;
		
		int i, j, k, idx, gCount, oneCount;
		

		
		idx = 0;
		for (i=0;i<data.length-1;i++) {
			for (j=i+1;j<data.length;j++) {
				gCount = oneCount = 0;
				for (k=0;k<L;k++) {
					if (data[i][k]!='-' && data[j][k] != '-') {
						if (data[i][k] == data[j][k])
							numData[idx][k] = 0;
						else
							numData[idx][k] = 1;
						oneCount += numData[idx][k];
					}
					else {
						numData[idx][k] = -1;
						gCount++;
					}
				}
				for (k=0;k<L;k++) {
					if (numData[idx][k] < 0) {
						numData[idx][k] = 1.0*oneCount/(L-gCount);
					}
				}
				idx++;
			}
		}
		

		
		
		double sum;
		for (k=0;k<L;k++) {
			sum= 0.0;
			for (i=0;i<numData.length;i++) {
				sum += numData[i][k];
			}
			sum /= numData.length;
			sdotj[k] = sum;
		}
		
		double[] gFreq = new double[data[0].length];
		for (k=0;k<L;k++) {
			sum = 0.0;
			for (i=0;i<data.length;i++) {
				if (data[i][k]=='-') 
					sum += 1.0;
			}
			gFreq[k] = sum / data.length;
		}
		
		
		int[] idV = myFunc.doubleArraySort(gFreq);
		
		int center = idV.length/2;
		int left, right;
		
		left=center;
		while (left >= 0  && Math.abs(gFreq[idV[center]] - gFreq[idV[left]]) < myFunc.EPSILON) {
			left--;
		}
		left++;
		
		right=center;
		while (right < idV.length && Math.abs(gFreq[idV[center]] - gFreq[idV[right]]) < myFunc.EPSILON  ) {
			right++;
		}
		right--;		
		
		if (center-left<right-center)
			center = left;
		else
			center = right + 1;
		
		
		double[] groupA = new double[center];
		double[] groupB = new double[idV.length-center];
		
		for (i=0;i<center;i++) {
			groupA[i] = sdotj[idV[i]];
		}
		for (i=center;i<idV.length;i++) {
			groupB[i-center] = sdotj[idV[i]];
		}
		
		if (debug) {
			myFunc.print(String.format("\ngFreq of groupA (size=%d)\n", groupA.length));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngFreq of groupB (size=%d)\n", groupB.length));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %f",gFreq[idV[i]]));
			}
			myFunc.print(String.format("\ngid of groupA (size=%d)\n", groupA.length));
			for (i=0;i<center;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			myFunc.print(String.format("\ngid of groupB (size=%d)\n", groupB.length));
			for (i=center;i<idV.length;i++) {
				myFunc.print(String.format(" %d",idV[i]));
			}
			
			myFunc.print(String.format("\n"));
			myFunc.printArrayRstyle(groupA, "groupA");
			myFunc.printArrayRstyle(groupB, "groupB");
		}

		
		double[] ret = new double[2];
		double[] ret2 = new double[2];
		
		myFunc.calcMeanVar(ret, groupA);
		myFunc.calcMeanVar(ret2, groupB);
		
		double stat;
		//stat = (ret[0]-ret2[0])/Math.sqrt(ret[1]/groupA.length + ret2[1]/groupB.length); //this doesn't properly work. overestimation of variance and pvalue concentrated aroung 0.5
		stat = (ret[0]-ret2[0]);
		
		if (debug) {
			myFunc.print(String.format("\nstat=%f\n",stat));
			
			myFunc.printArrayRstyle(sdotj, "sdotj");
			myFunc.printArrayRstyle(gFreq, "gFreq");
			myFunc.printArrayRstyle(idV, "idV");
			myFunc.print(String.format("\n\n"));
			
			for (i=0;i<data.length;i++) {
				myFunc.print(String.format("\n"));
				for (j=0;j<data[0].length;j++) {
					myFunc.print(String.format("%c",data[i][j]));
				}
			}
		}
	
		
		return stat;
		
		
	
	}
	
	
	public void tripletIndelSubsDependencyTestJob() {

		//
		// see 2020.06.28 of ind20200706summary2Jeff.pdf 
		// testing independency of subs and indel
		// Jeff's idea vs.
		// my idea
		

		
		LoadSeqFile(oriSeqFile);
		
		int iter = alphabetData.length * (alphabetData.length-1) * (alphabetData.length-2) / 6;
		
		double[] minCellCnt = new double [iter];
		
		//Tae-Kun's suggestion
		//tripletCompositeJobSub(minCellCnt);
		
		//Jeff's suggestion
		tripletCompositeJobSub2(minCellCnt);

		
	}
	
	public void tripletCompositeJobSub2(double[] minCellCnt) {
		
		// Jeff's suggestion
		

				
		LRTComposite(minCellCnt);
		
		boolean debug = true;
		
		int i,j,k,cnt;
		double M;
		M = minCellCnt[0];
		for (i=0;i<minCellCnt.length;i++) {
			if (minCellCnt[i] > M) 
				M = minCellCnt[i];
		}
		int[] first, second, third;
		first=second=third=null;
		
		double[] ret = new double[2];
		double twiceDiff;
		
		myFunc.errPrint(String.format("\nAfter getting maximum"));
		myFunc.print(String.format("\nAfter getting maximum"));
		
		cnt = 0;		
		for (i=0;i<this.alphabetData.length;i++) {
			for (j=i+1;j<this.alphabetData.length;j++) {
				for (k=j+1;k<alphabetData.length;k++) {
					if (Math.abs(minCellCnt[cnt] - M)<myFunc.EPSILON) {
						myFunc.addToEnd(first, i);
						myFunc.addToEnd(second,j);
						myFunc.addToEnd(third, k);

						if (debug) {
							myFunc.errPrint(String.format("\n(%d,%d,%d)", i,j,k));
							myFunc.print(String.format("\n\n(%d,%d,%d)", i,j,k));
						}
						
						LRTCompositeSub(ret, minCellCnt, i,j,k, cnt); // jeff's 
						twiceDiff = 2.0*(ret[1] - ret[0]);
						
						if (debug) {
							myFunc.errPrint(String.format("  2*logLikeDiff= %f ", twiceDiff));
							myFunc.print(String.format("\n2*logLikeDiff= %f ", twiceDiff));	
						}
						
					}
					cnt++;
				}
			}
		}
		
		
		
		
	}
	
	public void tripletCompositeJobSub(double[] minCellCnt) {
		// Tae-Kun's suggestion
		
		double oriStat, resStat;
		int iter;
		oriStat = LRTComposite(minCellCnt);
		myFunc.print(String.format("\n\noriStat= %f", oriStat));
		
		iter = 200;
		double[] bootStat =null;
		
		this.backupUnsortedAlphabetData();
		
		int i, j, k, idx, L;
		L = this.alphabetData[0].length; 
		for (i=0;i<iter;i++) {
			//if (i%10==0)
			myFunc.errPrint(String.format("\n%dth iteration", i));
			myFunc.print(String.format("\n\n%dth iteration#########", i));
			for (j=0;j<L;j++) {
				idx = myRand.nextInt(L);
				for (k=0;k<this.alphabetData.length;k++) {
					alphabetData[k][j] = alphabetDataOriUnsorted[k][idx];
				}
			}
			resStat = LRTComposite(minCellCnt);
			bootStat = myFunc.addToEnd(bootStat, resStat);
			
			if (i%2==0 || i==iter-1) {
				myFunc.print(String.format("\n\n"));	
				myFunc.printArrayRstyle(bootStat, "bootStat");
				myFunc.print(String.format("\noriStat= %f", oriStat));				
				myFunc.print(String.format("\nmean(bootStat)"));
				myFunc.print(String.format("\nsqrt(var(bootStat))"));
				myFunc.print(String.format("\naaa <- bootStat - mean(bootStat)"));
				myFunc.print(String.format("\na <- sum(aaa>abs(oriStat))"));
				myFunc.print(String.format("\nb <- sum(aaa < -abs(oriStat))"));
				myFunc.print(String.format("\n(a+b)/length(aaa)\n\n"));
			}
		}
		
	}
	
	
	public void randomCopyDataXDataY20191130(char[][][] seqData) {
		
		int i, j, L1, L2, idx1, idx2;
		
		L1 = this.alphabetDataOriUnsorted[0].length/2;
		L2 = this.alphabetDataOriUnsorted[0].length - L1;
		
		for (i=0;i<seqData[0][0].length;i++) {
			//idx1 = myFunc.myRand.nextInt(L1);
			//idx2 = L1 + myFunc.myRand.nextInt(L2);
			idx1 = myRand.nextInt(L1);
			idx2 = L1 + myRand.nextInt(L2);
			for (j=0;j<seqData[0].length;j++) {
				if (myFunc.isMeaningful(alphabetDataOriUnsorted[j][idx1]) && myFunc.isMeaningful(alphabetDataOriUnsorted[j][idx2])) {
					seqData[0][j][i] = alphabetDataOriUnsorted[j][idx1];
					seqData[1][j][i] = alphabetDataOriUnsorted[j][idx2];
				}
				else if (!myFunc.isMeaningful(alphabetDataOriUnsorted[j][idx1]) && myFunc.isMeaningful(alphabetDataOriUnsorted[j][idx2])) {
					seqData[0][j][i] = alphabetDataOriUnsorted[j][idx1];
					seqData[1][j][i] = '-';
				}
				else if (myFunc.isMeaningful(alphabetDataOriUnsorted[j][idx1]) && !myFunc.isMeaningful(alphabetDataOriUnsorted[j][idx2])) {
					seqData[0][j][i] = '-';
					seqData[1][j][i] = alphabetDataOriUnsorted[j][idx2];
				}
				else if (!myFunc.isMeaningful(alphabetDataOriUnsorted[j][idx1]) && !myFunc.isMeaningful(alphabetDataOriUnsorted[j][idx2])) {
					seqData[0][j][i] = '-';
					seqData[1][j][i] = '-';
				}
				else {
					System.err.println("Something wrong...");
					System.exit(0);
				}
			}
		}
		
		//L = this.alphabetDataOriUnsorted[0].length/2;
		this.alphabetData = new char[this.alphabetDataOriUnsorted.length][this.seqLength];
		this.taxaNameList = new String[this.taxaNameListOri.length];
		
		for (i=0;i<this.alphabetData.length;i++) {
			this.taxaNameList[i] = this.taxaNameListOri[i];
		}
		
		
	}
	
	public void randomCopyDataXDataY(char[][][] destData, char[][][] sourceData) {
		
		Node terminalNd[] = new Node[this.taxaNum];
		int tNameId[] = new int[this.taxaNum];
		
		Node pNode;
		String str;
		
		boolean debug = false; // true; //false;

		int i, j, k, idx, DXsize, DYsize;
		
		DXsize = destData[0][0].length;
		DYsize = destData[1][0].length;
		
		idx = 0;
		
		pNode = this.startNode;
		do {
			pNode = pNode.isoNd.desNd;
			if (pNode.isoNd == null)  { // if terminal 
				terminalNd[idx] = pNode;
				idx++;
				pNode = pNode.desNd;
			}
		} while (pNode != this.startNode);
		
		for (i=0;i<taxaNameList.length;i++) {
			str = taxaNameList[i];
			idx = -1;
			for (j=0;j<terminalNd.length;j++) {
				if (str.equals(terminalNd[j].taxonName)) {
					idx = j;
					break;
				}
			}
			if (idx == -1) {
				System.err.print("Something wrong in randomCopyDataXDataY() ");
				System.exit(0);
			}
			tNameId[i] = idx;
		}
		
		int[][] resampledID = new int[2][];
		int L;
		if (DXsize > DYsize) 
			L = DXsize;
		else 
			L = DYsize;
		resampledID[0] = new int[L];
		resampledID[1] = new int[L];
		
		for (i=0;i<L;i++) {
			//resampledID[0][i] = myFunc.myRand.nextInt(sourceData[0][0].length);
			//resampledID[1][i] = myFunc.myRand.nextInt(sourceData[1][0].length);
			resampledID[0][i] = myRand.nextInt(sourceData[0][0].length);
			resampledID[1][i] = myRand.nextInt(sourceData[1][0].length);
		}
				
		for (k=0;k<L;k++) {	
			if (k > DXsize-1 && k > DYsize-1)
				break;
			for (i=0;i<2;i++) {
				for (j=0;j<destData[i].length;j++) {
					if (k<DXsize)
						destData[0][j][k] = sourceData[0][j][resampledID[0][k]];
					if (k<DYsize) 
						destData[1][j][k] = sourceData[1][j][resampledID[1][k]];
				}
			}
		}
		
		if (debug) {
			myFunc.printAlphabetData(taxaNameList, destData[0], "resampled Dx");
		}


		
		// fill gap
		for (j=0;j<destData[0][0].length;j++) {   // seqlength
			for (i=0;i<destData[0].length;i++) {  // taxaNum
				//myFunc.print(String.format("\nj=%d, i=%d", j,i));
				if (destData[0][i][j] == '-') {
					int[] nonGapTaxonID = new int[1];
					double[] dist = new double[1];
					myFunc.findNonGapPos(nonGapTaxonID, dist, i, j, terminalNd, tNameId, taxaNameList, destData[0]);
					
					for (k=0;k<gammaCateNum;k++) 
						BrGammaSpace[k] = dist[0] * gammaRateFactor[k];
					calTransProb(BrGammaSpace);
					
					char c = myFunc.fillGap(destData[0][nonGapTaxonID[0]][j], alphabetVec, gammaRateFreq, alphabetDataPatternNum.length, stateDim,  probMat, myFunc.myRand );
					destData[0][i][j] = c;
				}
			}
		}
		
		if (debug) {
			myFunc.printAlphabetData(taxaNameList, destData[0], "resample Dx + gap filled");
		}
	
		
		// gap pattern copy
		for (i=0;i<destData[0][0].length;i++) {   // seqlength
			for (j=0;j<destData[0].length;j++) { // taxaNum
				char c = sourceData[1][j][resampledID[1][i]];
				if (c == '-' || c == '?')
					destData[0][j][i] = '-';
			}
		}
		
		if (debug) {
			myFunc.printAlphabetData(taxaNameList, destData[0], "resampled DX + gap filled + gap pattern copied");
			myFunc.printAlphabetData(taxaNameList, destData[1], "resampled DY ");
			
		}

		
		
		
		
	}

	
	
	public void randomCopyDataXDataY() {
		
		Node terminalNd[] = new Node[this.taxaNum];
		int tNameId[] = new int[this.taxaNum];
		
		Node pNode;
		String str;
		
		boolean debug = true; // true; //false;

		int i, j, k, idx;
		
		idx = 0;
		
		pNode = this.startNode;
		do {
			pNode = pNode.isoNd.desNd;
			if (pNode.isoNd == null)  { // if terminal 
				terminalNd[idx] = pNode;
				idx++;
				pNode = pNode.desNd;
			}
		} while (pNode != this.startNode);
		
		for (i=0;i<taxaNameList.length;i++) {
			str = taxaNameList[i];
			idx = -1;
			for (j=0;j<terminalNd.length;j++) {
				if (str.equals(terminalNd[j].taxonName)) {
					idx = j;
					break;
				}
			}
			if (idx == -1) {
				System.err.print("Something wrong in randomCopyDataXDataY() ");
				System.exit(0);
			}
			tNameId[i] = idx;
		}
		
		int[][] resampledID = new int[2][];
		resampledID[0] = new int[this.seqLength];
		resampledID[1] = new int[this.seqLength];
				
		int L = this.alphabetDataOriUnsorted[0].length/2;
		for (i=0;i<resampledID[0].length;i++) {
			resampledID[0][i] = myRand.nextInt(L);
			resampledID[1][i] = myRand.nextInt(L);
		}
		
		/*
		double p = 0.5; //1.0;
		int[][] randomGapToDataX = new int[(int) (this.seqLength * p)][2];
		L = this.taxaNum-3;
		for (i=0;i<randomGapToDataX.length;i++) {
			// to begin with, randomly insert gap to only two taxa
			randomGapToDataX[i][0] = 3 + myRand.nextInt(L);
			randomGapToDataX[i][1] = 3 + myRand.nextInt(L); 
		}
		*/
		
		//L = this.alphabetDataOriUnsorted[0].length/2;
		this.alphabetData = new char[this.alphabetDataOriUnsorted.length][this.seqLength];
		this.taxaNameList = new String[this.taxaNameListOri.length];
		
		int iter;
		
		for (i=0;i<this.alphabetData.length;i++) {
			this.taxaNameList[i] = this.taxaNameListOri[i];
		}
		
		// copy DataX
		for (i=0;i<this.alphabetData[0].length;i++) {
			if (debug)
				myFunc.print(String.format(" %d", resampledID[0][i]));
			//myFunc.print(String.format(" %d", i));
			for (j=0;j<this.alphabetData.length;j++) {
				//this.alphabetData[j][i] = this.alphabetDataOriUnsorted[j][resampledID[0][i]];
				this.alphabetData[j][i] = this.alphabetDataOriUnsorted[j][i];
			}
		}
		
		alphabetDataPatternNum = new int[this.alphabetData[0].length];
		for (i=0;i<alphabetDataPatternNum.length;i++) {
			alphabetDataPatternNum[i] = 1;
		}
		
		/*
		// randomly insert gap to DataX
		for (i=0;i<randomGapToDataX.length;i++) {
			for (j=0;j<randomGapToDataX[i].length;j++) {
				this.alphabetData[randomGapToDataX[i][j]][i] = '-';
			}
		}
		*/
		
		String[] topo;
		
		if (debug) {
			myFunc.printAlphabetData(taxaNameList, alphabetData, "resampled Dx");
			
			InitML();
			this.setRecalNeeded();
			this.calcLogLike();
			
			myFunc.print(String.format("\nlogLike=%f", this.logLike));
			myFunc.print(String.format("\nAlpha estimate = %f", this.alpha));
			topo = new String[4];
			this.getTree(topo);
			myFunc.print(String.format("\n%s",topo[0]));
			myFunc.print(String.format("\n#resampled dataX, log-lk= %f, seqLength= %d", this.logLike, this.seqLength));
			
		}

		
		// fill gap
		for (j=0;j<this.alphabetData[0].length;j++) {
			for (i=0;i<this.alphabetData.length;i++) {
				//myFunc.print(String.format("\nj=%d, i=%d", j,i));
				if (this.alphabetData[i][j] == '-') {
					int[] nonGapTaxonID = new int[1];
					double[] dist = new double[1];
					myFunc.findNonGapPos(nonGapTaxonID, dist, i, j, terminalNd, tNameId, taxaNameList, alphabetData);
					
					for (k=0;k<gammaCateNum;k++) 
						BrGammaSpace[k] = dist[0] * gammaRateFactor[k];
					calTransProb(BrGammaSpace);
					
					char c = myFunc.fillGap(alphabetData[nonGapTaxonID[0]][j], alphabetVec, gammaRateFreq, alphabetDataPatternNum.length, stateDim,  probMat, myFunc.myRand );
					alphabetData[i][j] = c;
				}
			}
		}
		

		if (debug) {
			
			myFunc.printAlphabetData(taxaNameList, alphabetData, "resample Dx + gap filled");
		
			InitML();
			this.setRecalNeeded();
			this.calcLogLike();
			
			myFunc.print(String.format("\nlogLike=%f", this.logLike));
			myFunc.print(String.format("\nAlpha estimate = %f", this.alpha));
			topo = new String[4];
			this.getTree(topo);
			myFunc.print(String.format("\n%s",topo[0]));
			myFunc.print(String.format("\n#gap-filled dataX', log-lk= %f, seqLength= %d", this.logLike, this.seqLength));
		}

		
		
		// gap pattern copy
		for (i=0;i<this.alphabetData[0].length;i++) {
			for (j=0;j<this.alphabetData.length;j++) {
				char c = this.alphabetDataOriUnsorted[j][alphabetDataOriUnsorted[0].length/2 + resampledID[1][i]];
				if (c == '-' || c == '?')
				this.alphabetData[j][i] = '-';
			}
		}
		
		if (debug) {
			myFunc.printAlphabetData(taxaNameList, alphabetData, "resampled DX + gap filled + gap pattern copied");
			
			InitML();
			this.setRecalNeeded();
			this.calcLogLike();
			
			myFunc.print(String.format("\nlogLike=%f", this.logLike));
			myFunc.print(String.format("\nAlpha estimate = %f", this.alpha));
			topo = new String[4];
			this.getTree(topo);
			myFunc.print(String.format("\n%s",topo[0]));
			myFunc.print(String.format("\n#gap-filled, gap-pattern copied dataX', log-lk= %f, seqLength= %d", this.logLike, this.seqLength));
			
		}

		
		
		
		//System.exit(0);
		
		/////////////////

		
		
		
		
		
	}

	
	public void job20200611() {
		
	}
	
	public void job20200727() {
		this.version = 20210619;	
		System.out.println("Version: ESL_v02_"+this.version);
		
		
	}
	
	public void optAlpha(boolean print2screen) {
		
		String buf;
		buf = String.format("\n -alpha-");
		if (print2screen)
			System.err.print(buf);
	
		double x,NewLogLike, ori,OriLogLike, New1stD,NewVal;
	
		ori = alpha;
		
		setAlpha(ori);
		NewLogLike = OriLogLike = calcLogLike();
	
		double a,b,v,v2,h,tmp1,tmp2;
		boolean recovered;
	
		if (Math.abs(ori - myFunc.ALPHA_LOWER_LIMIT) < myFunc.EPSILON) {
			setAlpha(myFunc.ALPHA_LOWER_LIMIT + myFunc.ALPHA_LOWER_LIMIT * myFunc.DELTA_RATIO_derivative_alpha);
			a = calcLogLike();
			if (OriLogLike>a) {
				setAlpha(myFunc.ALPHA_LOWER_LIMIT);
				NewLogLike = calcLogLike();
				double p = (a - OriLogLike) / (myFunc.ALPHA_LOWER_LIMIT * myFunc.DELTA_RATIO_derivative_alpha);
				buf = String.format("%7.4f %7.4f %8.6f *", myFunc.ALPHA_LOWER_LIMIT, p, NewLogLike);
				if (print2screen)
					System.err.print(buf);
				return;
			}
		}
		
		if (Math.abs(ori - myFunc.ALPHA_UPPER_LIMIT) < 0.001) {
			setAlpha(myFunc.ALPHA_UPPER_LIMIT - myFunc.ALPHA_UPPER_LIMIT * myFunc.DELTA_RATIO_derivative_alpha);
			a = calcLogLike();
			if (OriLogLike>a) {
				setAlpha(myFunc.ALPHA_UPPER_LIMIT);
				NewLogLike = calcLogLike();
				double p = (a - OriLogLike) / (myFunc.ALPHA_UPPER_LIMIT * myFunc.DELTA_RATIO_derivative_alpha);
				buf = String.format("%7.4f %7.4f %8.6f *", myFunc.ALPHA_UPPER_LIMIT, p, NewLogLike);
				if (print2screen)
					System.err.print(buf);
				return;
			}
		}
	
	
		x = ori; // initial value
		if (x < myFunc.ALPHA_LOWER_LIMIT) x = myFunc.ALPHA_LOWER_LIMIT;
		if (x > myFunc.ALPHA_UPPER_LIMIT) x = myFunc.ALPHA_UPPER_LIMIT;	
	
		v = x * myFunc.DELTA_RATIO_derivative_alpha;
		//if (v < SmallDiff4Deriv ) v = SmallDiff4Deriv;
	
		setAlpha(x+v);
		tmp2 = calcLogLike();
	
		tmp1 = OriLogLike;
		//NewLogLike = tmp1; 
		a = (tmp2-tmp1)/v;
		NewVal = x;
		New1stD = a;
	
		buf = String.format("\n%4c %8.6f %7.4f %8.6f", ' ', x, a, OriLogLike);
		if (print2screen)
			System.err.print(buf);
	
		int cnt = 0;
		do  {
			recovered = false;
	
			v = x * myFunc.DELTA_RATIO_derivative_alpha;
			//if (v<SmallDiff4Deriv) v = SmallDiff4Deriv;
			v2 = (x+v) *  myFunc.DELTA_RATIO_derivative_alpha;
			//if (v2 < SmallDiff4Deriv) v2 = SmallDiff4Deriv;
	
			setAlpha(x+v);
			tmp1 = calcLogLike();
		
			setAlpha(x+v+v2);
			tmp2 = calcLogLike();
	
			b = (tmp2-tmp1)/v2;
			if (Math.abs(b-a) <  myFunc.EPSILON) {
				buf = String.format(" // amlost flat // OptAlphaNew(..)");
				if (print2screen)
					System.err.print(buf);
				break;
				//goto outofwhileloop;
			}
			h = - a/(b-a) * v;
	
			if (x + h < myFunc.ALPHA_LOWER_LIMIT) {
				while (x+h < myFunc.ALPHA_LOWER_LIMIT) {
					h /= 2.0;
				}
			}

			if (x + h > myFunc.ALPHA_UPPER_LIMIT) {
				while (x+h > myFunc.ALPHA_UPPER_LIMIT) {
					//cout<<endl<<"x="<<x<<" h="<<h<<" x+h="<<x+h<<" h is adjusted";
					//cerr<<endl<<"x="<<x<<" h="<<h<<" x+h="<<x+h<<" h is adjusted";
					h /= 2.0;
				}
			}

		
			
			x += h;
			v = x * myFunc.DELTA_RATIO_derivative_alpha;
			//if (v < SmallDiff4Deriv) v = SmallDiff4Deriv;
	
			setAlpha(x+v);
			tmp2 = calcLogLike();
	
			setAlpha(x);
			tmp1 = calcLogLike();
	
	
			a = (tmp2-tmp1)/v;
	
			if (tmp1 > NewLogLike) {
				NewLogLike = tmp1;
				NewVal = x;
				New1stD = a;
			}
			else { 
				/*
				// added by seo 20171016
				if (true) {
					x = NewVal;
					v = x * myFunc.DELTA_RATIO_derivative_alpha;
					setAlpha(x + v);
					tmp2 = calcLogLike();
					setAlpha(x);
					tmp1 = calcLogLike();
					a = (tmp2 - tmp1) / v;
					NewLogLike = tmp1;
					NewVal = x;
					New1stD = a;
					recovered = true;
				}
				*/
			}
			cnt++; // pTree prevent optimization to be trapped
		} while (Math.abs(a) > myFunc.SmallFirstDerivativeAlpha && cnt<myFunc.maxNewtonR); // while(fabs(a) > SmallFirstDerivativeAlpha&&cnt<10); //   //
		
		/*
		} while(Math.abs(a) > myFunc.SmallFirstDerivative 
			&& cnt<myFunc.maxNewtonR 
			&& NewLogLike - OriLogLike > (-OriLogLike)*tol) ;
			*/
		
		
	outofwhileloop:
		
		
		//if (NewLogLike > OriLogLike) {
			setAlpha(NewVal);
			NewLogLike = calcLogLike();
		//}

		
		
		buf = String.format(" | %8.6f %7.4f %8.6f, %d-r", NewVal, New1stD, NewLogLike, cnt);
		if (print2screen)
			System.err.print(buf);
	
	
		/*
		if (tmp1-NewLogLike < numeric_limits<double>::epsilon() ) {
			setAlpha(NewVal);
			tmp1 = CalcLogLike();
			sprintf(buf," | %7.4f %7.4f %8.6f",NewVal,New1stD,tmp1);
			cerr<<buf;cerr<<", "<<cnt<<"-r";
		}
		*/
	
		/*
		if (cnt==MaxNewtonR || fabs(OriLogLike-NewLogLike) <numeric_limits<double>::epsilon() ) {
			OptAlpha2(tol);
			x = this->Alpha;
		}	
		*/
	
	
		if (cnt == myFunc.maxNewtonR || Math.abs(OriLogLike - NewLogLike) < myFunc.EPSILON) { //  || NewVal > 10.0 ) {
			setAlpha(myFunc.ALPHA_LOWER_LIMIT);
			a = calcLogLike();
			if (a>NewLogLike) {
				NewLogLike = a;
				buf = String.format("\n%4c %7.4f %7c %8.6f *", ' ', myFunc.ALPHA_LOWER_LIMIT, ' ', NewLogLike);
				if (print2screen)
					System.err.print(buf);
			}
			else {
				double tmp;
				if (NewLogLike > OriLogLike) {
					if (true) {
						buf = String.format( "\n NewVal= %8.6f,  %8.6f", NewVal, NewLogLike);
						if (print2screen)
							System.err.print(buf);
					}
					setAlpha(NewVal);
					logLike = calcLogLike();
					NewLogLike = logLike;
					optAlpha2(print2screen);
					logLike = calcLogLike();
					tmp = logLike;
					if (true) {
						buf = String.format("\n  after OptAlpha2(..)= %8.6f,  %8.6f", alpha, tmp);
						if (print2screen)
							System.err.print(buf);
					}
					if (tmp < NewLogLike) {
						setAlpha(NewVal);
						logLike = calcLogLike();
						buf = String.format(" recovered to NewVal (%f,%f)", NewVal, logLike);
						if (print2screen)
							System.err.print(buf);
						
					}
				}
				else {
					if (true) {
						buf = String.format("\n ori= %8.6f,  %8.6f", ori, OriLogLike);
						if (print2screen)
							System.err.print(buf);
					}
					setAlpha(ori);
					logLike = calcLogLike();
					OriLogLike = logLike;
					if (true) {
						buf = String.format("\n ori= %8.6f,  %8.6f", ori, OriLogLike);
						if (print2screen)
							System.err.print(buf);
						//cerr << endl << "ori=" << ori << ", OriLogLike=" << OriLogLike;
					}
					optAlpha2(print2screen);
					logLike = calcLogLike();
					tmp = logLike;
					if (true) {
						buf = String.format("\n after OptAlpha2(..)= %8.6f,  %8.6f", alpha, tmp);
						if (print2screen)
							System.err.print(buf);
						//cerr << endl << "ori=" << ori << ", OriLogLike=" << OriLogLike;
					}
					if (tmp < OriLogLike) {
						setAlpha(ori);
						logLike = calcLogLike();
						buf = String.format("\n recovered to ori (%f,%f)",  ori, logLike);
						if (print2screen)
							System.err.print(buf);
					}
				}
			}
		}
	
	
	
	}
	


	public void optAlpha2(boolean print2screen) {
			
		double Ori;
		Ori = alpha;
		setAlpha(Ori);
		double OriLogLike = calcLogLike();
		double left, right, center;
		double h;
		double a;
		double tmp1,tmp2;
	
		center = Ori;
		left = Ori;
		if (left < myFunc.ALPHA_LOWER_LIMIT) left = myFunc.ALPHA_LOWER_LIMIT;
		h = left * myFunc.DELTA_RATIO_derivative_alpha;
		//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
		setAlpha(left+h);
		tmp2 = calcLogLike();
	
		setAlpha(left);
		tmp1 = calcLogLike();
	
		a = (tmp2-tmp1)/h;
	
		if (a<0.0) {
			right = Ori;
			left = Ori;
			
			do {
				//left = left * 0.9;
				left = left * 0.8;
				h = left * myFunc.DELTA_RATIO_derivative_alpha;
				//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
				setAlpha(left+h);
				tmp2 = calcLogLike();
		
				setAlpha(left);
				tmp1 = calcLogLike();
		
				a = (tmp2-tmp1)/h;
			} while(a<0.0 && left > myFunc.ALPHA_LOWER_LIMIT);
			if (left  < myFunc.ALPHA_LOWER_LIMIT) left = myFunc.ALPHA_LOWER_LIMIT;
		}
		else {
			left = Ori;
			right = Ori;
			do {
				//right = right * 1.1;
				right = right * 1.2;
				h = right * myFunc.DELTA_RATIO_derivative_alpha;
				
				if (right + h > myFunc.ALPHA_UPPER_LIMIT) {
					right = myFunc.ALPHA_UPPER_LIMIT; // - myFunc.ALPHA_UPPER_LIMIT * myFunc.DELTA_RATIO_derivative_alpha;
					h = myFunc.ALPHA_UPPER_LIMIT * myFunc.DELTA_RATIO_derivative_alpha;
				}

				
				setAlpha(right+h);
				tmp2 =calcLogLike();
		
				setAlpha(right);
				tmp1 = calcLogLike();
		
				a = (tmp2-tmp1)/h;
			} while(a>0.0 && Math.abs(right - myFunc.ALPHA_UPPER_LIMIT) < myFunc.EPSILON) ; 
		}
		
	
		do {
			center = (left+right)*0.5;
			h = center * myFunc.DELTA_RATIO_derivative_alpha;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
			setAlpha(center+h);
			tmp2 = calcLogLike();
	
			setAlpha(center);
			tmp1 = calcLogLike();
	
			a = (tmp2-tmp1)/h;
	
			if (a<0.0) right = center;
			else left = center;
		}while(Math.abs(a) > myFunc.SmallFirstDerivativeAlpha && right-left >1.0e-6);
	
		String buf;
		buf = String.format("\n%5c  %8.6f %7.4f %8.6f",'*',center,a,tmp1);
		if (print2screen)
			System.err.print(buf);
	
		if (tmp1 < OriLogLike) {
			if (print2screen)
				System.err.print("   (recovered)");
			setAlpha(Ori);
			tmp1 = calcLogLike();
			if (true) {
				buf = String.format(" Ori= %8.6f,  %8.6f", Ori, tmp1);
				if (print2screen)
					System.err.print(buf);
			}
		}
		//cout<<endl<<"LogLike = "<<LogLike;
	
	}




	public void optAlpha2old() {
			
		double Ori;
		Ori = alpha;
		setAlpha(Ori);
		double OriLogLike = calcLogLike();
		double left, right, center;
		double h;
		double a;
		double tmp1,tmp2;
	
		center = Ori;
		//left = center * 0.9;
		left = center * 0.8;
		if (left < myFunc.ALPHA_LOWER_LIMIT) left = myFunc.ALPHA_LOWER_LIMIT;
		h = left * myFunc.DELTA_RATIO_derivative_alpha;
		//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
		setAlpha(left+h);
		tmp2 = calcLogLike();
	
		setAlpha(left);
		tmp1 = calcLogLike();
	
		a = (tmp2-tmp1)/h;
	
		while(a<0.0 && left > myFunc.ALPHA_LOWER_LIMIT) {
			//left = left * 0.9;
			left = left * 0.8;
			h = left * myFunc.DELTA_RATIO_derivative_alpha;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
			setAlpha(left+h);
			tmp2 = calcLogLike();
	
			setAlpha(left);
			tmp1 = calcLogLike();
	
			a = (tmp2-tmp1)/h;
		}
		if (left  < myFunc.ALPHA_LOWER_LIMIT) left = myFunc.ALPHA_LOWER_LIMIT;
	
		//right = center * 1.1;
		right = center * 1.2;
		h = right * myFunc.DELTA_RATIO_derivative_alpha;
		//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
		setAlpha(right+h);
		tmp2 = calcLogLike();
	
		setAlpha(right);
		tmp1 = calcLogLike();
	
		a = (tmp2-tmp1)/h;
	
		while(a>0.0) {
			//right = right * 1.1;
			right = right * 1.2;
			h = right * myFunc.DELTA_RATIO_derivative_alpha;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
			setAlpha(right+h);
			tmp2 =calcLogLike();
	
			setAlpha(right);
			tmp1 = calcLogLike();
	
			a = (tmp2-tmp1)/h;
		}
	
		do {
			center = (left+right)*0.5;
			h = center * myFunc.DELTA_RATIO_derivative_alpha;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
			setAlpha(center+h);
			tmp2 = calcLogLike();
	
			setAlpha(center);
			tmp1 = calcLogLike();
	
			a = (tmp2-tmp1)/h;
	
			if (a<0.0) right = center;
			else left = center;
		}while(Math.abs(a) > myFunc.SmallFirstDerivativeAlpha && right-left >1.0e-6);
	
		String buf;
		buf = String.format("\n%5c  %8.6f %7.4f %8.6f",'*',center,a,tmp1);
		System.err.print(buf);
	
		if (tmp1 < OriLogLike) {
			System.err.print("   (recovered)");
			setAlpha(Ori);
			tmp1 = calcLogLike();
			if (true) {
				buf = String.format(" Ori= %8.6f,  %8.6f", Ori, tmp1);
				System.err.print(buf);
			}
		}
		//cout<<endl<<"LogLike = "<<LogLike;
	
	}


	
	public void optGapPropMultFactor() {
		// this was removed for distribution
	}
	

	public void optGapPropMultFactor2() {
		// this was removed for distribution
	}




	public void optGapPropMultFactor2old() {
		// this was removed for distribution
	}


	

	public void calcBrDeriv(Node ptr, double v, int order, double[] ret) { // order = 1 first; order=2 second deriv
	// ret[0]: first deriv, ret[1]:second deriv	
	// Recalculation of loglikelihood. All sublikelihood except this branch must be calculated
	// before this routine.
	
		//referece: Yang 2000 Maximum likelihood estimation on large phylogenies and analysis of adaptive
		//evolution in human influenza virus A, JME 51:423-432
		
		
		/*	
		// instead of allocating memory every time... this procedure is done once before calling calcBrDeriv(..)
		double[] sitewiseLike;
		sitewiseLike = new double[this.sitewiseLogLike_deriv.length];
		double[][] sitewiseTemp;
		sitewiseTemp = new double[2][this.sitewiseLogLike_deriv.length];	
		 */		
		
		
		if (!(order == 1 || order == 2)) {
			myFunc.errPrint(String.format("\n Order of calcBrDeriv(..) should be 1 or 2"));
			System.exit(0);
		}
	
		int i, j,k,l, patt_size;
	
		patt_size = alphabetDataPatternNum.length;
	
		ptr.branchLength = v;
		ptr.desNd.branchLength = v;
		
		double tmp;
	

		
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.NocalcGapPropMultFactor) {
			for (i=0;i<gammaCateNum;i++) {
				BrGammaSpace[i] = v * gammaRateFactor[i];
			}
			calTransProb_brDeriv(BrGammaSpace, gammaRateFactor, 1); // order == 1
		}

		for (j=0;j<patt_size;j++) {
			if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
				if ( (j > 0 && Math.abs(this.sitewiseGapProp[j]- this.sitewiseGapProp[j-1]) > myFunc.EPSILON) 
					 ||	j==0 ) {
					for (i=0;i<gammaCateNum;i++) 
						BrGammaSpace[i] = (v * sitewiseGapPropBrMultFactor[j]  ) * gammaRateFactor[i];
					calTransProb_brDeriv(BrGammaSpace, gammaRateFactor, sitewiseGapPropBrMultFactor[j], 1); // order == 1
					
				}
				else 
					; // do nothing
			}

			for (i=0;i<gammaCateNum;i++) {
				for (k=0;k<stateDim;k++) {
					tmp = 0.0;
					for (l=0;l<stateDim;l++) {
						tmp += transProb(i,k,l) * ptr.desNd.subLikelihood[i*patt_size*stateDim + j*stateDim + l]; // ptr->des_ptr->subLikelihood[i][j][l];
					}
					ptr.subLikelihood[i*patt_size*stateDim + j*stateDim + k] = tmp; // ptr->subLikelihood[i][j][k] = tmp;
				}
			}
		}
		calcLogLikeCenter(ptr, sitewiseLike); // "do not take log of sitewiseInfo"
		for (j=0;j<patt_size;j++) {
			sitewiseTemp[0][j] = sitewiseLike[j];
		}
		

		///////
		
		if (order==2) {
			if (this.gapPropMultFactorOpt == GapPropMultFactorType.NocalcGapPropMultFactor) {
				calTransProb_brDeriv(BrGammaSpace, gammaRateFactor, 2); // order == 2
			}
			for (j=0;j<patt_size;j++) {
				
				if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
					if ( (j > 0 && Math.abs(this.sitewiseGapProp[j]- this.sitewiseGapProp[j-1]) > myFunc.EPSILON) 
						 ||	j==0 ) {
						for (i=0;i<gammaCateNum;i++) 
							BrGammaSpace[i] = (v * sitewiseGapPropBrMultFactor[j]  ) * gammaRateFactor[i];
						calTransProb_brDeriv(BrGammaSpace, gammaRateFactor, sitewiseGapPropBrMultFactor[j], 2); // order == 2
						
					}
					else 
						; // do nothing
				}
					
				for (i=0;i<gammaCateNum;i++) {
					for (k=0;k<stateDim;k++) {
						tmp = 0.0;
						for (l=0;l<stateDim;l++) {
							tmp += transProb(i,k,l) * ptr.desNd.subLikelihood[i*patt_size*stateDim + j*stateDim + l]; // ptr->des_ptr->subLikelihood[i][j][l];
						}
						ptr.subLikelihood[i*patt_size*stateDim + j*stateDim + k] = tmp; // ptr->subLikelihood[i][j][k] = tmp;
					}
				}
			}
			calcLogLikeCenter(ptr, sitewiseLike); //"do not take log of sitewiseInfo"
			for (j=0;j<patt_size;j++) {
				sitewiseTemp[1][j] = sitewiseLike[j];
			}
		}

		////////
		
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.NocalcGapPropMultFactor) {
			calTransProb_brDeriv(BrGammaSpace, gammaRateFactor, 0);
		}
		
		for (j=0;j<patt_size;j++) {
				
			if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
				if ( (j > 0 && Math.abs(this.sitewiseGapProp[j]- this.sitewiseGapProp[j-1]) > myFunc.EPSILON) 
					 ||	j==0 ) {
					for (i=0;i<gammaCateNum;i++) 
						BrGammaSpace[i] = (ptr.branchLength * sitewiseGapPropBrMultFactor[j]  ) * gammaRateFactor[i];
					calTransProb_brDeriv(BrGammaSpace, gammaRateFactor, sitewiseGapPropBrMultFactor[j], 0); // order == 0
					
				}
				else 
					; // do nothing
			}
				
			for (i=0;i<gammaCateNum;i++) {
				for (k=0;k<stateDim;k++) {
					tmp = 0.0;
					for (l=0;l<stateDim;l++) {
						tmp += transProb(i,k,l) * ptr.desNd.subLikelihood[i*patt_size*stateDim + j*stateDim + l]; // ptr->des_ptr->subLikelihood[i][j][l];
					}
					ptr.subLikelihood[i*patt_size*stateDim + j*stateDim + k] = tmp; // ptr->subLikelihood[i][j][k] = tmp;
				}
			}
		}
		calcLogLikeCenter(ptr,sitewiseLike); // "do not take log of sitewiseInfo"

		
		
		
		double sum;
		
		// Eq (7) of Yang 2000 JME 51:423 
		// calc first Deriv
		sum = 0.0;
		for (j=0;j<patt_size;j++) {
			tmp = sitewiseTemp[0][j] / sitewiseLike[j];
			sum += tmp * alphabetDataPatternNum[j];
			sitewiseLogLike_deriv[j] = tmp;
		}
		if (order == 1) {
			ret[0] = sum;
		}
		
		//calc second deriv
		sum = 0.0;
		for (j=0;j<patt_size;j++) {
			tmp = (sitewiseLike[j]*sitewiseTemp[1][j] - sitewiseTemp[0][j]*sitewiseTemp[0][j]) 
					/ (sitewiseLike[j]*sitewiseLike[j]);
			sum += tmp * alphabetDataPatternNum[j];
			sitewiseLogLike_deriv2[j] = tmp;
		}
		
		ret[1] = sum;
		
		ptr.recalNeeded = ptr.desNd.recalNeeded = true; // because subLikelihood contaminated
		
	}




	public double RecalLogLike(Node ptr, double v) {
			
	// Recalculation of loglikelihood. All sublikelihood except this branch must be calculated
	// before this routine.
	
		int i, j,k,l, patt_size;
	
		patt_size = alphabetDataPatternNum.length;
	
		ptr.branchLength = v;
		ptr.desNd.branchLength = v;
	
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.NocalcGapPropMultFactor) {
			for (i=0;i<gammaCateNum;i++) 
				BrGammaSpace[i] = v * gammaRateFactor[i]; 
			calTransProb(BrGammaSpace);
		}
	
		for (j=0;j<patt_size;j++) {
			if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
				if ( (j > 0 && Math.abs(this.sitewiseGapProp[j]- this.sitewiseGapProp[j-1]) > myFunc.EPSILON) 
					 ||	j==0 ) {
					for (k=0;k<gammaCateNum;k++) 
						BrGammaSpace[k] = (v * sitewiseGapPropBrMultFactor[j]  ) * gammaRateFactor[k];
					calTransProb(BrGammaSpace);
				}
				else 
					; // do nothing
			}
				
			
			for (i=0;i<gammaCateNum;i++) {
				double tmp;
				for (k=0;k<stateDim;k++) {
					tmp = 0.0;
					for (l=0;l<stateDim;l++) {
						tmp += transProb(i,k,l) * ptr.desNd.subLikelihood[i*patt_size*stateDim + j*stateDim + l]; // ptr->des_ptr->subLikelihood[i][j][l];
					}
					ptr.subLikelihood[i*patt_size*stateDim + j*stateDim + k] = tmp; // ptr->subLikelihood[i][j][k] = tmp;
				}
			}
		}
	
		ptr.recalNeeded = false;
		ptr.desNd.recalNeeded = true;
	
		return calcLogLikeCenter(ptr);
	
	
	}



	public double transProb(int k, int i, int j) {
	
		return probMat[k*stateDim*stateDim + i*stateDim + j];
	}

	public void optAllBranches(boolean print2screen) {
	
		int iter;
		iter = brParam.length;
		double oldLogLike, newLogLike;
		
		//this.setRecalNeeded();
		//this.calcLogLike();
		oldLogLike = logLike; 
		
		newLogLike = oldLogLike;
	
		double temp = oldLogLike;
	
		int i=0;
		//char buf[] = new char[100];
		String buf;
		int detaillevel =0;
		if (print2screen) {
			switch(detaillevel) {
			case 1:
				System.out.print("\n -Br-");
			case 0:
				System.err.print("\n -Br-");
				//ScreenDisplay(cerr, " -Br-");
				break;
			case -2:
			case -1:
				System.out.print("\n -Br-");
				System.err.print("\n -Br-");
			}
		}

		
	
		oldLogLike = newLogLike;
		for (i = 0; i < iter; i++) {
		//for (i = iter-1; i >= 0 ; i--) {
			buf = String.format("\n%4d",i);
			if (print2screen) {
				switch(detaillevel) {
				case 1:
					System.out.print(buf);
				case 0:
					System.err.print(buf);
					break;
				case -2:
				case -1:
					break;
				}
			}

			optBranchLength(i, print2screen);
		}
		newLogLike = logLike;

	
		for (i = 0; i < iter; i++) {
			brParam[i] = brPos[i].branchLength;
		}
	
		//UpdatePairDist();
		
		//debugging
		//myFunc.print(String.format("\nbrParam[1] =  %3.30f", brParam[1]));
		
	}
	

	public void optBranchLengthOnly(boolean print2screen) {
		double newLogLike, oldLogLike;
	
		int i;
		String str;
		
		int cnt = 0;
		int k = 0;
	
		double tol;
		
		if (this.mlFineTuning == false)
			tol = Math.abs(1.0/this.logLike)*this.mlFineTuningMultFactor;  //tol = 0.001;
		else
			tol = 1.0e-8;
		
		do {
			
			str = String.format("\nbr only optimization R = %d", cnt);
			if (print2screen)
				System.err.print(str);
	
			calcLogLike();
			newLogLike = logLike; // CalcLogLike();
	
	
			oldLogLike = newLogLike;
			

			for (i=0;i<brPos.length;i++) {
				if (print2screen)
					myFunc.errPrint(String.format("\n - Br%d -", i));
				optBranchLength(brPos[i], print2screen);
			}

	
	
			calcLogLike();
			str = String.format("\n     %f", logLike);
			if (print2screen)
				System.err.print(str);
			
			newLogLike = logLike;
	
			//str =  String.format("\n  diff = %f (%f->%f) ", newLogLike - oldLogLike, oldLogLike, newLogLike);
			//System.err.print(str);
			
			cnt++;
			
			
			if (Math.abs(newLogLike - oldLogLike) < Math.abs(oldLogLike) * tol) {
				k++;
				//str  =  String.format("\nDifference is smaller than tolerance (relative proportion of %f; k=%d",tol,k);
				//System.err.print(str);
			}
			
		} while (k != optMaxR);
		
	}

	public void optBranchLength(int id, boolean print2screen) {
		optBranchLength(brPos[id],print2screen);
		return;
	}

	public void optBranchLength(Node ptr, boolean print2screen) {
	
		double OriLogLike, NewLogLike, OldLogLike, New1stD,NewVal, OldVal;
		double x, Ori;
		Ori = ptr.branchLength;
	
		Node oriStart = startNode;
		startNode = ptr;
	
		//setRecalNeeded(); // removing this increases speed
		OriLogLike = calcLogLike();
	
		x = Ori;
		double a, b;
		//char buf[200];
		String buf;
	
		double h;
		double tmp1,tmp2;
		double v,v2;	
		
		/*
		double[] sitewiseLike;
		sitewiseLike = new double[this.sitewiseLogLike_deriv.length];
		double[][] sitewiseTemp;
		sitewiseTemp = new double[2][this.sitewiseLogLike_deriv.length];
		*/	
		
		if (Math.abs(Ori-myFunc.BRANCH_LENGTH_LOWER_LIMIT) <  0.01 * myFunc.BRANCH_LENGTH_LOWER_LIMIT) { //  myFunc.EPSILON) { 
			//do not use "< myFunc.EPSILON"  because this block is ignored when Ori = myFunc.BRANCH_LENGTH_LOWER_LIMIT + esp(very small value) as input
			a = RecalLogLike(ptr, 2.0*myFunc.BRANCH_LENGTH_LOWER_LIMIT);
			tmp1 = (a-OriLogLike)/( 2.0*myFunc.BRANCH_LENGTH_LOWER_LIMIT); // first derivative
			if (OriLogLike > a || Math.abs(tmp1) < myFunc.SmallFirstDerivative) { // if decreasing or if not-informative sequence (total gap seq)
				NewLogLike = RecalLogLike(ptr, myFunc.BRANCH_LENGTH_LOWER_LIMIT);
				double p = (a - OriLogLike)/myFunc.BRANCH_LENGTH_LOWER_LIMIT;
				buf = String.format("%7.4f %7.4f %8.6f *",x,p,NewLogLike);
				if (print2screen)
					System.err.print(buf);
				x = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
				startNode = oriStart;
				return;
			}
		}
		
		if (Math.abs(Ori-myFunc.BRANCH_LENGTH_UPPER_LIMIT) <  myFunc.EPSILON) {
			v = myFunc.BRANCH_LENGTH_UPPER_LIMIT * myFunc.DELTA_RATIO_derivative_br;
			a = RecalLogLike(ptr, myFunc.BRANCH_LENGTH_UPPER_LIMIT + v);
			if (OriLogLike < a) {
				NewLogLike = RecalLogLike(ptr, myFunc.BRANCH_LENGTH_UPPER_LIMIT);
				double p = (a - OriLogLike)/v;
				buf = String.format("%7.4f %7.4f %8.6f *",x,p,NewLogLike);
				if (print2screen)
					System.err.print(buf);
				x = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
				startNode = oriStart;
				return;
			}
		}
	

	
		if (x<myFunc.BRANCH_LENGTH_LOWER_LIMIT) x = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
	
		v = x*myFunc.DELTA_RATIO_derivative_br;
	
		
		//tmp2 = RecalLogLike(ptr, x+v);
		tmp1 = RecalLogLike(ptr, x);
		
		NewLogLike = OldLogLike = tmp1;
		
		//a = (tmp2-tmp1)/v;
		double ret[] = new double[2];
		
		this.calcBrDeriv(ptr, x, 1, ret);
		a = ret[0];
		
		NewVal = OldVal = x;
		New1stD = a;
	
		buf = String.format("%7.4f %7.4f %8.6f",x,a,NewLogLike);
		if (print2screen)
			System.err.print(buf);
	
		//double r = Math.min((-OldLogLike) * tol, 10000.0);
		
		int cnt=0;
		do {
			v = x * myFunc.DELTA_RATIO_derivative_br;
			v2 = (x+v) * myFunc.DELTA_RATIO_derivative_br; //seems to be better...

			//tmp2 = RecalLogLike(ptr, x+v+v2);
			//tmp1 = RecalLogLike(ptr, x+v);
			
			//b = (tmp2-tmp1)/v2;
			this.calcBrDeriv(ptr, x+v, 1, ret);
			b = ret[0];
			

			
			if (Math.abs(b-a)<myFunc.EPSILON) {
				buf = String.format(" // amlost flat //  OptBranchLength(..) ");
				if (print2screen)
					System.err.print(buf);
				cnt = myFunc.maxNewtonR;
				break;
			}
			
			//h = - a/(b-a) * v;
			this.calcBrDeriv(ptr, x, 2, ret);
			h = - a / ret[1]; 
			
						
			//System.exit(0);
			
			
			if (x + h < myFunc.BRANCH_LENGTH_LOWER_LIMIT) {
				while (x+h < myFunc.BRANCH_LENGTH_LOWER_LIMIT) {
					//cout<<endl<<"x="<<x<<" h="<<h<<" x+h="<<x+h<<" h is adjusted";
					//cerr<<endl<<"x="<<x<<" h="<<h<<" x+h="<<x+h<<" h is adjusted";
					h /= 2.0;
				}
			}
			if (x + h > myFunc.BRANCH_LENGTH_UPPER_LIMIT) {
				while (x+h > myFunc.BRANCH_LENGTH_UPPER_LIMIT) {
					//cout<<endl<<"x="<<x<<" h="<<h<<" x+h="<<x+h<<" h is adjusted";
					//cerr<<endl<<"x="<<x<<" h="<<h<<" x+h="<<x+h<<" h is adjusted";
					h /= 2.0;
				}
			}
			x += h;
			v = x * myFunc.DELTA_RATIO_derivative_br;
			//if (v < SmallDiff4Deriv) v = SmallDiff4Deriv;
	
			//tmp2 = RecalLogLike(ptr, x+v);
			tmp1 = RecalLogLike(ptr, x);
	
			//a = (tmp2-tmp1)/v;
			this.calcBrDeriv(ptr, x, 1, ret);
			a = ret[0];
	
			if (tmp1 > NewLogLike) {
				//OldLogLike = NewLogLike;
				//OldVal = NewVal;
				NewLogLike = tmp1;
				NewVal = x;
				New1stD = a;
			}
			/*
			if (NewLogLike > OriLogLike) {
				// if loglike increases thru Newton-Rnapson,
				// update it.
				Ori = NewVal;
				OriLogLike = NewLogLike;
			}
			*/
			cnt++; // pTree prevent optimization to be trapped

		} while(Math.abs(a) > myFunc.SmallFirstDerivative && cnt<myFunc.maxNewtonR) ;
			/*
		} while(Math.abs(a) > myFunc.SmallFirstDerivative 
				&& cnt<myFunc.maxNewtonR 
				&& NewLogLike - OldLogLike > (-OldLogLike) * tol) ;
				*/
			/*
		} while(Math.abs(a) > myFunc.SmallFirstDerivative * tol
			&& cnt<myFunc.maxNewtonR ) ;
			*/
	
		//if (NewLogLike >  OriLogLike - myFunc.EPSILON) {
			NewLogLike = RecalLogLike(ptr, NewVal);
		//}
		
		buf = String.format(" | %7.4f %7.4f %8.6f",NewVal,New1stD,NewLogLike); 
		if (print2screen)
			System.err.print(buf);
		
		buf = String.format(", %d-r", cnt);
		if (print2screen)
			System.err.print(buf);
	
		/*
		if (NewLogLike > OriLogLike) {
			// set with the highest value if the final round is not highest.
			BrParam[id] = NewVal;
			NewLogLike = RecalLogLike(BrPos[id], NewVal);
	
			sprintf(buf,"\n%4c %7.4f %7.4f %8.6f *",' ',NewVal,New1stD,NewLogLike);
			cerr<<buf;
		}
		*/
	
	
	
		//if (cnt == myFunc.maxNewtonR || Math.abs(OriLogLike-NewLogLike) < myFunc.EPSILON ) { 
		if (cnt == myFunc.maxNewtonR ) { 
			a = RecalLogLike(ptr, myFunc.BRANCH_LENGTH_LOWER_LIMIT);
			if (a>NewLogLike) {
				NewLogLike = a;
				buf = String.format("\n%4c %7.4f %7c %8.6f *",' ',myFunc.BRANCH_LENGTH_LOWER_LIMIT,' ',NewLogLike);
				if (print2screen)
					System.err.print(buf);
			}
			else {
				NewLogLike = RecalLogLike(ptr,NewVal);
				optBranchLength2(ptr, print2screen);
			}
		}
	
		//cout<<endl<<"NewLogLike = "<<NewLogLike;
	
		/*
		if (NewLogLike < OriLogLike) {
			//NewLogLike might be changed thru if(cnt == MaxNewtonR){}
			BrParam[id] = Ori;
			NewLogLike = RecalLogLike(BrPos[id],Ori);
		}
		*/
	
	
		startNode = oriStart;
	
	
	
	}
		
	



	public void optBranchLength2(int id, boolean print2screen) {
	// non-Newton method
		optBranchLength2(brPos[id], print2screen);
		return;
	
	}


	public void optBranchLength2(Node ptr, boolean print2screen) {
	// non-Newton method
		double Ori = ptr.branchLength; 
		double OriLogLike = logLike; // CalcLogLike();
	
		double left, right, center;
		double h;
		double a;
		double tmp1,tmp2;
		
		double ret[] = new double[2];
	
		/*
		double[] sitewiseLike;
		sitewiseLike = new double[this.sitewiseLogLike_deriv.length];
		double[][] sitewiseTemp;
		sitewiseTemp = new double[2][this.sitewiseLogLike_deriv.length];
		*/	
		
		
		center = Ori;
		//left = center * 0.9;
		left = center * 0.8;
		if (left < myFunc.BRANCH_LENGTH_LOWER_LIMIT) left = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
		h = left * myFunc.DELTA_RATIO_derivative_br;
	
		tmp2 = RecalLogLike(ptr,left+h);
		tmp1 = RecalLogLike(ptr,left);
	
		//a = (tmp2-tmp1)/h;
		this.calcBrDeriv(ptr, left, 1, ret);
		a = ret[0];
		
		if (a > 0.0) {
			right = Ori;
			do {
				//right = right * 1.1;
				right = right * 1.2;
				if (right > myFunc.BRANCH_LENGTH_UPPER_LIMIT)
					right = myFunc.BRANCH_LENGTH_UPPER_LIMIT;
				h = right*myFunc.DELTA_RATIO_derivative_br;
				//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
		
				tmp2 = RecalLogLike(ptr,right+h);
				tmp1 = RecalLogLike(ptr,right);
		
				//a = (tmp2-tmp1)/h;
				this.calcBrDeriv(ptr, right, 1, ret);
				a = ret[0];
			}while(a>0.0&&right<Ori*10.0&&Math.abs(right-myFunc.BRANCH_LENGTH_UPPER_LIMIT) >  myFunc.EPSILON) ;
		}
		else {
			right = left;
			left = Ori;
			do {
				//left = left * 0.9;
				left = left * 0.8;
				h = left*myFunc.DELTA_RATIO_derivative_br;
				//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
		
				tmp2 = RecalLogLike(ptr,left+h);
				tmp1 = RecalLogLike(ptr,left);
		
				//a = (tmp2-tmp1)/h;
				this.calcBrDeriv(ptr, left, 1, ret);
				a = ret[0];
			}while(a<0.0&&left>myFunc.BRANCH_LENGTH_LOWER_LIMIT) ;
			if (left<myFunc.BRANCH_LENGTH_LOWER_LIMIT) left = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
		}
	
		while(a<0.0&&left>myFunc.BRANCH_LENGTH_LOWER_LIMIT) {
			//left = left * 0.9;
			left = left * 0.8;
			h = left*myFunc.DELTA_RATIO_derivative_br;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
	
			tmp2 = RecalLogLike(ptr,left+h);
			tmp1 = RecalLogLike(ptr,left);
	
			//a = (tmp2-tmp1)/h;
			this.calcBrDeriv(ptr, left, 1, ret);
			a = ret[0];
		}
		if (left<myFunc.BRANCH_LENGTH_LOWER_LIMIT) left = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
	
		do {
			center = (left+right)*0.5;
			h = center * myFunc.DELTA_RATIO_derivative_br;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
	
			tmp2 = RecalLogLike(ptr,center+h);
			tmp1 = RecalLogLike(ptr,center);
			
			//a = (tmp2-tmp1)/h;
			this.calcBrDeriv(ptr, center, 1, ret);
			a = ret[0];
			
			if (a<0.0) right = center;
			else left = center;
		}while(Math.abs(a)>myFunc.SmallFirstDerivative&& right-left >1.0e-6);
	
		//char buf[200];
		String buf;
		buf = String.format("\n%4c %7.4f %7.4f %8.6f",'*',center,a,tmp1);
		if (print2screen)
			System.err.print(buf);
	
		if (tmp1 < OriLogLike) {
			ptr.branchLength = Ori;
			tmp1 = RecalLogLike(ptr,Ori);
		}
		//cout<<endl<<"LogLike = "<<LogLike;
	
	}
	
	public void setAlpha(double a) 
	{
		if (this.gammaCateNum == 1) {
			gammaRateFreq[0] = 1.0;
			gammaRateFactor[0] = 1.0;
		}
		else {
			alpha = a;
			myFunc.DiscreteGamma(gammaRateFreq, gammaRateFactor, alpha, alpha, gammaCateNum, 0);
			this.setRecalNeeded();
			return;
		}
	}





	public void initParams() {
	
		//This should be run before InitML();
		//TopologyMat should be initialzed before this function;

		int i;
	
		//userBr = false; //true; // 
		
		if (brParam == null)
			brParam = new double[2*taxaNum-3]; 

	
		if (userBr) {
			for (i = 0; i < brPos.length; i++) {
				brParam[i] = brPos[i].branchLength;
			}
		}
		else {
			for (i=0;i<brPos.length;i++) {
				brParam[i] = 0.01; //0.01; //  
			}
			for (i=0;i<brPos.length;i++) {
				brPos[i].branchLength = brPos[i].desNd.branchLength = brParam[i];
			}
		}
	
	
	
		if (myJob == JobType.EST_BR_HESS || myJob == JobType.EST_BR_HESS_ESL) {
			// this is for param estimation
			for (i=0;i<brPos.length;i++) {
				brParam[i] = 0.001; //0.01; //  
				//brParam[i] = 0.1 + myRand.nextDouble()*0.5;
			}
			for (i=0;i<brPos.length;i++) {
				brPos[i].branchLength = brPos[i].desNd.branchLength = brParam[i];
			}
			setAlpha(0.5 + myRand.nextDouble()*0.5);
		}
		else if (myJob == JobType.READ_INFO_PAML) {
			// setAlpha() is already done in readInfo_paml()
		}
		else if (myJob == JobType.EST_HESS_ESL) {
			setAlpha(this.initial_alpha);
		}
		else if (myJob == JobType.SIMUL) {
			setAlpha(this.initial_alpha);
		}


	
		/*
		for (i=0;i<PairDistBrIdxSave.size();i++) {
			for (j=0;j<TopologyMat[i].size();j++) {
				if (TopologyMat[i][j] == 1)
					PairDistBrIdxSave[i].push_back(j);
			}
		}
		*/
	

		//PI.resize(4, 0.25);
	
	}


	public void calRateMat() {
		
	}
	

	public double calcLogLike() {
		
		Node pNode;
		pNode = startNode;
		do {
			calcLogLike(pNode);
			pNode = pNode.isoNd;
		} while (pNode != startNode);

		return calcLogLikeCenter(startNode);
	}
	
	/*
	public void calc2ndDeriv() {
		//Calculating Hessian
		
		brParamHess = new double[2*taxaNum-3]; 
		brESL = new double[2][2*taxaNum-3]; 
		double ret[] = new double[2];

		
		int i, iter;
		double loglike, x, h;

		Node ptr, oriStart;
		oriStart = startNode;
		
		iter = brParam.length;		
		for (i = 0; i < iter; i++) {
			//myFunc.errPrint(String.format("\nHess calc.. br%d (%d)", i, 2*taxaNum-3)); 
			
			ptr = brPos[i];
			startNode = ptr;
			setRecalNeeded();	
			loglike = calcLogLike();
			x = brParam[i];
			if (Math.abs(x-myFunc.BRANCH_LENGTH_LOWER_LIMIT) <  myFunc.EPSILON) {
				brParamHess[i] = 0.0;
			}
			else {
				this.calcBrDeriv(ptr, x, 2, ret);
				brParamHess[i] = ret[1];
				RecalLogLike(ptr, brParam[i]);
			}
		}
	}
	*/
	
	public void calcJMatrix() {
		
		int i, iter;
		iter = brParam.length;
		Node ptr, oriStart;
		oriStart = startNode;
		double loglike, x;
		double ret[] = new double[2];
		
		
		
		for (i = 0; i < iter; i++) {
			ptr = brPos[i];
			startNode = ptr;
			setRecalNeeded();	
			loglike = calcLogLike();
			x = brParam[i];
			this.calcBrDeriv(ptr, x, 2, ret);
			
		}
		
		
	}
	

	public void calc2ndDerivTest20200721() {
		// test for dominance of diagonal element of J matrix 
		// J matrix: outer product of first deriv
		
		myFunc.errPrint(String.format("\nStart of calc2ndDerivTest20200721()")); 
		myFunc.print(String.format("\nStart of calc2ndDerivTest20200721()")); 	
		
		int i, j, k, iter;
		iter = brParam.length;
		Node ptr, oriStart;
		oriStart = startNode;
		
		double loglike, x, h;
		double ret[] = new double[2];
		double invalid1stD[] = new double[iter];		
		
		double firstDSave[][] = new double[iter][sitewiseLogLike_deriv.length];
		double secondDSave[][] = new double[iter][sitewiseLogLike_deriv2.length];		
		double JMatrix[][] = new double[iter][iter];
		double IMatDiag[] = new double[iter];
		
		
		for (i = 0; i < iter; i++) {
			ptr = brPos[i];
			startNode = ptr;
			setRecalNeeded();	
			loglike = calcLogLike();
			x = brParam[i];
			this.calcBrDeriv(ptr, x, 2, ret);
			
			//if (x < 1.0 / this.seqLength || Math.abs(ret[0]) > 1000.0  )  { // definition of valid[]; invalid if 1st deriv > arbitray 1000.0 or short br
			if (Math.abs(ret[0]) > 1000.0  )  { // definition of valid[]; invalid if 1st deriv > arbitray 1000.0 
				valid[i] = false;
				invalid1stD[i] = ret[0];
			}
			else if (x < 1.0/this.seqLength ) { //|| x < 0.01) {
				valid[i] = false;
				invalid1stD[i] = ret[0];
			}
			else 
				valid[i] = true;
			
			for (j=0;j<sitewiseLogLike_deriv.length;j++) {
				firstDSave[i][j] = this.sitewiseLogLike_deriv[j];
				secondDSave[i][j] = this.sitewiseLogLike_deriv2[j];
			}
			
			RecalLogLike(ptr, brParam[i]);
			myFunc.errPrint(String.format("\ni=%d, loglike=%f ",i, this.logLike)); 
			
		}
		
		
		for (i=0;i<iter;i++) {
			for (j=i;j<iter;j++) {
				for (k=0;k<sitewiseLogLike_deriv.length;k++) {
					JMatrix[i][j] += firstDSave[i][k] * firstDSave[j][k];
				}
				JMatrix[i][j] /= sitewiseLogLike_deriv.length;
				JMatrix[j][i] = JMatrix[i][j];
			}
			double sum = 0.0;
			for (k=0;k<sitewiseLogLike_deriv.length;k++) {
				sum += secondDSave[i][k];
			}
			IMatDiag[i] = -sum/sitewiseLogLike_deriv.length;
		}
		
		myFunc.print(String.format("\n\ni , I_diag, J_diag")); 	
		for (i=0;i<iter;i++) {
			myFunc.print(String.format("\ni=%d, %f, %f ",i, IMatDiag[i], JMatrix[i][i])); 
		}
		
		
		myFunc.print(String.format("\n\n#For image...\nJMatrix <- matrix(c("));
		k=0;
		for (j=0;j<JMatrix.length;j++ ) {
			if (valid[j]) {
				for (i=0;i<JMatrix[j].length;i++) {
					if (valid[i]) {
						k++;
						if (j==JMatrix.length-1 && i==JMatrix[j].length-1) {
							myFunc.print(String.format("%f)", JMatrix[j][i]));
						}
						else {
							myFunc.print(String.format("%f,", JMatrix[j][i]));
						}
						if (k%50==0)
							myFunc.print(String.format("\n"));
					}

				}
			}
		}	
		k = (int) Math.sqrt(1.0*k);
		myFunc.print(String.format(",byrow=T, nrow=%d,ncol=%d)",k,k));
		

		
		double totSum,diagSum;
		totSum = diagSum = 0.0;
		
		for (i=0;i<JMatrix.length;i++) {
			//diagSum += Math.abs(JMatrix[i][i]);
			diagSum += JMatrix[i][i]*JMatrix[i][i];			
			for (j=0;j<JMatrix.length;j++) {
				//totSum += Math.abs(JMatrix[i][j]);
				totSum += JMatrix[i][j] * JMatrix[i][j];
			}
		}
		
		myFunc.print(String.format("\n\ndiagSum=%f, totSum=%f, ratio=%f", diagSum, totSum, diagSum/totSum)); 
		
		
		
		
		
		
		
		
		myFunc.errPrint(String.format("\nEnd of calc2ndDerivTest20200721()")); 
		myFunc.print(String.format("\nEnd of calc2ndDerivTest20200721()")); 
		System.exit(0);
		
	}
	
	
	public void calc2ndDeriv(boolean simulData, double[][] saveSecondDeriv) {
		//Calculating Hessian
		/*
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
			myFunc.errPrint(String.format("\ncalc2ndDeriv(..) is not confirmed for GapPropMultFactorType.CalcGapPropMultFactor")); 
			System.exit(0);
		}
		*/
		
		int i,j,k, iter;
		double x, h;
		iter = brParam.length;
		Node ptr, oriStart;
		oriStart = startNode;
		
		double ret[] = new double[2];
		double invalid1stD[] = new double[iter];
		double[] CILeft, CIRight, stdSave;
		
		CILeft = new double[iter];
		CIRight = new double[iter];
		stdSave = new double[iter];
		
		setRecalNeeded();	
		calcLogLike();
		
		boolean debug = false;
		
		if (!simulData && debug)
			myFunc.print(String.format("\r\nBefore calc2ndDeriv(boolean simulData, double[][] saveSecondDeriv), logLike=%f", this.logLike));
		
		/*
		double[] sitewiseLike;
		sitewiseLike = new double[this.sitewiseLogLike_deriv.length];
		double[][] sitewiseTemp;
		sitewiseTemp = new double[2][this.sitewiseLogLike_deriv.length];
		*/	
		
		double zscore, std;
		zscore = 0.0;
		std = 0.0;
		if (this.CIforBoundaryCheck == 0)
			zscore = 1.959964;
		else if (this.CIforBoundaryCheck == 1)
			zscore = 2.575829;
		else {
			System.err.print("\r\nError in <CI for boundary check> option");
			System.exit(0);
		}
		
		//debugging
		//myFunc.print(String.format("\nbrParam[1] =  %3.30f", brParam[1]));
		
		for (i = 0; i < iter; i++) {
			if (!simulData && debug)
				myFunc.errPrint(String.format("\nHess calc.. br%d (%d)", i, 2*taxaNum-3)); 
			
			ptr = brPos[i];
			startNode = ptr;
			setRecalNeeded();	
			calcLogLike();
			x = brParam[i];
			
			//debugging
			//myFunc.print(String.format("\nbrParam[1] =  %3.30f", brParam[1]));
			
			if (simulData) {
				if (valid[i]) {
					this.calcBrDeriv(ptr, x, 2, ret);
					brParamHess[i] = ret[1];
					for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
						saveSecondDeriv[i][j] = this.sitewiseLogLike_deriv2[j];
					}
				}
				else {
					for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
						saveSecondDeriv[i][j] = 0.0;
					}
				}
			}
			else { // if !simulData
				if (Math.abs(x-myFunc.BRANCH_LENGTH_LOWER_LIMIT) <  myFunc.EPSILON) {
					// if not assign valid[] = false to zero branch length, 
					// beta estimate is unreasonably very low. 
					
					// for debugging
					//myFunc.print(String.format("\nMath.abs(x-myFunc.BRANCH_LENGTH_LOWER_LIMIT) =  %3.30f", Math.abs(x-myFunc.BRANCH_LENGTH_LOWER_LIMIT)));
					//myFunc.print(String.format("\nx =  %3.30f", x));
					
					this.calcBrDeriv(ptr, x, 2, ret);
					valid[i] = false;
					invalid1stD[i] = 0.0; //ret[0];  
					brParamHess[i] = 0.0; //ret[1];  
					JMatrix[i] = 0.0;
					for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
						saveSecondDeriv[i][j] = 0.0;
					}
					CILeft[i] = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
					CIRight[i] = 0.1;
					stdSave[i] = 0.0;
					if (debug)
						myFunc.print(String.format("\nbr%d's length = almost zero ", i)); 
				}
				else {
					
					// for debugging
					//myFunc.print(String.format("\nMath.abs(x-myFunc.BRANCH_LENGTH_LOWER_LIMIT) =  %3.30f", Math.abs(x-myFunc.BRANCH_LENGTH_LOWER_LIMIT)));
					//myFunc.print(String.format("\nx =  %3.30f", x));
					
					this.calcBrDeriv(ptr, x, 2, ret);
					
					if (Math.abs(ret[0]) > 1000.0  )  { // definition of valid[]; invalid if 1st deriv > arbitray 1000.0 
						valid[i] = false;
						invalid1stD[i] = 0.0; //ret[0];
						brParamHess[i] = 0.0;
						JMatrix[i] = 0.0;
						for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
							saveSecondDeriv[i][j] = 0.0;
						}
						CILeft[i] = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
						CIRight[i] = 0.1;
						stdSave[i] = 0.0;
						if (debug)
							myFunc.print(String.format("\nbr%d firstD is very large, %f", i, ret[0])); 
					}
					else {
						brParamHess[i] = ret[1];
						JMatrix[i] = 0.0;
						for (j=0;j<this.sitewiseLogLike_deriv.length;j++) {
							JMatrix[i] += sitewiseLogLike_deriv[j] * sitewiseLogLike_deriv[j];
						}
						JMatrix[i] /= sitewiseLogLike_deriv.length;
						
						std = Math.sqrt(JMatrix[i]*this.seqLength/(brParamHess[i]*brParamHess[i]));
						if (this.shortBrConstraint == 0) {
							valid[i] = true;
							for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
								saveSecondDeriv[i][j] = this.sitewiseLogLike_deriv2[j];
							}
							CILeft[i] = brParam[i] - zscore*std;
							if (CILeft[i] < 0.0) {
								CILeft[i] = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
								if (debug)
									myFunc.print(String.format("\nbr%d's left bound of normal CI hits zero, (%f, %f), but valid", i, brParam[i] - zscore*std, brParam[i] + zscore*std)); 
							}
							CIRight[i] = brParam[i] + zscore*std;
						}
						else if (this.shortBrConstraint == 1 && brParam[i] - zscore*std < myFunc.BRANCH_LENGTH_LOWER_LIMIT)  { // (brParam[i] - zscore*Math.sqrt(-1.0/brParamHess[i]) < myFunc.BRANCH_LENGTH_LOWER_LIMIT) 
							// constraint #1
							valid[i] = false;
							brParamHess[i] = 0.0;
							JMatrix[i] = 0.0;
							for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
								saveSecondDeriv[i][j] = 0.0;
							}
							CILeft[i] = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
							CIRight[i] = brParam[i] + zscore*std;
							if (debug)
								myFunc.print(String.format("\nbr%d's left bound of normal CI hits zero, (%f, %f), thus invalid", i, brParam[i] - zscore*std, brParam[i] + zscore*std)); 
						}
						else if (this.shortBrConstraint == 1 ) {
							valid[i] = true;
							for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
								saveSecondDeriv[i][j] = this.sitewiseLogLike_deriv2[j];
							}
							CILeft[i] = brParam[i] - zscore*std;
							CIRight[i] = brParam[i] + zscore*std;
							if (debug)
								myFunc.print(String.format("\nbr%d's left bound of normal CI does not hit zero, (%f, %f), thus valid", i, CILeft[i], CIRight[i])); 
						}
						else if (this.shortBrConstraint == 2 && brParam[i] - zscore*std < myFunc.BRANCH_LENGTH_LOWER_LIMIT)  { // (brParam[i] - zscore*Math.sqrt(-1.0/brParamHess[i]) < myFunc.BRANCH_LENGTH_LOWER_LIMIT) 
							// constraint #1
							valid[i] = false;
							brParamHess[i] = 0.0;
							JMatrix[i] = 0.0;
							for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
								saveSecondDeriv[i][j] = 0.0;
							}
							CILeft[i] = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
							CIRight[i] = brParam[i] + zscore*std;
							if (debug)
								myFunc.print(String.format("\nbr%d's left bound of normal CI hits zero, (%f, %f), thus invalid", i, brParam[i] - zscore*std, brParam[i] + zscore*std)); 
						}
						else { // this.shortBrConstraint == 2 && brParam[i] - zscore*std > myFunc.BRANCH_LENGTH_LOWER_LIMIT
							
							RecalLogLike(ptr, brParam[i]);
							double maxlnL = this.logLike;
							RecalLogLike(ptr, brParam[i] - zscore*std);
							double minlnL = this.logLike;
							double normlnL = -0.5*Math.log(2.0*3.14159265359) - Math.log(std) - 0.5*zscore*zscore;
							normlnL += maxlnL - (-0.5*Math.log(2.0*3.14159265359) - Math.log(std) );
							
							RecalLogLike(ptr, brParam[i] - zscore*std + 2*zscore*std*0.1);
							if (this.logLike > normlnL){
								if (debug)
									myFunc.print(String.format("\r\nbr%d's loglk (at theta - zscore*std + 2*zscore*std*0.1)  %f > %f (corres. to normal) *************", i,  logLike, normlnL)); 
								valid[i] = true;
								for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
									saveSecondDeriv[i][j] = this.sitewiseLogLike_deriv2[j];
								}
							}
							else {
								if (debug)
									myFunc.print(String.format("\r\nbr%d's loglk (at theta - zscore*std + 2*zscore*std*0.1)  %f > %f (corres. to normal) **(invalid)**", i,  logLike, normlnL)); 
								valid[i] = false;
								brParamHess[i] = 0.0;
								JMatrix[i] = 0.0;
								for (j=0;j<this.sitewiseLogLike_deriv2.length;j++) {
									saveSecondDeriv[i][j] = 0.0;
								}
							}
							CILeft[i] = brParam[i] - zscore*std;
							CIRight[i] = brParam[i] + zscore*std;
						}
						stdSave[i] = std;
					}
					
				}
				if (debug) {
					myFunc.print(String.format("\r\n--- %dth br+-std : %f +- %f : ",i, brParam[i], std));
					if (valid[i])
						myFunc.print(String.format("valid "));
					else
						myFunc.print(String.format("invalid "));
				}

			}
			
			RecalLogLike(ptr, brParam[i]);
		} //for (i = 0; i < iter; i++) {
		
		FileWriter fout = null;
		if (!simulData) {	
			/// checking log-likelihood surface
			double xVal[], yVal[], yVal_new_approx[];
			xVal = yVal = null;
			int n = 201;
			xVal = new double[n];
			yVal = new double[n];
			yVal_new_approx = new double[n];
			String fileName = this.oriSeqFile + "_" + "loglike_surface.txt";		
			try {
				fout = new FileWriter(fileName);
			
				fout.write(String.format("### Input Options ###"));
				for (String s : this.optString) {
					fout.write(String.format("\n"));
					fout.write(s);
				}
				fout.write(String.format("\n"));
				
				
				for (i = 0; i < iter; i++) {
					//if (valid[i]) {
						myFunc.errPrint(String.format("\nChecking log-likelihood surface.. br%d (%d)", i, 2*taxaNum-3)); 
						
						ptr = brPos[i];
						startNode = ptr;
						setRecalNeeded();	
						calcLogLike();
						double oriL = this.logLike;
						double L,U,delta;

						//L = brParam[i] - zscore*Math.sqrt(JMatrix[i]*this.seqLength/(brParamHess[i]*brParamHess[i])); // Math.sqrt(-1.0/brParamHess[i]);
						L = CILeft[i];
						if (L<0.0)
							L = 0.0;
						//U = brParam[i] + zscore*Math.sqrt(JMatrix[i]*this.seqLength/(brParamHess[i]*brParamHess[i])); // Math.sqrt(-1.0/brParamHess[i]);
						U = CIRight[i];
						delta = (U-L)/n;
						for (j=0;j<n;j++) {
							xVal[j] = L + delta*j;
						}
						for (j=0;j<n;j++) {
							yVal[j] = RecalLogLike(ptr, xVal[j]);
						}
						
						
						fout.write(String.format("\r\n######################\r\n"));
						if (valid[i]) {
							fout.write(String.format("\r\n#valid branch"));
						}
						else 
							fout.write(String.format("\r\n#invalid branch"));
						fout.write(String.format("\r\n#br%d: %f", i, brParam[i]));
						fout.write(String.format("\r\n#std: %f\r\n", stdSave[i])) ; // Math.sqrt(JMatrix[i]*this.seqLength/(brParamHess[i]*brParamHess[i])) )); // Math.sqrt(-1.0/brParamHess[i])));
						myFunc.printArrayRstyle(fout, xVal, String.format("\r\nxVal_br%d", i));
						myFunc.printArrayRstyle(fout, yVal, String.format("\r\nyVal_br%d", i));

						
						
						fout.write(String.format("\r\na <- dnorm(xVal_br%d,%f,%f) ", i, brParam[i], stdSave[i] )); // Math.sqrt(JMatrix[i]*this.seqLength/(brParamHess[i]*brParamHess[i])) )); //Math.sqrt(-1.0/brParamHess[i])));
						fout.write(String.format("\r\na <- log(a) "));
						fout.write(String.format("\r\nb <-  max(yVal_br%d) - a[which.max(yVal_br%d)]", i, i ));
						fout.write(String.format("\r\nyVal_br%d_3 <- b + a", i));
						
						if (this.CIforBoundaryCheck == 0) {
							fout.write(String.format("\r\n#yVal_br%d_2 <- rep(max(yVal_br%d) + log(0.15), length(xVal_br%d)) ", i, i, i));
							// log(0.15) = -1.89712 for 95% likelihood-based interval; for the meaning of log(0.15) see 37p of In All Likelihoods
							
						}
						else if (this.CIforBoundaryCheck == 1) {
							fout.write(String.format("\r\n#yVal_br%d_2 <- rep(max(yVal_br%d) + log(0.04), length(xVal_br%d)) ", i, i, i));
							// log(0.04) = -3.218876 for 99% likelihood-based interval; for the meaning of log(0.15)
						}
						else {
							System.err.print("\r\nError in <CI for boundary check> option");
							System.exit(0);
						}
						fout.write(String.format("\r\nyVal_br%d_2 <- rep(yVal_br%d_3[length(yVal_br%d)], length(xVal_br%d)) ", i,i, i, i));
						
						fout.write(String.format("\r\nfig%d <- ggplot()  + geom_line(aes(x=xVal_br%d, y=yVal_br%d)) + geom_point(aes(x=xVal_br%d, y=yVal_br%d))", i, i, i, i, i));
						fout.write(String.format("\r\nfig%d <- fig%d + geom_line(aes(x=xVal_br%d, y=yVal_br%d_2))", i, i, i, i));
						fout.write(String.format("\r\nfig%d <- fig%d + geom_line(aes(x=xVal_br%d, y=yVal_br%d_3))", i, i, i, i));
						
						fout.write(String.format("\r\nfig%d\r\n ", i));
						
						double diff = oriL - yVal[yVal.length-1];
						
						
						int id = -1;
						for (j=0;j<yVal.length-1;j++) {
							if (yVal[j] < oriL - diff && oriL - diff <= yVal[j+1]) {
								id = j;
								break;
							}
						}
						int maxID = -1;
						double maxV = -1e10;
						for (j=0;j<yVal.length;j++) {
							if (yVal[j] > maxV ) {
								maxID = j;
								maxV = yVal[j];
							}
						}
						if (id != -1 && maxID != -1) {

							
						}
						
						
						//fout.write(String.format("\r\nmax(yVal_br%d) + yVal_br%d[1] - 2*yVal_br%d_2[1] ", i,i,i));
						//fout.write(String.format("\r\nwhich(yVal_br%d > yVal_br%d_2[1])[1] - 1 \r\n", i,i));
						
						RecalLogLike(ptr, brParam[i]);
					//}
				}
				fout.write(String.format("\r\n#--------------\r\n"));
				myFunc.printArrayRstyle(fout, brParam, "brParam");
				myFunc.printArrayRstyle(fout, stdSave, "stdSave");
				fout.write(String.format("\nplot(brParam,stdSave)"));
				

				
				
			}
			catch (IOException e) {
				myFunc.print(String.format("\n%s error", fileName));
			} finally {
				try {
					fout.close();
				} catch (IOException e) {
					System.out.println(e);
				} catch (NullPointerException e) {
					System.out.println(e);
				}
			}
		}
		
		startNode = oriStart;
		setRecalNeeded();	
		calcLogLike();
		
		if (!simulData)
			myFunc.print(String.format("\r\nAfter calc2ndDeriv(boolean simulData, double[][] saveSecondDeriv), logLike=%f", this.logLike));
		
		// program should stop if there is no valid branch
		j = 0;
		for (i = 0; i < iter; i++) {
			if (valid[i])
				j++; 
		}
		if (!simulData && j==0) {
			myFunc.errPrint(String.format("\r\nAll MLE's are very close to boundary. Program stops. "));
			myFunc.print(String.format("\r\nAll MLE's are very close to boundary. Program stops. "));
			System.exit(0);
		}

		
	}
	

	public void Calc2ndDeriv2() {
		// this is fancier 2nd-derivative. 
		// Using Ricardson's extrapolation
		// 20190926 note
		
		myFunc.errPrint(String.format("\nCalc2ndDeriv2() should not be reached! )")); 
		System.exit(0);
		
		brParamHess = new double[2*taxaNum-3]; 

		

		double x, h, v1, a, b, c, oriAlpha, oriRateParam, oriBr, sum;
		int i;
		
		
		//Calculating alpha Hess
		oriAlpha = x = alpha;
		h = x * myFunc.DELTA_RATIO_derivative_alpha;
		sum = 0.0;
		setAlpha(x+2*h);
		sum -= calcLogLike();
		setAlpha(x+h);
		sum += 16 * calcLogLike(); 
		setAlpha(x);
		sum -= 30 * calcLogLike(); 
		setAlpha(x-h);
		sum += 16 * calcLogLike(); 
		setAlpha(x-2*h);
		sum -= calcLogLike();
		alphaHess = sum / (12*h*h);
		
	

		
		//Calculating brHess
		int iter;
		iter = brParam.length;
		Node ptr, oriStart;
		oriStart = startNode;
		for (i = 0; i < iter; i++) {
			ptr = brPos[i];
			startNode = ptr;
			setRecalNeeded();	
			calcLogLike();
			x = brParam[i];
			if (Math.abs(x-myFunc.BRANCH_LENGTH_LOWER_LIMIT) <  myFunc.EPSILON) {
				brParamHess[i] = 0.0;
			}
			else {
				h = x*myFunc.DELTA_RATIO_derivative_br;
				sum = 0.0;
				sum -= RecalLogLike(ptr, x+2*h);
				sum += 16 * RecalLogLike(ptr, x+h);
				sum -= 30 * RecalLogLike(ptr, x);
				sum += 16 * RecalLogLike(ptr, x-h);
				sum -= RecalLogLike(ptr, x-2*h);
				brParamHess[i] = sum / (12*h*h);
				RecalLogLike(ptr, brParam[i]);
			}

		}
		
		startNode = oriStart;
		setRecalNeeded();	
		calcLogLike();

		
	}

	/*
	public void Calc2ndDeriv() {
		// This is crude, simple 2nd derivative
	
		
		brParamHess = new double[2*taxaNum-3]; 
		rateParamHess = new double[6]; // GTR model
		

		double x, v1, a, b, c, oriAlpha, oriRateParam, oriBr;
		int i;
		
		
		//Calculating alpha Hess
		oriAlpha = x = alpha;
		v1 = x * myFunc.DELTA_RATIO_derivative_alpha;
		setAlpha(x);
		c = calcLogLike();
		setAlpha(x + v1);
		b = calcLogLike();
		setAlpha(x - v1);
		a = calcLogLike();
		alphaHess = (b - 2 * c + a) / (v1*v1);
		setAlpha(oriAlpha);
		calcLogLike();
		
		//Calculating rateParamHess
		for (i=2;i<4;i++) {  // for (i = 0; i < iter; i++) { // 
			oriRateParam = x = rateParam[i];
			v1 = x * myFunc.DELTA_RATIO_derivative_rateParam;
			setRateParam(i, x);
			c = calcLogLike();
			setRateParam(i, x + v1);
			b = calcLogLike();
			setRateParam(i, x - v1);
			a = calcLogLike();
			rateParamHess[i] = (b - 2 * c + a) / (v1*v1);
			setRateParam(i, oriRateParam);
			calcLogLike();
		}
		
		//Calculating brHess
		int iter;
		iter = brParam.length;
		Node ptr, oriStart;
		oriStart = startNode;
		for (i = 0; i < iter; i++) {
			ptr = brPos[i];
			startNode = ptr;
			setRecalNeeded();	
			calcLogLike();
			x = brParam[i];
			if (Math.abs(x-myFunc.BRANCH_LENGTH_LOWER_LIMIT) <  myFunc.EPSILON) {
				brParamHess[i] = 0.0;
			}
			else {
				v1 = x*myFunc.DELTA_RATIO_derivative_br;
				c = RecalLogLike(ptr, x);
				b = RecalLogLike(ptr, x + v1);
				a = RecalLogLike(ptr, x - v1);
				brParamHess[i] = (b - 2 * c + a) / (v1*v1);
				RecalLogLike(ptr, brParam[i]);
			}

		}
		
		startNode = oriStart;
		setRecalNeeded();	
		calcLogLike();

		
	}
	*/
	
	public void printEstimatedParam() {

		int i;

		myFunc.print(String.format("\nAlpha estimate = %f", this.alpha));

		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
			
			double tmp = 0.0;
			this.setGapPropMultFactorSlope(gapPropMultFactorSlope);			
			for (i=0;i<this.alphabetDataPatternNum.length;i++) {
				tmp += sitewiseGapPropBrMultFactor[i] * this.alphabetDataPatternNum[i];
			}
			tmp /= this.seqLength;
			
			myFunc.print(String.format("\ngapPropMultFactorSlope = %f", this.gapPropMultFactorSlope));
			myFunc.print(String.format("\nmean of sitewiseGapPropBrMultFactor[..] = %f", tmp));			
			myFunc.print(String.format("\ngapOverallMean = %f", this.gapOverallMean));	
		}

		myFunc.print(String.format("\n### branch length estimates..."));	
		for (i = 0; i < brPos.length; i++) { // for (i = 0; i < 3; i++) { // 		
			myFunc.print(String.format("\nbr%d = %f", i, brPos[i].branchLength));	
		}	
		
		myFunc.print(String.format("\nLoglike = %f", this.logLike));
		
		String[] topo = new String[4];
		this.getTree(topo);
		myFunc.print(String.format("\r\nEstimated phylogeny: %s",topo[0]));	
		
	}
	
	public void Print2ndDerivScreen() {
		
		boolean tmp = false;
		
		if (tmp) 
			return;
		
		
		//printing
		String str;
		int i, iter;
		iter = brParam.length;
		
		/*
		if (myJob==JobType.Est)
			myFunc.print(String.format("\n\nAfter optimization, log-like=%f", this.logLike));
		else if (myJob==JobType.CalcHess)
			myFunc.print(String.format("\n\nAfter read-in, log-like=%f", this.logLike));
		else if  (myJob==JobType.Simul)
			myFunc.print(String.format("\n\nAfter generating random seqs, log-like=%f", this.logLike));
			*/
		
		myFunc.print(String.format("\nlogLike=%f", this.logLike));
			
		int k;
		if (myJob == JobType.SIMUL) {
			myFunc.print(String.format("\nOnly first 10 2nd_Deriv_brParam[..] are shown"));		
			k = 10;
			//k = 1000;
			if (k>iter)
				k = iter;
		}
		else 
			k = iter;

		str = String.format("\n\n2nd_Deriv_brParam[..] =  (- Hessian) | brLength");
		System.out.print(str);
		for (i = 0; i < k; i++) {
		//for (i = 0; i < iter; i++) {
			str = String.format("\n2nd_Deriv_brParam[%d] = %f | %f", i, brParamHess[i], brParam[i]);
			System.out.print(str);	
			if (!valid[i]) 
				myFunc.print(String.format(" <= NA"));
		}	
		
		//this.printNonBrParam();
		
	
		/*
		myFunc.print(String.format("\n\nFisherInfo_%s <- c(", this.oriSeqFile));
		for (i = 0; i < iter-1; i++) {
			myFunc.print(String.format("%f, ",-brParamHess[i]));
		}
		myFunc.print(String.format("%f) ",-brParamHess[i]));
		*/
		
		String[] topo = new String[4];
		this.getTree(topo);
		myFunc.print(String.format("\n%s",topo[0]));
		//myFunc.print(String.format("\n%s",topo[1]));
		
		
	}
	
	
	
	public void backupEstimates() {
		int i;
		
		this.brEstimateBackup = new double[brParam.length];
		
		for (i = 0; i < brParam.length; i++) {
			brEstimateBackup[i] = brParam[i];
		}

		this.alphaBackup = this.alpha;
		
		this.PIBackup = new double[PI.length];
		
		for (i = 0; i < PI.length; i++) {
			PIBackup[i] = PI[i];
		}
		
		/*
		this.rateParamBackup = new double[this.rateParam.length];
		for (i=0;i<rateParamBackup.length;i++) {
			rateParamBackup[i] = rateParam[i];
		}
		*/
	
		
	}
	
	public void recoverBackupedEstimates() {
		int i;
		
		for (i = 0; i < brParam.length; i++) {
			 brParam[i] = brEstimateBackup[i];
		}
		for (i = 0; i < brPos.length; i++) {
			brPos[i].branchLength = brPos[i].desNd.branchLength = brParam[i];
		}	
		
		this.setAlpha(this.alphaBackup);
		
		for (i = 0; i < PI.length; i++) {
			PI[i] = PIBackup[i];
		}
		
		/*
		for (i=0;i<rateParamBackup.length;i++) {
			rateParam[i] = rateParamBackup[i];
		}
		*/
		
		this.calRateMat();
		

	}
	

	
	public void optimizeSub_localBr(Node ptr, boolean print2screen) {
		if (true) {
			//this.setRecalNeeded();
			this.calcLogLike();
			return; 
		}
		
		double newLogLike, oldLogLike;
		
		Node pNode;
		
		/*
		int idx = -1;
		for (i=0;i<brPos.length;i++) {
			if (brPos[i] == ptr || brPos[i].desNd == ptr) {
				idx = i;
				break;
			}
		}
		*/
		
		pNode = ptr.desNd;
	
		String str;
		Node oriStart = this.startNode;
		this.startNode = ptr;
		
		int cnt = 0;
		int k = 0;
	
		double tol;
		
		//boolean oriTuneType = this.mlFineTuning;
		//this.mlFineTuning = true;
		
		if (this.mlFineTuning == false)
			tol = Math.abs(1.0/this.logLike)*this.mlFineTuningMultFactor;  //tol = 0.001;
		else
			tol = 1.0e-8;
		
		do {
			
			str = String.format("\n\nLocal br's optimization R = %d", cnt);
			if (print2screen)
				System.err.print(str);
	
			calcLogLike();
			newLogLike = logLike; // CalcLogLike();
	
	
			oldLogLike = newLogLike;
			
			if (print2screen)
				System.err.print("\n -Br-");
			optBranchLength(pNode, print2screen);
			if (print2screen)
				System.err.print("\n -Br-");			
			//optBranchLength(pNode.isoNd, print2screen);
			if (print2screen)
				System.err.print("\n -Br-");
			//optBranchLength(pNode.isoNd.isoNd, print2screen);				
			
			if (pNode.desNd.isoNd != null) {
				if (print2screen)
					System.err.print("\n -Br-");
				//optBranchLength(pNode.desNd.isoNd, print2screen);	
				if (print2screen)
					System.err.print("\n -Br-");
				//optBranchLength(pNode.desNd.isoNd.isoNd, print2screen);				
			}
	
			calcLogLike();
			str = String.format("\n     %f", logLike);
			if (print2screen)
				System.err.print(str);
			
			newLogLike = logLike;
	
			//str =  String.format("\n  diff = %f (%f->%f) ", newLogLike - oldLogLike, oldLogLike, newLogLike);
			//System.err.print(str);
			
			cnt++;
			
			
			if (Math.abs(newLogLike - oldLogLike) < Math.abs(oldLogLike) * tol) {
				k++;
				//str  =  String.format("\nDifference is smaller than tolerance (relative proportion of %f; k=%d",tol,k);
				//System.err.print(str);
			}
			
		} while (k != optMaxR);
		
		this.startNode = oriStart;

		//this.mlFineTuning = oriTuneType;
		
	}
	
	public void optAllRateParams(boolean print2screen) {
		// for over-riding
	}
	
	public void optimizeSub_pruning_paramSets(boolean print2screen) {

		if (print2screen==false) {
			//myFunc.print(String.format("\noptimizeSub_pruning_paramSets(false)..."));
			//myFunc.errPrint(String.format("\noptimizeSub_pruning_paramSets(false)..."));
		}
		optAllBranches(print2screen);
		if (this.gammaCateNum > 1)
			optAlpha(print2screen);	
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) 
			optGapPropMultFactor();
	}

	public void optimizeSub_pruning_paramSets_2(double tol) {

	}
	
	public void optimizeSub_pruning(boolean print2screen) {
		
		double oldLogLike, newLogLike;
	
	
		int cnt = 0;
		int k = 0;
	
		double tol;
		
		if (this.mlFineTuning == false)
			tol = Math.abs(1.0/this.logLike)*this.mlFineTuningMultFactor;  //tol = 0.001;
		else
			tol = 1.0e-8;
	

		long time_start, time_end, ElapsedSec;
		time_start = System.currentTimeMillis();
		
		/*
		double ori_BRANCH_LENGTH_LOWER_LIMIT = BRANCH_LENGTH_LOWER_LIMIT;
		BRANCH_LENGTH_LOWER_LIMIT = 0.01;	
		*/
	
		String str;
		String message;
	
		// temporal space for calculating derivative of br
		// this moved ti initML()
		/*
		sitewiseLike = new double[this.sitewiseLogLike_deriv.length];
		sitewiseTemp = new double[2][this.sitewiseLogLike_deriv.length];
		*/
		
		
		do {
			str = String.format("\n\nOptimization R = %d", cnt);
			
			if (cnt==31)
				System.out.print(" ");
			
			if (print2screen)
				System.err.print(str);
	
			calcLogLike();
			newLogLike = logLike; // CalcLogLike();
	
	
			oldLogLike = newLogLike;
			
			this.optimizeSub_pruning_paramSets(print2screen);
	
			calcLogLike();
			str = String.format("\n     %f", logLike);
			if (print2screen)
				System.err.print(str);
			
			newLogLike = logLike;
	
			str =  String.format("\n  diff = %f (%f->%f) ", newLogLike - oldLogLike, oldLogLike, newLogLike);
			if (print2screen)
				System.err.print(str);
			
			cnt++;
			
			time_end = System.currentTimeMillis();
			
			ElapsedSec = (time_end - time_start)/1000;
			message = String.format("  %02d:%02d:%02d", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
			if (print2screen)
				System.err.print(message);
	
			/*
			//double r = Math.min((-oldLogLike) * tol, 100.0);
			if (Math.abs(newLogLike - oldLogLike) < (-oldLogLike) * tol) {
			//if (Math.abs(newLogLike - oldLogLike) < Math.abs(oldLogLike) * 1.0e-8) {
			//if (Math.abs(newLogLike - oldLogLike) < Math.abs(oldLogLike) * 1.0) { // debugging
				if (tol > 1.0e-8 + myFunc.EPSILON) {
					//tol *= 0.1;
					myFunc.errPrint(String.format("\ntol changed from %f to %8.15f", tol*10, tol));
				}
				else {
					myFunc.errPrint(String.format("\ntol not changed : %8.15f", tol));
				}
			}
			else {
				myFunc.errPrint(String.format("\ntol not changed : %8.15f", tol));
			}
			*/
			
			if (Math.abs(newLogLike - oldLogLike) < Math.abs(oldLogLike) * tol) {
				k++;
				str  =  String.format("\nDifference is smaller than tolerance (relative proportion of %f; k=%d",tol,k);
				if (print2screen)
					System.err.print(str);
			}
			
	
		} while (k != optMaxR);
		
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor)
			; //optimizeSub_pruning_paramSets_2(tol);
	
		message = String.format("\nParameter ML opt :   %02d:%02d:%02d\r\n", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
		System.out.print(message);
		
		this.printEstimatedParam();
		
	}








	@Override
	public void preSolution() {
		

		// getOption() should be done
		// in derived class
		
		this.gapPropMultFactorSlope = 0.0;
		
		if (this.myJob != JobType.SIMUL) {
			LoadSeqFile(oriSeqFile);
			sortData();
		}
		else {
			// this is just temporary allocation. 
			//alphabetData = new char[taxaNum][this.simulLength];
			//alphabetDataPatternNum = new int[this.simulLength];
			alphabetData = new char[taxaNum][seqLength];
			taxaNameList = new String[taxaNum];
		}
	
		buildTree(oriTopo);		
		
		PrintTreeTopo();
		
		
		/*
		if (this.myJob == JobType.Simul) {
			this.setAlpha(this.alpha);
			this.LoadSeqFile_simul();
			sortData();
			// PI is replaced with empirical freq after sortData()
			for (int i=0;i<this.alphabetFreq.size();i++) 
				PI[i] = this.alphabetFreq.get(i);			
			
		}
		*/
		
		if (this.myJob != JobType.SIMUL) {
			InitML();
			initParams();
			myFunc.errPrint(String.format("\nloglk= %f", this.calcLogLike())); 
		}
		else {
			
		}

		
		System.err.print("\nEnd of super.preSolution()"); 
		
	}

	public void allocateSpace() {


		
		BrGammaSpace = new double[gammaCateNum];
		
		gammaRateFreq = new double[gammaCateNum]; 
		gammaRateFactor = new double[gammaCateNum];

		//brParam = new double[2*taxaNum-3]; 
		
		ri = new double[stateDim];
		space = new double[stateDim * 3];
		EigenRoot = new double[stateDim];
		LeftModal = new double[stateDim*stateDim];
		RightModal = new double[stateDim*stateDim];
		rateMat = new double[stateDim*stateDim];
		probMat = new double[gammaCateNum*stateDim*stateDim];
		probMatP = new double[taxaNum*taxaNum*gammaCateNum*stateDim*stateDim];
		

		
	}
	
	
	public void fillTermLikelihood(char c, double[] v, int pos, double a, int[] ii)
	{
		
		// The following has been moved to TreeMLAA.java
		// In TreeMLNuc.java, this function is redefined
		
		/*
		/// general model
		int i, sameFound;
		
		sameFound = 0;
		for (i=0;i<this.alphabetVec.size();i++) {
			if (this.alphabetVec.get(i).equals(c)) {
				v[pos + i] = a; 
				ii[0] =1;
				sameFound = 1;
			}
			else if (c=='-') {
				v[pos + i] = a; 
				ii[0] =1;
				sameFound = 1;
			}
			else if (c=='?') {
				v[pos + i] = a; 
				ii[0] =1;
				sameFound = 1;
			}
		}

		if (sameFound == 0) {
			System.err.print("\n Invalid alphabet " + c + " ... in fillTermLikelihood(..)"); 
			System.exit(0);
		}
		
		*/
		
	}
	

	public void destroyTreeMemory() {
		destroySubLikelihood();
		this.alphabetData = null;
		this.alphabetDataOri = null;
		this.alphabetDataOriUnsorted = null;
		this.alphabetDataPatternNum = null;
		this.alphabetDataPatternNumOri = null;
		this.cntUnderflow = null;
		this.brPos = null; 
		
		System.gc();
		
	}
	
	public void destroySubLikelihood(Node p) {
		p.subLikelihood = null;
		p.desNd.subLikelihood = null;
		Node pNode;
		if (p.desNd.isoNd != null) {  // if des is not terminal node
			pNode = p.desNd.isoNd;
			do {
				destroySubLikelihood(pNode);
				pNode = pNode.isoNd;
			}while(pNode != p.desNd);
		}
	}
	
	public void destroySubLikelihood() {
		Node pNode = startNode;
		do {
			destroySubLikelihood(pNode);
			pNode = pNode.isoNd;
		} while (pNode != startNode);
	}
	
	public void InitSubLikelihood(Node p) {

		Node pNode;
		int i,j,k,patt_size;

		patt_size = alphabetDataPatternNum.length;
		p.subLikelihood = new double[gammaCateNum*patt_size*stateDim];
		p.desNd.subLikelihood = new double[gammaCateNum*patt_size*stateDim];

		
		if (p.desNd.isoNd != null) {  // if des is not terminal node
			pNode = p.desNd.isoNd;
			do {
				InitSubLikelihood(pNode);
				pNode = pNode.isoNd;
			}while(pNode != p.desNd);
		}
		else {  // it des is terminal node
			String str = p.desNd.taxonName;
			int id = -1;
			for (i=0;i<taxaNameList.length;i++) {
				if (str.equals(taxaNameList[i]) ) {
					id = i;
					break;
				}
			}
			if (id == -1) {
				System.err.print(str + " cannot be found in " + dataFileName);
				System.exit(0);
			}

			for (j=0;j<gammaCateNum;j++) { // == gammaCateNum
				for (k=0;k<patt_size;k++) {  // == patternCnt
					int[] tmp = new int[1];
					fillTermLikelihood(alphabetData[id][k], p.desNd.subLikelihood, j*patt_size*stateDim + k*stateDim, PreventUnderflow[k], tmp);
					if (j==0) { // this should be count only once.
						cntUnderflow[k] += tmp[0];
					}
					/*
					if (k==18||k==19)
						System.out.print("\ncate="+j+", patt="+k+", id="+id+", "+nucData[id][k]);
					*/
				}
			}
		}
	}

	
	public void InitML()
	{

		PreventUnderflow = new double[alphabetDataPatternNum.length]; 
		cntUnderflow = new int[alphabetDataPatternNum.length]; 
		
		int i;
		for (i=0;i<PreventUnderflow.length;i++) {
			PreventUnderflow[i] = 1.0; // when using other values than 1.0, we should modify Tree::CalcLogLikeTripleSub(int i)
			cntUnderflow[i] = 0; 
		}

		Node pNode = startNode;
		do {
			InitSubLikelihood(pNode);
			pNode = pNode.isoNd;
		} while (pNode != startNode);

		setRecalNeeded();
		
		sitewiseLogLike = new double[alphabetDataPatternNum.length];
		sitewiseLogLike_deriv = new double[alphabetDataPatternNum.length];
		sitewiseLogLike_deriv2 = new double[alphabetDataPatternNum.length];
	

		// temporal space for calculating derivative of br
		sitewiseLike = new double[this.sitewiseLogLike_deriv.length];
		sitewiseTemp = new double[2][this.sitewiseLogLike_deriv.length];
	
		
		//brParam = new double[2*taxaNum-3]; 
		
		//this.setGapPropMultFactorSlope(0.0);

	}
	
	public void generateBootIndex(boolean isRand, long seed, int[] bootIdx) { 
		int i, j, idx, remainder;
	


		/*
		//deterministic
		for (i=0;i<bootIdx.length;i++) {
			bootIdx[i] = i%size;
		}	
		*/

		/*		
		// the remaining index set is random
		// random assign
		//for (i=size+1;i<bootIdx.length;i++) {
		for (i=0;i<bootIdx.length;i++) {
			idx = myFunc.myRand.nextInt(size);
			//idx = i%gapInfo[0].length;
			bootIdx[i] = idx;
		}	
		*/
		
		// first set random
		/*
		Random localRand;
		if (seed == -1)
			localRand = new Random();
		else 
			localRand = new Random(seed);
			*/
		
		
		for (i=0;i<bootIdx.length;i++) {
			if (isRand)
				idx = myRand.nextInt(bootIdx.length);
			else
				idx = i;
			bootIdx[i] = idx;
		}	
		
		
		/*
		// copy remaining sets
		for (i=size;i<bootIdx.length;i++) {

			if (isRand)
				idx = myFunc.myRand.nextInt(size);
			else 
				idx = bootIdx[i%size];
			idx = bootIdx[i%size];
			bootIdx[i] = idx;
		}	
	*/
		
	}
	
	
	public void bootstrapFisherInfo(long seed, double[][] destOri, double[][] destFull, double[][] destGappy, double[][] sourceOri, double[][] sourceFull, double[][] sourceGappy) {
		
		int[] bootIdx;
		bootIdx = new int[sourceOri[0].length];
		
		this.generateBootIndex(true,seed, bootIdx);
		myFunc.bootstrapMat(bootIdx, destOri, sourceOri);
		myFunc.bootstrapMat(bootIdx, destFull, sourceFull);
		myFunc.bootstrapMat(bootIdx, destGappy, sourceGappy);
		
		
	}
	
	
	public void bootstrapFisherInfo_translocation(long seed, double[][] destOri, double[][] destFull, double[][] destGappy, double[][] sourceOri, double[][] sourceFull, double[][] sourceGappy) {
		
		int[] bootIdx;
		bootIdx = new int[sourceOri[0].length];
		
		this.generateBootIndex(true,seed, bootIdx);
		myFunc.bootstrapMat(bootIdx, destOri, sourceOri);
		

		double[][] bootOriMeanVar = new double[2][destOri.length];
		double[] center = new double[destOri.length];		
		double[] dist1  = new double[destOri.length];
		double[] dist2  = new double[destOri.length];

		double[][] sourceOriMeanVar = new double[2][sourceOri.length];		
		double[][] sourceFullMeanVar = new double[2][sourceFull.length];
		double[][] sourceGappyMeanVar = new double[2][sourceGappy.length];
		double[][] destGappyMeanVar = new double[2][sourceGappy.length];
		
		myFunc.calcMeanVarMatrix(sourceOriMeanVar, sourceOri);	
		myFunc.calcMeanVarMatrix(sourceFullMeanVar, sourceFull);
		myFunc.calcMeanVarMatrix(sourceGappyMeanVar, sourceGappy);

		
		myFunc.calcMeanVarMatrix(bootOriMeanVar, destOri);			
		myFunc.subtractVec(dist1, bootOriMeanVar[0], sourceOriMeanVar[0]);

		// resampling simulated gappy
		myFunc.bootstrapShiftMat(bootIdx, 0, dist1, destGappy, sourceGappy);

		// resampling bootFull 
		myFunc.calcMeanVarMatrix(destGappyMeanVar, destGappy);
		double tmp;
		int i;		
		for (i=0;i<dist1.length;i++) {
			tmp = destGappyMeanVar[0][i] * sourceFullMeanVar[0][i] / sourceGappyMeanVar[0][i] - sourceFullMeanVar[0][i];
			dist1[i] = tmp;
		}
		myFunc.bootstrapShiftMat(bootIdx, 0, dist1,  destFull, sourceFull);
		/////
		
		

		
	}
	
	
	public void estimateParamOnly() {
		
		long time_start, time_end;
		time_start = System.currentTimeMillis();
		
		
		includeAllSitesForGapPropCDF = true;
		//includeAllSitesForGapPropCDF = false;
		
		LoadSeqFile(oriSeqFile);
		if (this.myFreqOpt == FreqType.DATAFREQ) {
			this.getEmpiricalPI();
			calRateMat();
		}
		
		InitML();
		
		
		if (true) {
			calcSitewiseGapProp();
			//myFunc.print(String.format("\n\nsitewiseGapProp <- c(...) omitted.."));
			//myFunc.printArrayRstyle(this.sitewiseGapProp, "sitewiseGapProp");
		}
		
		
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
			this.setGapPropMultFactorSlope(0.0);
			this.calcLogLike();
			myFunc.print(String.format("\nWith input data, logLike=%f", this.logLike));
			myFunc.errPrint(String.format("\nWith input data, logLike=%f", this.logLike));
			
			double r = 0.2;
			this.setGapPropMultFactorSlope(r); 
			this.calcLogLike();
			myFunc.print(String.format("\nAfter setting s=%f, logLike=%f", r, this.logLike));
			myFunc.errPrint(String.format("\nAfter setting s=%f, logLike=%f", r, this.logLike));
		
		}
		else
			this.setGapPropMultFactorSlope(0.0);
		

		if (!dataSorted) {
			backupUnsortedAlphabetData();
			sortData();
		}
		
		calRateMat();
		InitML();
		
		initParams();
		
		leastSquareMethod();
		
		optimizeSub_pruning(true);  
		
		
		time_end = System.currentTimeMillis();
		long ElapsedSec = (time_end - time_start)/1000;
		String message = String.format("\n %02d:%02d:%02d", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
		System.err.print(message);
		System.out.println(message);

		
		if (this.dataSorted) {
			this.calcLogLike();
			if (this.multiThrId==0)
				myFunc.print(String.format("\r\n\r\nBefore restoring data sort, %d patterns,  loglike= %f ", alphabetDataPatternNum.length, this.logLike));

			this.recoverUnsortedAlphabetData();			
			
			if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
				this.calcSitewiseGapProp();
				this.calcSitewiseGapPropCDF();
				this.setGapPropMultFactorSlope(this.gapPropMultFactorSlope);
			}
			
			InitML();
			this.setRecalNeeded();
			this.calcLogLike();
			if (this.multiThrId==0) 
					
			if (this.multiThrId==0) {
				myFunc.print(String.format("\nAfter restoring data sort, "));
				myFunc.print(String.format(" %d patterns,  loglike= %f \r\n", alphabetDataPatternNum.length, this.logLike));
			}
		}

		printEstimatedParam();
		
		String[] topo = new String[4];
		this.getTree(topo);
		myFunc.print(String.format("\nEstimated Tree: \n%s\n",topo[0]));
		
	}
	
	public void estimateRhoBeta() {
		
		double[][] dataCompleteConcat = null;
		double[][] dataGappyConcat = null;
		
		dataCompleteConcat = new double[this.taxaNum*2-3][this.seqLength*this.simulLengthTimes2];
		dataGappyConcat = new double[this.taxaNum*2-3][this.seqLength*this.simulLengthTimes2];
		
		double[] retBeta = new double[5];
		double[] retRho = new double[2];
		double[][] retParameterwiseBeta = new double[2][this.taxaNum*2-3];
		double[][] retParameterwiseRho = new double[2][this.taxaNum*2-3];
		
		long time_start, time_end;
		time_start = System.currentTimeMillis();
		
		if (myJob == JobType.EST_BR_HESS_ESL || myJob == JobType.READ_INFO_PAML)
			estimateESL(2, dataCompleteConcat, dataGappyConcat);
		else if (myJob == JobType.EST_BR_HESS) {
			estimateESL(-1, dataCompleteConcat, dataGappyConcat);
			return;
		}
		else if (myJob == JobType.EST_HESS_ESL || myJob == JobType.READ_INFO)
			estimateESL(0, dataCompleteConcat, dataGappyConcat);
		else if (myJob == JobType.SIMUL)
			estimateESL(1, dataCompleteConcat, dataGappyConcat);
	

		
		/////////
		
		this.MyDerivative.analyzeDerivMeasure(true, retBeta, retParameterwiseBeta, retRho, retParameterwiseRho, valid, MyDerivative.trueGappyData, dataCompleteConcat, dataGappyConcat);

		double[] internalBrBeta = null;
		double[] terminalBrBeta = null;
		double[] internalBrRho = null;
		double[] terminalBrRho = null;
		double[] internalBr = null;
		double[] terminalBr = null;
		
		int i;
		for (i=0;i<valid.length;i++) {
			if (valid[i]) {
				this.parameterwiseRho[0][i] = retParameterwiseRho[0][i]; 
				this.parameterwiseBeta[0][i] = retParameterwiseBeta[0][i]; 
				
				if (this.brPos[i].isoNd==null || this.brPos[i].desNd.isoNd == null) {
					terminalBrBeta = myFunc.addToEnd(terminalBrBeta, this.parameterwiseBeta[0][i] );
					terminalBrRho = myFunc.addToEnd(terminalBrRho, this.parameterwiseRho[0][i] );
					terminalBr = myFunc.addToEnd(terminalBr, this.brPos[i].branchLength );
				}
				else {
					internalBrBeta = myFunc.addToEnd(internalBrBeta, this.parameterwiseBeta[0][i] );
					internalBrRho = myFunc.addToEnd(internalBrRho, this.parameterwiseRho[0][i] );
					internalBr = myFunc.addToEnd(internalBr, this.brPos[i].branchLength );
				}
			}
		}	
	

		
		this.globalBeta = MyDerivative.globalBeta;
		this.globalRho = MyDerivative.globalRho;



		if (this.multiThrId==0) {

			this.calcWeight();
			
			//parameterwiseXX should be recal
			this.calcRho(simulFisherInfo);
			
			if (this.myJob != JobType.SIMUL)
				printSitewiseESLInfo();

			printTreeWithRhoBeta(); 
			//printParameterWiseRhoBeta(); 
			//this.MyDerivative.printInfo(); // this contains bootstrap info; moved after bootstrap
			
			myFunc.print(String.format("\r\n\r\nglobalBeta= %f, globalRho= %f",MyDerivative.globalBeta, MyDerivative.globalRho));

			
			if (this.myJob != JobType.SIMUL) {
				myFunc.print(String.format("\n\n####### Separate lengths of terminal and internal brs\n"));
				myFunc.printArrayRstyle(terminalBr, "terminalBr");
				myFunc.printArrayRstyle(internalBr, "internalBr");
				myFunc.print(String.format("\ntotBr <- c(terminalBr, internalBr) \n"));
				myFunc.print(String.format("\n\n####### Separate beta's of terminal and internal brs\n"));
				myFunc.printArrayRstyle(terminalBrBeta, "terminalBrBeta");
				myFunc.printArrayRstyle(internalBrBeta, "internalBrBeta");
				myFunc.print(String.format("\ntotBeta <- c(terminalBrBeta, internalBrBeta) \n"));
				myFunc.print(String.format("\nggplot() + geom_point(aes(x=totBr, y=totBeta)) + xlab(\"br length\") + ylab(\"parameterwise M-Factor\") "));
				myFunc.print(String.format("\n\n####### Separate Rho's of terminal and internal brs\n"));
				myFunc.printArrayRstyle(terminalBrRho, "terminalBrRho");
				myFunc.printArrayRstyle(internalBrRho, "internalBrRho");
				myFunc.print(String.format("\ntotRho <- c(terminalBrRho, internalBrRho) \n"));
				myFunc.print(String.format("\nggplot() + geom_point(aes(x=totBr, y=totRho)) + xlab(\"br length\") + ylab(\"parameterwise G-Factor\") "));
				myFunc.print(String.format("\n\n####### \n"));
			}
			
			
		}
		
		time_end = System.currentTimeMillis();
		
		long ElapsedSec = (time_end - time_start)/1000;
		String message = String.format("\n\nestimateESL(..) running :   %02d:%02d:%02d", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
		System.err.print(message);
		System.out.print(message);
		
		
		if (this.myJob != JobType.SIMUL)
			;//this.generateSitesOfPositiveRho();
		
		time_start = System.currentTimeMillis();
		
		//// bootstrapping
		this.calcESLBoot(this.randSeed,dataCompleteConcat, dataGappyConcat);
		//// bootstrapping
		
		time_end = System.currentTimeMillis();
			
		ElapsedSec = (time_end - time_start)/1000;
		message = String.format("\n\n CalcESLBoot(..) running :   %02d:%02d:%02d", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
		System.err.print(message);
		System.out.print(message);
		System.out.print("\r\n(end)");

		
	}
	

	
	
	public void estimateESL(int id, double[][] dataCompleteConcat, double[][] dataGappyConcat) { 

		// id:-1 -> estimate (br, hess);
		// id:0 -> estimate (br,hess,ESL);
		// id:1 -> readin (br,hess) and estimate (br,hess,ESL); 
		// id:2 -> readin paml info and estimate (br,hess,ESL); 
		
		if (!(id==-1||id==0||id==1||id==2)) {
			System.err.print("Something Wrong in estimateESL(..)");
			System.exit(0);
		}
		
		int i,j;

		this.meanESL = new double[2];
		
		if (brParam == null)
			brParam = new double[2*taxaNum-3]; 
		this.sitewise2ndDerivTot = new double[this.brParam.length][this.alphabetDataPatternNum.length];
		
		this.spESL = new double[this.brParam.length][this.alphabetDataPatternNum.length];
		this.sitewiseESL = new double[this.alphabetDataPatternNum.length];
		this.parameterwiseESL = new double[this.brParam.length];
		
		this.sitewiseGapProp  = new double[this.alphabetDataPatternNum.length];
		this.parameterwiseRho = new double[3][this.brParam.length]; //[0:mean, 1:var_boot, 2:var_analytic][idx for br] 
		this.sitewiseRhoSumStd = new double[2];
		
		this.sitewiseBetaTot = new double[this.brParam.length][this.alphabetDataPatternNum.length];
		this.sitewiseBeta = new double[this.alphabetDataPatternNum.length];
		this.parameterwiseBeta = new double[2][this.brParam.length];
		this.parameterwiseBetaCov = new double[this.brParam.length][this.brParam.length];
		this.sitewiseBetaSumStd = new double[2];
		
		this.sitewiseESL = new double[this.alphabetDataPatternNum.length];	
		brParamHessOri = new double[2*taxaNum-3]; 
		brParamHess = new double[2*taxaNum-3]; 
		this.JMatrix =  new double[2*taxaNum-3]; 

		oriFisherInfo = new double[2*taxaNum-3]; 
		simulFisherInfo = new double[2][2*taxaNum-3]; 
		simulGappyFisherInfoInvCov = new double[2*taxaNum-3][2*taxaNum-3];
		
		valid = new boolean[this.brParam.length]; 
		
		if (true) {
			calcSitewiseGapProp();
			//myFunc.print(String.format("\n\nsitewiseGapProp <- c(...) omitted.."));
			//myFunc.printArrayRstyle(this.sitewiseGapProp, "sitewiseGapProp");
		}

		if (!dataSorted) {
			backupUnsortedAlphabetData();
			sortData();
		}

		System.gc();
		
		if (id==0) {
			if (myJob != JobType.READ_INFO) { // checking
				System.err.print("Something Wrong in estimateESL(..)");
				System.exit(0);
			}
			this.readFisherInfo();
			if (this.multiThrId==0)
				myFunc.print(String.format("\n\nAfter read-in "));
		}
		else if (id==2) {
			if (myJob == JobType.READ_INFO_PAML) { // checking
				this.readInfo_paml();
			}
		}
		else {
			if (myJob == JobType.SIMUL)
				; // do nothing
			else
				initParams();		
		}


		
		this.makeAllGappyTaxaBrZero(); 
		
		calRateMat();
		InitML();
		
		/*
		for (i=0;i<this.taxaNameList.length;i++) {
			myFunc.print(String.format("\ni=%d, %s",i, this.taxaNameList[i]));
		}
		*/
		
		
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
			this.setGapPropMultFactorSlope(0.0);
			this.calcLogLike();
			myFunc.print(String.format("\nWith input data, logLike=%f", this.logLike));
			myFunc.errPrint(String.format("\nWith input data, logLike=%f", this.logLike));
			
			this.setGapPropMultFactorSlope(-0.2); 
		}
		else
			; //this.setGapPropMultFactorSlope(0.0);
		
		
		//// (parameter optimization here) ////
		optimizeSub_pruning(true);  // <=======  comment out if "no_ori_opt"
		//// (parameter optimization here) ////

		//for (i = 0; i < brPos.length; i++) {
			//brParam[i] = brPos[i].branchLength;
		//}		

		
		this.backupEstimates();
		
		System.gc();
		
		if (this.dataSorted) {
			this.calcLogLike();
			if (this.multiThrId==0)
				myFunc.print(String.format("\r\n\r\nBefore restoring data sort, %d patterns,  loglike= %f ", alphabetDataPatternNum.length, this.logLike));
			this.recoverUnsortedAlphabetData();
			
			if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
				this.calcSitewiseGapProp();
				this.calcSitewiseGapPropCDF();
				this.setGapPropMultFactorSlope(this.gapPropMultFactorSlope);
			}
			
			if (this.multiThrId==0)
				myFunc.print(String.format("\nAfter restoring data sort, "));
		}
		else {
			if (this.multiThrId==0)
				myFunc.print(String.format("\nAfter reading br's and alpha, "));
			this.calcLogLike();
		}		
		
		InitML();
		this.setRecalNeeded();
		this.calcLogLike();
		
		double[] ret = new double[2];
		myFunc.calcMeanVar(ret, this.sitewiseLogLike);
		this.sitewiseLogLikeMean = ret[0];
		this.sitewiseLogLikeVar = ret[1]/this.sitewiseLogLike.length;
		
		if (this.multiThrId==0)
			myFunc.print(String.format(" %d patterns,  loglike= %f ", alphabetDataPatternNum.length, this.logLike));


		
		System.gc();
		
		if (this.multiThrId==0) {
			myFunc.print(String.format("\n\nAfter optimization, "));
			myFunc.print(String.format("performing calc2ndDeriv(..) "));
			this.recoverBackupedEstimates();
			//this.calc2ndDerivTest20200721();
			calc2ndDeriv(false, this.sitewise2ndDerivTot); //simulData = false
			double[][] tmp = new double[this.sitewise2ndDerivTot.length][this.sitewise2ndDerivTot[0].length];
			for (int ii=0;ii<this.sitewise2ndDerivTot.length;ii++) {
				for (int jj=0;jj<this.sitewise2ndDerivTot[0].length;jj++) {
					tmp[ii][jj] = - this.sitewise2ndDerivTot[ii][jj];
				}
			}
			
			//MyDerivative intialization
			this.MyDerivative = new DerivativeData();
			this.MyDerivative.setupTrueGappyData(tmp, valid);
			this.MyDerivative.saveGapInfo(this.alphabetData);
			
			for (i=0;i<oriFisherInfo.length;i++) {
				oriFisherInfo[i] = -brParamHess[i];
			}
			for (i=0;i<oriFisherInfo.length;i++) {
				oriFisherInfo[i] /= this.seqLength;
			}
		}
		else {
			//myFunc.print(String.format("and calc2ndDeriv(..) omitted for multiple thread "));
			copy2ndDeriv(myFunc.brParamHessBackup);
		}
		
			
		
		if (this.multiThrId==0)
			; //Print2ndDerivScreen();
		
		
		if (id==-1) 
			return;
		
		this.alphabetDataOri = new char[this.taxaNum][this.alphabetDataPatternNum.length];
		this.alphabetDataPatternNumOri = new int[this.alphabetDataPatternNum.length];
		for (i=0;i<this.alphabetDataPatternNum.length;i++) {
			this.alphabetDataPatternNumOri[i] = this.alphabetDataPatternNum[i];
			for (j=0;j<this.taxaNum;j++) {
				this.alphabetDataOri[j][i] = this.alphabetData[j][i];
			}
		}
		
		for (i=0;i<brParamHess.length;i++) {
			brParamHessOri[i] = brParamHess[i];
		}
		
		
		//System.exit(0);
		
		/*
		//// (parameter optimization here) ////
		optimizeSub_pruning();  // <=======
		for (i = 0; i < brPos.length; i++) {
			brParam[i] = brPos[i].branchLength;
		}	
		//// (parameter optimization here) ////
		 */

			
		estimateESL_sub_generateRandSeq(true, dataCompleteConcat, dataGappyConcat); //simulData = true;
			
		this.recoverUnsortedAlphabetData();  // this may not be necessary
		InitML();
		this.calcLogLike();
			
		/*
		 * calc2ndDeriv(sitewiseESLTot);  // do the following instead...
		 */
		for (i=0;i<brParamHess.length;i++) {
			brParamHess[i] = brParamHessOri[i];
		}

		if (this.multiThrId==0) {
			//myFunc.print(String.format("\n\nAfter generating extremely long sequences, original values are.."));
			//Print2ndDerivScreen();
		}
		
		myFunc.print(String.format("\n\nAfter generating extremely long sequences, original values are.."));
		myFunc.print(String.format("\nlogLike=%f", this.logLike));
		Print2ndDerivFile(); // this should be placed after generating extremely long sequences
		
		

	}



	public void estimateESL(int id) {
		myFunc.errPrint(String.format("\nestimateESL(int id) is void fuction:"));
		System.exit(0);
	}
	
	
	public void calcRho(double[][] simulFisherInfo) {
		// new definition of sp-ESL
		//simulFisherInfo[0]: complete
		//simulFisherInfo[1]: gappy
		int i,j;
		double sum, sum2, tmp;
		
		sum = sum2 = 0.0;

		for (j=0;j<this.spESL[0].length;j++) {
			tmp = 0.0;
			for (i=0;i<this.spESL.length;i++) {				
				if (valid[i]) {
					//this.spESL[i][j] = - this.sitewise2ndDerivTot[i][j]/ simulFisherInfo[1][i] * this.MyDerivative.rho[i] / this.MyDerivative.beta[i] * this.weightForRho[i];
					//tmp += this.spESL[i][j]; 
					//sum += this.spESL[i][j];
					
					this.spESL[i][j] = - this.sitewise2ndDerivTot[i][j]/ simulFisherInfo[1][i] * this.MyDerivative.rho[i] / this.MyDerivative.beta[i];
					tmp += this.spESL[i][j] * this.weightForRho[i];
					sum += this.spESL[i][j] * this.weightForRho[i];
				}
				else
					this.spESL[i][j] = 0.0;
			}
			this.sitewiseESL[j] = tmp;
		}
		
		this.globalRho = sum/this.seqLength;
				
		if (myJob != JobType.SIMUL) {
			myFunc.print(String.format("\n\nRho by suming weighted sp-ESL : %f ",  sum));	
		}
		
		
		for (i=0;i<this.spESL.length;i++) {				
			if (valid[i]) {
				tmp = 0.0;
				for (j=0;j<this.spESL[0].length;j++) {
					tmp += this.spESL[i][j];
				}

				//this.parameterwiseESL[i] = tmp / this.weightForRho[i];
				this.parameterwiseESL[i] = tmp;
			}
			else
				this.parameterwiseESL[i] = 0.0;

		}
			
		
		// checking

		// calculate sitewise gap proportion
		/*
		for (i=0;i<this.alphabetData[0].length;i++) {
			tmp = 0.0;
			for (j=0;j<this.alphabetData.length;j++) {
				if (this.alphabetData[j][i] == '-' || this.alphabetData[j][i] == '?' )
					tmp += 1.0;
			}
			this.sitewiseGapProp[i] = tmp / alphabetData.length;
		}
		*/
		this.calcSitewiseGapProp();
	}

	public void printParameterWiseRhoBeta() {
		int i;
		double sum;		
		
		int k;
		
		
		k=0;
		myFunc.print(String.format("\n\n br id | br length | parameterwiseBeta +- std | Test stat"));
		for (i=0;i<this.parameterwiseBeta[0].length;i++) {
			if (valid[i]) {
				myFunc.print(String.format("\n%d | %f | %f +- %f | %f ", i, this.brParam[i], this.parameterwiseBeta[0][i], this.parameterwiseBeta[1][i], (this.parameterwiseBeta[0][i] - 1.0)/this.parameterwiseBeta[1][i]));
				k++;
			}
			else
				myFunc.print(String.format("\n%d | %f | NA (invalid 2nd deriv) | NA ",i,this.brParam[i]));
		}
		
	
		double data[] = new double[k];
		double data2[] = new double[k];

		k=0;
		for (i=0;i<this.parameterwiseBetaStat.length;i++) {
			if (valid[i]) {
				data[k] = this.parameterwiseBetaStat[k];
				data2[k] = this.parameterwisePvalue[k];
				k++;
			}
			else
				;
		}
		
	
		System.out.print("\n\n");
		/*
		myFunc.printArrayRstyle(data, "p_BetaStat");
		System.out.print("\hist(p_BetaStat)");
		System.out.print("\na<- pnorm(p_BetaStat)");
		*/
		
		
		
		
		myFunc.printArrayRstyle(data2, "pValue");
		System.out.print("\nhist(pValue)");	
		System.out.print("\na<- pValue");	
		System.out.print("\nhist(a)");
		System.out.print("\na.ecdf = ecdf(a)");
		System.out.print("\nplot(a.ecdf, verticals=TRUE, do.points=FALSE, main=\"CDF\")");
		System.out.print("\nabline(0,1) ");		
		System.out.print("\nks.test(a,\"punif\",0,1) ");

		
		System.out.print("\n\n");
		
		myFunc.printArrayRstyle(data, "TStat");
		System.out.print("\nhist(TStat)");
		System.out.print("\na<- pnorm(TStat)");		
		System.out.print("\nhist(a)");
		System.out.print("\na.ecdf = ecdf(a)");
		System.out.print("\nplot(a.ecdf, verticals=TRUE, do.points=FALSE, main=\"CDF\")");
		System.out.print("\nabline(0,1) ");		
		System.out.print("\nks.test(a,\"punif\",0,1) ");

		
		System.out.print("\n\nb <- pValue - a");
		System.out.print("\nplot(a,b)");
			
		
		
		/*			*/
		

		myFunc.print(String.format("\n\nBranch lengths r style..."));
		myFunc.printArrayRstyle(this.brParam, "brLength");
		
		
		sum = 0.0;
		for (i=0;i<this.parameterwiseBeta[0].length;i++) {
			if (valid[i]) {
				sum += this.parameterwiseBeta[0][i] * this.weightForBeta[i];
			}
		}
		myFunc.print(String.format("\n\n\nWeighted sum of parameterwise Beta: %f ", sum));
		
		/*
		data = new double[this.parameterwiseRho[0].length];
		for (i=0;i<data.length;i++) {
			data[i] = this.parameterwiseBeta[0][i];
		}
		*/
		myFunc.print(String.format("\nparameterwise Beta r style..."));
		myFunc.printArrayRstyle(this.parameterwiseBeta[0], "aaa");
		
		
		myFunc.print(String.format("\n\n parameterwiseRho with bootstrap (analytic) method "));
		myFunc.print(String.format("\nbr id | br length | parameterwiseRho +- boot_std (analytic_std) "));
		for (i=0;i<this.parameterwiseRho[0].length;i++) {
			if (valid[i])
				myFunc.print(String.format("\n%d | %f | %f +- %f (%f) ", i, this.brParam[i], this.parameterwiseRho[0][i], this.parameterwiseRho[1][i], this.parameterwiseRho[2][i]));
			else
				myFunc.print(String.format("\n%d | %f | NA (invalid 2nd deriv) ",i,this.brParam[i]));
		}
		
		
		
	
		
		//checking

		sum = 0.0;
		for (i=0;i<this.parameterwiseRho[0].length;i++) {
			if (valid[i]) {
				sum += this.parameterwiseRho[0][i] * this.weightForRho[i];
			}
		}
		myFunc.print(String.format("\n\nWeighted sum of parameterwise Rho: %f ", sum));
		
		/*
		for (i=0;i<data.length;i++) {
			data[i] = this.parameterwiseRho[0][i];
		}
		*/
		myFunc.print(String.format("\nparameterwise Rho r style..."));
		myFunc.printArrayRstyle(parameterwiseRho[0], "aaa");
		myFunc.print(String.format("\n"));

		
		
	}


	public void calcESLBoot(long seed, double[][] dataCompleteConcat, double[][] dataGappyConcat) {
		
		this.MyDerivative.bootIter = this.bootIter;
		
		if (this.bootTypeOpt == BootstrapType.RELLBoot)
			calcESLBootRELL(dataCompleteConcat,  dataGappyConcat) ;
		else if (this.bootTypeOpt == BootstrapType.FullBoot)
			calcESLBootFull(seed, dataCompleteConcat, dataGappyConcat);
		else ;
		
	}
	
	public void calcESLBootFull(long seed, double[][] dataCompleteConcat, double[][] dataGappyConcat) {
		
		int i,j;
		
		char[][] oriAlphaData = new char[this.alphabetData.length][this.alphabetData[0].length];
		
		for (i=0;i<oriAlphaData.length;i++) {
			for (j=0;j<oriAlphaData[i].length;j++) {
				oriAlphaData[i][j] = this.alphabetData[i][j];
			}
		}
		
		
		int[] bootIdx;
		bootIdx = new int[oriAlphaData[0].length];
		
		
		dataCompleteConcat = new double[this.brParam.length][this.seqLength*this.simulLengthTimes2];
		dataGappyConcat = new double[this.brParam.length][this.seqLength*this.simulLengthTimes2];

		double[][] pBetaSave = new double[valid.length][bootIter];
		double[][] pRhoSave  = new double[valid.length][bootIter];
		double[] gBetaSave = new double[bootIter];
		double[] gRhoSave = new double[bootIter];

		double[] retBeta = new double[5];
		double[] retRho = new double[2];
		double[][] retParameterwiseBeta = new double[2][valid.length];
		double[][] retParameterwiseRho = new double[2][valid.length];
	
		myFunc.print(String.format("\n\n######## bootstrap resampling (full version) start....\n"));
		
		long time_start, time_end;
		time_start = System.currentTimeMillis();
		
		for (j=0;j<this.bootIter;j++) {
			myFunc.print(String.format("\n\n\n###%dth bootstrap resampling (full version)", j));
			this.generateBootIndex(true,this.randSeed + j, bootIdx);
			myFunc.bootstrapMat(bootIdx, alphabetData, oriAlphaData);
			if (this.myFreqOpt == FreqType.DATAFREQ) {
				this.getEmpiricalPI();
				calRateMat();
			}
			
			if (myJob == JobType.READ_INFO_PAML)
				estimateESL(2, dataCompleteConcat, dataGappyConcat);
			else 
				estimateESL(1, dataCompleteConcat, dataGappyConcat);
			this.MyDerivative.analyzeDerivMeasure(true, retBeta, retParameterwiseBeta, retRho, retParameterwiseRho, valid, MyDerivative.trueGappyData, dataCompleteConcat, dataGappyConcat);

			
			gBetaSave[j] = this.MyDerivative.globalBeta;
			gRhoSave[j] = this.MyDerivative.globalRho;
			
			myFunc.print(String.format("\nglobalBeta= %f, globalRho= %f",MyDerivative.globalBeta, MyDerivative.globalRho));

			for (i=0;i<valid.length;i++) {
				pBetaSave[i][j] = retParameterwiseBeta[0][i];
				pRhoSave[i][j] = retParameterwiseRho[0][i];
			}
			if (j%2==0) {
				myFunc.printArrayRstyle(gBetaSave, "gBetaSaveBootFullTemp" ,j+1);
				myFunc.printArrayRstyle(gRhoSave, "gRhoSaveBootFullTemp",j+1);
			}
			

			time_end = System.currentTimeMillis();
			long ElapsedSec = (time_end - time_start)/1000;
			String message = String.format("\n%dth iteration;   %02d:%02d:%02d", j, (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
			System.err.print(message);
			System.out.println(message);
			
		}
		
		myFunc.print(String.format("\n##### bootstrap resampling (full version) end....\n"));
		
		myFunc.print(String.format("\n##### recovering original data....\n"));
		
		for (i=0;i<oriAlphaData.length;i++) {
			for (j=0;j<oriAlphaData[i].length;j++) {
				this.alphabetData[i][j] = oriAlphaData[i][j];
			}
		}	
		
		if (this.myFreqOpt == FreqType.DATAFREQ) {
			this.getEmpiricalPI();
			calRateMat();
		}
		
		if (myJob == JobType.READ_INFO_PAML)
			estimateESL(2, dataCompleteConcat, dataGappyConcat);
		else 
			estimateESL(1, dataCompleteConcat, dataGappyConcat);
		this.MyDerivative.analyzeDerivMeasure(true, retBeta, retParameterwiseBeta, retRho, retParameterwiseRho, valid, MyDerivative.trueGappyData, dataCompleteConcat, dataGappyConcat);
		myFunc.print(String.format("\nglobalBeta= %f, globalRho= %f",MyDerivative.globalBeta, MyDerivative.globalRho));

		double oriStat = (this.MyDerivative.globalBeta - 1.0);
			
		MyDerivative.invalidBootstrappedGBeta = MyDerivative.invalidBootstrappedGRho = 0; 
			
		MyDerivative.pBetaMin = 0.0;
		MyDerivative.pBetaMax = 2.0;
		MyDerivative.pRhoMin = 0.0;
		MyDerivative.pRhoMax = 2.0;
			
		int k = 0;
		for (j=0;j<gBetaSave.length;j++) {
			if (gBetaSave[j] < MyDerivative.pBetaMin) {
				k++;
				gBetaSave[j] = MyDerivative.pBetaMin;
			}	
			else if (gBetaSave[j] > MyDerivative.pBetaMax) {
				k++;
				gBetaSave[j] = MyDerivative.pBetaMax;
			}
		}
		MyDerivative.invalidBootstrappedGBeta = k;
			
		double[] ret = new double[2];
		myFunc.calcMeanVar(ret, gBetaSave);
		this.MyDerivative.globalBetaVar = ret[1];
		this.MyDerivative.globalBetaStd = Math.sqrt(ret[1]);
		this.MyDerivative.globalBetaStat = (MyDerivative.globalBeta-1.0)/MyDerivative.globalBetaStd;
			
		k = 0;
		for (j=0;j<gRhoSave.length;j++) {
			if (gRhoSave[j] < MyDerivative.pBetaMin) {
				k++;
				gRhoSave[j] = MyDerivative.pBetaMin;
			}	
			else if (gRhoSave[j] > MyDerivative.pBetaMax) {
				k++;
				gRhoSave[j] = MyDerivative.pBetaMax;
			}
		}
		MyDerivative.invalidBootstrappedGRho = k; 	
			
		myFunc.calcMeanVar(ret, gRhoSave);
		this.MyDerivative.globalRhoVar = ret[1];
		this.MyDerivative.globalRhoStd = Math.sqrt(ret[1]);

		this.MyDerivative.invalidBootstrappedPBeta = new int[valid.length]; // # of invalid pBeta[i] ; out of  [0,2] 
		this.MyDerivative.invalidBootstrappedPRho = new int[valid.length]; // # of invalid pRho[i]; out of  [0,1]
			
		boolean debug = false;
		for (i=0;i<valid.length;i++) {
			k = 0;			
			for (j=0;j<pBetaSave[i].length;j++) {
				if (pBetaSave[i][j] < MyDerivative.pBetaMin) {
					k++;
					pBetaSave[i][j] = MyDerivative.pBetaMin;
				}	
				else if (pBetaSave[i][j] > MyDerivative.pBetaMax) {
					k++;
					pBetaSave[i][j] = MyDerivative.pBetaMax;
				}
			}
			MyDerivative.invalidBootstrappedPBeta[i] = k;
			myFunc.calcMeanVar(ret, pBetaSave[i]);
			if (debug && (i==0||i==6||i==10||i==13||i==15))
				myFunc.printArrayRstyle(pBetaSave[i], "pBetaSave");
			this.MyDerivative.betaStd[i] = Math.sqrt(ret[1]);
			this.MyDerivative.betaStat[i] = (MyDerivative.beta[i]-1.0)/MyDerivative.betaStd[i];
				
			k = 0;			
			for (j=0;j<pRhoSave[i].length;j++) {
				if (pRhoSave[i][j] < MyDerivative.pRhoMin) {
					k++;
					pRhoSave[i][j] = MyDerivative.pRhoMin;
				}	
				else if (pRhoSave[i][j] > MyDerivative.pRhoMax) {
					k++;
					pRhoSave[i][j] = MyDerivative.pRhoMax;
				}
			}
			MyDerivative.invalidBootstrappedPRho[i] = k;
				
			myFunc.calcMeanVar(ret, pRhoSave[i]);
			if (debug && (i==0||i==13||i==15))
				myFunc.printArrayRstyle(pRhoSave[i], "pRhoSave");
			this.MyDerivative.rhoStd[i] = Math.sqrt(ret[1]);
		}
					
			

		
		//boolean debug2 = true;
		//if (debug2 && myJob != JobType.SIMUL ) {
		if (this.bootedBetaAlreadyPrinted<3) {
			myFunc.print(String.format("\n\n######Bootstrapped gBeta and gRho...\n"));
			myFunc.printArrayRstyle(gBetaSave, "gBetaSaveBootFull");
			System.out.print("qqnorm(gBetaSaveBootFull)");
			System.out.print("\nqqline(gBetaSaveBootFull)\n");
			myFunc.printArrayRstyle(gRhoSave, "gRhoSaveBootFull");		
			System.out.print("qqnorm(gRhoSaveBootFull)");
			System.out.print("\nqqline(gRhoSaveBootFull)\n");
			bootedBetaAlreadyPrinted++;
		}
			
		
		
		myFunc.calcMeanVar(ret, gBetaSave);
		for (j=0;j<bootIter;j++) {
			gBetaSave[j] -= ret[0];
		}		
		
		MyDerivative.pValueBoot = 0.0;
		for (i=0;i<bootIter;i++) {
			if (gBetaSave[i]< oriStat)
				MyDerivative.pValueBoot += 1.0;
		}
		MyDerivative.pValueBoot /= bootIter;

		/*
		if (this.multiThrId==0) {
			this.calcWeight();
			//parameterwiseXX should be recal
			this.calcRho(simulFisherInfo);
			
			if (this.myJob != JobType.SIMUL)
				printSitewiseESLInfo();

			printTreeWithRhoBeta(); 
			//printParameterWiseRhoBeta(); 
			this.MyDerivative.printInfo();
		}
		*/
		

		if (this.multiThrId==0) {
			if (this.myJob != JobType.SIMUL)
				this.MyDerivative.printGFMFInfo();
		}
		
	}
	
	
	public void calcESLBootRELL(double[][] dataCompleteConcat, double[][] dataGappyConcat) {
		
		int i, j, k;
		
			
		double oriStat;
	
		if (bootIter > 0) {
			myFunc.errPrint(String.format("\n\nBootstrapping... %d iteration",this.bootIter));
			myFunc.print(String.format("\n\nBootstrapping... %d iteration",this.bootIter));
		}

		double[][] pBetaSave = new double[valid.length][bootIter];
		double[][] pRhoSave  = new double[valid.length][bootIter];
		double[] gBetaSave = new double[bootIter];
		double[] gRhoSave = new double[bootIter];
			
		double[][] bootOri = new double[MyDerivative.trueGappyData.length][MyDerivative.trueGappyData[0].length];		
		double[][] bootFull = new double[dataCompleteConcat.length][dataCompleteConcat[0].length];
		double[][] bootGappy = new double[dataGappyConcat.length][dataGappyConcat[0].length];	
			
			
		double[] retBeta = new double[5];
		double[] retRho = new double[2];
		double[][] retParameterwiseBeta = new double[2][valid.length];
		double[][] retParameterwiseRho = new double[2][valid.length];
			
		for (j=0;j<this.bootIter;j++) {
			this.bootstrapFisherInfo_translocation(this.randSeed + j, bootOri, bootFull, bootGappy,  MyDerivative.trueGappyData, dataCompleteConcat, dataGappyConcat);
			
			// use bootstrapFisherInfo(..) if "no_ori_opt"
			//this.bootstrapFisherInfo(this.randSeed + j, bootOri, bootFull, bootGappy,  MyDerivative.trueGappyData, dataCompleteConcat, dataGappyConcat);
				
			// if original gap pattern is random use this line
			// No!! Even with this, null cdf is not unif[0,1]. 
			//this.bootstrapFisherInfo(j, bootOri, bootFull, bootGappy,  bootOri, bootFull, bootGappy);
				
				
			this.MyDerivative.analyzeDerivMeasure(true, retBeta, retParameterwiseBeta, retRho, retParameterwiseRho, valid, bootOri, bootFull, bootGappy);
				
			gBetaSave[j] = this.MyDerivative.globalBeta;
			gRhoSave[j] = this.MyDerivative.globalRho;

			for (i=0;i<valid.length;i++) {
				pBetaSave[i][j] = retParameterwiseBeta[0][i];
				pRhoSave[i][j] = retParameterwiseRho[0][i];
			}
		}

		this.MyDerivative.analyzeDerivMeasure(true, retBeta, retParameterwiseBeta, retRho, retParameterwiseRho, valid, MyDerivative.trueGappyData, dataCompleteConcat, dataGappyConcat);
		oriStat = (this.MyDerivative.globalBeta - 1.0);
			
		MyDerivative.invalidBootstrappedGBeta = MyDerivative.invalidBootstrappedGRho = 0; 
			
		MyDerivative.pBetaMin = 0.0;
		MyDerivative.pBetaMax = 2.0;
		MyDerivative.pRhoMin = 0.0;
		MyDerivative.pRhoMax = 2.0;
			
		k = 0;
		for (j=0;j<gBetaSave.length;j++) {
			if (gBetaSave[j] < MyDerivative.pBetaMin) {
				k++;
				gBetaSave[j] = MyDerivative.pBetaMin;
			}	
			else if (gBetaSave[j] > MyDerivative.pBetaMax) {
				k++;
				gBetaSave[j] = MyDerivative.pBetaMax;
			}
		}
		MyDerivative.invalidBootstrappedGBeta = k;
			
		double[] ret = new double[2];
		myFunc.calcMeanVar(ret, gBetaSave);
		this.MyDerivative.globalBetaVar = ret[1];
		this.MyDerivative.globalBetaStd = Math.sqrt(ret[1]);
		this.MyDerivative.globalBetaStat = (MyDerivative.globalBeta-1.0)/MyDerivative.globalBetaStd;
			
		k = 0;
		for (j=0;j<gRhoSave.length;j++) {
			if (gRhoSave[j] < MyDerivative.pBetaMin) {
				k++;
				gRhoSave[j] = MyDerivative.pBetaMin;
			}	
			else if (gRhoSave[j] > MyDerivative.pBetaMax) {
				k++;
				gRhoSave[j] = MyDerivative.pBetaMax;
			}
		}
		MyDerivative.invalidBootstrappedGRho = k; 	
			
		myFunc.calcMeanVar(ret, gRhoSave);
		this.MyDerivative.globalRhoVar = ret[1];
		this.MyDerivative.globalRhoStd = Math.sqrt(ret[1]);

		this.MyDerivative.invalidBootstrappedPBeta = new int[valid.length]; // # of invalid pBeta[i] ; out of  [0,2] 
		this.MyDerivative.invalidBootstrappedPRho = new int[valid.length]; // # of invalid pRho[i]; out of  [0,1]
			
		boolean debug = false;
		for (i=0;i<valid.length;i++) {
			k = 0;			
			for (j=0;j<pBetaSave[i].length;j++) {
				if (pBetaSave[i][j] < MyDerivative.pBetaMin) {
					k++;
					pBetaSave[i][j] = MyDerivative.pBetaMin;
				}	
				else if (pBetaSave[i][j] > MyDerivative.pBetaMax) {
					k++;
					pBetaSave[i][j] = MyDerivative.pBetaMax;
				}
			}
			MyDerivative.invalidBootstrappedPBeta[i] = k;
			myFunc.calcMeanVar(ret, pBetaSave[i]);
			if (debug && (i==0||i==6||i==10||i==13||i==15))
				myFunc.printArrayRstyle(pBetaSave[i], "pBetaSave");
			this.MyDerivative.betaStd[i] = Math.sqrt(ret[1]);
			this.MyDerivative.betaStat[i] = (MyDerivative.beta[i]-1.0)/MyDerivative.betaStd[i];
				
			k = 0;			
			for (j=0;j<pRhoSave[i].length;j++) {
				if (pRhoSave[i][j] < MyDerivative.pRhoMin) {
					k++;
					pRhoSave[i][j] = MyDerivative.pRhoMin;
				}	
				else if (pRhoSave[i][j] > MyDerivative.pRhoMax) {
					k++;
					pRhoSave[i][j] = MyDerivative.pRhoMax;
				}
			}
			MyDerivative.invalidBootstrappedPRho[i] = k;
				
			myFunc.calcMeanVar(ret, pRhoSave[i]);
			if (debug && (i==0||i==13||i==15))
				myFunc.printArrayRstyle(pRhoSave[i], "pRhoSave");
			this.MyDerivative.rhoStd[i] = Math.sqrt(ret[1]);
		}
				
		
		//boolean debug2 = true;
		//if (debug2 && myJob != JobType.SIMUL ) {
		//if (debug2) {
		if (this.bootedBetaAlreadyPrinted<3) {
			myFunc.print(String.format("\n\n######Bootstrapped gBeta and gRho...\n"));
			myFunc.printArrayRstyle(gBetaSave, "gBetaSaveBootRELL");
			myFunc.print("\nqqnorm(gBetaSaveBootRELL)");
			myFunc.print("\nqqline(gBetaSaveBootRELL)\n");
			myFunc.printArrayRstyle(gRhoSave, "gRhoSaveBootRELL");	
			myFunc.print("\nqqnorm(gRhoSaveBootRELL)");
			myFunc.print("\nqqline(gRhoSaveBootRELL)\n");
			this.bootedBetaAlreadyPrinted++;
		}
		
			
		myFunc.calcMeanVar(ret, gBetaSave);
		for (j=0;j<bootIter;j++) {
			gBetaSave[j] -= ret[0];
		}		
		
		MyDerivative.pValueBoot = 0.0;
		for (i=0;i<bootIter;i++) {
			if (gBetaSave[i]< oriStat)
				MyDerivative.pValueBoot += 1.0;
		}
		MyDerivative.pValueBoot /= bootIter;

		
		/*
		if (this.multiThrId==0) {

			this.calcWeight();
			
			//parameterwiseXX should be recal
			this.calcRho(simulFisherInfo);
			
			if (this.myJob != JobType.SIMUL)
				printSitewiseESLInfo();

			printTreeWithRhoBeta(); 
			//printParameterWiseRhoBeta(); 
			this.MyDerivative.printInfo();
			
		}
		*/
		
		if (this.multiThrId==0) {
			if (this.myJob != JobType.SIMUL) {
				myFunc.printArrayRstyle(this.taxonwiseGapProp, "taxonwiseGapProp");
				myFunc.print(String.format("\r\n###Proportion of meaningful characters of each taxon"));
				for (i=0;i<this.taxaNameList.length;i++) {
					myFunc.print(String.format("\r\ni=%d, %s : %f", i, taxaNameList[i], 1.0 - taxonwiseGapProp[i]));
				}
				this.MyDerivative.printGFMFInfo();
			}
		}
		
		////////////////////////////////////////////////////////////////////////////
		/// this is for debugging
		/// for checking symmetry of pBeta
		/*
		if (this.myJob != JobType.SIMUL) { 
			String str = this.oriSeqFile + "_pBeta.txt";
			try {
				FileWriter fout = new FileWriter(str);
				fout.write(String.format("\r\n\r\n### Input Options ###"));
				for (String s : this.optString) {
					fout.write(String.format("\n"));
					fout.write(s);
				}
				
				fout.write(String.format("\r\n\r\nTree branch information (check if reorderBrIdx() was run)"));
				for (i=0;i<this.brPos.length;i++) {
					fout.write(String.format("\r\nbr%d : %d <--> %d ", i, brPos[i].nodeNum, brPos[i].desNd.nodeNum));
					if (brPos[i].desNd.isoNd == null) {
						fout.write(String.format("; terminal br to %s", brPos[i].desNd.taxonName));
					}
					else {
						fout.write(String.format("; MRCA of %s and %s", this.getLeftBottomTaxon(brPos[i].desNd.isoNd), this.getRightBottomTaxon(brPos[i].desNd.isoNd.isoNd) ));
					}
				}
				
				fout.write(String.format("\r\n\r\nBootstrapped p-ESL  ")); // (input options)
				for (i=0;i<pBetaSave.length;i++) {
					fout.write(String.format("\r\nbr%d : %d <--> %d ", i, brPos[i].nodeNum, brPos[i].desNd.nodeNum));
					if (brPos[i].desNd.isoNd == null) {
						fout.write(String.format("; terminal br to %s", brPos[i].desNd.taxonName));
					}
					else {
						fout.write(String.format("; MRCA of %s and %s", this.getLeftBottomTaxon(brPos[i].desNd.isoNd), this.getRightBottomTaxon(brPos[i].desNd.isoNd.isoNd) ));
					}
					myFunc.printArrayRstyle(fout, pBetaSave[i], String.format("pBeta%d", i));
				}
				fout.close();
			}
			catch (IOException e) {
				myFunc.print(String.format("\n%s error", str));
			}
		}
		*/
		/// this is for debugging
		/// for checking symmetry of pBeta
		////////////////////////////////////////////////////////////////////////////

	}

	
	

	@Override
	public void getSolution() {
		

		
	}




	@Override
	public void printResult() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void optMultiTree() {
		
		this.getOption();
		
		LoadSeqFile(oriSeqFile);
		sortData();
		
		String[] topo = new String[1];
		
		int i;
		for (i=0;i<this.topoList.size();i++) {
			System.out.printf(String.format("\n%dth tree: %s", i, topoList.get(i)));
			buildTree(topoList.get(i));
			InitML();
			initParams();
			calcLogLike();
			System.out.print("\nBefore opt logLike=" + logLike);
			optimizeSub_pruning(true);
			calcLogLike();
			System.out.print("\nAfter opt logLike=" + logLike);
			getTree(topo);
			myFunc.print(String.format("\n%s",topo[0]));
			//myFunc.print(String.format("alpha=%f, kappa1=%f, kappa2=%f", this.alpha, this.rateParam[2], this.rateParam[3]));
			
		}
	}
	
	
	public void readFisherInfo() {
		
		String fileName = new String();
		fileName = this.oriSeqFile+"_2ndDeriv_in.txt";
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileName);
			Scanner scanner = new Scanner(fis);
			
			String[] splitStr;
			int i;
			
			/*
			String s = scanner.nextLine(); // logLike=XXXXX
			int iter = brParam.length;
			for (i=0;i<iter;i++) {
				s = scanner.nextLine(); // 2nd_Deriv_brParam[x]=xxxx
				s.trim();
				splitStr = s.split("\\s+");
				brParamHess[i] = Double.valueOf(splitStr[1]);
				brParam[i] =  Double.valueOf(splitStr[3]);
			}
			s = scanner.nextLine(); // Alpha_estimate=xxxx
			s.trim();
			splitStr = s.split("\\s+");
			this.alpha = Double.valueOf(splitStr[1]);
			s = scanner.nextLine(); // tree topology
			*/
			
			/////
			
			String s = scanner.nextLine(); // logLike=XXXXX
			int iter = brParam.length;
			for (i=0;i<iter;i++) {
				s = scanner.nextLine(); // 2nd_Deriv_brParam[x]=xxxx
			}
			s = scanner.nextLine(); // Alpha_estimate= xxxx
			s.trim();
			splitStr = s.split("\\s+");
			this.alpha = Double.valueOf(splitStr[1]);
			this.setAlpha(this.alpha);			
			
			oriTopo = scanner.nextLine(); // tree topology
			buildTree(oriTopo);	
			
			s = scanner.nextLine(); // blank
			s = scanner.nextLine(); // oriFisherInfo, simulFisherInfo, validInfo
			iter = oriFisherInfo.length;
			for (i=0;i<iter;i++) {
				s = scanner.nextLine(); // 2nd_Deriv_brParam[x]=xxxx
				s.trim();
				splitStr = s.split("\\s+");
				oriFisherInfo[i] = Double.valueOf(splitStr[1]);
				simulFisherInfo[0][i] = Double.valueOf(splitStr[2]);
				simulFisherInfo[1][i] = Double.valueOf(splitStr[3]);
				valid[i] = Boolean.valueOf(splitStr[4]);
			}
			
			/*
			s = scanner.nextLine(); // blank
			s = scanner.nextLine(); // sitewiseLogLike_deriv2[..]
			iter = this.sitewiseLogLike_deriv2.length;
			for (i=0;i<iter;i++) {
				s = scanner.nextLine(); // sitewiseLogLike_deriv2[j]=  xxxx
				s.trim();
				splitStr = s.split("\\s+");
				sitewiseLogLike_deriv2[i] = Double.valueOf(splitStr[1]);
			}
			*/
			
			scanner.close();
			
		}
		catch (IOException e) {
			System.out.println(e);
			myFunc.print(String.format("\ncheck %s", fileName));
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
		
		
	}

	public void readInfo_paml() {
		// read data from paml
		
		String fileName = new String();
		fileName = this.oriSeqFile+"_paml_res.txt";
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileName);
			Scanner scanner = new Scanner(fis);
			
			String[] splitStr;
			int i;
			
			String s;
			do {
				s = scanner.nextLine();
				s.trim();
				splitStr = s.split("\\s+");
			} while ( !( splitStr[0].equals("tree")&&splitStr[1].equals("length") ) );
			
			s = scanner.nextLine(); // blank
			s = scanner.nextLine(); // "((((1: 0.xxx, 2: 0.xxx):..."
			s = scanner.nextLine(); // blank
			s = scanner.nextLine(); // "((((Taxon1: 0.xxx, Taxon2: 0.xxx)..."
			s.trim();
			splitStr = s.split("\\s+");
			
			s = "";
			for (i=0;i<splitStr.length;i++) {
				s += splitStr[i];
			}
			
			oriTopo = s; // tree topology
			buildTree(oriTopo);	
			
			s = scanner.nextLine(); // blank
			s = scanner.nextLine(); // "Detailed output identifying parameters"
			s = scanner.nextLine(); // blank
			s = scanner.nextLine(); // "alpha (gamma, K = 5) =  0.xxxx"
			s.trim();
			splitStr = s.split("\\s+");
			this.alpha = Double.valueOf(splitStr[6]);
			this.setAlpha(this.alpha);		
	
			scanner.close();
			
		}
		catch (IOException e) {
			System.out.println(e);
			myFunc.print(String.format("\ncheck %s", fileName));
			System.exit(0);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
		
		
	}
	

	
	public void copy2ndDeriv(double[] tmp) {
		int i;
		for (i=0;i<tmp.length;i++) {
			this.brParamHess[i] = tmp[i];
		}
	}
	
	public void backup2ndDeriv(double[] tmp) {
		int i;
		for (i=0;i<brParamHess.length;i++) {
			tmp[i] = this.brParamHess[i];
		}
	}

	public void estimateESL_sub_generateRandSeq(boolean simulData, double[][] dataCompleteConcat, double[][] dataGappyConcat) {
		
		int i, j, k;
		
		for (i=0;i<oriFisherInfo.length;i++) {
			simulFisherInfo[0][i] = simulFisherInfo[1][i] = 0.0;
		}
		
		for (i=0;i<this.simulGappyFisherInfoInvCov.length;i++) {
			for (j=0;j<this.simulGappyFisherInfoInvCov[0].length;j++) {
				this.simulGappyFisherInfoInvCov[i][j] = 0.0;
			}
		}
		
		
		//double[] sumBetaVarNumeratorBoot, sumBetaNumeratorBoot, sumTestStatBoot;
		//double sumBetaVarNumeratorOri, sumBetaNumeratorOri;
		//double sumTestStat;
		//int bootIter = 200;
		//sumBetaVarNumeratorBoot = new double[bootIter];
		//sumBetaNumeratorBoot = new double[bootIter];
		//sumTestStatBoot  = new double[bootIter];

		double[][] bootDistSimulFull;
		double[][] bootDistSimulGappy;
		int[] bootIdx;
		bootDistSimulFull = new double[valid.length][bootIter];
		bootDistSimulGappy = new double[valid.length][bootIter];
		for (i=0;i<bootDistSimulFull.length;i++) {
			for (j=0;j<bootDistSimulFull[i].length;j++) {
				bootDistSimulFull[i][j] = bootDistSimulGappy[i][j] = 0.0;
			}
		}
		
		
		/*
		for (i=0;i<oriFisherInfo.length;i++) {
			oriFisherInfo[i] /= this.seqLength;
		}
		*/

		int oriSeqLength = this.seqLength;
		
		///// generating complete data sets
		
		this.seqLength = oriSeqLength * this.simulLengthTimes;
		//int extremelyLargeLength = 5000;
		
		int iter;
		iter = this.simulLengthTimes2 % this.simulLengthTimes;
		
		if (iter != 0) {
			System.err.print("\n3rd of <simul length> should be multiple of 2nd.. ");
			System.exit(0);
		}
		iter = this.simulLengthTimes2 / this.simulLengthTimes;
		
		/*
		long time_start, time_end;
		time_start = System.currentTimeMillis();
		*/
		if (this.multiThrId==0)
			myFunc.errPrint(String.format("\nProgram will end when %d points are shown.\n", iter));
		
		//Path cwd = Path.of("").toAbsolutePath(); 
		File cwd = new File("").getAbsoluteFile();
		myFunc.errPrint(String.format("\nCurrent working dir: ") + cwd + "\r\n\r\n");

		double[][] sitewise2ndDerivTotSimulated = new double[this.brParam.length][this.seqLength];
		double[][] dataComplete = new double[sitewise2ndDerivTotSimulated.length][sitewise2ndDerivTotSimulated[0].length];
		double[][] dataGappy  = new double[sitewise2ndDerivTotSimulated.length][sitewise2ndDerivTotSimulated[0].length];
		
		//retBeta[0] : beta
		//retBeta[1] : variance of beta
		//retBeta[2] : denominator of beta; numerator == retBeta[0]*retBeta[2];
		//retBeta[3] : variance of numerator of Beta; its variance == retBeta[1]*retBeta[2]*retBeta[2];
		//parameterwiseBeta[0][paramID]: beta
		//parameterwiseBeta[1][paramID]: variance of beta
		//retRho[0] : rho
		//retRho[1] : variance of rho
		//parameterwiseRho[0][paramID]: rho
		//parameterwiseRho[1][paramID]: variance of rho
	
		//copyGapPatternFromOriginalData();
		bootIdx = new int[this.MyDerivative.trueGappyData[0].length];
		this.generateBootIndex(false, -1, bootIdx);
		
		for (i=0;i<iter;i++) {
			
			System.gc();
			
			if (this.multiThrId==0)
				myFunc.errPrint(String.format(". %dth",i));
			
			this.recoverBackupedEstimates();
			generateRandSeq(i); 
			// no need to update topo
			// no need to update alpha
		
			
			boolean randOpt = false; // do not use this unless original analysis optimize long simulated sequences. 
			if (randOpt) {
				optimizeRandomSeq();
				this.sitewise2ndDerivTot = new double[this.brParam.length][this.alphabetDataPatternNum.length];
				calc2ndDeriv(false, sitewise2ndDerivTotSimulated); //simulData = false
			}
			else {
				InitML();	
				this.setRecalNeeded();
				this.calcLogLike();
				
				calc2ndDeriv(simulData, sitewise2ndDerivTotSimulated);
			}
			

			
			this.printProcess(i, iter, "complete");
			
			for (j=0;j<simulFisherInfo[0].length;j++) {
				simulFisherInfo[0][j] += -brParamHess[j]; // sum should be cumulative because for (i=0;i<iter;i++) 
			}
			
			for (j=0;j<sitewise2ndDerivTotSimulated.length;j++) {
				for (k=0;k<sitewise2ndDerivTotSimulated[j].length;k++) {
					dataComplete[j][k] = - sitewise2ndDerivTotSimulated[j][k];
				}
			}

			
			///////
			/// make imaginary gappy data
			///
			
			//if (randOpt)
				//this.recoverBackupedEstimates();
			//generateRandSeq(i); // do not use this; this makes gappy data independent from full data; 
			
			//copyGapPatternFromOriginalData();
			this.importGapPattern(bootIdx, this.MyDerivative.gapInfo);
			
			////////////////////////////////////////////////
			//print randomly generated sequences....
			//print randomly generated sequences....
			//print randomly generated sequences....
			//printRandSeq();  System.exit(0);
			///////////////////////////////////////////
			
			boolean randOpt2 = false;
			if (randOpt2) {
				optimizeRandomSeq();
				this.sitewise2ndDerivTot = new double[this.brParam.length][this.alphabetDataPatternNum.length];
				calc2ndDeriv(false, sitewise2ndDerivTotSimulated); //simulData = false
			}
			else {
				InitML();	
				this.setRecalNeeded();
				this.calcLogLike();
				
				calc2ndDeriv(simulData, sitewise2ndDerivTotSimulated);
			}
			
			
			for (j=0;j<sitewise2ndDerivTotSimulated.length;j++) {
				for (k=0;k<sitewise2ndDerivTotSimulated[j].length;k++) {
					dataGappy[j][k] = - sitewise2ndDerivTotSimulated[j][k];
				}
			}

			for (j=0;j<dataComplete.length;j++) {
				for (k=0;k<dataComplete[j].length;k++) {
					dataCompleteConcat[j][i*this.seqLength+k] = dataComplete[j][k];
					dataGappyConcat[j][i*this.seqLength+k] = dataGappy[j][k];
				}
			}
			
			
			for (j=0;j<simulFisherInfo[1].length;j++) {
				simulFisherInfo[1][j] += -brParamHess[j]; // sum should be cumulative because for (i=0;i<iter;i++) 
			}
			
		
			
			this.printProcess(i, iter, "gappy");
			
			
			
			if (i%50==0) {
				/*
				time_end = System.currentTimeMillis();
				long ElapsedSec = (time_end - time_start)/1000;
				String message = String.format("\n  %02d:%02d:%02d", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
				System.err.print(message);
				*/
			}
		}  // for (i=0;i<iter;i++) {
		

		
		
		
		this.seqLength = oriSeqLength;
		
		this.alphabetData = new char[this.alphabetDataOri.length][alphabetDataOri[0].length];
		this.alphabetDataPatternNum = new int[this.alphabetDataPatternNumOri.length];
		for (i=0;i<this.alphabetDataPatternNumOri.length;i++) {
			this.alphabetDataPatternNum[i] = this.alphabetDataPatternNumOri[i];
			for (j=0;j<this.taxaNum;j++) {
				this.alphabetData[j][i] = this.alphabetDataOri[j][i];
			}
		}
		
		for (i=0;i<brParamHessOri.length;i++) {
			brParamHess[i] = brParamHessOri[i];
		}
		
		
		for (j=0;j<simulFisherInfo[0].length;j++) {
			simulFisherInfo[0][j] /= oriSeqLength * this.simulLengthTimes2; 
			simulFisherInfo[1][j] /= oriSeqLength * this.simulLengthTimes2;
		}
		

		
	}
	
	public void Print2ndDerivFile() {

		//if (this.myJob != JobType.SIMUL) {
			String fileName = new String();
			fileName = this.oriSeqFile+ nameTag + "_2ndDeriv.txt";
			//fileName = this.oriSeqFile+"_2ndDeriv.txt";
			int i, iter;
			iter = brParamHess.length;
			FileWriter fout = null;
			try {
				String[] topo = new String[4];
				this.getTree(topo);
				
				fout = new FileWriter(fileName);
				
				fout.write(String.format("### Fisher information of data ###"));
				fout.write(String.format("\r\nInfo[brID]: oriFisherInfo, simulFisherInfo[0], simulFisherInfo[1], JMatrix(diag) validInfo ; //[0] complete, [1] imaginary gappy")); 
				for (i=0;i<iter;i++) {
					fout.write(String.format("\r\nInfo[%d]:  %.15f  %.15f %.15f  %.15f %b",i, oriFisherInfo[i], simulFisherInfo[0][i], simulFisherInfo[1][i],JMatrix[i], valid[i] ));
				}
				
				fout.write(String.format("\r\n\r\n### Hessian information ###"));
				fout.write(String.format("\r\nlogLike= %f", this.logLike));
				for (i = 0; i < iter; i++) {
					fout.write(String.format("\r\n2nd_Deriv_brParam[%d]= %f | %f", i, brParamHess[i], brParam[i]));
					if (!valid[i]) 
						fout.write(String.format(" => NA"));
				}	
				fout.write(String.format("\r\nAlpha_estimate = %f", this.alpha));
				fout.write(String.format("\r\nEstimated phylogeny: %s",topo[0]));				
	
				


				
				if (this.subsModel == ModelType.TN93 || this.subsModel ==  ModelType.GTR) {
					fout.write(String.format("\n\nEstimates under nucleotide model"));
					fout.write(String.format("\nrateParam[0] = %f; %c<->%c", rateParam[0], alphabetVec.get(0), alphabetVec.get(1) ));
					fout.write(String.format("\nrateParam[1] = %f; %c<->%c", rateParam[1], alphabetVec.get(0), alphabetVec.get(2) ));
					fout.write(String.format("\nrateParam[2] = %f; %c<->%c", rateParam[2], alphabetVec.get(0), alphabetVec.get(3) ));
					fout.write(String.format("\nrateParam[3] = %f; %c<->%c", rateParam[3], alphabetVec.get(1), alphabetVec.get(2) ));
					fout.write(String.format("\nrateParam[4] = %f; %c<->%c", rateParam[4], alphabetVec.get(1), alphabetVec.get(3) ));
					fout.write(String.format("\nrateParam[5] = %f; %c<->%c \r\n", rateParam[5], alphabetVec.get(2), alphabetVec.get(3) ));
					for (i=0;i<rateParam.length;i++) 
						fout.write(String.format("%f ", rateParam[i] ));
					
					fout.write(String.format("\r\n "));
					for (i=0;i<this.PI.length;i++) {
						char c = ' ';
						switch(i) {
							case 0: c = 'A'; break;
							case 1: c = 'C'; break;
							case 2: c = 'T'; break;
							case 3: c = 'G'; break;
							default: System.exit(0);
						}
						fout.write(String.format("\nPI[%d] = %f // %c", i, PI[i], c));
					}
				
				}
				
				//fout.write(String.format("\n%s",topo[1]));



				this.PrintTreeTopo(fout);
				
				fout.write(String.format("\r\n\r\n### Input Options ###"));
				for (String s : this.optString) {
					fout.write(String.format("\n"));
					fout.write(s);
				}
				
				
				/*
				fout.write(String.format("\n"));
				fout.write(String.format("\nsitewiseLogLike_deriv2[..] ")); 
				iter = this.sitewiseLogLike_deriv2.length;
				for (i=0;i<iter;i++) {
					fout.write(String.format("\nsitewiseLogLike_deriv2[%d]=  %.15f ",i, sitewiseLogLike_deriv2[i] ));
				}
				*/

				fout.write(String.format("\n")); 
				
			}
			catch (IOException e) {
				System.out.println(e);
			} finally {
				try {
					fout.close();
				} catch (IOException e) {
					System.out.println(e);
				} catch (NullPointerException e) {
					System.out.println(e);
				}
			}
			
			if (this.multiThrId==0)
				this.PrintSitewiseGapPropLoglike();
			
			
			
		//}

		

		/*
		myFunc.print(String.format("\n"));
		myFunc.print(String.format("\nseq-gen.v1.3.2 -mWAG -g5 -a%f  -l1000 -n1 -z1  < %s > %s\n\n", 
				alpha, this.oriSeqFile+"_esttree.txt", this.oriSeqFile+"_longseq.txt" ));
		*/

		// save seq-gen commands in batch file and run
		/*
		fileName = "my_job.bat";
		try {
			FileWriter fout = new FileWriter(fileName);
			str = String.format("seq-gen.v1.3.2 -mWAG -g5 -a%f  -l1000 -n1 -z1  < %s > %s", 
					alpha, this.oriSeqFile+"_esttree.txt", this.oriSeqFile+"_longseq.txt \n exit \n ");
		
			fout.write(str);
			fout.close();
		}
		catch (IOException e) {
			myFunc.print(String.format("\n%s error", fileName));
		}
		
		try
	    { 
			 //String mes = "cmd /c start \"\" my_job.bat";
			String mes = "cmd /c start my_job.bat";
			//String mes = "";
			Runtime.getRuntime().exec(mes);
	    } 
		catch (Exception e) 
		{ 
			System.out.println("Something Wrong in Runtime.getRuntime().exec(..) "); 
			e.printStackTrace(); 
		} 
		*/
		
		
		
	
	}
	
	

	public void printRandSeq(String fileName) {
		
		
		FileWriter fout = null;
		try {

			fout = new FileWriter(fileName);
			
			int i,j;
	
			//fout.write(String.format("\r\n\r\nTotal data\r\n")); 
			fout.write(String.format("%d %d", taxaNameList.length, alphabetData[0].length));
			int showLength;
			//showLength = 100; 
			showLength = alphabetData[0].length;
			if (showLength > alphabetData[0].length)
				showLength = alphabetData[0].length;
			//myFunc.print(String.format("\r\n(Only first %d sites are shown...)", showLength));
			for (i=0;i<taxaNameList.length;i++) {
				fout.write(String.format("\r\n%s   ", taxaNameList[i]));
				for (j=0;j<showLength;j++) {
					fout.write(String.format("%c", alphabetData[i][j]));
				}
			}
	
			/*
			myFunc.print(String.format("\r\n\r\nData X"));
			myFunc.print(String.format("\r\n%d %d", taxaNameList.length, alphabetData[0].length/2));
			for (i=0;i<taxaNameList.length;i++) {
				myFunc.print(String.format("\r\n%s   ", taxaNameList[i]));
				for (j=0;j<showLength;j++) {
					myFunc.print(String.format("%c", alphabetData[i][j]));
				}
			}
	
			myFunc.print(String.format("\r\n\r\nData Y"));
			myFunc.print(String.format("\r\n%d %d", taxaNameList.length, alphabetData[0].length/2));
			for (i=0;i<taxaNameList.length;i++) {
				myFunc.print(String.format("\r\n%s   ", taxaNameList[i]));
				for (j=alphabetData[i].length/2;j<Math.min(alphabetData[i].length/2 + showLength,alphabetData[i].length) ;j++) {
					myFunc.print(String.format("%c", alphabetData[i][j]));
				}
			}
			*/
		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fout.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
		
	}


	public void printRandSeq() {
		int i,j;

		myFunc.print(String.format("\r\n\r\nTotal data"));
		myFunc.print(String.format("\r\n%d %d", taxaNameList.length, alphabetData[0].length));
		int showLength;
		//showLength = 100; 
		showLength = alphabetData[0].length;
		if (showLength > alphabetData[0].length)
			showLength = alphabetData[0].length;
		myFunc.print(String.format("\r\n(Only first %d sites are shown...)", showLength));
		for (i=0;i<taxaNameList.length;i++) {
			myFunc.print(String.format("\r\n%s   ", taxaNameList[i]));
			for (j=0;j<showLength;j++) {
				myFunc.print(String.format("%c", alphabetData[i][j]));
			}
		}

		/*
		myFunc.print(String.format("\r\n\r\nData X"));
		myFunc.print(String.format("\r\n%d %d", taxaNameList.length, alphabetData[0].length/2));
		for (i=0;i<taxaNameList.length;i++) {
			myFunc.print(String.format("\r\n%s   ", taxaNameList[i]));
			for (j=0;j<showLength;j++) {
				myFunc.print(String.format("%c", alphabetData[i][j]));
			}
		}

		myFunc.print(String.format("\r\n\r\nData Y"));
		myFunc.print(String.format("\r\n%d %d", taxaNameList.length, alphabetData[0].length/2));
		for (i=0;i<taxaNameList.length;i++) {
			myFunc.print(String.format("\r\n%s   ", taxaNameList[i]));
			for (j=alphabetData[i].length/2;j<Math.min(alphabetData[i].length/2 + showLength,alphabetData[i].length) ;j++) {
				myFunc.print(String.format("%c", alphabetData[i][j]));
			}
		}
		*/
		
	}


	public void calcWeight() {
		
		int i;
		double sum = 0.0;
		
		//calculating w_demon
		//this.w_denom = 0.0;
		/*
		for (i=0;i<simulFisherInfo[0].length;i++) {
			if (valid[i]) {
				this.w_denom += simulFisherInfo[0][i]*simulFisherInfo[0][i];
			}
		}
		*/
		
		this.weightForRho = new double[simulFisherInfo[0].length];
		sum = 0.0;
		for (i=0;i<simulFisherInfo[0].length;i++) {
			if (valid[i]) {
				this.weightForRho[i] = simulFisherInfo[0][i]*simulFisherInfo[0][i];
				sum += this.weightForRho[i];
			}
			else
				this.weightForRho[i] = 0.0;
		}
		for (i=0;i<simulFisherInfo[0].length;i++) {
			if (valid[i]) {
				this.weightForRho[i] /= sum;
			}
			else
				this.weightForRho[i] = 0.0;
		}
		
		this.weightForBeta = new double[simulFisherInfo[0].length];
		sum = 0.0;
		for (i=0;i<simulFisherInfo[0].length;i++) {
			if (valid[i]) {
				this.weightForBeta[i] = simulFisherInfo[0][i]*simulFisherInfo[1][i];
				sum += this.weightForBeta[i];
			}
			else
				this.weightForBeta[i] = 0.0;
		}
		for (i=0;i<simulFisherInfo[0].length;i++) {
			if (valid[i]) {
				this.weightForBeta[i] /= sum;
			}
			else
				this.weightForBeta[i] = 0.0;
		}

	}
	
	public void calcGlobalBeta(double[] ret) {
		// ret[0] : beta
		// ret[1] : std
		
	}
	
	
	
	public void printSitewiseLoglike(int tag) {
		
		boolean printOut = false;
		
		if (printOut) {
			int i;
			myFunc.print(String.format("\nsitewiseLoglike%d <- c(",  tag));
			for (i=0;i<this.sitewiseLogLike.length;i++) {
				if (i!=0 && i%20==0) 
					myFunc.print(String.format("\n"));
				myFunc.print(String.format("%f",this.sitewiseLogLike[i]));
				if (i!=this.sitewiseLogLike.length-1)
					myFunc.print(String.format(", "));
				else 
					myFunc.print(String.format(")\n "));
				
			}
		}

	}
	
	
	public void printSitewiseESLInfo() {
		printSitewiseESLInfo_sub1(); // detail results of s-ESL and others
		printSitewiseESLInfo_sub2(); // only s-ESL, p-ESL, sp-ESL
		
		//printSitewiseESLInfo_old(); // printSitewiseESLInfo_sub1() + printSitewiseESLInfo_sub2()
	}
	
	public void printSitewiseESLInfo_sub1() {
		// print to file
		int i,j,k;
		double sum;
		int invalidCount = 0;
		
		if (this.myJob != JobType.SIMUL) {
			String fileName = new String();
			fileName = this.oriSeqFile + nameTag + "_sp-ESL_info.txt";
			String fileName2 = this.oriSeqFile + nameTag + "_sp-ESL_score_only.txt";
			try {
				FileWriter fout = new FileWriter(fileName);
				
				fout.write(String.format("### Input Options ###"));
				for (String s : this.optString) {
					fout.write(String.format("\n"));
					fout.write(s);
				}
				
				fout.write(String.format("\r\n\n### Taxa list and proportion of meaningful characters"));
				for (i=0;i<this.taxaNameList.length;i++) 
					fout.write(String.format("\r\n#i=%d, %s, %f ", i, this.taxaNameList[i], 1.0 - taxonwiseGapProp[i])); 
				
				fout.write(String.format("\r\n\r\n### Sitewise ESL (unsorted) ###")); 
				//fout.write(String.format("\n# site num | column pattern | pattern number | sitewise ESL")); 
				fout.write(String.format("\n# site num | column pattern | sitewise ESL")); 
				for (i=0;i<this.alphabetDataPatternNumOri.length;i++) {
					fout.write(String.format("\n#%dth site: ",i)); 
					for (j=0;j<this.alphabetDataOri.length;j++) {
						fout.write(String.format("%c",this.alphabetDataOri[j][i])); 
					}
					//fout.write(String.format(" | %d",this.alphabetDataPatternNumOri[i]));
					fout.write(String.format(" | %f",this.sitewiseESL[i]));
				}
				
				// sorted s-ESL...
				
				double[] tmpSitewiseESL = new double[this.sitewiseESL.length];
				int[] tmpIdx = new int[this.sitewiseESL.length];
				for (i=0;i<tmpSitewiseESL.length;i++) {
					tmpSitewiseESL[i] = this.sitewiseESL[i];
				}
				tmpIdx = myFunc.doubleArraySortDescend(tmpSitewiseESL);
				
				fout.write(String.format("\r\n\r\n### Sitewise ESL (sorted, start) ###")); 
				//fout.write(String.format("\r\n site num | column pattern | pattern number | sitewise ESL | brID(max sp-ESL), brID(min sp-ESL)")); 
				fout.write(String.format("\r\n site num | column pattern | sitewise ESL | brID(max sp-ESL), brID(min sp-ESL)")); 
				fout.write(String.format("\r\n                       1         2         3         4         5         6")); 
				fout.write(String.format("\r\n              123456789012345678901234567890123456789012345678901234567890")); 
				for (i=0;i<this.alphabetDataPatternNumOri.length;i++) {
					fout.write(String.format("\n#i=%d | %dth site: ",i,tmpIdx[i])); 
					for (j=0;j<this.alphabetDataOri.length;j++) {
						fout.write(String.format("%c",this.alphabetDataOri[j][tmpIdx[i]])); 
					}
					//fout.write(String.format(" | %d",this.alphabetDataPatternNumOri[tmpIdx[i]]));
					fout.write(String.format(" | %f",this.sitewiseESL[tmpIdx[i]]));
					
					// find min and max sp-ESL at the site
					
					int maxIdx=-1;
					double maxVal=-1.0e10;
					int minIdx = -1;
					double minVal = 1.0e10;
					invalidCount = 0;
					for (int r=0;r<this.spESL.length;r++ ) {
						if (valid[r]) {
							if (maxVal < this.spESL[r][tmpIdx[i]]) {
								maxIdx = r;
								maxVal = this.spESL[r][tmpIdx[i]];
							}
							if (minVal > this.spESL[r][tmpIdx[i]]) {
								minIdx = r;
								minVal = this.spESL[r][tmpIdx[i]];
							}
						}
						else {
							invalidCount++;
						}
					}
					fout.write(String.format(" | br%d(%f), br%d(%f)",maxIdx, maxVal , minIdx, minVal ));
				}
				
				fout.write(String.format("\r\n\r\n#### Sitewise ESL (sorted, end) #####"));
				
				
				// notice of validity 	
				if (invalidCount != 0) {
					fout.write(String.format("\r\n\r\n### Warning: Some branches were ignored. ")); 
					for (j=0;j<brParam.length;j++) {
						if (valid[j]==false) {
							fout.write(String.format("\n###%dth br is ignored for ESL calculation; br=%f",j,  brParam[j]));
						}
						else {
							;
						}
					}
					
					fout.write("\r\n brLengthsInvalidRemoved" +  " <- c(");
					for (k=0;k<this.brPos.length;k++) {
						if (valid[k]==false) {
							if (k!=0 && k%20==0) 
								fout.write(String.format("\r\n"));
							fout.write(String.format("%f",this.brPos[k].branchLength));
							if (k!=this.brPos.length-1)
								fout.write(String.format(", "));
							else 
								fout.write(String.format(")\r\n"));
						}
					}
				}

				fout.write(String.format("\n\n### sitewise gap proportion\r\n"));
				myFunc.printArrayRstyle(fout, this.sitewiseGapProp, "sitewiseGapProp");
				
				////////
				fout.write(String.format("\n\n### s_ESL <- c(..)) <= this information can be found in ") + fileName2);

				sum = 0.0;
				for (i=0;i<this.alphabetDataPatternNumOri.length;i++) {
					sum += sitewiseESL[i] * this.alphabetDataPatternNumOri[i];
				}
				
				fout.write(String.format("\nsum(s_ESL)"));
				fout.write(String.format("\n#sum of sitewiseESL = %f",sum));
				
				/// check..
				sum = 0.0;
				for (j=0;j<this.spESL.length;j++ ) {
					for (i=0;i<this.spESL[j].length;i++) {
						if (valid[j])
							sum += this.spESL[j][i] * this.alphabetDataPatternNumOri[i];
					}
				}

				//fout.write(String.format("\n#sum of sp-ESL = %f (this is just for checking)",sum));
				
				fout.write(String.format("\n\n###Correspondence between indices for R commands and branches. "));
				k=0;
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						fout.write(String.format("\nR_idx = %d | br_idx = %d |", k+1, j));
						//myFunc.print(String.format("\nR_id=%d | br[%d] | ",k+1,j));
						k++;
						Node pNode = null;
						int id = -1;
						for (i=0;i<this.nodePos.length;i++) {
							if (nodePos[i].nodeNum == brPos[j].desNd.nodeNum) {
								pNode = nodePos[i];
								id = i;
								break;
							}
						}
						
						if (pNode.isoNd == null) { // if terminal node
							fout.write("Node " + id + ": " + pNode.taxonName);
							//System.out.print("Node " + id + ": " + pNode.taxonName);
							
						}
						else {
							fout.write("Node " + id + ":");
							fout.write(brPos[j].nodeNum + "->");
							pNode = nodePos[id].isoBig.isoNd;
							do {
								fout.write(", <-" + pNode.desNd.nodeNum);
								//System.out.print(", <-" + pNode.desNd.nodeNum);
								pNode = pNode.isoNd;
							}while(pNode != nodePos[id].isoBig);
							pNode = brPos[j];
							if (pNode.desNd.isoNd == null) {
								fout.write(String.format("; terminal br to %s", pNode.desNd.taxonName));
							}
							else {
								fout.write(String.format("; MRCA of %s and %s", this.getLeftBottomTaxon(pNode.desNd.isoNd), this.getRightBottomTaxon(pNode.desNd.isoNd.isoNd) ));
							}
						}
					}
				}
				
				k=0;
				double[] brSave,pESLSave;
				brSave = null;
				pESLSave = null;
				fout.write(String.format("\r\n\r\n### R_idx | br_idx | p-ESL | br length"));
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						fout.write(String.format("\r\nR_idx = %d | br_idx = %d |", k+1, j));
						fout.write(String.format("%f | %f", this.parameterwiseESL[j], this.brPos[j].branchLength));
						brSave = myFunc.addToEnd(brSave, this.brPos[j].branchLength);
						pESLSave = myFunc.addToEnd(pESLSave, this.parameterwiseESL[j]);
						//rhoW = myFunc.addToEnd(rhoW, this.weightForRho[j]);
						k++;
					}
				}
				fout.write(String.format("\r\n\r\n####vectors for R\r\n"));
				myFunc.printArrayRstyle(fout, brSave, "brLength");
				myFunc.printArrayRstyle(fout, pESLSave, "\r\np_ESL");
				fout.write(String.format("\r\nplot(brLength, p_ESL) \r\n"));
				
				
				/////
				
				fout.write(String.format("\n\n###sp_ESL <- matrix(c(....)) <= this information can be found in ") + fileName2);
				
				
				k=0;
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						k++;
					}
				}
				int validNum = k;
				
				fout.write(String.format("\n# check if sum(sp_ESL[,1]*Gi_Weight) == s_ESL[1] "));
				fout.write(String.format("\n\n### R commands for figures"));
				fout.write(String.format("\nx<-1:dim(sp_ESL)[1] \ny<-1:%d",spESL[0].length));
				fout.write(String.format("\n#install.packages(\"tidyverse\") \nlibrary(ggplot2) \nlibrary(reshape2)  "));

				fout.write(String.format("\n#p1 <- ggplot(data.frame(s_ESL),aes(seq_along(s_ESL),s_ESL))+geom_bar(stat=\"identity\") + xlab('site') + ylab('s-ESL')"));
				fout.write(String.format("\n##p1 <- ggplot(data.frame(s_ESL),aes(seq_along(s_ESL),s_ESL, fill=seqColumns))+geom_bar(stat=\"identity\") + xlab('site') + ylab('s-ESL')"));
				fout.write(String.format("\n##If there is filtered partition, make seqColumns with MyTools.FindFilteredPosition()"));
				fout.write(String.format("\n#p1"));
				
				fout.write(String.format("\n#melted_sp_ESL <- melt(sp_ESL, value.name=\"sp.ESL\", varnames=c('param','site'))"));
				fout.write(String.format("\n#p2 <- ggplot(melted_sp_ESL, aes(x=site,y=param)) + geom_tile(aes(fill = sp.ESL),  colour = \"white\") + scale_fill_gradient(low = \"white\", high = \"steelblue\")"));
				fout.write(String.format("\n#p2"));
				
				fout.write(String.format("\nz <- sp_ESL"));
				fout.write(String.format("\np3 <- persp(x,y,z, col=\"white\", theta=45, phi=30, xlab=\"br\", ylab=\"site\", zlab=\"sp-ESL\")"));
				fout.write(String.format("\np3\n"));
				
				/*
				System.out.print("\r\n brLengthsInvalidRemoved" +  " <- c(");
				for (k=0;k<this.brPos.length;k++) {
					if (!valid[k]) {
						if (k!=0 && k%20==0) 
							myFunc.print(String.format("\r\n"));
						myFunc.print(String.format("%f",this.brPos[k].branchLength));
						if (k!=this.brPos.length-1)
							myFunc.print(String.format(", "));
						else 
							myFunc.print(String.format(")\r\n"));
					}
				}
				*/
				
				fout.close();
			}
			catch (IOException e) {
				myFunc.print(String.format("\n%s error", fileName));
			}
		}
		

	}


	
	public void printSitewiseESLInfo_sub2() {
		// print to file
		int i,j,k;
		double sum;
		
		if (this.myJob != JobType.SIMUL) {
			String fileName2 = new String();
			fileName2 = this.oriSeqFile + nameTag + "_sp-ESL_score_only.txt";
			try {
				FileWriter fout = new FileWriter(fileName2);
				
				//fout.write(String.format("\n\n"));
				myFunc.printArrayRstyle(fout, this.sitewiseESL, "s_ESL");
				
				k=0;
				double[] pESLSave, rhoW;
				pESLSave = null;
				rhoW = null;

				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						pESLSave = myFunc.addToEnd(pESLSave, this.parameterwiseESL[j]);
						rhoW = myFunc.addToEnd(rhoW, this.weightForRho[j]);
					}
				}
				fout.write(String.format("\r\n\r\n"));
				myFunc.printArrayRstyle(fout, pESLSave, "p_ESL");
				
				/////
				
				fout.write(String.format("\n\n#For image...\nsp_ESL <- matrix(c("));
				k=0;
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						k++;
					}
				}
				int validNum = k;
				
				k=0;
				int kk = 0;
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						for (i=0;i<this.spESL[j].length;i++) {
							if (kk==validNum-1 && i==spESL[j].length-1) {
								fout.write(String.format("%f)", this.spESL[j][i]));
								k++;
							}
							else {
								fout.write(String.format("%f,", this.spESL[j][i]));
								k++;
							}
							if (k%50==0)
								fout.write(String.format("\n"));
						}
						kk++;
					}
				}		
				fout.write(String.format(",byrow=T, nrow=%d,ncol=%d)\r\n\r\n",validNum,spESL[0].length));
				myFunc.printArrayRstyle(fout, rhoW, "Gi_Weight");

				
				fout.write(String.format("\r\n\r\n"));
				fout.close();
			}
			catch (IOException e) {
				myFunc.print(String.format("\n%s error", fileName2));
			}
		}
	}


	
	public void printSitewiseESLInfo_old() {
		// printSitewiseESLInfo_sub1() + printSitewiseESLInfo_sub2()
		int i,j,k;
		double sum;
		
		if (this.myJob != JobType.SIMUL) {
			String fileName = new String();
			//String fileName2 = new String();
			fileName = this.oriSeqFile + nameTag + "_sp-ESL.txt";
			//fileName2 = this.oriSeqFile + nameTag + "_sp-ESL_only.txt";
			try {
				FileWriter fout = new FileWriter(fileName);
				
				fout.write(String.format("\r\n\r\n### Input Options ###"));
				for (String s : this.optString) {
					fout.write(String.format("\n"));
					fout.write(s);
				}
				
				fout.write(String.format("\r\n\rnTaxa list and none-gap proportion"));
				for (i=0;i<this.taxaNameList.length;i++) 
					fout.write(String.format("\r\n#i=%d, %s, %f ", i, this.taxaNameList[i], 1.0 - taxonwiseGapProp[i])); 
				
				fout.write(String.format("\n#### Sitewise ESL ####\n#")); 
				fout.write(String.format("\n# site num | column pattern | pattern number | sitewise ESL")); 
				for (i=0;i<this.alphabetDataPatternNumOri.length;i++) {
					fout.write(String.format("\n#%dth site: ",i)); 
					for (j=0;j<this.alphabetDataOri.length;j++) {
						fout.write(String.format("%c",this.alphabetDataOri[j][i])); 
					}
					fout.write(String.format(" | %d",this.alphabetDataPatternNumOri[i]));
					fout.write(String.format(" | %f",this.sitewiseESL[i]));
				}
				
				// sorted s-ESL...
				
				double[] tmpSitewiseESL = new double[this.sitewiseESL.length];
				int[] tmpIdx = new int[this.sitewiseESL.length];
				for (i=0;i<tmpSitewiseESL.length;i++) {
					tmpSitewiseESL[i] = this.sitewiseESL[i];
				}
				tmpIdx = myFunc.doubleArraySortDescend(tmpSitewiseESL);
				
				fout.write(String.format("\r\n\r\n#### Sitewise ESL (after sorting, start) #####")); 
				fout.write(String.format("\r\n# site num | column pattern | pattern number | sitewise ESL | brID(max sp-ESL), brID(min sp-ESL)")); 
				fout.write(String.format("\r\n                       1         2         3         4         5         6")); 
				fout.write(String.format("\r\n              123456789012345678901234567890123456789012345678901234567890")); 
				for (i=0;i<this.alphabetDataPatternNumOri.length;i++) {
					fout.write(String.format("\n#i=%d | %dth site: ",i,tmpIdx[i])); 
					for (j=0;j<this.alphabetDataOri.length;j++) {
						fout.write(String.format("%c",this.alphabetDataOri[j][tmpIdx[i]])); 
					}
					fout.write(String.format(" | %d",this.alphabetDataPatternNumOri[tmpIdx[i]]));
					fout.write(String.format(" | %f",this.sitewiseESL[tmpIdx[i]]));
					
					// find min and max sp-ESL at the site
					
					int maxIdx=-1;
					double maxVal=-1.0e10;
					int minIdx = -1;
					double minVal = 1.0e10;
					for (int r=0;r<this.spESL.length;r++ ) {
						if (valid[r]) {
							if (maxVal < this.spESL[r][tmpIdx[i]]) {
								maxIdx = r;
								maxVal = this.spESL[r][tmpIdx[i]];
							}
							if (minVal > this.spESL[r][tmpIdx[i]]) {
								minIdx = r;
								minVal = this.spESL[r][tmpIdx[i]];
							}
							
						}
					}
					fout.write(String.format(" | br%d(%f), br%d(%f)",maxIdx, maxVal , minIdx, minVal ));
				}
				
				fout.write(String.format("\r\n\r\n#### Sitewise ESL (after sorting, end) #####"));
				
				
				// notice of validity 				
				fout.write(String.format("\r\n\r\nWarning...")); 

				for (j=0;j<brParam.length;j++) {
					if (valid[j]==false) {
						fout.write(String.format("\n###%dth br is ignored for ESL; br=%f",j,  brParam[j]));
					}
					else {
						;
					}
				}
				
				
				fout.write(String.format("\n\n"));
				myFunc.printArrayRstyle(fout, this.sitewiseGapProp, "\r\nsitewiseGapProp");
				
				////////
				fout.write(String.format("\n\ns_ESL <- c("));
				k=0;
				for (i=0;i<this.sitewiseESL.length;i++) {
					for (j=0;j<this.alphabetDataPatternNumOri[i];j++) {
						if (i==sitewiseESL.length-1 && j == alphabetDataPatternNumOri[i]-1) {
							fout.write(String.format("%f)\n",sitewiseESL[i]));
							k++;
						}
						else {
							fout.write(String.format("%f, ",sitewiseESL[i]));
							k++;
						}
						if (k%50==0)
							fout.write(String.format("\n"));
					}
				}
				
				sum = 0.0;
				for (i=0;i<this.alphabetDataPatternNumOri.length;i++) {
					sum += sitewiseESL[i] * this.alphabetDataPatternNumOri[i];
				}
				
				fout.write(String.format("\nsum(s_ESL)"));
				fout.write(String.format("\n#sum of sitewiseESL = %f",sum));
				
				/// check..
				sum = 0.0;
				for (j=0;j<this.spESL.length;j++ ) {
					for (i=0;i<this.spESL[j].length;i++) {
						if (valid[j])
							sum += this.spESL[j][i] * this.alphabetDataPatternNumOri[i];
					}
				}

				
				fout.write(String.format("\n#sum of sp-ESL = %f (this is just for checking)",sum));
				
				
				
				fout.write(String.format("\n\n#For image...Index info of sp_ESL"));
				k=0;
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						fout.write(String.format("\nR_id=%d | br[%d] |", k+1, j));
						//myFunc.print(String.format("\nR_id=%d | br[%d] | ",k+1,j));
						k++;
						Node pNode = null;
						int id = -1;
						for (i=0;i<this.nodePos.length;i++) {
							if (nodePos[i].nodeNum == brPos[j].desNd.nodeNum) {
								pNode = nodePos[i];
								id = i;
								break;
							}
						}
						
						if (pNode.isoNd == null) { // if terminal node
							fout.write("Node " + id + ": " + pNode.taxonName);
							//System.out.print("Node " + id + ": " + pNode.taxonName);
							
						}
						else {
							/*
							fout.write("Node " + id + ":");
							//System.out.print("Node " + id + ":");
							pNode = nodePos[id].isoBig;

							if (pNode == startNode) {
								fout.write("(StartNode) ->");
								fout.write(pNode.desNd.nodeNum);
								//System.out.print("(StartNode) ->");
								//System.out.print(pNode.desNd.nodeNum);
							}
							else {
								fout.write(pNode.desNd.nodeNum + "->");
								//System.out.print(pNode.desNd.nodeNum + "->");
							}
							pNode = nodePos[id].isoBig.isoNd;
							do {
								fout.write(", <-" + pNode.desNd.nodeNum);
								//System.out.print(", <-" + pNode.desNd.nodeNum);
								pNode = pNode.isoNd;
							}while(pNode != nodePos[id].isoBig);
							*/
							
							/////
							fout.write("Node " + id + ":");
							fout.write(brPos[j].nodeNum + "->");
							pNode = nodePos[id].isoBig.isoNd;
							do {
								fout.write(", <-" + pNode.desNd.nodeNum);
								//System.out.print(", <-" + pNode.desNd.nodeNum);
								pNode = pNode.isoNd;
							}while(pNode != nodePos[id].isoBig);
							pNode = brPos[j];
							if (pNode.desNd.isoNd == null) {
								fout.write(String.format("; terminal br to %s", pNode.desNd.taxonName));
							}
							else {
								fout.write(String.format("; MRCA of %s and %s", this.getLeftBottomTaxon(pNode.desNd.isoNd), this.getRightBottomTaxon(pNode.desNd.isoNd.isoNd) ));
							}
						}
					}
				}
				
				k=0;
				double[] brSave,pESLSave,rhoW;
				brSave = null;
				pESLSave = null;
				rhoW = null;
				fout.write(String.format("\r\n\r\n## R_id | br id | p-ESL | br length"));
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						fout.write(String.format("\r\nR_id=%d | br[%d] |", k+1, j));
						fout.write(String.format("%f | %f", this.parameterwiseESL[j], this.brPos[j].branchLength));
						brSave = myFunc.addToEnd(brSave, this.brPos[j].branchLength);
						pESLSave = myFunc.addToEnd(pESLSave, this.parameterwiseESL[j]);
						rhoW = myFunc.addToEnd(rhoW, this.weightForRho[j]);
						k++;
					}
				}
				fout.write(String.format("\r\n"));
				myFunc.printArrayRstyle(fout, brSave, "brLength");
				myFunc.printArrayRstyle(fout, pESLSave, "p_ESL");
				fout.write(String.format("\r\nplot(brLength, p_ESL) \r\n"));
				myFunc.printArrayRstyle(fout, rhoW, "Gi_Weight");
				
				
				/////
				
				fout.write(String.format("\n\n#For image...\nsp_ESL <- matrix(c("));
				k=0;
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						k++;
					}
				}
				int validNum = k;
				
				k=0;
				int kk = 0;
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						for (i=0;i<this.spESL[j].length;i++) {
							if (kk==validNum-1 && i==spESL[j].length-1) {
								fout.write(String.format("%f)", this.spESL[j][i]));
								k++;
							}
							else {
								fout.write(String.format("%f,", this.spESL[j][i]));
								k++;
							}
							if (k%50==0)
								fout.write(String.format("\n"));
						}
						kk++;
					}
				}		
				
				fout.write(String.format(",byrow=T, nrow=%d,ncol=%d)",validNum,spESL[0].length));
				
				fout.write(String.format("\r\n\r\nsum(sp_ESL) # checking"));
				fout.write(String.format("\nsum(sp_ESL[,1]) # checking"));
				fout.write(String.format("\n\n"));
				fout.write(String.format("\nx<-1:dim(sp_ESL)[1] \ny<-1:%d",spESL[0].length));
				fout.write(String.format("\n#install.packages(\"tidyverse\") \nlibrary(ggplot2) \nlibrary(reshape2)  "));

				fout.write(String.format("\n#p1 <- ggplot(data.frame(s_ESL),aes(seq_along(s_ESL),s_ESL))+geom_bar(stat=\"identity\") + xlab('site') + ylab('s-ESL')"));
				fout.write(String.format("\n##p1 <- ggplot(data.frame(s_ESL),aes(seq_along(s_ESL),s_ESL, fill=seqColumns))+geom_bar(stat=\"identity\") + xlab('site') + ylab('s-ESL')"));
				fout.write(String.format("\n##If there is filtered partition, make seqColumns with MyTools.FindFilteredPosition()"));
				fout.write(String.format("\n#p1"));
				
				fout.write(String.format("\n#melted_sp_ESL <- melt(sp_ESL, value.name=\"sp.ESL\", varnames=c('param','site'))"));
				fout.write(String.format("\n#p2 <- ggplot(melted_sp_ESL, aes(x=site,y=param)) + geom_tile(aes(fill = sp.ESL),  colour = \"white\") + scale_fill_gradient(low = \"white\", high = \"steelblue\")"));
				fout.write(String.format("\n#p2"));
				
				fout.write(String.format("\nz <- sp_ESL"));
				fout.write(String.format("\np3 <- persp(x,y,z, col=\"white\", theta=45, phi=30, xlab=\"br\", ylab=\"site\", zlab=\"sp-ESL\")"));
				fout.write(String.format("\np3\n"));
				

				//// print row index and br index
				fout.write(String.format("\n\n## sp_ESL's row index = br index"));
				k=1;
				for (j=0;j<this.spESL.length;j++ ) {
					if (valid[j]) {
						fout.write(String.format("\n## row %d = br %d", k, j));
						k++;
					}
					else {
						fout.write(String.format("\n## row N/A = br %d",  j));
					}
				}	
				

				
				System.out.print("\r\n brLengthsInvalidRemoved" +  " <- c(");
				for (k=0;k<this.brPos.length;k++) {
					if (valid[k]) {
						if (k!=0 && k%20==0) 
							myFunc.print(String.format("\r\n"));
						myFunc.print(String.format("%f",this.brPos[k].branchLength));
						if (k!=this.brPos.length-1)
							myFunc.print(String.format(", "));
						else 
							myFunc.print(String.format(")\r\n"));
					}
				}
				
				
				//// beta print
				
				
				
				
				fout.close();
			}
			catch (IOException e) {
				myFunc.print(String.format("\n%s error", fileName));
			}
		}
	}



	public void printTreeWithRhoBeta() {
		
		if (this.myJob != JobType.SIMUL) {
			String fileName = new String();
			int i, iter;
			iter = brParamHess.length;
			try {
				String[] topo = new String[4];
				this.getTree(topo);
				
				/// print p-ESL to file
				fileName = this.oriSeqFile+ nameTag + "_esl_tree_nex.txt";
				FileWriter fout = new FileWriter(fileName);
				fout.write(String.format("#NEXUS"));
				fout.write(String.format("\n\nBegin tata;"));
				fout.write(String.format("\n\tDeminsions ntax=%d",this.taxaNum));
				fout.write(String.format("\n\tTaxlabels"));
				for (i=0;i<this.taxaNameList.length;i++) {
					fout.write(String.format("\n\t\t%s",this.taxaNameList[i]));
				}
				fout.write(String.format("\n\t\t;"));
				fout.write(String.format("\nEnd;"));
				fout.write(String.format("\n\nBegin trees;"));
				fout.write(String.format("\n\tTranslate"));
				for (i=0;i<this.taxaNameList.length;i++) {
					fout.write(String.format("\n\t\t%d %s",i+1, this.taxaNameList[i]));
				}
				fout.write(String.format("\n\t\t;"));
				fout.write(String.format("\n\t tree Tree1 = [&R] ") + topo[1]);
				fout.write(String.format("\n\t [tree Tree2 = [&R] ") + topo[2] + "]");	
				fout.write(String.format("\n\t [Tree1 is rho, Tree2 is beta ] "));	
				fout.write(String.format("\nEnd;"));
				
				fout.write(String.format("\n\n[ # r code; copy these code to R prompt after saving " + fileName + " in c:/temp/ "));
				fout.write(String.format("\n# if (!requireNamespace(\"BiocManager\", quietly = TRUE)) "));
				fout.write(String.format("\n# 		install.packages(\"BiocManager\")"));	
				fout.write(String.format("\n# BiocManager::install(\"ggtree\")"));
				fout.write(String.format("\nlibrary(ggtree)"));			
				fout.write(String.format("\nlibrary(treeio)"));	
				fout.write(String.format("\nlibrary(tidyverse)"));	
				
				fout.write(String.format("\nesl_tree_file <- \"c:/temp/") + fileName + String.format("\""));	
				fout.write(String.format("\nesl_tree <- read.beast(esl_tree_file)"));				
				fout.write(String.format("\nx <- as_tibble(esl_tree)"));
				fout.write(String.format("\n#y <- mutate(x, ESL = ifelse(ESL<10, NA, ESL))"));		
				fout.write(String.format("\ny <- x"));	
				fout.write(String.format("\ntreey <- as.treedata(y)"));				
				fout.write(String.format("\nggtree(treey, aes(color=Rho),size=1) + geom_tiplab(size=2, color=\"purple\") +"));		
				fout.write(String.format("\nscale_color_continuous(low='darkgreen', high='red',na.value = 'grey') +"));	
				fout.write(String.format("\n#scale_color_continuous(low='grey', high='black',na.value = 'grey') +"));
				fout.write(String.format("\ntheme(legend.position=\"right\") "));	
				fout.write(String.format("\n#ggtree(treey, aes(color=Beta),size=1) + geom_tiplab(size=2, color=\"purple\") +"));		
				fout.write(String.format("\n#scale_color_continuous(low='darkgreen', high='red',na.value = 'grey') +"));		
				fout.write(String.format("\n#theme(legend.position=\"right\") "));	
				fout.write(String.format("\n]\n"));	
				
	
				fout.close();
				
			}
			catch (IOException e) {
				myFunc.print(String.format("\n%s error", fileName));
			}
			
			
			if (this.multiThrId==0)
				this.PrintSitewiseGapPropLoglike();
			
		}
		
	}
	
	

	public void optimizeRandomSeq() {
		
		int i, j;
		char[][] oriAlphabetDataUnsorted = new char[alphabetDataOriUnsorted.length][alphabetDataOriUnsorted[0].length];

		//backup space of alphabetDataOriUnsorted
		for (i=0;i<alphabetDataOriUnsorted.length;i++) {
			for (j=0;j<alphabetDataOriUnsorted[i].length;j++) {
				oriAlphabetDataUnsorted[i][j] = alphabetDataOriUnsorted[i][j];
			}
		}
		
		
		
		///////
		
		if (this.myFreqOpt == FreqType.DATAFREQ) {
			this.getEmpiricalPI();
		}
		backupUnsortedAlphabetData();
		sortData();
		calRateMat();
		InitML();
		
		//// (parameter optimization here) ////
		optimizeSub_pruning(true);
		//myFunc.print(String.format("\nNo optimization for br and alpha... omitting optimizeSub_pruning()"));
		
		
		if (this.dataSorted) {
			this.calcLogLike();
			if (this.multiThrId==0)
				myFunc.print(String.format("\r\n\r\nBefore restoring data sort, %d patterns,  loglike= %f ", alphabetDataPatternNum.length, this.logLike));
			this.recoverUnsortedAlphabetData();
			if (this.multiThrId==0)
				myFunc.print(String.format("\nAfter restoring data sort, "));
		}

		InitML();
		this.setRecalNeeded();
		this.calcLogLike();
		if (this.multiThrId==0) 
			myFunc.print(String.format(" %d patterns,  loglike= %f ", alphabetDataPatternNum.length, this.logLike));
	

		//restore space of alphabetDataOriUnsorted
		alphabetDataOriUnsorted = new char[oriAlphabetDataUnsorted.length][oriAlphabetDataUnsorted[0].length];
		for (i=0;i<alphabetDataOriUnsorted.length;i++) {
			for (j=0;j<alphabetDataOriUnsorted[i].length;j++) {
				alphabetDataOriUnsorted[i][j] = oriAlphabetDataUnsorted[i][j];
			}
		}
		
		
	}
	

	
	public void printVariousStats(
			boolean[] valid,
			double[] globalBetaStatSave, 
			double[] globalBetaSave, 
			double[] globalBetaVarSave, 
			double[][] parameterwiseBetaSave,
			double[][] parameterwiseRhoSave,
			double[] globalBetaPvalueSave
			) {
		int j;
		
		System.out.print("\n");

		//for (j=0;j<10;j++) {
		for (j=0;j<valid.length;j++) {
			if (valid[j]) {
				;
				//myFunc.printArrayRstyle(parameterwiseBetaSave[j], String.format("parameterwiseBetaSave%d", j) );
			}
		}
		
		//for (j=0;j<10;j++) {
		for (j=0;j<valid.length;j++) {
			if (valid[j]) {
				;
				myFunc.printArrayRstyle(parameterwiseRhoSave[j], String.format("parameterwiseRhoSave%d", j) );
			}
		}
		
		System.out.print("\n\n$$$$$$$\n");

		/*
		myFunc.printArrayRstyle(globalBetaSave, "globalBetaSave");
		myFunc.printArrayRstyle(globalBetaVarSave, "globalBetaVarSave");
		System.out.print("\nhist(globalBetaSave,main=\"Dist. of globalBeta\",xlab=\"\")");
		System.out.print("\nhist(globalBetaVarSave,main=\"Dist. of globalBetaVar\",xlab=\"\")");
		System.out.print("\n");	
		*/
		

		
		myFunc.printArrayRstyle(globalBetaStatSave, "globalBetaStatSave");
		System.out.print("hist(globalBetaStatSave,main=\"Dist. of T\",xlab=\"\")");
		System.out.print("\na<- pnorm(globalBetaStatSave)");		
		System.out.print("\nhist(a, main=\"Cumulative Prob. of T\",xlab=\"\")");
		System.out.print("\na.ecdf = ecdf(a)");
		System.out.print("\nplot(a.ecdf, verticals=TRUE, do.points=FALSE, main=\"CDF of T\",xlab=\"\")");
		System.out.print("\nabline(0,1)");	
		System.out.print("\nqqnorm(globalBetaStatSave)");
		System.out.print("\nqqline(globalBetaStatSave)");
		System.out.print("\nks.test(a,\"punif\",0,1)  \n");
		


		myFunc.printArrayRstyle(globalBetaPvalueSave, "globalBetaPvalueSave");
		System.out.print("#hist(globalBetaPvalueSave,main=\"Dist. of cumu prob\",xlab=\"\")");
		System.out.print("\na<- globalBetaPvalueSave");		
		System.out.print("\nhist(a, main=\"Cumulative probability \",xlab=\"\")");
		System.out.print("\na.ecdf = ecdf(a)");
		System.out.print("\nplot(a.ecdf, verticals=TRUE, do.points=FALSE, main=\"CDF of T\",xlab=\"\")");
		System.out.print("\nabline(0,1)");			
		System.out.print("\nks.test(a,\"punif\",0,1) ");
		System.out.print("\nb <- hist(globalBetaPvalueSave,breaks=10, freq=F)");
		System.out.print("\nsum(abs(b$density-1.0)) \n");
		
		

	}


	
	public void importGapPattern(int[] bootIdx, boolean[][] gapInfo) { 
		int i, j, idx;
		
		for (i=0;i<this.alphabetData[0].length;i++) {
			idx = bootIdx[i%gapInfo[0].length];
			for (j=0;j<this.alphabetData.length;j++) {
				if (gapInfo[j][idx]) 
					alphabetData[j][i] = '-';
			}
		}
		
	}
		
		
	
	
	public void copyGapPatternFromOriginalData() {
		
		
		int i, j, k, iter, remainder, unitL;
		//iter = this.alphabetData[0].length;
		
		remainder = this.alphabetData[0].length % this.alphabetDataOriUnsorted[0].length;
		
		unitL = this.alphabetDataOriUnsorted[0].length;
		
		if (remainder != 0) {
			System.err.print("\nSomething wrong in copyGapPatternFromOriginalData() ");
			System.exit(0);
		}
		
		iter = this.alphabetData[0].length / this.alphabetDataOriUnsorted[0].length;
	
	
		//m times gap copying
		for (i=0;i<this.alphabetDataOriUnsorted[0].length;i++) {
			int idx = myRand.nextInt(alphabetDataOriUnsorted[0].length);
			for (j=0;j<this.alphabetDataOriUnsorted.length;j++) {
				char c = alphabetDataOriUnsorted[j][idx];
				if ( c== '-' || c== '?') {
					for (k=0;k<iter;k++) {
						this.alphabetData[j][k*unitL + i] = c;
					}
				}
			}
		}

		/*			
		// random gap copying
		for (i=0;i<this.alphabetData[0].length;i++) {
			int idx = myFunc.myRand.nextInt(alphabetDataOriUnsorted[0].length);
			for (j=0;j<this.alphabetData.length;j++) {
				char c = alphabetDataOriUnsorted[j][idx];
				if ( c== '-' || c== '?') {
					this.alphabetData[j][i] = c;
				}
			}
		}
		*/		
		
	}
	
	public void printProcess(int i, int iter, String message) {
		
		if (iter<=5 && this.multiThrId==0) {
			myFunc.print(String.format("\n\n-- %dth Random data set (%s) --",i, message));
			//Print2ndDerivScreen();
			myFunc.errPrint(String.format("\n"));
		}
		else if (iter<=100  && this.multiThrId==0) {
			if (i%20==0) {
				myFunc.print(String.format("\n\n-- %dth Random data set (%s) --",i, message));
				//Print2ndDerivScreen();
				myFunc.errPrint(String.format("\n"));
			}
		}
		else if (iter<=1000  && this.multiThrId==0)  {
			if (i%200==0) {
				myFunc.print(String.format("\n\n-- %dth Random data set (%s) --",i, message));
				//Print2ndDerivScreen();
				myFunc.errPrint(String.format("\n"));
			}
		}
		else if (this.multiThrId==0){
			if (i%500==0) {
				myFunc.print(String.format("\n\n-- %dth Random data set (%s) --",i, message));
				Print2ndDerivScreen();
				myFunc.errPrint(String.format("\n"));
			}
		}
		else {
			
		}
		
	}
	
	
	public void pruneTaxa(String[] names) {
	}
	
	
	public void PrintSitewiseGapPropLoglike() {
		
		
		int i,j;
	
		this.calcSitewiseGapProp();
		
		boolean tmp = false;
		
		if (tmp) {
			myFunc.print(String.format("\n\n#gap proportion and sitewise loglike...\nx<-c("));
			for (i=0;i<sitewiseGapProp.length;i++) {
				myFunc.print(String.format("%f",sitewiseGapProp[i]));
				if (i==sitewiseGapProp.length-1)
					System.out.print(") ");
				else
					System.out.print(", ");
				if (i%50==0 && i>0)
					System.out.print("\n");
			}
			
			myFunc.print(String.format("\n\ny<-c("));
			for (i=0;i<sitewiseGapProp.length;i++) {
				myFunc.print(String.format("%f",this.sitewiseLogLike[i]));
				if (i==sitewiseGapProp.length-1)
					System.out.print(")");
				else
					System.out.print(",");
				if (i%50==0 && i>0)
					System.out.print("\n");
			}
			
			myFunc.print(String.format("\n\nplot(x,y, xlim=c(0,1))"));
		}
		
	}

	
	public int BootstrapUsingESL(int id) {

		Vector<Integer> resampledID = new Vector<Integer>();
		
		int r, R, i, j, iter;
		double sum = 0.0;
		double prevSum = 0.0;
		
		do {
			prevSum = sum;
			r = myRand.nextInt(this.seqLength);
			resampledID.add(r);
			sum += this.sitewiseESL[r];
		} while (sum < this.ESL);
		
		if (Math.abs(prevSum-ESL) < Math.abs(sum-ESL))
			R = resampledID.size()-1;
		else
			R = resampledID.size();
		
		if (R > this.seqLength) 
			iter = R;
		else {
			while (resampledID.size()<this.seqLength) {
				r = myRand.nextInt(this.seqLength);
				resampledID.add(r);
			}
			iter = this.seqLength;
		}
			
		
		String normalFileName = new String();
		normalFileName = this.oriSeqFile + "_boot_"  + nameTag + String.format("%d.txt", id);
		
		String eslBootFileName = new String();
		eslBootFileName  = this.oriSeqFile + "_boot_esl_" +  nameTag + String.format("%d.txt", id);
		
		try {
			FileWriter normalFout = new FileWriter(normalFileName);
			FileWriter eslFout = new FileWriter(eslBootFileName);
			//fout.write(String.format("%d %d", this.taxaNum, n));  // for phylip
			
			for (i=0;i<this.taxaNum;i++) {
				//fout.write(String.format("\n%s  ", this.taxaNameList[i])); // for phylip
				normalFout.write(String.format(">%s  \n", this.taxaNameList[i])); // for fasta
				eslFout.write(String.format(">%s  \n", this.taxaNameList[i])); // for fasta
				for (j=0;j<iter;j++) {
					if (j<R) {
						eslFout.write(String.format("%c", this.alphabetData[i][resampledID.get(j)])); 
					}
					if (j<this.seqLength) {
						normalFout.write(String.format("%c", this.alphabetData[i][resampledID.get(j)])); 
					}
				}
				eslFout.write(String.format("\n")); // for fasta
				normalFout.write(String.format("\n")); // for fasta
			}
			eslFout.write(String.format("\n")); 
			normalFout.write(String.format("\n")); 
			eslFout.close();
			normalFout.close();
		}
		catch (IOException e) {
			myFunc.print(String.format("\n%s or %s error", normalFileName, eslBootFileName));
		}
		
		String fileName = this.oriSeqFile + "_boot_posinfo_" +  nameTag + String.format("%d.txt", id);
		try {
			FileWriter fout = new FileWriter(fileName);
			fout.write(String.format("ESL= %f", this.ESL)); 
			fout.write(String.format("\nSite | Resampled position | s-ESL | partial sum")); 
			sum = 0.0;
			for (i=0;i<resampledID.size();i++) {
				sum += this.sitewiseESL[resampledID.get(i)];
				fout.write(String.format("\ni=%d | %d | %f | %f ", i, resampledID.get(i), this.sitewiseESL[resampledID.get(i)], sum)); 
			}
			fout.write(String.format("\n%d Sites were sampled for s-ESL bootstrap.", R)); 
			fout.close();
		}
		catch (IOException e) {
			myFunc.print(String.format("\n%s error", fileName));
		}
		
		return R;
		
	}
	
	public void raxmlRelated() {
		boolean doNotRunThis = false;
		if (doNotRunThis) { //  if (bootIter > 0) {
			int i;
			int[] bootSize = new int[bootIter];
			for (i=0;i<bootIter;i++) 
				bootSize[i]= this.BootstrapUsingESL(i);
			this.PrintRaxmlCommand(bootIter);
			
			myFunc.print(String.format("\nbootSize <- c("));
			for (i=0;i<bootIter-1;i++)  {
				myFunc.print(String.format("%d, ",bootSize[i]));
			}
			myFunc.print(String.format("%d)\n\n ",bootSize[bootIter-1]));
		}
	}
	

	
	public void makeAllGappyTaxaBrZero() {
		
		int i, j;

		for (i=0;i<this.alphabetData.length;i++) {
			boolean AllGap = true;
			for (j=0;j<this.alphabetData[0].length;j++) {
				if (!isGap(alphabetData[i][j]))
					AllGap = false;
			}
			if (AllGap) {
				for (j=0;j<brPos.length;j++) {
					if (brPos[j].taxonName.equals(this.taxaNameList[i]) || brPos[j].desNd.taxonName.equals(this.taxaNameList[i]) ) {
						brPos[j].branchLength = brPos[j].desNd.branchLength = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
						myFunc.print(String.format("\nTaxon %s is composed of all gaps", taxaNameList[i]));
					}
				}
			}
		}
		
	}
	
	


	public void generateSitesOfPositiveRho() {
		// This code was modified without checking (20210619)
		String posFileName = new String();
		
		boolean positive = true;
		double lowerBound;
		
		if (positive == true) {
			lowerBound = myFunc.EPSILON;
			posFileName = this.oriSeqFile + "_posrho"  + nameTag + String.format(".txt");
		}
		else {
			lowerBound = - myFunc.EPSILON; // non-negative
			posFileName = this.oriSeqFile + "_nonneg_rho"  + nameTag + String.format(".txt");
		}
		
		try {
			FileWriter posFout = new FileWriter(posFileName);
			int i,j,iter,posCnt;
			posCnt = 0;
			iter = this.sitewiseESL.length;
			for (i=0;i<iter;i++) {
				if (this.sitewiseESL[i] > lowerBound) 
					posCnt++;
			}
			posFout.write(String.format("%d %d  \n", this.taxaNum, posCnt)); 
			for (i=0;i<this.taxaNum;i++) {
				posFout.write(String.format("%s   ", this.taxaNameList[i])); 
				for (j=0;j<iter;j++) {
					if (this.sitewiseESL[j] > lowerBound) {
						posFout.write(String.format("%c", this.alphabetData[i][j])); 
					}
				}
				posFout.write(String.format("\n")); // for fasta
			}
			posFout.write(String.format("\n")); 
			posFout.close();
		}
		catch (IOException e) {
			myFunc.print(String.format("\n%s error", posFileName));
		}
		
			
	}

	@Override
	public void calcPairMLDist() {
		this.pairDist = new double[taxaNum][taxaNum];

		this.startNode = this.generateBr(this.taxaNameList[0]);
		startNode.isoNd = generateBr("");
		startNode.isoNd.isoNd =  generateBr("");		
		startNode.isoNd.isoNd.isoNd = startNode;
	
		brPos = null;
		brParam = null;
		
		brPos = myFunc.addToEnd(brPos, startNode);
		brPos = myFunc.addToEnd(brPos, startNode.isoNd);
		brPos = myFunc.addToEnd(brPos, startNode.isoNd.isoNd);
		
		brParam = myFunc.addToEnd(brParam, startNode.branchLength);
		brParam = myFunc.addToEnd(brParam, startNode.isoNd.branchLength);
		brParam = myFunc.addToEnd(brParam, startNode.isoNd.isoNd.branchLength);
		
		int i, j, r;
		for (i=0;i<brParam.length;i++) {
			brPos[i].branchLength = brPos[i].desNd.branchLength = brParam[i] = 0.1;
		}
		this.backupBrParam(brParam);
		
		for (i=0;i<alphabetData.length-1;i++) {
			for (j=i+1;j<alphabetData.length;j++) {
				this.pairDist[i][j] = this.pairDist[j][i] = calcPairMLDistSub(i, j);
			}
		}
		
	}
	

	@Override
	public double calcPairMLDistSub(int id1, int id2) {
		// this was not carefully checked...
		// but using it before NJ seems to work well
		// log-like of GTR distances were much improved than TN93 distances
		
		this.startNode.desNd.taxonName = this.taxaNameList[id1];
		this.startNode.isoNd.desNd.taxonName = this.taxaNameList[id2];
		this.startNode.isoNd.isoNd.desNd.taxonName = this.taxaNameList[id2]; // dummy
		
		this.InitML();
		
		int j, k, l, patt_size;
		patt_size = alphabetDataPatternNum.length;
		
		for (j=0;j<patt_size;j++) {
			for (k=0;k<gammaCateNum;k++) {
				for (l=0;l<stateDim;l++) {
					this.startNode.isoNd.isoNd.subLikelihood[k*patt_size*stateDim + j*stateDim + l] = 1.0;
				}
			}
		}
	
		this.startNode.isoNd.branchLength = this.startNode.isoNd.desNd.branchLength = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
		
		this.setRecalNeeded();
		this.calcLogLike();
		
		optBranchLength(startNode,false);
		
		double dist = this.startNode.branchLength + this.startNode.isoNd.branchLength;
		myFunc.errPrint(String.format("\ni=%d, j=%d : %f", id1, id2, dist));
		//myFunc.print(String.format("\ni=%d, j=%d : %f", id1, id2, dist));
		
		return dist ;
	}
	
	
} /// end of public class TreeML extends Tree implements Analysis {


