package ESL_v02;

import java.util.Random;

public class TestMain {

	public static void main(String[] args) {
		
		InputOption OPT = new InputOption(); 
		OPT.LoadInputOption();
		
		if (OPT.totalNumThread == 1) {
			System.out.println("single thread..");

			Analysis Anal;
			
			SiteData SData;
			
			if (OPT.myJob == JobType.SITEWISE_LOGLIKE_ANAL) {
				
				SData  = new SiteData();
				//SData.sitewiseLogLikeTest();
				SData.simulation20200712();
			}
			else {
				if (OPT.subsModel == ModelType.JC || OPT.subsModel == ModelType.TN93 || OPT.subsModel == ModelType.GTR )
					Anal = new TreeMLNuc();
				else
					Anal = new TreeMLAA();
	
				if (OPT.myJob == JobType.ML_TREE_EST || OPT.myJob == JobType.CLUSTERING) 
					Anal.job20200727();
				else
					Anal.job20200611();
			}

			
		}
		else {
			if (OPT.myJob != JobType.EST_HESS_ESL) {
				System.err.print(String.format("\nOnly EST_HESS_ESL option can be used with multi thread."));
				System.exit(0);
			}
						
			MyMultiThreadJob myJob = new MyMultiThreadJob(OPT.totalNumThread, OPT.maxSimulThread);
			myJob.DoAnalysis();
		}




	}

}
