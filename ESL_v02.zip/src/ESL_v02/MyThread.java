package ESL_v02;

import java.io.FileWriter;
import java.io.IOException;

// code were borrowed from
// https://medium.com/edureka/java-thread-bfb08e4eb691
// https://www.particleincell.com/2011/java-multithreading/

// These classes for multithread were not carefully checked. 
// 

class MyThread extends Thread {
	String name;
	Thread t;
	int id;
	
	int taxaNum;
	double[][] simulFisherInfo; //[0] complete, [1] gappy
	double[] oriFisherInfo; 
	boolean[] valid;
	
	TreeMLAA myTree;
	
    MyThread (String thread, int k, ThreadGroup tg){
    	super(tg, thread);
    	
    	name = thread; 
    	t = new Thread(this, name);
    	id = k;
    	System.out.println("New thread: " + t);
    	//t.start();
    }

    public void run() {
 

   		myTree = new TreeMLAA(name, id);
   		myTree.job20200611();
   		
   		this.taxaNum = myTree.taxaNum;
   		simulFisherInfo = new double[2][2*taxaNum-3]; 
   		oriFisherInfo = new double[2*taxaNum-3]; 
   		valid = new boolean[2*taxaNum-3]; 
    		
   		int iter = 2*taxaNum-3;
   		int i;
		for (i=0;i<iter;i++) {
			this.simulFisherInfo[0][i] = myTree.simulFisherInfo[0][i];
			this.simulFisherInfo[1][i] = myTree.simulFisherInfo[1][i];
			this.oriFisherInfo[i] = myTree.oriFisherInfo[i];
			this.valid[i] = myTree.valid[i];
		}
		
		if (myTree.multiThrId != 0) {
			//myTree.destroySubLikelihood();
			myTree.destroyTreeMemory();
		}
		
		if (id != 0) {
			myTree = null;
			System.gc();
		
		}

		
		//Thread.sleep(1000);
    }
}
 

class MyMultiThreadJob {

	public int totalNumThread;
	public int maxSimulThread;
	double[] meanESL;
	double[][] simulFisherInfo; 
	double[] oriFisherInfo; 
	boolean[] valid;
	double[][] brESL;
	
	MyThread[] myT;
	
	MyMultiThreadJob(int k, int r) {
		totalNumThread = k;
		maxSimulThread = r;
	}

	public void DoAnalysis() {
		// this is copy of main() within class MultiThread
	
		int i, j, iter;
		


		

		
		ThreadGroup tg = new ThreadGroup("main");
		//int np = Runtime.getRuntime().availableProcessors();
		
		String str = new String();
		
		myT = new MyThread[totalNumThread];
		
		
		for (i=0;i<totalNumThread;i++) {
			str = "_th" + Integer.toString(i) + "_";
			myT[i] = new MyThread(str, i, tg);
		}
		
		myT[0].start(); // first thread is special for calculating 2nd derivative
		while(tg.activeCount()>0)
		{
			try {
				Thread.sleep(100);
				} 
			catch (InterruptedException e) {e.printStackTrace();}
		}		
		
		myFunc.brParamHessBackup = new double[2*myT[0].myTree.taxaNum-3]; 
		
		myT[0].myTree.backup2ndDeriv(myFunc.brParamHessBackup);
		
		
		i=1;
		while (i<totalNumThread)
		{
			/*do we have available CPUs?*/
			//np = Runtime.getRuntime().availableProcessors() - tg.activeCount();
			//if (tg.activeCount()<np)
			if (Runtime.getRuntime().availableProcessors() - tg.activeCount() > 0 && tg.activeCount() < maxSimulThread)
			{
				myT[i].start();
				System.err.print(String.format("\n%dth thread (total: %d) started, currently %d jobs running", i, totalNumThread, tg.activeCount()));
				i++;
			} 
			else {
				try {
					Thread.sleep(100);
				} /*wait 0.1 second before checking again*/
				catch (InterruptedException e) {e.printStackTrace();}

			}
		}
		
		int k;
		k = tg.activeCount();
		while (k>0) {
			try {
				Thread.sleep(1000);
			} /*wait 0.1 second before checking again*/
			catch (InterruptedException e) {e.printStackTrace();}
			if (k != tg.activeCount()) {
				k = tg.activeCount();
				System.err.print(String.format("\n                               , currently %d jobs running", tg.activeCount()));
			}
		}
 
 
		/*wait for threads to finish*/
		while(tg.activeCount()>0)
		{
			try {
				Thread.sleep(100);
				} 
			catch (InterruptedException e) {e.printStackTrace();}
		}
 
		
		String fileName = new String();
		fileName = myT[0].myTree.oriSeqFile+ "_multiThread_2ndDeriv.txt";
		
		iter = myT[0].myTree.brParamHess.length;
		try {
			FileWriter fout = new FileWriter(fileName);
			fout.write(String.format("logLike= %f", myT[0].myTree.logLike));
			
			iter = myT[0].simulFisherInfo[0].length;
			
			for (i = 0; i < iter; i++) {
				fout.write(String.format("\n2nd_Deriv_brParam[%d]= %f | %f", i, myT[0].myTree.brParamHess[i], myT[0].myTree.brParam[i]));
			}	
			fout.write(String.format("\nAlpha_estimate= %f", myT[0].myTree.alpha));
			String[] topo = new String[3];
			myT[0].myTree.getTree(topo);
			fout.write(String.format("\n%s",topo[0]));
			
			fout.write(String.format("\n"));
			
	   		simulFisherInfo = new double[2][iter]; 
	   		oriFisherInfo = new double[iter]; 
	   		valid = new boolean[iter]; 
	   		
	   		for (i=0;i<iter;i++) {
	   			valid[i] = myT[0].valid[i];
	   			oriFisherInfo[i] = myT[0].oriFisherInfo[i];
	   			simulFisherInfo[0][i] = simulFisherInfo[1][i] = 0.0;
	   			for (j=0;j<totalNumThread;j++) {
	   				simulFisherInfo[0][i] += myT[j].simulFisherInfo[0][i];
	   				simulFisherInfo[1][i] += myT[j].simulFisherInfo[1][i];
	   			}
	   			simulFisherInfo[0][i] /= totalNumThread;
	   			simulFisherInfo[1][i] /= totalNumThread;
	   		}
			
			fout.write(String.format("\nInfo[xx]: oriFisherInfo, simulFisherInfo[0], simulFisherInfo[1], validInfo ; //[0] complete, [1] imaginary gappy")); 
			for (i=0;i<iter;i++) {
				fout.write(String.format("\nInfo[%d]:  %.15f  %.15f  %.15f  %b",i, oriFisherInfo[i], simulFisherInfo[0][i], simulFisherInfo[1][i],valid[i] ));
			}
		

			fout.write(String.format("\n\n\n########")); 
			//fout.write(String.format("\nThis is the results of multi threads; long PSL is %d*%d=%d", myT[0].myTree.extremelyLargeLength, myT.length, myT[0].myTree.extremelyLargeLength * myT.length )); 
			fout.write(String.format("\nThis is the results of multi threads; long PSL is %d*%d=%d", myT[0].myTree.seqLength*myT[0].myTree.simulLengthTimes2, myT.length, myT[0].myTree.seqLength*myT[0].myTree.simulLengthTimes2 * myT.length )); 
			
			
			fout.write(String.format("\n")); 
			
			fout.close();
			
			////////
			
			double sum;
			
			brESL = new double[2][2*myT[0].myTree.taxaNum-3]; 
			meanESL = new double[2];
			
			double w_denom;
			w_denom = 0.0;
			for (i=0;i<simulFisherInfo[0].length;i++) {
				if (valid[i]) {
					w_denom += simulFisherInfo[0][i]*simulFisherInfo[0][i];
				}

			}
			
			
			// imaginary gappy 
			sum = 0.0;
			for (i=0;i<oriFisherInfo.length;i++) {
				if (!valid[i]) 
					brESL[1][i] = 0.0;
				else
					brESL[1][i] = simulFisherInfo[1][i] / simulFisherInfo[0][i] * myT[0].myTree.seqLength;
				sum += brESL[1][i] * simulFisherInfo[0][i] * simulFisherInfo[0][i] / w_denom ;
			}
			meanESL[1] = sum;
			
			/////
			// real gappy
			sum = 0.0;
			for (i=0;i<oriFisherInfo.length;i++) {
				if (!valid[i]) 
					brESL[0][i] = 0.0;
				else
					brESL[0][i] = oriFisherInfo[i] / simulFisherInfo[0][i] * myT[0].myTree.seqLength;
				sum += brESL[0][i] * simulFisherInfo[0][i] * simulFisherInfo[0][i] / w_denom ;
			}
			this.meanESL[0] = sum;
			
			
			System.out.print(String.format("\n\n#########\nThe above is results of individual thread; Ignore them. \n"));
			//System.out.print(String.format("\nThis is the results of multi threads; long PSL is %d*%d=%d", myT[0].myTree.extremelyLargeLength, myT.length, myT[0].myTree.extremelyLargeLength * myT.length )); 
			System.out.print(String.format("\nThis is the results of multi threads; long PSL is %d*%d=%d", myT[0].myTree.seqLength*myT[0].myTree.simulLengthTimes2, myT.length, myT[0].myTree.seqLength*myT[0].myTree.simulLengthTimes2 * myT.length )); 
			
			printFisherInfoToScreen(); 

			
			
			
				
			
		}
		catch (IOException e) {
			System.out.print(String.format("\n%s error", fileName));
		}

		System.out.println("Main thread exiting.");
	}
	
	
	
	public void printFisherInfoToScreen() {
		
		int i;
		double sum = 0.0;
		
		double w_denom = 0.0;
		for (i=0;i<simulFisherInfo[0].length;i++) {
			if (valid[i]) {
				w_denom += simulFisherInfo[0][i]*simulFisherInfo[0][i];
			}
	
		}
		
		System.out.print(String.format("\n\n---(imaginary ESL)--------------"));
		System.out.print(String.format("\nall threads summary"));
		System.out.print(String.format("\nPSL(imaginary gappy)=%d", myT[0].myTree.seqLength));
		sum = 0.0;
		for (i=0;i<oriFisherInfo.length;i++) {
			System.out.print(String.format("\nESL_of_br[%d]=%f/%f*n= %f",i,simulFisherInfo[1][i],
					simulFisherInfo[0][i], brESL[1][i] ));
			if (!valid[i])
				System.out.print(String.format("<- invalid p-ESL"));
			sum += brESL[1][i] * simulFisherInfo[0][i] * simulFisherInfo[0][i] / w_denom ;
		}
		System.out.print(String.format("\n(weighted)Mean ESL=%f",sum));
		
		System.out.print(String.format("\nw_denom=%f\n",w_denom));
		for (i=0;i<oriFisherInfo.length-1;i++) {
			if (valid[i])
				System.out.print(String.format("%f*%f+",simulFisherInfo[0][i],simulFisherInfo[0][i]));
			else 
				System.out.print(String.format("%f*%f+",0.0,0.0));
		}
		if (valid[i])
			System.out.print(String.format("%f*%f",simulFisherInfo[0][i],simulFisherInfo[0][i]));
		else
			System.out.print(String.format("%f*%f",0.0,0.0));
		
		System.out.print(String.format("\nn_e=%f\n",this.meanESL[1]));
		for (i=0;i<oriFisherInfo.length-1;i++) {
			if (valid[i])
				System.out.print(String.format("%f*%f/w_denom*%f+",simulFisherInfo[0][i], simulFisherInfo[0][i],brESL[1][i] ));
			else
				System.out.print(String.format("%f*%f/w_denom*%f+",0.0, 0.0,0.0 ));
		}
		if (valid[i])
			System.out.print(String.format("%f*%f/w_denom*%f",simulFisherInfo[0][i], simulFisherInfo[0][i],brESL[1][i] ));
		else
			System.out.print(String.format("%f*%f/w_denom*%f",0.0, 0.0,0.0 ));
		
		
		/////
		//  ESL of real data
		sum = 0.0;
		System.out.print(String.format("\n\n--(real ESL)---------------"));
		System.out.print(String.format("\nall threads summary"));
		System.out.print(String.format("\nPSL=%d", myT[0].myTree.seqLength));
		for (i=0;i<oriFisherInfo.length;i++) {
			System.out.print(String.format("\nESL_of_br[%d]=%f/%f*n= %f",i,oriFisherInfo[i],
					simulFisherInfo[0][i], brESL[0][i] ));
			if (!valid[i])
				System.out.print(String.format("<- invalid p-ESL"));
			sum += brESL[0][i] * simulFisherInfo[0][i] * simulFisherInfo[0][i] / w_denom ;
		}
		
		System.out.print(String.format("\n(weighted)Mean ESL=%f",sum));
		
		System.out.print(String.format("\nw_denom=%f\n",w_denom));
		for (i=0;i<oriFisherInfo.length-1;i++) {
			if (valid[i])
				System.out.print(String.format("%f*%f+",simulFisherInfo[0][i],simulFisherInfo[0][i]));
			else 
				System.out.print(String.format("%f*%f+",0.0,0.0));
		}
		if (valid[i])
			System.out.print(String.format("%f*%f",simulFisherInfo[0][i],simulFisherInfo[0][i]));
		else
			System.out.print(String.format("%f*%f",0.0,0.0));
		
		System.out.print(String.format("\nn_e=%f\n",this.meanESL[0]));
		for (i=0;i<oriFisherInfo.length-1;i++) {
			if (valid[i])
				System.out.print(String.format("%f*%f/w_denom*%f+",simulFisherInfo[0][i], simulFisherInfo[0][i],brESL[0][i] ));
			else
				System.out.print(String.format("%f*%f/w_denom*%f+",0.0, 0.0,0.0 ));
		}
		if (valid[i])
			System.out.print(String.format("%f*%f/w_denom*%f",simulFisherInfo[0][i], simulFisherInfo[0][i],brESL[0][i] ));
		else
			System.out.print(String.format("%f*%f/w_denom*%f",0.0, 0.0,0.0 ));
		
		System.out.print(String.format("\n\nFor simple arithmetic mean...\nz<-c("));
		for (i=0;i<brESL[0].length;i++) {
			if (valid[i]) {
				System.out.print(String.format("%f",brESL[0][i]));
				if (i==brESL[0].length-1 || i==brESL[0].length-2 && valid[brESL[0].length-1] == false)
					System.out.print(") ");
				else 
					System.out.print(", ");
			}
		}
		System.out.print(String.format("\nmean(z) \nvar(z) \nsd(z) \nsd(z)/mean(z) \n\n"));
		
		
		System.out.print(String.format("\n\n#Relationship of br vs. 2ndDeriv or brESL.."));
		System.out.print(String.format("\nx<-c("));
		for (i=0;i<myT[0].myTree.brParam.length;i++) {
			if (valid[i]) {
				System.out.print(String.format("%f",myT[0].myTree.brParam[i]));
				if (i==myT[0].myTree.brParam.length-1 || i==myT[0].myTree.brParam.length-2 && valid[myT[0].myTree.brParam.length-1] == false)
					System.out.print(") ");
				else 
					System.out.print(", ");
			}
		}
		
		System.out.print(String.format("\ny<-c("));
		for (i=0;i<this.oriFisherInfo.length;i++) {
			if (valid[i]) {
				System.out.print(String.format("%f",oriFisherInfo[i]));
				if (i==oriFisherInfo.length-1 || i==oriFisherInfo.length-2 && valid[oriFisherInfo.length-1] == false)
					System.out.print(") ");
				else 
					System.out.print(", ");
			}
		}
		

		System.out.print(String.format("\n\nplot(x,y,xlab=\"br\", ylab=\"Fisher Info\") \nplot(x,z,xlab=\"br\", ylab=\"ESL\")\n"));
	
		
	}
	
	
	
}



class MultiThread {

	
	public static void main(String args[]) {
		
		MyMultiThreadJob MyJob = new MyMultiThreadJob(2, 2);
		MyJob.DoAnalysis();
		
		
	}
}