package ESL_v02;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Vector;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TreeMLNuc extends TreeML implements Analysis {

	double[] rateParamHess;

	
	
	TreeMLNuc() {
		nameTag = "";
		multiThrId = 0;
		
		// these are required in order to print out only once. 
		bootedBetaAlreadyPrinted = 0;
		this.bootedRhoAlreadyPrinted =  false;
		this.mlFineTuning = true;
		
	}

	public void job20200611() { 
		
	       
		this.version = 20210619;	
		System.out.println("Version: ESL_v02_"+this.version);
		
		preSolution();
		getSolution();
		
		
		//printResult();
		
		
		/*		
		this.jobESLCalc();
			 */
		
		
		
	}
	
	public void job20200727() { // ml topology searching
		
	}
	
	
	public void getSolution() {
		
		if (myJob == JobType.INDEL_SUBS_DEPENDENCY) {
			
		}
		else if (myJob == JobType.SIMUL) {

		}
		else if (myJob == JobType.EST_BR_HESS_ESL || myJob == JobType.READ_INFO_PAML) {
			if (this.myFreqOpt == FreqType.DATAFREQ) {
				this.getEmpiricalPI();
				calRateMat();
			}
			
			this.estimateRhoBeta();
			
			//this.raxmlRelated();

		}
		else if (myJob == JobType.EST_BR_HESS) {
	

		}
		else if (myJob == JobType.EST_HESS_ESL || myJob == JobType.READ_INFO) {

		}
		else if (myJob == JobType.INDEL_SUBS_TEST) {

		}
		else {
			myFunc.print(String.format("\nNot implemented..\n\n "));
			System.exit(0);
		}
		
		
		
	}
	
		
	public void jobESLCalc() {
		//Calc2ndDeriv();
		Calc2ndDeriv2();
		
		Print2ndDerivScreen();
		
		
		try
	    { 
			 //String mes = "cmd /c start \"\" my_job.bat";
			 String mes = "cmd /c start my_job.bat";
			 Runtime.getRuntime().exec(mes);
	    } 
		catch (Exception e) 
		{ 
			System.out.println("Something Wrong in Runtime.getRuntime().exec(..) "); 
			e.printStackTrace(); 
		} 
		
	}
	
	
	public void preSolution() {
		
		this.getOption();
		
		LoadSeqFile(oriSeqFile); // to get taxaNum etc..., this function will be called again
		
		alphabetVec = new Vector<Character>();
		alphabetVec.setSize(4);
		alphabetVec.set(0, 'A');
		alphabetVec.set(1, 'C');
		alphabetVec.set(2, 'T');
		alphabetVec.set(3, 'G');
		
		alphabetFreq = new Vector<Double>();
		alphabetFreq.setSize(alphabetVec.size());
		
		
		myFunc.myRand = new Random(this.randSeed + this.multiThrId);
		myRand = new Random(this.randSeed + this.multiThrId);
		
		stateDim = 4;
		
		gammaCateNum = 5;
		//gammaCateNum = 1;
		
		rateParam = new double[6]; // GTR model
		
		if (this.OPT.subsModel == ModelType.JC) {
			for (int i=0;i<rateParam.length;i++) {
				rateParam[i] = 1.0;
			}			
		}
		else if (this.OPT.subsModel == ModelType.TN93) {
			this.rateParam[0] = this.rateParam[1] = this.rateParam[4] = this.rateParam[5] = 1.0;	
			this.rateParam[2] = OPT.rateParam[2];
			this.rateParam[3] = OPT.rateParam[3];
		}
		else if (this.OPT.subsModel == ModelType.GTR) {
			for (int i=0;i<rateParam.length;i++) {
				rateParam[i] = this.OPT.rateParam[i];
			}
		}
		else {
			System.err.println("\ncheck subs model");
			System.exit(0);
		}

		
		
		
		this.allocateSpace();
		
		PI = new double[stateDim];

		if (gammaCateNum == 1) {
			this.setAlpha(myFunc.ALPHA_UPPER_LIMIT);
			initial_alpha = this.alpha = myFunc.ALPHA_UPPER_LIMIT;
		}
		else 
			this.setAlpha(initial_alpha);
		
		buildTree(oriTopo);		
		if (this.multiThrId==0) {
			reorderBrIdx();
			PrintTreeTopo();
		}

		
		
		//super.preSolution();
		
	}
	
	public void preSolutionNuc20200720() {
		
		// buildTree(oriTopo) is not here
		
		
		this.getOption();
		
		alphabetVec = new Vector<Character>();
		alphabetVec.setSize(4);
		alphabetVec.set(0, 'A');
		alphabetVec.set(1, 'C');
		alphabetVec.set(2, 'T');
		alphabetVec.set(3, 'G');
		
		alphabetFreq = new Vector<Double>();
		alphabetFreq.setSize(alphabetVec.size());
		
		
		myFunc.myRand = new Random(this.randSeed + this.multiThrId);
		myRand = new Random(this.randSeed + this.multiThrId);
		
		stateDim = 4;
		
		gammaCateNum = 5;
		//gammaCateNum = 1;
		
		rateParam = new double[6]; // GTR model
		for (int i=0;i<rateParam.length;i++) {
			rateParam[i] = this.OPT.rateParam[i];
		}
		
		
		
		this.allocateSpace();
		
		PI = new double[stateDim];

		if (gammaCateNum == 1) {
			this.setAlpha(10000.0);
			initial_alpha = this.alpha = 10000.0;
		}
		else 
			this.setAlpha(initial_alpha);
		
		
	}
	
	
	
	public void fillTermLikelihood(char c, double[] v, int pos, double a, int[] i)
	{
		/// DNA model
		switch (c) {
		case 'A': v[pos + 0] = a; i[0] = 1; break;
		case 'C': v[pos + 1] = a; i[0] = 1;  break;
		case 'T': v[pos + 2] = a; i[0] = 1;  break;
		case 'G': v[pos + 3] = a; i[0] = 1;  break;
		/**/
		case 'R': v[pos + 0] = v[pos + 3] = a; i[0] = 2; break; // A, G
		case 'Y': v[pos + 1] = v[pos + 2] = a; i[0] = 2; break;  // C, T
		case '-': v[pos + 0] = v[pos + 1] = v[pos + 2] = v[pos + 3] = a; i[0] = 4; break;
		case '?': v[pos + 0] = v[pos + 1] = v[pos + 2] = v[pos + 3] = a; i[0] = 4; break;
		case 'N': v[pos + 0] = v[pos + 1] = v[pos + 2] = v[pos + 3] = a; i[0] = 4; break;
		case '.': v[pos + 0] = v[pos + 1] = v[pos + 2] = v[pos + 3] = a; i[0] = 4; break;
		case 'S': v[pos + 1] = v[pos + 3] = a; i[0] = 2; break; //G, C
		case 'W': v[pos + 0] = v[pos + 2] = a; i[0] = 2; break; // A, T
		case 'K': v[pos + 2] = v[pos + 3] = a; i[0] = 2; break; //G, T
		case 'M': v[pos + 0] = v[pos + 1] = a; i[0] = 2; break; //A, C
		case 'B': v[pos + 1] = v[pos + 2] = v[pos + 3] = a; i[0] = 3; break; //C,G,T
		case 'D': v[pos + 0] = v[pos + 2] = v[pos + 3] = a; i[0] = 3; break; //A,G,T
		case 'H': v[pos + 0] = v[pos + 1] = v[pos + 2] = a; i[0] = 3; break; //A,C,T
		case 'V': v[pos + 0] = v[pos + 1] = v[pos + 3] = a; i[0] = 3; break; //A,C,G
		
		default: 
			System.err.print("\n Invalid nuc " + c + " ... in fillTermLikelihood(..)"); break;
		}
	
		i[0] = 1;
	
	
	}
	
	public void calRateMat() {
		calRateMatGTR();
	}
	
	public void calRateMatGTR() {
		
		// order : A, C, T, G
		// param[0]:A<->C
		// param[1]:A<->T
		// param[2]:A<->G
		// param[3]:C<->T
		// param[4]:C<->G
		// param[5]:T<->G = 1.0,  fixed
	
		int i,j,dim;
		dim =4;
	
		for (i=0;i<dim;i++) {
			for (j=i+1;j<dim;j++) {	
				rateMat[i*dim+j] = PI[j];
				rateMat[j*dim+i] = PI[i];
			}
		}
	
		rateMat[0*dim+1] *= rateParam[0];
		rateMat[1*dim+0] *= rateParam[0];
	
		rateMat[0*dim+2] *= rateParam[1];
		rateMat[2*dim+0] *= rateParam[1];
	
	
		rateMat[0*dim+3] *= rateParam[2];
		rateMat[3*dim+0] *= rateParam[2];
	
		rateMat[1*dim+2] *= rateParam[3];
		rateMat[2*dim+1] *= rateParam[3];
	
		rateMat[1*dim+3] *= rateParam[4];
		rateMat[3*dim+1] *= rateParam[4];
	
		for (i=0;i<dim;i++) {
			double tmp = 0.0;
			for (j=0;j<dim;j++) {
				if (i != j) tmp += rateMat[i*dim+j];
			}
			rateMat[i*dim+i] = -tmp;
		}
	
		double normal = 0;
		for (i=0;i<dim;i++)
			normal += -rateMat[i*dim+i] * PI[i];
	
		for (i=0;i<dim*dim;i++) {
			rateMat[i] /= normal;
		}
	
	
	
		/// Ziheng Yang's code
		myFunc.eigen(1,rateMat,dim,EigenRoot,ri,LeftModal,RightModal,space, dim);
		/*
		for (i=0;i<dim;i++) {
			System.out.print("\nEigenRoot["+i+"]="+EigenRoot[i]);
		}
		for (i=0;i<dim;i++) {
			System.out.print("\nLeftModal["+i+"]["+i+"]="+LeftModal[i*dim+i]);
		}
		System.exit(0);
		*/
	    myFunc.xtoy (LeftModal, RightModal, dim*dim);
		myFunc.matinv (RightModal, dim, dim, space);
	
		rateMatRecalNeeded = false;
	
	}
	
	public double calcLogLike() {
		
		calRateMatGTR();
		return super.calcLogLike();
		
	}
	

	public void initParams() {
	

		int i;
		//rateParamsSave.resize(6); // GTR model
		for (i=0;i<rateParam.length;i++)
			rateParam[i] = 1.0;
		//rateParam[2] = rateParam[3] =   9.23077;  //9.0; //1.0; // 10.0; // initial for A<->G, C<->T
	

		super.initParams();
	}
	
	public void setRateParam(int i, double d) {
		rateParam[i] = d;
		calRateMatGTR();	
		this.setRecalNeeded();
	}

	public void optRateParam(int id, boolean print2screen) {
		//cerr<<endl<<" -rate param "<<id<< " -";
	
		double x,NewLogLike,OldLogLike, ori,OriLogLike,New1stD,NewVal, OldVal;
		
		ori = rateParam[id];
	
		/*
		setRateParam(id, ori);
		OriLogLike = CalcLogLike();
		*/
		NewLogLike = OriLogLike = logLike;
	
		double a,b,v,v2,h,tmp1,tmp2;		
		String buf;
		
		if (Math.abs(ori-myFunc.RATE_PARAM_LOWER_LIMIT) <  myFunc.EPSILON) {
			setRateParam(id, 2.0*myFunc.RATE_PARAM_LOWER_LIMIT);
			a = calcLogLike();
			
			tmp1 = (a-OriLogLike)/( 2.0*myFunc.RATE_PARAM_LOWER_LIMIT); // first derivative
			if (OriLogLike > a || Math.abs(tmp1) < myFunc.SmallFirstDerivative) { // if decreasing or if not-informative sequence (total gap seq)
				setRateParam(id, myFunc.RATE_PARAM_LOWER_LIMIT);
				NewLogLike = calcLogLike();
				double p = (a - OriLogLike)/myFunc.RATE_PARAM_LOWER_LIMIT;
				buf = String.format("%7.4f %7.4f %8.6f *",myFunc.RATE_PARAM_LOWER_LIMIT,p,NewLogLike);
				if (print2screen)
					System.err.print(buf);
				x = myFunc.RATE_PARAM_LOWER_LIMIT;
				return;
			}
		}
		
		
		if (Math.abs(ori-myFunc.RATE_PARAM_UPPER_LIMIT) <  myFunc.EPSILON) {
			v = myFunc.RATE_PARAM_UPPER_LIMIT * myFunc.DELTA_RATIO_derivative_rateParam;
			setRateParam(id, myFunc.RATE_PARAM_UPPER_LIMIT + v);
			a = calcLogLike();
			
			if (OriLogLike < a) {
				setRateParam(id, myFunc.RATE_PARAM_UPPER_LIMIT);
				NewLogLike = calcLogLike();
				double p = (a - OriLogLike)/v;
				buf = String.format("%7.4f %7.4f %8.6f *",myFunc.RATE_PARAM_UPPER_LIMIT,p,NewLogLike);
				if (print2screen)
					System.err.print(buf);
				return;
			}
		}
	
		
		
		x = ori; // initial value

		v = x * myFunc.DELTA_RATIO_derivative_rateParam;
		//if (v < SmallDiff4Deriv ) v = SmallDiff4Deriv;
	
		setRateParam(id, x+v);
		tmp2 = calcLogLike();
	
		tmp1 = OriLogLike;
		//NewLogLike = OldLogLike = tmp1; 
		a = (tmp2-tmp1)/v;
		NewVal = OldVal = x;
		New1stD = a;
	

		buf = String.format("%7.4f %7.4f %8.6f",x,a,OriLogLike);
		if (print2screen)
			System.err.print(buf);
	
		boolean recovered;
	
		int cnt = 0;
		do  {
			recovered = false;
	
			OldLogLike = logLike;
	
			v = x * myFunc.DELTA_RATIO_derivative_rateParam;
			//if (v<SmallDiff4Deriv) v = SmallDiff4Deriv;
			v2 = (x+v) * myFunc.DELTA_RATIO_derivative_rateParam;
			//if (v2 < SmallDiff4Deriv) v2 = SmallDiff4Deriv;
	
			setRateParam(id, x + v);
			tmp1 = calcLogLike();
	
			setRateParam(id, x+v+v2);
			tmp2 = calcLogLike();
	
	
			b = (tmp2-tmp1)/v2;
			if (Math.abs(b-a) < myFunc.EPSILON ) {
				buf = String.format(" // amlost flat // OptRateParam(..)");
				if (print2screen)
					System.err.print(buf);
				break;
				//goto outofwhileloop;
			}
			h = - a/(b-a) * v;
			if (x + h < myFunc.RATE_PARAM_LOWER_LIMIT) {
				while (x+h<myFunc.RATE_PARAM_LOWER_LIMIT) {
					h /= 2.0;
				}
			}
			if (x + h > myFunc.RATE_PARAM_UPPER_LIMIT) {
				while (x+h > myFunc.RATE_PARAM_UPPER_LIMIT) {
					//cout<<endl<<"x="<<x<<" h="<<h<<" x+h="<<x+h<<" h is adjusted";
					//cerr<<endl<<"x="<<x<<" h="<<h<<" x+h="<<x+h<<" h is adjusted";
					h /= 2.0;
				}
			}

			x += h;
			v = x * myFunc.DELTA_RATIO_derivative_rateParam;
			//if (v < SmallDiff4Deriv) v = SmallDiff4Deriv;
	
			setRateParam(id, x+v);
			tmp2 = calcLogLike();
	
			setRateParam(id, x);
			tmp1 = calcLogLike();
	
	
			a = (tmp2-tmp1)/v;
	
			if (tmp1 > NewLogLike) {
				//OldLogLike = NewLogLike;
				NewLogLike = tmp1;
				//OldVal = NewVal;
				NewVal = x;
				New1stD = a;
			}
			else { // added by seo 20171016
				x = NewVal;
				v = x * myFunc.DELTA_RATIO_derivative_rateParam;
				setRateParam(id, x + v);
				tmp2 = calcLogLike();
				setRateParam(id, x);
				tmp1 = calcLogLike();
				a = (tmp2 - tmp1) / v;
				NewLogLike = logLike;
				NewVal = x;
				New1stD = a;
				recovered = true;
			}
			cnt++; // pTree prevent optimization to be trapped
		} while(Math.abs(a) > myFunc.SmallFirstDerivativeRateParam && cnt<myFunc.maxNewtonR);
	
	outofwhileloop:
	
		setRateParam(id, NewVal);
		NewLogLike = calcLogLike();
		
		///after final round 
		buf = String.format(" | %7.4f %7.4f %8.6f, %d-r",NewVal,New1stD,NewLogLike, cnt);
		if (print2screen)
			System.err.print(buf);
	
		if (cnt==myFunc.maxNewtonR || Math.abs(OriLogLike-NewLogLike) < myFunc.EPSILON ) {
			optRateParam2(id, print2screen);
		}
	
	}

	public void optRateParam2(int id, boolean print2screen) {
		
		double Ori;
		Ori = rateParam[id]; 
		//setAlpha(Ori);
		double OriLogLike = logLike; // CalcLogLike();
		double left, right, center;
		double h;
		double a;
		double tmp1,tmp2;
	
		if (Ori < myFunc.RATE_PARAM_LOWER_LIMIT) Ori = myFunc.RATE_PARAM_LOWER_LIMIT;
		h = Ori * myFunc.DELTA_RATIO_derivative_rateParam;
		//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
		
		setRateParam(id, Ori+h);
		tmp2 = calcLogLike();
	
		setRateParam(id, Ori);
		tmp1 = calcLogLike();
	
		a = (tmp2-tmp1)/h;
	
		if (a<0.0) {
			right = Ori;
			left = Ori;
			do {
				left = left * 0.8;
				h = left * myFunc.DELTA_RATIO_derivative_rateParam;

				setRateParam(id, left+h);
				tmp2 = calcLogLike();
			
				setRateParam(id, left);
				tmp1 = calcLogLike();
			
				a = (tmp2-tmp1)/h;
			} while(a<0.0&&left>myFunc.RATE_PARAM_LOWER_LIMIT);
			if (left < myFunc.RATE_PARAM_LOWER_LIMIT) left = myFunc.RATE_PARAM_LOWER_LIMIT;
		}
		else {
			left = Ori;
			right = Ori;
			
			do {
				//right = right * 1.1;
				right = right * 1.2;
				if (right > myFunc.RATE_PARAM_UPPER_LIMIT)
					right = myFunc.RATE_PARAM_UPPER_LIMIT;
				h = right * myFunc.DELTA_RATIO_derivative_rateParam;
				//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
		
				setRateParam(id, right+h);
				tmp2 = calcLogLike();
		
				setRateParam(id, right);
				tmp1 = calcLogLike();
		
				a = (tmp2-tmp1)/h;
			} while(a>0.0 &&right < myFunc.RATE_PARAM_UPPER_LIMIT) ; 
			if (right >  myFunc.RATE_PARAM_UPPER_LIMIT) right =  myFunc.RATE_PARAM_UPPER_LIMIT;
		}
		
	
		do {
			center = (left+right)*0.5;
			h = center * myFunc.DELTA_RATIO_derivative_rateParam;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
			
			setRateParam(id, center+h);
			tmp2 = calcLogLike();
	
			setRateParam(id, center);
			tmp1 = calcLogLike();
	
			a = (tmp2-tmp1)/h;
	
			if (a<0.0) right = center;
			else left = center;
		}while(Math.abs(a) > myFunc.SmallFirstDerivativeRateParam && right-left >1.0e-6);
	
		String buf;
		buf = String.format("\n%5c  %7.4f %7.4f %8.6f",'*',center,a,tmp1);
		if (print2screen)
			System.err.print(buf);
	
		if (tmp1 < OriLogLike) {
			setRateParam(id, Ori);
			tmp1 = calcLogLike();
	
		}
		//cout<<endl<<"LogLike = "<<LogLike;
	
	}
	


	public void optRateParam2old(int id) {
	
		double Ori;
		Ori = rateParam[id]; 
		//setAlpha(Ori);
		double OriLogLike = logLike; // CalcLogLike();
		double left, right, center;
		double h;
		double a;
		double tmp1,tmp2;
	
		center = Ori;
		//left = center * 0.9;
		left = center * 0.8;
		if (left < myFunc.RATE_PARAM_LOWER_LIMIT) left = myFunc.RATE_PARAM_LOWER_LIMIT;
		h = left * myFunc.DELTA_RATIO_derivative_rateParam;
		//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
		
		setRateParam(id, left+h);
		tmp2 = calcLogLike();
	
		setRateParam(id, left);
		tmp1 = calcLogLike();
	
		a = (tmp2-tmp1)/h;
	
		//while(a<0.0&&left>myFunc.RATE_PARAM_LOWER_LIMIT) {
		while(a<myFunc.EPSILON &&left>myFunc.RATE_PARAM_LOWER_LIMIT) {
			//left = left * 0.9;
			left = left * 0.8;
			h = left * myFunc.DELTA_RATIO_derivative_rateParam;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
			setRateParam(id, left+h);
			tmp2 = calcLogLike();
	
			setRateParam(id, left);
			tmp1 = calcLogLike();
	
			a = (tmp2-tmp1)/h;
		}
		if (left < myFunc.RATE_PARAM_LOWER_LIMIT) left = myFunc.RATE_PARAM_LOWER_LIMIT;
		
		
		right = center * 1.2;
		if (right > myFunc.RATE_PARAM_UPPER_LIMIT)
			right = myFunc.RATE_PARAM_UPPER_LIMIT;
		h = right*myFunc.DELTA_RATIO_derivative_br;
		
		
	
		setRateParam(id, right+h);
		tmp2 = calcLogLike();
	
		setRateParam(id, right);
		tmp1 = calcLogLike();
	
		a = (tmp2-tmp1)/h;
	
		while(a>-myFunc.EPSILON&&Math.abs(right-myFunc.RATE_PARAM_UPPER_LIMIT) >  myFunc.EPSILON ) {
			//right = right * 1.1;
			right = right * 1.2;
			if (right > myFunc.RATE_PARAM_UPPER_LIMIT)
				right = myFunc.RATE_PARAM_UPPER_LIMIT;
			h = right * myFunc.DELTA_RATIO_derivative_rateParam;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
	
			setRateParam(id, right+h);
			tmp2 = calcLogLike();
	
			setRateParam(id, right);
			tmp1 = calcLogLike();
	
			a = (tmp2-tmp1)/h;
		}
	
		do {
			center = (left+right)*0.5;
			h = center * myFunc.DELTA_RATIO_derivative_rateParam;
			//if (h<SmallDiff4Deriv) h = SmallDiff4Deriv;
			
			setRateParam(id, center+h);
			tmp2 = calcLogLike();
	
			setRateParam(id, center);
			tmp1 = calcLogLike();
	
			a = (tmp2-tmp1)/h;
	
			if (a<0.0) right = center;
			else left = center;
		}while(Math.abs(a) > myFunc.SmallFirstDerivativeRateParam && right-left >1.0e-6);
	
		String buf;
		buf = String.format("\n%5c  %7.4f %7.4f %8.6f",'*',center,a,tmp1);
		System.err.print(buf);
	
		if (tmp1 < OriLogLike) {
			setRateParam(id, Ori);
			tmp1 = calcLogLike();
	
		}
		//cout<<endl<<"LogLike = "<<LogLike;
	
	}
	

	
	@Override
	public void optAllRateParams(boolean print2screen) {
	
		int iter;
		iter = rateParam.length - 1; // the last rateParam = 1.0;
		double oldLogLike, newLogLike;
	
	
		setRecalNeeded();
		oldLogLike = calcLogLike();
	
		double temp = oldLogLike;
	
		int i=0;
		String buf;
	
		if (this.subsModel == ModelType.JC) {
			// do nothing
		}
		else {
			buf = String.format("\n -rateParam-");
			if (print2screen)
				System.err.print(buf);
			oldLogLike = logLike;
			if (this.subsModel == ModelType.GTR) {
				for (i=0;i<rateParam.length;i++) {
					//if (i!=2) { // if not A <->G
					if (i!=rateParam.length-1) { // if not T <->G	
						buf = String.format("\n%4d ",i);
						if (print2screen)
							System.err.print(buf);
						optRateParam(i,print2screen);
					}

				}
			}
			else if (this.subsModel == ModelType.TN93) {
				for (i=2;i<4;i++) {  // for (i = 0; i < iter; i++) { // 
					buf = String.format("\n%4d ",i);
					if (print2screen)
						System.err.print(buf);
					optRateParam(i,print2screen);
				}
			}
			else {
				myFunc.print(String.format("\nNot implemented..\n\n "));
				System.exit(0);
			}

			newLogLike = logLike;
			
		}
		

	
	}


	@Override
	public void optimizeSub_pruning_paramSets(boolean print2screen) {
		super.optimizeSub_pruning_paramSets(print2screen);
		optAllRateParams(print2screen);	
		//optAllRateParams(print2screen); //twice
		
		/*
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
			optGapPropMultFactor();
			if (this.gammaCateNum > 1)
				optAlpha();	
			optAllRateParams();	
			optAllRateParams(); //twice
			optAllBranches();
		}

		else {
			if (this.gammaCateNum > 1)
				optAlpha();	
						
			optAllRateParams();	
			optAllRateParams(); // twice
			optAllBranches();
		}
		*/
	}

	public void optimizeSub_pruning_paramSets_2(boolean print2screen) {
		////////////////////////////////////
		// this is only for slope estimation
		// if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor)
		//////////////////////////////////////
		String str = String.format("\nAfter only optGapPropMultFactor() opt");
		System.out.print(str);
		Print2ndDerivScreen();

		if (this.gammaCateNum > 1)
			optAlpha(print2screen);	
		optAllRateParams(print2screen);	
		optAllBranches(print2screen);

		this.setRecalNeeded();
		this.calcLogLike();	
		str = String.format("\n\nAfter 1-R the other opt's");
		System.out.print(str);
		Print2ndDerivScreen();
	}

	
	
	
	public void Calc2ndDeriv2() {
		super.Calc2ndDeriv2();
		
		rateParamHess = new double[6]; // GTR model
		
		int i;
		double x, h, sum, oriRateParam;
		//Calculating rateParamHess
		for (i=2;i<4;i++) {  // for (i = 0; i < iter; i++) { // 
			oriRateParam = x = rateParam[i];
			h =	 x * myFunc.DELTA_RATIO_derivative_rateParam;	
			sum = 0.0;
			setRateParam(i, x+2*h);
			sum -= calcLogLike();
			setRateParam(i, x+h);
			sum += 16 * calcLogLike(); 
			setRateParam(i, x);
			sum -= 30 * calcLogLike(); 
			setRateParam(i, x-h);
			sum += 16 * calcLogLike(); 
			setRateParam(i, x-2*h);
			sum -= calcLogLike();
			rateParamHess[i] = sum / (12*h*h);
			setRateParam(i, oriRateParam);
			calcLogLike();
		}
	}
	
	@Override
	public void printEstimatedParam() {

		myFunc.print(String.format("\n\nEstimates under nucleotide model"));
		myFunc.print(String.format("\nrateParam[0] = %f; %c<->%c", rateParam[0], alphabetVec.get(0), alphabetVec.get(1) ));
		myFunc.print(String.format("\nrateParam[1] = %f; %c<->%c", rateParam[1], alphabetVec.get(0), alphabetVec.get(2) ));
		myFunc.print(String.format("\nrateParam[2] = %f; %c<->%c", rateParam[2], alphabetVec.get(0), alphabetVec.get(3) ));
		myFunc.print(String.format("\nrateParam[3] = %f; %c<->%c", rateParam[3], alphabetVec.get(1), alphabetVec.get(2) ));
		myFunc.print(String.format("\nrateParam[4] = %f; %c<->%c", rateParam[4], alphabetVec.get(1), alphabetVec.get(3) ));
		myFunc.print(String.format("\nrateParam[5] = %f; %c<->%c \r\n", rateParam[5], alphabetVec.get(2), alphabetVec.get(3) ));
		int i;
		for (i=0;i<rateParam.length;i++) 
			myFunc.print(String.format("%f ", rateParam[i] ));
		
		myFunc.print(String.format("\r\n "));
		for (i=0;i<this.PI.length;i++) {
			char c = ' ';
			switch(i) {
				case 0: c = 'A'; break;
				case 1: c = 'C'; break;
				case 2: c = 'T'; break;
				case 3: c = 'G'; break;
				default: System.exit(0);
			}
			myFunc.print(String.format("\nPI[%d] = %f // %c", i, PI[i], c));
		}
			
		super.printEstimatedParam();
		
		///myFunc.printArrayRstyle(this.sitewiseGapProp, "sitewiseGapProp");
		
	}
	
	public void simulation20200424() {
		
		
	}
	
	
	
	public void simulation20200421() {
		
		
	}
	
	public void backupEstimates() {
		int i;
		
		super.backupEstimates();
		
		this.rateParamBackup = new double[this.rateParam.length];
		for (i=0;i<rateParamBackup.length;i++) {
			rateParamBackup[i] = rateParam[i];
		}
	
		
	}
	
	public void recoverBackupedEstimates() {
		int i;
		
		
		super.recoverBackupedEstimates();
		
		for (i=0;i<rateParamBackup.length;i++) {
			rateParam[i] = rateParamBackup[i];
		}
		
		this.calRateMat();
		

	}
	
	public void simulation20200611() {
	
	}
	
	public void simulation20200327(double [] rho, double [] beta) {
		
	}
	

	public void simulation20210424(double [] rho, double [] beta) {
		
	}
	

	
} // end of public class TreeMLNuc extends TreeML implements Analysis {


