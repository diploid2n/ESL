package ESL_v02;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.lang.*;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;



public class Tree {

	public ModelType subsModel;
	public FreqType myFreqOpt;
	public BootstrapType bootTypeOpt;
	public GapPropMultFactorType gapPropMultFactorOpt;
	
	InputOption OPT;
	
	int multiThrId;
	
	int version;
	int taxaNum, taxaNumOri, seqLength, simulLength;
	int shortBrConstraint;
	int CIforBoundaryCheck;
	
	//simulLength2, extremelyLargeLength
	int simulLengthTimes, simulLengthTimes2;
	int brNum, nodeNum, ingroupTaxaNum, ingroupBrNum, ingroupNodeNum;
	int  bootIter;
	
	JobType myJob; //Est, CalcHess, Simul
	
	String[] taxaNameList, taxaNameListOri, taxaNameListFromTreeTopo;
	String[] taxaNameListIdenticalA, taxaNameListIdenticalB; // B is removed taxa from original data
	String firstTaxon; // position for getting alphabetical order topology string
	
	double[][] brESL;
	
	public String oriTopo, oriSeqFile;
	
	double alpha, initial_alpha;
	
	double meanESL[]; //0: real data, 1:imaginary gappy
	double globalBeta;
	double globalRho;
	//double w_denom;
	double[] weightForRho;
	double[] weightForBeta;
	
	boolean[] valid; // second derivative validity

	
	int randSeed;
	double nonrandomRatio;
	int randomInitialTrees;
	
	Vector<Double> alphabetFreq;
	Vector<Character> alphabetVec;
	
	Node startNode; // StartNodePtr
	/*
	ArrayList<Node> brPos;
	ArrayList<Node> nodePos; 
	ArrayList<Node> nodeOfTip; // PtrToTip
	*/
	
	Node[] brPos, nodePos, nodeOfTip;
	boolean[] brPosValidity;
	//int brPosIdx;
	
	boolean userBr;

	double[] PreventUnderflow; //[patternCnt] 
	int[]  cntUnderflow; //[patternCnt] vague nuc.  
	int[] alphabetDataPatternNum, alphabetDataPatternNumOri; 
	
	double[] sitewiseGapProp;
	double[] taxonwiseGapProp;
	double[] sitewiseGapPropCDF;
	//double[] sitewiseGapPropBrMultFactorOri;
	double[] sitewiseGapPropBrMultFactor;	
	double gapPropMultFactorSlope;
	double gapOverallMean;
	
	int stateDim, gammaCateNum;
	String dataFileName;
	
	char[][] alphabetData, alphabetDataOri, alphabetDataOriUnsorted; //[TaxaNum][SeqLength]   ,; //
	char[][] alphabetDataIdentical;
	
	double[][] sitewiseESLTot;
	double[][] sitewise2ndDerivTot;
	
	
	//double[][] sitewiseRhoTot;
	//double[] sitewiseRho;
	double[] parameterwiseESL;	
	double[] sitewiseESL;	
	double[][] spESL;
	
	double[][] parameterwiseRho; //[0][parameter id] : mean, [1][parameter id]:std of the mean ; // see 20200211 handwritten note for bootstrapped variance. 


	double[] sitewiseRhoSumStd;
	
	double[][] sitewiseBetaTot;
	double[] sitewiseBeta;
	double[] sitewiseBetaSumStd;
	double[][] parameterwiseBeta;  //[parameter id][0] : mean, [parameter id][1]:std of the mean
	double[][] parameterwiseBetaCov;
	double[] parameterwiseBetaStat;
	double[] parameterwisePvalue;
	double globalBetaPvalue;
	
	//double globalBetaStd, globalBetaStdFromBoot, globalRhoStd;
	
	double ESL;
	
	boolean dataSorted;
	
	double gammaRateFreq[]; // gammaRateFreq[10];   
	double gammaRateFactor[];
	
	double[] brParam, BrGammaSpace, BrParamPathSum;


	double[] probMatP;

	double[] ri, EigenRoot, LeftModal, RightModal, space, rateMat, probMat; 

	double logLike;
	double[] PI; //A,C,T,G
	double[] sitewiseLogLike; // [patternCnt]
	double[] sitewiseLogLike_deriv; // [patternCnt]
	double[] sitewiseLogLike_deriv2; // [patternCnt]
	
	double sitewiseLogLikeMean, sitewiseLogLikeVar;
	//double sitewiseLogLikeSimulMean, sitewiseLogLikeSimulVar;
	
	boolean rateMatRecalNeeded;
	
	int optMaxR;
	
	ArrayList<String> topoList;
	
	double[][] pairDist;
	
	String outgroupTaxon;
	
	// backup estimates
	double[] brEstimateBackup;	
	double[] PIBackup;
	double alphaBackup;
	double[] rateParamBackup;
	
	
	public Vector<String> optString;
	
	Random myRand;
	
	double[][] topoMat;
	
	boolean includeAllSitesForGapPropCDF;
	
	
	// K-means clustering
	double distCenterTaxa[][]; //double[this.taxaNameList.length][numCluster];
	int clusterMember[];
	Node[] centerPos;
	double[] centerBrRatio;
	int numCluster;
	double KMeanClusterVecSumSq;
	double KMeanClusterSubtreeSumSq;
	double[][] patristicDistance;
	double[] silhouetteCoeff;
	
	// ball representation
	double[][] alphabetData2Double;
	double[][] centroidVec;
	
	/////////////////////////////////////
	/////////////////////////////////////
	/////////

	/*
	public String getTree() {
		return String.format("getTree() not implemented yet..");
	}
	*/
	
	public void setBrPosValidity(boolean TF) {
		Node pNode;
		pNode = this.startNode;
		do {
			setBrPosValidity(pNode, TF);
			pNode = pNode.isoNd;
		} while (pNode!=this.startNode);
	}
	
	public void setBrPosValidity(Node ptr, boolean TF) {
		if (ptr.desNd.isoNd != null) {
			Node pNode;
			pNode = ptr.desNd.isoNd;
			do {
				setBrPosValidity(pNode, TF);
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
		}
		int i;
		for (i=0;i<this.brPos.length;i++) {
			if (brPos[i] == ptr || brPos[i].desNd == ptr) {
				this.brPosValidity[i] = TF;
				break;
			}
		}
	}
	
	public void setStartNode(String str) {
		
		Node pNode;
		pNode = this.startNode;
		
		do {
			if (str.equals(pNode.taxonName)) {
				this.startNode = pNode.desNd;
				return;
			}
			if (pNode.desNd.isoNd != null) {
				pNode = pNode.desNd.isoNd;
			}
			else pNode = pNode.desNd;
		} while (pNode != this.startNode);
		
		/*
		int i;
		for (i=0;i<brPos.length;i++) {
			if (brPos[i].desNd.taxonName.equals(str)) {
				this.startNode = brPos[i];
				break;
			}
		}
		*/
	}
	
	public void rotateDesIso(Node ptr) {
		boolean debugMode = false;
		
		if (ptr.desNd.isoNd != null) {
			Node pNode, pNode2, rightMost;
			pNode = ptr.desNd;
			String[] topoStr = new String[1];
			do {
				if (debugMode) {
					this.getTopologySub(ptr, topoStr);
					System.out.print("\r\n# within rotate pNode: "+topoStr[0]);
				}

				pNode = pNode.isoNd;
			} while (pNode.isoNd.isoNd != ptr.desNd);
			
			
			rightMost = pNode;
			
			if (debugMode) {
				this.getTopologySub(rightMost, topoStr);
				System.out.print("\r\n# within rotate rightMost: "+topoStr[0]);
			}

			
			pNode = ptr.desNd.isoNd;
			pNode2 = rightMost.isoNd;
			
			rightMost.isoNd = ptr.desNd;
			ptr.desNd.isoNd = pNode2;
			pNode2.isoNd = pNode;

		}
	}
	
	public void exchangeLeftRight(Node ptr) {
		if (ptr.desNd.isoNd != null) {
			Node pNode;
			pNode = ptr.desNd.isoNd;
			do {
				exchangeLeftRight(pNode);
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
			pNode = ptr.desNd.isoNd;
			ptr.desNd.isoNd = ptr.desNd.isoNd.isoNd;
			ptr.desNd.isoNd.isoNd = pNode;
			ptr.desNd.isoNd.isoNd.isoNd = ptr.desNd;
		}
	}
	
	public void exchangeLeftRight() {
		Node pNode;
		pNode = this.startNode;
		do {
			exchangeLeftRight(pNode);
			pNode = pNode.isoNd;
		} while (pNode != startNode);
	}
	
	public void calcPairDist() {
		/// simple number of difference
		// data sorting should be done before. 
		
		this.pairDist = new double[taxaNum][taxaNum];

		int i,j, k, diff, total;
		for (i=0;i<alphabetData.length;i++) {
			for (j=i;j<alphabetData.length;j++) {
				diff = 0;
				total = 0;
				for (k=0;k<alphabetData[0].length;k++) {
					if (alphabetData[i][k] !='-' && alphabetData[i][k] !='?' 
						&& alphabetData[j][k] !='-' && alphabetData[j][k] !='?') {
						total += alphabetDataPatternNum[k];
						if (alphabetData[i][k] != alphabetData[j][k]) {
							diff += alphabetDataPatternNum[k];
						}
					}

				}
				this.pairDist[i][j] = this.pairDist[j][i] = 1.0*diff/total; // 1.0*diff/total; //1.0*diff/this.seqLength;
			}
		}
		
		
		/*
		System.out.print("\r\np distances");
		for (i=0;i<nucData.length;i++) {
			System.out.print("\r\n");
			for (j=0;j<nucData.length;j++) {
				System.out.print(" "+this.pairDist[i][j]);
			}
		}
		System.out.print("\r\nPattern numbers..\n\r");
		for (i=0;i<nucDataPatternNum.length;i++) {
			System.out.print(" "+this.nucDataPatternNum[i]);
		}
		*/
		
	}


	
	public void calcPairDist2() {
		/// simple number of difference
		// data sorting should be done before. 
		
		this.pairDist = new double[taxaNum][taxaNum];

		int i,j, k, diff, total;
		for (i=0;i<alphabetData.length;i++) {
			for (j=i;j<alphabetData.length;j++) {
				diff = 0;
				total = 0;
				for (k=0;k<alphabetData[0].length;k++) {
					if (alphabetData[i][k] !='-' && alphabetData[i][k] !='?' 
						&& alphabetData[j][k] !='-' && alphabetData[j][k] !='?') {
						total += alphabetDataPatternNum[k];
						if (alphabetData[i][k] != alphabetData[j][k]) {
							diff += alphabetDataPatternNum[k];
						}
					}

				}
				double r = 1.0-1.0/this.stateDim;
				if (1.0-1.0/r * 1.0*diff/total > 0.0)
					r = - r * Math.log(1.0-1.0/r * 1.0*diff/total);
				else
					r = 1.0e6; // large number 
				this.pairDist[i][j] = this.pairDist[j][i] = r; // 1.0*diff/total; //1.0*diff/this.seqLength;
			}
		}
		
	}
	
	public void calcPairDistTN93Gamma(double a) {
		/// simple number of difference
		// data sorting should be done before. 
		
		this.pairDist = new double[taxaNum][taxaNum];

		int i,j, k, diff, total;
		double P1, P2, Q, w1, w2, w3, k1, k2, k3, k4;
		double piA, piC, piT, piG,  piR, piY;
		piR = PI[0] + PI[3];
		piY = PI[1] + PI[2]; 
		piA = PI[0];
		piC = PI[1];
		piT = PI[2];
		piG = PI[3];
				
		k1 = 2.0 * piA * piG/(piR); //2*A*G/(A+G)
		k2 = 2.0 * piT * piC/(piY); //2*C*T/(C+T)
		k3 = 2.0*(piR*piY-piA*piG*piY/piR-piT*piC*piR/piY);
		k4 = 2*(piA*piG+piT*piC+piR*piY);

		
		for (i=0;i<alphabetData.length;i++) {
			for (j=i;j<alphabetData.length;j++) {
				diff = 0;
				total = 0;
				P1 = P2 = Q = 0.0;
				for (k=0;k<alphabetData[0].length;k++) {
					//if (alphabetData[i][k] !='-' && alphabetData[i][k] !='?' 
						//&& alphabetData[j][k] !='-' && alphabetData[j][k] !='?') {
					if (!this.isGap(alphabetData[i][k]) && !this.isGap(alphabetData[j][k])) {
						
						total += alphabetDataPatternNum[k];
						if (alphabetData[i][k] ==  alphabetData[j][k]) {
							;
						}
						else if (alphabetData[i][k] == 'A' && alphabetData[j][k] == 'G') {
							P1 += alphabetDataPatternNum[k];
						}
						else if (alphabetData[i][k] == 'G' && alphabetData[j][k] == 'A') {
							P1 += alphabetDataPatternNum[k];
						}
						else if (alphabetData[i][k] == 'T' && alphabetData[j][k] == 'C') {
							P2 += alphabetDataPatternNum[k];
						}
						else if (alphabetData[i][k] == 'C' && alphabetData[j][k] == 'T') {
							P2 += alphabetDataPatternNum[k];
						}
						else {
							Q += alphabetDataPatternNum[k];
						}
					}
				}
				P1 /= total;
				P2 /= total;
				Q /= total;
				w1 = 1.0 - P1/k1 - Q/(2*piR);
				w2 = 1.0 - P2/k2 - Q/(2*piY);
				w3 = 1.0 - Q/(2*piY*piR);
				double dist;
				if (w1<0 || w2<0 || w3 < 0)
					dist =  1.0e6; // large number
				else {
					dist = a * (k1*Math.pow(w1, -1.0/a)+k2*Math.pow(w2, -1.0/a)+k3*Math.pow(w3, -1.0/1)-k4);
					if (dist<myFunc.BRANCH_LENGTH_LOWER_LIMIT)
						dist = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
				}
				this.pairDist[i][j] = this.pairDist[j][i] = dist; 
			}
		}
		
		System.err.print("");
		
	}
	
	
	public void calcPairDistTN93() {
		/// simple number of difference
		// data sorting should be done before. 
		
		this.pairDist = new double[taxaNum][taxaNum];

		int i,j, k, diff, total;
		double P1, P2, Q, w1, w2, w3, k1, k2, k3;
		double piA, piC, piT, piG,  piR, piY;
		piR = PI[0] + PI[3];
		piY = PI[1] + PI[2]; 
		piA = PI[0];
		piC = PI[1];
		piT = PI[2];
		piG = PI[3];
				
		k1 = 2.0 * piA * piG/(piR); //2*A*G/(A+G)
		k2 = 2.0 * piT * piC/(piY); //2*C*T/(C+T)
		k3 = 2.0*(piR*piY-piA*piG*piY/piR-piT*piC*piR/piY);

		
		for (i=0;i<alphabetData.length;i++) {
			for (j=i;j<alphabetData.length;j++) {
				diff = 0;
				total = 0;
				P1 = P2 = Q = 0.0;
				for (k=0;k<alphabetData[0].length;k++) {
					//if (alphabetData[i][k] !='-' && alphabetData[i][k] !='?' 
						//&& alphabetData[j][k] !='-' && alphabetData[j][k] !='?') {
					if (!this.isGap(alphabetData[i][k]) && !this.isGap(alphabetData[j][k])) {
						
						total += alphabetDataPatternNum[k];
						if (alphabetData[i][k] ==  alphabetData[j][k]) {
							;
						}
						else if (alphabetData[i][k] == 'A' && alphabetData[j][k] == 'G') {
							P1 += alphabetDataPatternNum[k];
						}
						else if (alphabetData[i][k] == 'G' && alphabetData[j][k] == 'A') {
							P1 += alphabetDataPatternNum[k];
						}
						else if (alphabetData[i][k] == 'T' && alphabetData[j][k] == 'C') {
							P2 += alphabetDataPatternNum[k];
						}
						else if (alphabetData[i][k] == 'C' && alphabetData[j][k] == 'T') {
							P2 += alphabetDataPatternNum[k];
						}
						else {
							Q += alphabetDataPatternNum[k];
						}
					}
				}
				P1 /= total;
				P2 /= total;
				Q /= total;
				w1 = 1.0 - P1/k1 - Q/(2*piR);
				w2 = 1.0 - P2/k2 - Q/(2*piY);
				w3 = 1.0 - Q/(2*piY*piR);
				double dist;
				if (w1<0 || w2<0 || w3 < 0)
					dist =  1.0e6; // large number
				else {
					dist = -k1*Math.log(w1) - k2*Math.log(w2) - k3*Math.log(w3);
				}
				this.pairDist[i][j] = this.pairDist[j][i] = dist; 
			}
		}
		
		System.err.print("");
		
	}
	
	
	public void getOption() {


		
		OPT = new InputOption();
		
		
		//OPT.LoadInputOption_test12("options_test12.txt");
		//OPT.LoadInputOption_test12("options_20190926.txt");

		
		OPT.LoadInputOption();

		
		//System.out.println(OPT.oriSeqFile);
		//System.out.println(OPT.nModel);
		
	
		this.subsModel = OPT.subsModel;
		this.myFreqOpt  = OPT.myFreqOpt;
		this.oriTopo = OPT.oriTopo;
		this.oriSeqFile = OPT.oriSeqFile;

		this.randSeed = OPT.randSeed;
		this.nonrandomRatio = OPT.nonrandomRatio;
		this.randomInitialTrees = OPT.randomInitialTrees;
		
		this.simulLength = OPT.simulLength;
		this.simulLengthTimes = OPT.simulLengthTimes;
		this.simulLengthTimes2 = OPT.simulLengthTimes2;
		this.bootIter = OPT.bootIter;
		this.bootTypeOpt = OPT.bootTypeOpt;
		this.gapPropMultFactorOpt = OPT.gapPropMultFactorOpt;
		

		
		//this.taxaNum = OPT.simulTaxa;
		this.taxaNumOri = this.taxaNum;
		this.shortBrConstraint = OPT.shortBrConstraint;
		this.CIforBoundaryCheck = OPT.CIforBoundaryCheck;
		
		
		this.myJob = OPT.myJob;
		
		if (OPT.initial_alpha > myFunc.ALPHA_UPPER_LIMIT)
			OPT.initial_alpha = myFunc.ALPHA_UPPER_LIMIT;
		if (OPT.initial_alpha < myFunc.ALPHA_LOWER_LIMIT)
			OPT.initial_alpha = myFunc.ALPHA_LOWER_LIMIT;			
		this.alpha = this.initial_alpha = OPT.initial_alpha;

		
	
		
		optString = new Vector<String>(); 
		
		if (this.multiThrId==0) {
			myFunc.print(String.format("\n### Input Options ###"));
			for (String s : OPT.optString) {
	            //System.out.println(s);
	            myFunc.print("\n" + s);
	            optString.add(s);
	        }
		}
		
		
		
		
	}
	
	public void printOption() {
		
		
		
	}

	
	public void getTree(String[] treetopo)
	{
	
		if (this.brESL == null) 
			brESL = new double[2][2*taxaNum-3];
		
		Node pNode = this.startNode.isoNd;
		String[] topoA = new String[4];
	
		

		getTree2(pNode,topoA);
		
		int i;
		for (i=0;i<topoA.length;i++) {
			treetopo[i] = "(";		
			treetopo[i] += topoA[i];
		}

	
		pNode = pNode.isoNd;
		do {
			for (i=0;i<topoA.length;i++) {
				treetopo[i] +=",";
			}
			getTree2(pNode,topoA);
			for (i=0;i<topoA.length;i++) {
				treetopo[i] += topoA[i];
			}
			pNode = pNode.isoNd;
		} while(pNode != this.startNode.isoNd);
		for (i=0;i<topoA.length;i++) {
			treetopo[i] += ");";
		}
	}
	
	public void getTree2(Node ptr, String[] topostr)
	{
		Node pNode;
		String[] topoA = new String[4];
		
		int i;
	
		if (ptr.desNd.isoNd == null) { // if terminal node
			topostr[0] = ptr.desNd.taxonName;
			topostr[0] += ":";
			//topostr[0] += String.format("%.10f", ptr.branchLength);
			topostr[0] += String.format("%f", ptr.branchLength);
			topostr[3] = ptr.desNd.taxonName; // only topology
			
			if (this.parameterwiseRho == null) // if paramterwiseRho, parameterwiseBeta tree is not required
				return;
			
			int id = -1;
			for (i=0;i<this.taxaNameList.length;i++) {
				if (this.taxaNameList[i].equals(ptr.desNd.taxonName)) {
					id = i;
					break;
				}
			}
			if (id==-1) {
				System.err.println("\nSomething wrong 1 ...");
				System.exit(0);
			}
			topostr[1] = String.format("%d", id+1);
			topostr[2] = String.format("%d", id+1);
			
			id = -1;
			for (i=0;i<this.brPos.length;i++) {
				if (this.brPos[i] == ptr || this.brPos[i] == ptr.desNd) {
					id = i;
					break;
				}
			}
			if (id==-1) {
				System.err.println("\nSomething wrong 2 ...");
				System.exit(0);
			}
			
			if (valid[id])
				topostr[1] += String.format("[Rho=%f]", this.parameterwiseRho[0][id]);
			else
				topostr[1] += String.format("[Rho=%f]", this.globalRho);
			topostr[1] += ":";
			//topostr[1] += String.format("%.10f", ptr.branchLength);
			topostr[1] += String.format("%f", ptr.branchLength);
			if (valid[id])
				topostr[2] += String.format("[Beta=%f]", this.parameterwiseBeta[0][id]);
			else
				topostr[2] += String.format("[Beta=%f]", this.globalBeta);
			topostr[2] += ":";
			//topostr[2] += String.format("%.10f", ptr.branchLength);
			topostr[2] += String.format("%f", ptr.branchLength);
			
			/*
			topostr[1] += String.format("[ESL=%f]", this.brESL[0][id]);
			topostr[1] += ":";
			topostr[1] += String.format("%f", ptr.branchLength);
			topostr[2] += String.format("[ESL=%f]", this.brESL[1][id]);
			topostr[2] += ":";
			topostr[2] += String.format("%f", ptr.branchLength);
			*/
			
		}
		else { // if not terminal
			
			int id = -1;
			for (i=0;i<this.brPos.length;i++) {
				if (this.brPos[i] == ptr || this.brPos[i] == ptr.desNd) {
					id = i;
					break;
				}
			}
			if (id==-1) {
				System.err.println("\nSomething wrong 3 ...");
				System.exit(0);
			}
			
			pNode = ptr.desNd.isoNd;
			getTree2(pNode,topoA);		
			for (i=0;i<topostr.length-1;i++) {
				topostr[i] = "(";
				topostr[i] += topoA[i];
			}
			String strA;
			strA = topoA[3];
			
			pNode = pNode.isoNd;
			do {
				for (i=0;i<topostr.length-1;i++) {
					topostr[i] +=",";
				}
				getTree2(pNode,topoA);
				for (i=0;i<topostr.length-1;i++) {
					topostr[i] += topoA[i];
				}
				pNode = pNode.isoNd;
			} while(pNode != ptr.desNd);
			topostr[0] += ")";
			//topostr[0] += ":" + String.format("%.10f", ptr.branchLength);
			topostr[0] += ":" + String.format("%f", ptr.branchLength);
			
			String strB;
			strB = topoA[3];
			
			if (strA.compareTo(strB)<0) 
				topostr[3] = "(" + strA + "," + strB + ")";
			else {
				topostr[3] = "(" + strB + "," + strA + ")";
				/*
				// swap leftWing and rightWing
				Node isoNd = ptr.desNd.isoNd;
				Node isoIsoNd = ptr.desNd.isoNd.isoNd;
				ptr.desNd.isoNd = isoIsoNd;
				ptr.desNd.isoNd.isoNd = isoNd;
				ptr.desNd.isoNd.isoNd.isoNd = ptr.desNd;
				this.setRecalNeeded(ptr.desNd);
				*/
			}
			
			if (this.parameterwiseRho == null) // if paramterwiseRho, parameterwiseBeta tree is not required
				return;
			
			topostr[1] += ")";
			if (valid[id])
				topostr[1] += String.format("[Rho=%f]", this.parameterwiseRho[0][id]);
			else
				topostr[1] += String.format("[Rho=%f]", this.globalRho);
			//topostr[1] += ":" + String.format("%.10f", ptr.branchLength);
			topostr[1] += ":" + String.format("%f", ptr.branchLength);
			
			topostr[2] += ")";
			if (valid[id])
				topostr[2] += String.format("[Beta=%f]", this.parameterwiseBeta[0][id]);
			else
				topostr[2] += String.format("[Beta=%f]", this.globalBeta);
			//topostr[2] += ":" + String.format("%.10f", ptr.branchLength);
			topostr[2] += ":" + String.format("%f", ptr.branchLength);
			
			/*
			topostr[1] += ")";
			topostr[1] += String.format("[ESL=%f]", this.brESL[0][id]);
			topostr[1] += ":" + String.format("%f", ptr.branchLength);
			
			topostr[2] += ")";
			topostr[2] += String.format("[ESL=%f]", this.brESL[1][id]);
			topostr[2] += ":" + String.format("%f", ptr.branchLength);
			 */
			
		}
	}
	
	public Node findNode(String str) {

		
		Node pNode, startPos;
		
		Node firstTerminal; 
		// this is for debugging mode. When data is not full set, outgroup setting in getTopology(..) may not be valid.
		// in this case, determine a randomly selected terminal node. 

		String tname;
		
		
		pNode = this.startNode;
		
		if (pNode.desNd.isoNd == null) { // startNode is terminal
			pNode = startNode.desNd;
		}
		else {
			do { // first go to terminal node
				pNode = pNode.desNd.isoNd;
			} while (pNode.desNd.isoNd != null);
			pNode = pNode.desNd;
		}
		
		tname = pNode.taxonName;
		firstTerminal = pNode;
		if (str.equals(tname)) {
			return pNode;
		}
		else {
			startPos = pNode;
			do {
				if (pNode.desNd.isoNd != null) {
					pNode = pNode.desNd.isoNd;
				}
				else { // terminal
					pNode = pNode.desNd;
					tname = pNode.taxonName;
					if (tname.equals(str)) {
						return pNode;
					}
				}
			} while (pNode != startPos);
			System.err.print("Something wrong in findNode(..)");
			return firstTerminal;
			//System.exit(0);
		}

		/*
		for (i=0;i<brPos.length;i++) {
			if (brPos[i].desNd.taxonName.equals(str)) {
				return brPos[i].desNd;
			}
		}
		*/
		
		
	}
	
	public void getTopology(String[] treetopo, String tname) {
		Node oriStartNode = this.startNode;
		
		Node pNode;
		this.startNode = this.findNode(tname).desNd;
		
		ArrayList<String> list = new ArrayList<String>();
		
		String[] str = new String[1];
		
		pNode = this.startNode;
		do {
			getTopologySub(pNode, str);
			list.add(str[0]);
			pNode = pNode.isoNd;
		} while (pNode != this.startNode);
		
		Collections.sort(list);
		
		int i;
		
		treetopo[0]= "(" + list.get(0) + ",";
		for (i=1;i<list.size()-1;i++) {
			treetopo[0] += list.get(i) + ",";
		}
		treetopo[0] += list.get(list.size()-1) + ");";
		
		this.startNode = oriStartNode;
		
	}
	
	public void getTopologySub(Node ptr, String[] treetopo)
	{
		
		ArrayList<String> list = new ArrayList<String>();
		
		String[] str = new String[1];
		
		if (ptr.desNd.isoNd != null) {
			Node pNode = ptr.desNd.isoNd;
			do {
				getTopologySub(pNode, str);
				list.add(str[0]);
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
			
			Collections.sort(list);
			
			int i;
			
			treetopo[0]= "(" + list.get(0) + ",";
			for (i=1;i<list.size()-1;i++) {
				treetopo[0] += list.get(i) + ",";
			}
			treetopo[0] += list.get(list.size()-1) + ")";
		}
		else {
			treetopo[0] = ptr.desNd.taxonName;
		}
		
	
		
		/*
		String[] topoA = new String[1];
		String[] topoB = new String[1];
	
		if (ptr.desNd.isoNd == null) { // if terminal node
			topostr[0] = ptr.desNd.taxonName;
		}
		else { // if not terminal
			getTopologySub(ptr.desNd.isoNd, topoA);
			getTopologySub(ptr.desNd.isoNd.isoNd, topoB);
			if (topoA[0].compareTo(topoB[0])<0) {
				topostr[0] = "("+topoA[0]+","+topoB[0]+")";
			}
			else 
				topostr[0] = "("+topoB[0]+","+topoA[0]+")";
	
		}
		*/
	}
	

	
	public void getEmpiricalPI() {
		// this function should be run before sortData()
		
		int i,j,k,L; 
		
		stateDim = this.alphabetVec.size();
	
		PI = new double[stateDim];
		for (i=0;i<PI.length;i++) 
			PI[i] = 0.0;
	
		L = 0;
		
		// checking 
		/*
		if (this.alphabetData[0].length != this.seqLength) {
			System.err.print("Something wrong in getEmpiricalPI()");
			System.exit(0);
		}
		*/
		
		
	
		int allGapSite = 0;
		for (j=0;j<alphabetData[0].length;j++) {
			Boolean allUncertain = true;
			for (i=0;i<alphabetData.length;i++) {
				char c = alphabetData[i][j];
				for (k=0;k<stateDim;k++) {
					if (alphabetVec.get(k).equals(c)) {
						//PI[k] += 1.0; L++;
						PI[k] += alphabetDataPatternNum[j];
						L += alphabetDataPatternNum[j];
						allUncertain = false;
					}
				}
			}
			if (allUncertain) 
				allGapSite++;
		}
		
		for (i=0;i<PI.length;i++) {
			PI[i] /= L*1.0;
			this.alphabetFreq.set(i, PI[i]);
		}

		// special routine to avoid zero empirical freq
		// when sequence length is extremely small
		// zero empirical freq can cause -infinity sitewise loglikelihood
		// to avoid this, assign very small freq
		boolean zeroFreq = false;
		for (i=0;i<PI.length;i++) {
			if (PI[i] < 1.0/L) {
				PI[i] = 1.0/L;
				zeroFreq = true;
			}
		}
		if (zeroFreq) {
			myFunc.print(String.format("\n # Zero frequency observed..."));

			double sum = 0.0;
			for (i=0;i<PI.length;i++) {
				sum += PI[i];
			}
			for (i=0;i<PI.length;i++) {
				PI[i] /= sum;
				this.alphabetFreq.set(i, PI[i]);
			}
		}
		
		
		if (this.multiThrId==0) {
			System.out.print("\r\n" + (alphabetData.length*alphabetData[0].length-L) + " invalid characters in alphabetData[][]..;getEmpiricalPI()");
			myFunc.print(String.format("\r\n # of all-gap sites: %d", allGapSite));
		}


		if (this.subsModel == ModelType.JC) {
			for (i=0;i<PI.length;i++) {
				PI[i] = 0.25;
				this.alphabetFreq.set(i, PI[i]);
			}
		}
	}
	
	public void sortData() {
		/*
		long time_start, time_end, ElapsedSec;
		time_start = System.currentTimeMillis();
		*/
		
		sortData20210620();
		//sortData20210621(); // much slower
		
		/*
		time_end = System.currentTimeMillis();
		ElapsedSec = (time_end - time_start)/1000;
		String message = String.format("\n%02d:%02d:%02d elapsed since starting estMLTopology()", (int)ElapsedSec/3600,((int)ElapsedSec%3600)/60, (int)ElapsedSec - ((int)ElapsedSec/60)*60);
		myFunc.print(message);
		System.err.print(message);
		*/
		
		//System.exit(0);
	}
	
	public void sortData20210620() {
		// this is faster than sortData20210621()  15min vs. 59 min
		
		//myFunc.print(String.format("\r\n\r\nRunning sortData()..."));
		System.err.print(String.format("\r\n\r\nRunning sortData()..."));
		
		int i,j,k,l,L; 

		
			
		///////////////  The following part is not used when many taxa
		/////////////// When there are many taxa, sorting data requires a lot of time and same pattern is hardly observed. 
	/*	
		//if (this.myJob == JobType.EST_HESS_ESL) 
			//this.dataSortingPass = true;
		//else 
			this.dataSortingPass = false;
		
		if (this.dataSortingPass) {
			alphabetDataPatternNum = new int[this.alphabetData[0].length];
			for (i=0;i<alphabetDataPatternNum.length;i++) {
				alphabetDataPatternNum[i] = 1;
			}
			return;
		}
		else {
			this.backupAlphabetData();
		}
		
		*/
		
		
		//System.err.print(String.format("\nreordering data sets..")); 
		

		char[][] temp;
		int[] temp_cnt;
		int temp_cnt_idx;
		
		temp = new char[taxaNum][alphabetData[0].length];
		temp_cnt = new int[alphabetData[0].length];
		
		L = alphabetData[0].length;
		
		
		temp_cnt_idx = 0;
		for (l=0;l<taxaNum;l++) {
			temp[l][temp_cnt_idx] = alphabetData[l][0];
		}
		temp_cnt[temp_cnt_idx] = 1;
		temp_cnt_idx++;
		
	
		boolean same;
		
		for (j=1;j<L;j++) {
			
			if (L > 10000 && j % 1000 == 0)
				System.err.print(String.format("\r\nj=%d/%d", j, L));
			
			boolean patt_found = false;
			for (k=0;k<temp_cnt_idx;k++) {
				same = true;
				for (l=0;l<taxaNum;l++) {
					if (temp[l][k] != alphabetData[l][j]) {
						same = false;
						break;
					}
				}
				if (same) {
					temp_cnt[k]++;
					patt_found = true;
					break;
				}
			}
			if (!patt_found) {
				for (l=0;l<taxaNum;l++) {
					temp[l][temp_cnt_idx] = alphabetData[l][j];
				}
				temp_cnt[temp_cnt_idx] = 1;
				temp_cnt_idx++;
			}
		}
		
		
		
		/////
		
		alphabetData = new char[taxaNum][temp_cnt_idx];
		alphabetDataPatternNum = new int[temp_cnt_idx];
		for (i=0;i<temp_cnt_idx;i++) {
			for (j=0;j<taxaNum;j++) {
				alphabetData[j][i] = temp[j][i];
			}
			alphabetDataPatternNum[i] = temp_cnt[i];
		}
		

		//System.err.print(String.format("\nreordering data sets..done.")); 
	
		/*   //These are not needed for dataSort(..)
		System.err.print(String.format("\r\n\r\nRunning calcSitewiseGapProp()..."));
		calcSitewiseGapProp();
		
		System.err.print(String.format("\r\nRunning rearrangeColumnsWithGapProp()..."));
		rearrangeColumnsWithGapProp(); // this is required to reduce computation time
		
		System.err.print(String.format("\r\nRunning calcSitewiseGapPropCDF()..."));
		calcSitewiseGapPropCDF();
		
		this.setGapPropMultFactorSlope(this.gapPropMultFactorSlope); ///////
		 */
		
		this.dataSorted = true;

		
	}
	
	public void sortData20210621() {
		// this is slower than sortData20210620()  59 min vs. 15 min.
		
		//myFunc.print(String.format("\r\n\r\nRunning sortData()..."));
		System.err.print(String.format("\r\n\r\nRunning sortData()..."));
		
		int i,j,k,l,L; 

		L = alphabetData[0].length;
		String colData[] = new String[L];
		
		for (i=0;i<L;i++) {
			colData[i] = "";
			for (j=0;j<taxaNum;j++) {
				colData[i] += alphabetData[j][i];
			}
		}
		
		int[] temp_cnt;
		int temp_cnt_idx;		
		temp_cnt = new int[alphabetData[0].length];
		char[][] temp;
		temp = new char[taxaNum][alphabetData[0].length];		
	
		temp_cnt_idx = 0;		
		for (l=0;l<taxaNum;l++) {
			temp[l][temp_cnt_idx] = alphabetData[l][0];
		}
		temp_cnt[temp_cnt_idx] = 1;
		
		
		boolean same;
		for (j=1;j<L;j++) {
			
			if (L > 10000 && j % 1000 == 0)
				System.err.print(String.format("\r\nj=%d/%d", j, L));
			
			boolean patt_found = false;
			for (k=0;k<temp_cnt_idx;k++) {
				if (colData[k].equals(colData[j]) ) {
					patt_found = true;
					temp_cnt[k]++;
					break;
				}
			}
			if (!patt_found) {
				for (l=0;l<taxaNum;l++) {
					temp[l][temp_cnt_idx] = alphabetData[l][j];
				}
				temp_cnt[temp_cnt_idx] = 1;
				temp_cnt_idx++;
			}
		}
		
		
		alphabetData = new char[taxaNum][temp_cnt_idx];
		alphabetDataPatternNum = new int[temp_cnt_idx];
		for (i=0;i<temp_cnt_idx;i++) {
			for (j=0;j<taxaNum;j++) {
				alphabetData[j][i] = temp[j][i];
			}
			alphabetDataPatternNum[i] = temp_cnt[i];
		}
		

		
		this.dataSorted = true;

		
	}
	

	public void setGapPropMultFactorSlope(double a) {
		//removed for distribution
	}
	
	public void calcLogLikeCenter(Node ptr, double[] sitewiseLike) {
		// this is special for 1st and 2nd derivative
		// store sitewise likelihood instead of log-likelihood to sitewiseLike[]

		int j,k,l;
		Node pNode;
	
		int patt_size;
		double tmp;	
		double Sum, subSum, sitelnlk;
	
		patt_size = alphabetDataPatternNum.length;
	
		for (j=0;j<patt_size;j++) {
			Sum = 0.0;
			for (k=0;k<gammaCateNum;k++) {
				subSum = 0.0;
				for (l=0;l<stateDim;l++) {
					tmp = 1.0;
					pNode = ptr;
					do {
						tmp *= pNode.subLikelihood[k*patt_size*stateDim + j*stateDim + l]; //pNode->subLikelihood[k][j][l];
						pNode = pNode.isoNd;
					} while(pNode!=ptr);
					tmp *= PI[l]; 
					subSum += tmp;
				}
				subSum *= gammaRateFreq[k];
				Sum += subSum;
			}
			
			sitelnlk = Sum;
			sitewiseLike[j] = sitelnlk;

		}
		
	}
	
	public double calcLogLikeCenter(Node ptr) {

		int i,j,k,l;
		Node pNode;
	
		int patt_size;
		double tmp;	
		double Sum, subSum, sitelnlk;
		logLike = 0.0;
	
		patt_size = alphabetDataPatternNum.length;
	
		/*
		double multF[] = new double[gammaCateNum];		
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
			for (i=0;i<gammaCateNum;i++) {
				tmp = (1.0-gapOverallMean*gapPropMultFactorSlope) + 1.0/gammaCateNum*gapPropMultFactorSlope*i;
				tmp += (1.0-gapOverallMean*gapPropMultFactorSlope) + 1.0/gammaCateNum*gapPropMultFactorSlope*(i+1);
				tmp *= 0.5;
				multF[i] = tmp;
			}
			tmp = 0.0;
			for (i=0;i<gammaCateNum;i++) {
				tmp += gammaRateFreq[i]*multF[i];
			}
			for (i=0;i<gammaCateNum;i++) {
				multF[i] = multF[i] / tmp;
			}
		}
		else {
			for (i=0;i<gammaCateNum;i++) {
				multF[i] = 1.0;
			}
		}
		*/
		
		
		
		for (j=0;j<patt_size;j++) {
			
			Sum = 0.0;
			for (k=0;k<gammaCateNum;k++) {
				subSum = 0.0;
				for (l=0;l<stateDim;l++) {
					tmp = 1.0;
					pNode = ptr;
					do {
						tmp *= pNode.subLikelihood[k*patt_size*stateDim + j*stateDim + l]; //pNode->subLikelihood[k][j][l];
						pNode = pNode.isoNd;
					} while(pNode!=ptr);
					tmp *= PI[l]; 
					subSum += tmp;
				}
				subSum *= gammaRateFreq[k]; //  * multF[k];
				Sum += subSum;
				/*
				if (j==3||j==18) {
					System.out.print("\nj=" + j + ", k="+k+", "+subSum);
				}
				*/
			}
			/*
			if (Sum < myFunc.EPSILON) 
				Sum = myFunc.EPSILON; // when zero, assign small value to prevent log(0)
				// this is incorrect, should not be used
				// Even when Sum is less than myFunc.EPSILON, log(Sum) can be valid and it happens a lot empirically
				*/
			sitelnlk = Math.log (Sum) - Math.log(PreventUnderflow[j]) * cntUnderflow[j];
			sitewiseLogLike[j] = sitelnlk;
			logLike += sitelnlk * alphabetDataPatternNum[j];
			/*
			System.out.print("\nj=" + j + ", " + sitelnlk + ", " + logLike);
			if (j==100)
				System.exit(0);
			*/
		}
	
		return logLike;
	}

	public void calTransProbGTR_brDeriv(double[] br, double[] gammaF, int order) {
		
		int dim = this.alphabetVec.size();
		int j;
	
		for (j = 0; j<gammaCateNum; j++) {
			myFunc.PMatUVRoot_yang_brDeriv(probMat, j*dim*dim, br[j], dim, LeftModal, RightModal, EigenRoot, gammaF[j], order);
		}
			
		//System.exit(0);
		return;
	}
	
	public void calTransProbGTR_brDeriv(double[] br, double[] gammaF, double multF, int order) {
		
		int dim = this.alphabetVec.size();
		int j;
	
		for (j = 0; j<gammaCateNum; j++) {
			myFunc.PMatUVRoot_yang_brDeriv(probMat, j*dim*dim, br[j], dim, LeftModal, RightModal, EigenRoot, gammaF[j], multF, order);
		}
			
		//System.exit(0);
		return;
	}
	
	
	public void calTransProbJC(double[] br) {
		// this is not necessary unless speed is not an issue.
		// prob calculation with JC can be replaced with GTR prob calculation. 
		// numerically confirmed 2020.03.31
		
		int i,j,k;
		int dim = this.alphabetVec.size();
		double diffP,sameP;
		for (j = 0; j<gammaCateNum; j++) {
			diffP = 0.25 - 0.25*Math.exp(-4.0*br[j]/3);
			sameP = 0.25 + 0.75*Math.exp(-4.0*br[j]/3);
			for (i=0;i<dim;i++) {
				for (k=0;k<dim;k++) {
					if (i==k)
						probMat[j*dim*dim+i*dim+k] = sameP;
					else
						probMat[j*dim*dim+i*dim+k] = diffP;
				}
			}
		}
	}
	
	public void calTransProbGTR(double[] br) {
	
		int dim = this.alphabetVec.size();
		int j;
	
		for (j = 0; j<gammaCateNum; j++) {
		//for (j = gammaCateNum-1; j<gammaCateNum; j++) {		
			/*
			System.out.print("\n\n\n");
			for (int jj = 0; jj < dim*dim; jj++) {
				System.out.print("\njj="+jj+","+LeftModal[jj]);
			}
			*/
			myFunc.PMatUVRoot_yang(probMat, j*dim*dim, br[j], dim, LeftModal, RightModal, EigenRoot);
			/*
			for (int jj = 0; jj < dim*dim; jj++) {
				System.out.print("\njj="+jj+","+probMat[j*dim*dim + jj]);
			}
			*/
		}
			
		//System.exit(0);
		return;
	}
	
	public void calTransProb_brDeriv(double[] br, double[] gammaF, int order)
	{
		calTransProbGTR_brDeriv(br, gammaF, order);
	}
	
	public void calTransProb_brDeriv(double[] br, double[] gammaF, double multF, int order)
	{
		calTransProbGTR_brDeriv(br, gammaF, multF, order);
	}
	
	public void calTransProb(double[] br)
	{
		//if (this.subsModel == ModelType.JC)
			//this.calTransProbJC(br);  // this is not necessary unless I want to speed up. Numerically identical with calTransProbGTR(br);
		//else if (this.subsModel == ModelType.GTR || this.subsModel == ModelType.TN93 )
			calTransProbGTR(br);

	}



	public void calcLogLike(Node ptr) {
	
		Node pNode;
		int i,j,k,l, patt_size;
		double tmp = 0.0;
	
		boolean recal;
	
		patt_size = alphabetDataPatternNum.length;
	
		if (ptr.recalNeeded) {
			;
		}
		else {
			return;
		}
	
		if (ptr.desNd.isoNd != null ) { // if des_ptr is not terminal
			pNode = ptr.desNd.isoNd;
			recal = false;
			do {
				if (pNode.recalNeeded) {
					calcLogLike(pNode);
					recal = true;
				}
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
			if (ptr.recalNeeded)
				recal = true;
	
			if (recal == false && ptr.desNd.recalNeeded == true) { // if (recal || ptr->recalNeeded) {
				;  // do nothing
			}
			else {
				for (i=0;i<patt_size;i++) {
					for (j=0;j<gammaCateNum;j++) {
						for (k=0;k<stateDim;k++) {
							tmp = 1.0;
							pNode = ptr.desNd.isoNd;
							do {
								tmp *= pNode.subLikelihood[j*patt_size*stateDim + i*stateDim + k]; //pNode->subLikelihood[j][i][k];
								pNode = pNode.isoNd;
							} while (pNode != ptr.desNd);
							ptr.desNd.subLikelihood[j*patt_size*stateDim + i*stateDim + k] = tmp; //ptr->des_ptr->subLikelihood[j][i][k] = tmp;
						}
					}
				}
			}
		}
		else { // if des_ptr is terminal, do nothing
			;
		}
	
	
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.NocalcGapPropMultFactor) {
			for (i=0;i<gammaCateNum;i++) 
				BrGammaSpace[i] = ptr.branchLength * gammaRateFactor[i];
		
			calTransProb(BrGammaSpace);
		}
		else ;

	
		

		for (j=0;j<patt_size;j++) {
			if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
				if ( (j > 0 && Math.abs(this.sitewiseGapProp[j]- this.sitewiseGapProp[j-1]) > myFunc.EPSILON) 
					 ||	j==0 ) {
					for (k=0;k<gammaCateNum;k++) 
						BrGammaSpace[k] = (ptr.branchLength * sitewiseGapPropBrMultFactor[j]  ) * gammaRateFactor[k];
					calTransProb(BrGammaSpace);
				}
				else 
					; // do nothing
			}
			for (i=0;i<gammaCateNum;i++) {
				for (k=0;k<stateDim;k++) {
					tmp = 0.0;
					for (l=0;l<stateDim;l++) {
						tmp += probMat[i*stateDim*stateDim + k*stateDim + l] * ptr.desNd.subLikelihood[i*patt_size*stateDim + j*stateDim + l]; // transProb(i,k,l) * ptr->des_ptr->subLikelihood[i][j][l];
					}
					ptr.subLikelihood[i*patt_size*stateDim + j*stateDim + k] = tmp;
					/*
					if (j==19||j==18) {
						System.out.print("\ncate=" + i + ", patt=" +j+ ", k=" + k + ", " + tmp);
					}
					*/
				}

			}

		}
	
		ptr.recalNeeded = false;
		ptr.desNd.recalNeeded = true;
	
	}


	public void setRecalNeeded()
	{
		Node pNode;
		pNode = startNode;
		
		if (startNode==null)
			return;
	
		do {
			setRecalNeeded(pNode);
			pNode = pNode.isoNd;
		} while (pNode != startNode);
		
	}

	public String getLeftBottomTaxon(Node ptr) {
		String str = "";
	
		if (ptr.desNd.isoNd == null) 
			str = ptr.desNd.taxonName;
		else {
			str = getLeftBottomTaxon(ptr.desNd.isoNd);
		}
		return str;
	}
	
	public String getRightBottomTaxon(Node ptr) {
		String str = "";
	
		if (ptr.desNd.isoNd == null) 
			str = ptr.desNd.taxonName;
		else {
			str = getLeftBottomTaxon(ptr.desNd.isoNd.isoNd);
		}
		return str;
	}
	

	public void setRecalNeeded(Node ptr)
	{
		Node pNode;
		Node pNode2;
		pNode = ptr;
	
		pNode.recalNeeded = true;
		pNode.desNd.recalNeeded = true;
	
		if (pNode.desNd.isoNd != null) { // if des is not terminal
			pNode = pNode.desNd.isoNd;
			pNode2 = pNode;
			do {
				setRecalNeeded(pNode2);
				pNode2.isoBig = ptr.desNd;
				pNode2 = pNode2.isoNd;
			} while (pNode2 != ptr.desNd);
			ptr.desNd.isoBig = ptr.desNd;
		}
	}

	public void setRecalNeededIfContains(Node ptr) {
		Node pNode;
		pNode = this.startNode;
		do {
			this.setRecalNeededIfContainsSub(pNode, ptr);
			pNode = pNode.isoNd;
		} while (pNode != this.startNode);
	}
	public boolean setRecalNeededIfContainsSub(Node pos, Node ptr)
	{
		boolean recal = false;
		
		if (pos.desNd.isoNd != null) {
			Node pNode = pos.desNd.isoNd;
			recal = false;
			do {
				boolean ret = this.setRecalNeededIfContainsSub(pNode, ptr);
				if (ret)
					recal = true;
				pNode = pNode.isoNd;
			} while (pNode != pos.desNd);
		}
		
		if (recal) {
			pos.recalNeeded = true;
			return true;
		}
		else {
			if (pos == ptr)  {
				pos.recalNeeded = true;
				return true;
			}

			else {
				if (pos.recalNeeded)  // even thought all des's are false, pos can be true because of inserting br. 
					return true;
				else 
					return false;
			}
	
		}
		

		
	}
	
	
	
	
	public void LoadSeqFile_simul() {
		
		// This is for simulation.
		// Only taxa names are read from the given sequence file.
		// Sequences are filled with simulation.
		
		seqLength = this.simulLength;
		alphabetData = new char[taxaNum][seqLength];
		this.generateRandSeq(0);
		this.dataFileName = "simulated_data.txt";
		
		
	}
		
	
	public void LoadSeqFile(String filename) {
		
		int i,j;
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			Scanner scanner = new Scanner(fis);
			
			String[] splitStr;
			
			String s = scanner.nextLine();
			s = s.trim();
			while (s == null) {
				s = scanner.nextLine();
				s = s.trim();
			}
			
			splitStr = s.split("\\s+");
			taxaNum = Integer.valueOf(splitStr[0]); 
			seqLength = Integer.valueOf(splitStr[1]);
			
			alphabetData = new char[taxaNum][seqLength];
			taxaNameList = new String[taxaNum];
			


			int partialL=0;
			String tmpStr = new String();
			for (i=0; i<taxaNum; i++) {
				s = scanner.nextLine();
				s = s.trim();
				splitStr = s.split("\\s+");
				taxaNameList[i] = splitStr[0];
				tmpStr = String.format("");
				partialL = 0;
				for (j=1;j<splitStr.length;j++) {
					tmpStr += splitStr[j];
					partialL += splitStr[j].length();
				}
				while (partialL < seqLength) {
					s = scanner.nextLine();
					s = s.trim();
					splitStr = s.split("\\s+");
					for (j=0;j<splitStr.length;j++) {
						tmpStr += splitStr[j];
						partialL += splitStr[j].length();
					}
				}
				if (partialL != seqLength) {
					System.err.print(String.format("\nSomething wrong in %s's seq", taxaNameList[i]));
					System.exit(0);
				}
				//alphabetData[i] = tmpStr.toCharArray();
				alphabetData[i] = tmpStr.toUpperCase().toCharArray();
			}
			
			scanner.close();
			
			this.dataFileName = filename;
			
			
			alphabetDataPatternNum = new int[this.alphabetData[0].length];
			for (i=0;i<alphabetDataPatternNum.length;i++) {
				alphabetDataPatternNum[i] = 1;
			}
			dataSorted = false;
			
			
			// check 'N' residue in DNA data
			// replace 'N' with '?'
			boolean dnamodel = true;
			if (this.subsModel == ModelType.WAG) 
				dnamodel = false;
			else if (this.subsModel == ModelType.MTREV24) 
				dnamodel = false;
			else if (this.subsModel == ModelType.LG)
				dnamodel = false;
			else if (this.subsModel == ModelType.DAYHOFF)
				dnamodel = false;
			if (dnamodel) {
				for (i=0;i<this.alphabetData.length;i++) {
					for (j=0;j<this.alphabetData[i].length;j++) {
						if (alphabetData[i][j] == 'N')
							alphabetData[i][j] = '?';
					}
				}
			}

			
			
		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
		
		/*
		myFunc.print(String.format("\n\n#Input data order"));
		int k=5;
		if (this.taxaNameList.length < k)
			k = taxaNameList.length;
		for (i=0;i<k;i++) {
			myFunc.print(String.format("\ni=%d, %s", i, this.taxaNameList[i]));
		}
		myFunc.print(String.format("\nThe other taxon name lists are omitted.."));
		myFunc.print(String.format("\n"));
		*/
		
		
		//this.generateBootstrapData(); 
		
		/* These are not needed here
		calcSitewiseGapProp();
		calcSitewiseGapPropCDF();
		*/
		
	}
	
	public void generateBootstrapData() {
				
		// 20201120 
		// this is simple bootstrap procedure
		// generate PSL * ratio columns. 
		// this can be run right after reading original data file
		
		int[] resampledID;
		
		double ratio;
		//ratio = 1.0;
		ratio = 1.0/0.853766; // 0.853766: ray-finned fish overall rho
		
		int r, i, j, k, L, bootSize;
		
		L = (int) (this.seqLength * ratio);
		resampledID = new int[L];	
		
		bootSize = 200;
		String normalFileName = new String();		
		
		Random localRand;
		
		localRand = new Random(this.randSeed);
		
		for (i=0;i<bootSize;i++) {

			for (j=0;j<L;j++) {
				resampledID[j] = localRand.nextInt(this.seqLength);
			}
			normalFileName = this.oriSeqFile + "_boot_"  + String.format("%d.txt", i);
			try {
				FileWriter normalFout = new FileWriter(normalFileName);
				for (j=0;j<this.taxaNum;j++) {
					//fout.write(String.format("\n%s  ", this.taxaNameList[i])); // for phylip
					normalFout.write(String.format(">%s  \r\n", this.taxaNameList[j])); // for fasta
					for (k=0;k<L;k++) {
						normalFout.write(String.format("%c", this.alphabetData[j][resampledID[k]])); 	
					}
					normalFout.write(String.format("\r\n")); // for fasta
				}
				normalFout.close();
			}
			catch (IOException e) {
				myFunc.print(String.format("\r\n%s error", normalFileName));
			}
			
		}
		
		PrintRaxmlCommand(bootSize);

		myFunc.print(String.format(" "));

		System.exit(0);
		
	}
	
	public void PrintRaxmlCommand(int iter) {
		int i;
		
		String str = new String();
		
		str = this.oriSeqFile;
		
		for (i=0;i<iter;i++) {
			myFunc.print(String.format("\nraxmlHPC-PTHREADS-SSE3_8.2.4.exe -T 8 -m GTRGAMMA -p 12345 -s %s_boot_%d.txt -M -#10 -n T%d", str, i, i));
		}
		
		myFunc.print(String.format("\n\n type "));
		
		for (i=0;i<iter;i++) {
			myFunc.print(String.format("RAxML_bestTree.T%d ", i));
		}
		
		myFunc.print(String.format("> RAxML_bootstrap.T2000 "));
		
		myFunc.print(String.format("\n\n raxmlHPC-PTHREADS-SSE3_8.2.4.exe -T 2 -m GTRGAMMA -p 12345  -f b -t %s_ml_tree.txt -z RAxML_bootstrap.T2000 -n T3000 ", this.oriSeqFile));
		
	
		myFunc.print(String.format("\n\n del "));
		
		for (i=0;i<iter;i++) {
			myFunc.print(String.format("*.T%d.* ", i));
		}
		
		myFunc.print(String.format(" *T2000  *T3000 "));
		
		myFunc.print(String.format("\n\n "));
	}
	
	
	
	public void LoadSeqFile_ori(String filename) {
		
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			Scanner scanner = new Scanner(fis);
			
			String[] splitStr;
			
			String s = scanner.nextLine();
			s = s.trim();
			while (s == null) {
				s = scanner.nextLine();
				s = s.trim();
			}
			
			splitStr = s.split("\\s+");
			taxaNum = Integer.valueOf(splitStr[0]); 
			seqLength = Integer.valueOf(splitStr[1]);
			
			alphabetData = new char[taxaNum][seqLength];
			taxaNameList = new String[taxaNum];
			

			int i;
			for (i=0; i<taxaNum; i++) {
				s = scanner.nextLine();
				s = s.trim();
				splitStr = s.split("\\s+");
				taxaNameList[i] = splitStr[0];
				alphabetData[i] = splitStr[1].toCharArray();
			}
			
			scanner.close();
			
			this.dataFileName = filename;
			
			
			alphabetDataPatternNum = new int[this.alphabetData[0].length];
			for (i=0;i<alphabetDataPatternNum.length;i++) {
				alphabetDataPatternNum[i] = 1;
			}
			dataSorted = false;
			
		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
	}
	
	public void generateRandSeq(int idx) {
		//myRand = new Random(this.randSeed);
		
		// random seq at startNode
		int i, j;
		double r;
		
		double[] cumFreq = new double[alphabetVec.size()];
		
		cumFreq[0] = PI[0];
		for (i=1;i<PI.length;i++) {
			cumFreq[i] = cumFreq[i-1] +  PI[i];
		}
		
		Node ptr = this.startNode;
		
		ptr.randSequence = new int[this.seqLength];
		ptr.randGammaCate = new int[this.seqLength];
		alphabetData = new char[taxaNum][this.seqLength];
		
		
		for (i=0;i<ptr.randSequence.length;i++) {
			r = this.myRand.nextDouble();
			for (j=0;j<cumFreq.length;j++) {
				if (r<cumFreq[j]) {
					ptr.randSequence[i] = j;
					break;
				}
			}
		}
		
		cumFreq = new double[this.gammaCateNum];
		cumFreq[0] = this.gammaRateFreq[0];
		for (i=1;i<this.gammaRateFreq.length;i++) {
			cumFreq[i] = cumFreq[i-1] + this.gammaRateFreq[i];
		}
		for (i=0;i<ptr.randGammaCate.length;i++) {
			r = myRand.nextDouble();
			for (j=0;j<cumFreq.length;j++) {
				if (r<cumFreq[j]) {
					ptr.randGammaCate[i] = j;
					break;
				}
			}
		}
		
		Node pNode;
		pNode = ptr.isoNd;
		do {
			pNode.randSequence = new int[this.seqLength];
			pNode.randGammaCate = new int[this.seqLength];
			for (i=0;i<ptr.randSequence.length;i++) {
				pNode.randSequence[i] = ptr.randSequence[i];
				pNode.randGammaCate[i] = ptr.randGammaCate[i];
			}
			pNode = pNode.isoNd;
		} while (pNode != ptr);
		
		

		boolean saveRandomSeq = false;
		
		if (saveRandomSeq) {
			// to save random sequences
			String fileName = new String();
			fileName = String.format("simulated_data_%d.txt", idx);
			try {
				FileWriter fout = null;
				fout = new FileWriter(fileName);
				String str = String.format("%d %d", this.taxaNum, this.seqLength);
				fout.write(str);
				pNode = ptr;
				do {
					this.generateRandSeq(pNode, fout);
					pNode = pNode.isoNd;
				} while (pNode != ptr);
				fout.close();
			}
			catch (IOException e) {
				myFunc.print(String.format("\n%s error", fileName));
			}
			//System.exit(0);
		}
		else {
			FileWriter fout = null;
			pNode = ptr;
			do {
				this.generateRandSeq(pNode, fout);
				pNode = pNode.isoNd;
			} while (pNode != ptr);
		}

			
		alphabetDataPatternNum = new int[this.alphabetData[0].length];
		for (i=0;i<alphabetDataPatternNum.length;i++) {
			alphabetDataPatternNum[i] = 1;
		}	
		dataSorted = false;
			
		
		System.gc();
	}
	
	
	public void generateRandSeq(Node ptr, FileWriter fout) {
		
		Node pNode;
		
		int i,j, k;
		double r;
		
		double[] cumFreq = new double[stateDim];
		
		for (i=0;i<gammaCateNum;i++) 
			BrGammaSpace[i] = ptr.branchLength * gammaRateFactor[i];

		// if br length is extremely short
		// make it zero
		if (Math.abs(ptr.branchLength-myFunc.BRANCH_LENGTH_LOWER_LIMIT) <  myFunc.EPSILON) {
			for (i=0;i<gammaCateNum;i++) 
				BrGammaSpace[i] = 0.0;
		}
	
		calTransProb(BrGammaSpace);
		
		ptr.desNd.randSequence = new int[this.seqLength];
		ptr.desNd.randGammaCate = new int[this.seqLength];
		
		
		for (j=0;j<ptr.randSequence.length;j++) {
			int id = ptr.randGammaCate[j];
			int x = ptr.randSequence[j];
			
			if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
				if ( (j > 0 && Math.abs(this.sitewiseGapProp[j]- this.sitewiseGapProp[j-1]) > myFunc.EPSILON) 
					 ||	j==0 ) {
					for (k=0;k<gammaCateNum;k++) 
						BrGammaSpace[k] = (ptr.branchLength * sitewiseGapPropBrMultFactor[j]  ) * gammaRateFactor[k];
					calTransProb(BrGammaSpace);
				}
				else 
					; // do nothing
			}
			
			
			cumFreq[0] = probMat[id*stateDim*stateDim + x*stateDim + 0];  
			for (i=1;i<PI.length;i++) {
				cumFreq[i] = cumFreq[i-1] +  probMat[id*stateDim*stateDim + x*stateDim + i];   
			}
			
			r = myRand.nextDouble();
			for (i=0;i<cumFreq.length;i++) {
				if (r<cumFreq[i]) {
					ptr.desNd.randSequence[j] = i;
					break;
				}
			}
		}
		
		for (j=0;j<ptr.randGammaCate.length;j++) {
			ptr.desNd.randGammaCate[j] = ptr.randGammaCate[j];
		}
	
		
		if (ptr.desNd.isoNd != null) {
			pNode = ptr.desNd.isoNd;
			do {
				pNode.randSequence = new int[this.seqLength];
				pNode.randGammaCate = new int[this.seqLength];
				for (j=0;j<ptr.randGammaCate.length;j++) {
					pNode.randGammaCate[j] = ptr.desNd.randGammaCate[j];
					pNode.randSequence[j] = ptr.desNd.randSequence[j];
				}
				generateRandSeq(pNode,fout);
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
		}
		else {
			if (fout!=null) {
				try {
					fout.write(String.format("\n%s  ", ptr.desNd.taxonName));
				}
				catch (IOException e) {
					System.err.print(String.format("\nrandom seq print error"));
				}
				
				for (i=0;i<ptr.desNd.randSequence.length;i++) {
					try {
						fout.write(this.alphabetVec.get(ptr.desNd.randSequence[i]));
					}
					catch (IOException e) {
						System.err.print(String.format("\nrandom seq print error"));
					}
				}
				myFunc.print(String.format("\n%s  ", ptr.desNd.taxonName));
				for (i=0;i<ptr.desNd.randSequence.length;i++) {
					myFunc.print(String.format("%c", this.alphabetVec.get(ptr.desNd.randSequence[i])));
				}
			}

			
			// find taxa location
			int id=-1;
			for (i=0;i<taxaNameList.length;i++) {
				if (taxaNameList[i].equals(ptr.desNd.taxonName)) {
					id = i;
					break;
				}
			}
			if (id==-1) {
				System.err.print("Something wrong...in generateRandSeq(..)");
				System.exit(0);
			}
			for (i=0;i<ptr.desNd.randSequence.length;i++) {
				this.alphabetData[id][i] = this.alphabetVec.get(ptr.desNd.randSequence[i]);
			}
			
			
		}

	}
	
	public void backupUnsortedAlphabetData()
	{
		int i,j, iter1, iter2;
		
		if (alphabetDataPatternNum.length != alphabetData[0].length) {
			System.err.print("Something wrong in backupUnsortedAlphabetData().. alphabetDataPatternNum.length != alphabetData[0].length");
			System.exit(0);
		}
		
		this.alphabetDataOriUnsorted = new char[this.alphabetData.length][this.alphabetData[0].length];
		this.taxaNameListOri = new String[this.taxaNameList.length];
		
		iter1 = this.alphabetData.length;
		iter2 = this.alphabetData[0].length;
		for (i=0;i<iter1;i++) {
			this.taxaNameListOri[i] = this.taxaNameList[i];
			for (j=0;j<iter2;j++) {
				this.alphabetDataOriUnsorted[i][j] = this.alphabetData[i][j];
			}
		}
		
		
		
	}
	
	public void recoverUnsortedAlphabetData()
	{
		int i,j, iter1, iter2;
		
		this.alphabetData = new char[this.alphabetDataOriUnsorted.length][this.alphabetDataOriUnsorted[0].length];
		this.taxaNameList = new String[this.taxaNameListOri.length];
		
		iter1 = this.alphabetDataOriUnsorted.length;
		iter2 = this.alphabetDataOriUnsorted[0].length;
		for (i=0;i<iter1;i++) {
			this.taxaNameList[i] = this.taxaNameListOri[i];
			for (j=0;j<iter2;j++) {
				this.alphabetData[i][j] = this.alphabetDataOriUnsorted[i][j];
			}
		}
		
		this.taxaNum = this.alphabetDataOriUnsorted.length;
		
		alphabetDataPatternNum = new int[this.alphabetData[0].length];
		for (i=0;i<alphabetDataPatternNum.length;i++) {
			alphabetDataPatternNum[i] = 1;
		}
		
		this.dataSorted = false;
		
		//calcSitewiseGapProp();
		//calcSitewiseGapPropCDF();

	
	}
	
	

	
	public void recoverUnsortedAlphabetData20191123(int jobIdx)
	{
		/// this is temporary function
		// first half is complete, sencond half is gappy
		// only first half(jobIdx==0) or second half (jobIdx==1) is copied
		
		this.alphabetData = new char[this.alphabetDataOriUnsorted.length][this.alphabetDataOriUnsorted[0].length/2];
		this.taxaNameList = new String[this.taxaNameListOri.length];
		
		int offSet, i, j, iter1, iter2;
		
		if (jobIdx==0) 
			offSet = 0;
		else 
			offSet = this.alphabetDataOriUnsorted[0].length/2;
		
		
		iter1 = this.alphabetDataOriUnsorted.length;
		iter2 = this.alphabetDataOriUnsorted[0].length/2;
		for (i=0;i<iter1;i++) {
			this.taxaNameList[i] = this.taxaNameListOri[i];
			for (j=0;j<iter2;j++) {
				this.alphabetData[i][j] = this.alphabetDataOriUnsorted[i][j+offSet];
			}
		}
		
		this.taxaNum = this.alphabetDataOriUnsorted.length;
		
		alphabetDataPatternNum = new int[this.alphabetData[0].length];
		for (i=0;i<alphabetDataPatternNum.length;i++) {
			alphabetDataPatternNum[i] = 1;
		}
		
		this.seqLength = this.alphabetData[0].length;
	}
	
	public void copyUnsortedAlphabetDataGapPattern20191123()
	{
		/// this is temporary function
		// this.alphabetData is extremely long seq
		// second half of alphabetDataOriUnsorted is original gappy data
		// randomly copy gap pattern of alphabetDataOriUnsorted to this.alphabetData
		
		int offSet, iter, i, j, r;
		
		offSet = this.alphabetDataOriUnsorted[0].length/2;
		
		iter = this.alphabetData[0].length;
		
		for (i=0;i<iter;i++) {
			//r = offSet + myFunc.myRand.nextInt(this.alphabetDataOriUnsorted[0].length/2);
			r = offSet + myRand.nextInt(this.alphabetDataOriUnsorted[0].length/2);
			for (j=0;j<this.alphabetDataOriUnsorted.length;j++) {
				char c = alphabetDataOriUnsorted[j][r];
				//if ( c== '-' || c== '?') {
				if (this.isGap(c)) {
					this.alphabetData[j][i] = c;
				}
			}
		}
	}
	
	
	public Node generateNode() {
		return new Node();
	}
	
	public void buildTree(String str) {
		
		int i;	
		Node pNode;
		Node pNode2;
		brPos = new Node[2*taxaNum-3];
		brPosValidity = new boolean[2*taxaNum-3];
		taxaNameListFromTreeTopo = new String[taxaNum];
		
		int taxaNameListFromTreeTopoIdx = 0;
		
		for (i=0; i<2*taxaNum-3; i++) {
			pNode = generateNode(); //new Node();
			brPos[i] = pNode;
			brPosValidity[i] = true;
		}
		
		nodePos = new Node[2*taxaNum-2];
		for (i=0; i<2*taxaNum-2; i++) {
			pNode = generateNode(); //new Node();
			nodePos[i] = pNode;
		}	

		nodeOfTip = new Node[taxaNum];
		for (i=0; i<taxaNum; i++) {
			pNode = generateNode(); //new Node();
			nodeOfTip[i] = pNode;
		}
		
		
		int BrPosIdx = 0;
		int NodePosIdx = 0;

		String pos = str;
		i = 0;
		while (pos.charAt(i) == ' ' || pos.charAt(i) == '\t') i++; //skip space or tab before topology

		ArrayList<Character> parenVec = new ArrayList<Character>(); 
		ArrayList<Node> NodeVec = new ArrayList<Node>(); //pNodeVec

		int n = taxaNum;

		int ptrToTipIdx = 0;
		int idxToBranchIdx = 0;

		int j = 0;



		i = 0;

		int k;
		
		while (pos.charAt(i) != ';') {  // tree topology must end with ';'
			char c = pos.charAt(i); if (c==' ');
			//System.out.print(c);
			if (pos.charAt(i) == '(') parenVec.add('('); 
			else if (pos.charAt(i) == ',')  parenVec.add(','); 
			else if (pos.charAt(i) == ')') {
				if (pos.charAt(i+1) == ';') {
					// final of buildTree(..).
					if (NodeVec.size() < 3) {
						System.out.print("\nError: Tree should be unrooted. ");
						System.exit(0);
					}
					k = 1;
					while (parenVec.get(parenVec.size() - k) == ',') k++;

					// obtained numMulti is the number of multifurcating branches.
					if (parenVec.size() - k != 0) {
						System.out.print("\nWrong Tree topology. ");
						System.exit(0);
					}
					
					k = 0;
					int numOfTermIntNode = 0;
					int numOfTaxa = 0;
					do {
						numOfTaxa += NodeVec.get(k).totDesTaxaNum;
						numOfTermIntNode += NodeVec.get(k).totDesNodeNum;
						NodeVec.get(k).isoNd = NodeVec.get(k + 1); 
						NodeVec.get(k).isoBig = NodeVec.get(NodeVec.size() - 1);
						k++;
					} while (k != NodeVec.size() - 1);
					NodeVec.get(k).isoNd = NodeVec.get(0); 
					NodeVec.get(k).isoBig = NodeVec.get(0); 
					startNode = NodeVec.get(NodeVec.size() - 1);
					startNode.totDesNodeNum = numOfTermIntNode + 1;
					startNode.totDesTaxaNum = numOfTaxa;
					

					pNode = NodeVec.get(0);
					do {
						pNode.nodeNum = NodePosIdx;
						pNode.isoBig = NodeVec.get(NodeVec.size() - 1);
						pNode = pNode.isoNd;
					} while (pNode != NodeVec.get(0));

					nodePos[NodePosIdx] = NodeVec.get(0);
					NodePosIdx++;

					break;
				} //  end of if (pos.charAt(i) == ';') {
				
									
				k = 1;
				while (parenVec.get(parenVec.size() - k) == ',') k++;
				int numMulti = k;
				// obtained numMulti is the number of multifurcating branches.

				k = NodeVec.size() - numMulti;
				pNode = NodeVec.get(k);
				pNode.nodeNum = NodePosIdx;

				int numOfTermIntNode = 0;
				int numOfTaxa = 0;

				do {
					numOfTermIntNode += NodeVec.get(k).totDesNodeNum;
					numOfTaxa += NodeVec.get(k).totDesTaxaNum;
					NodeVec.get(k).isoNd = NodeVec.get(k + 1);
					NodeVec.get(k + 1).nodeNum = NodePosIdx;
					k++;
				} while (k != NodeVec.size() - 1);
				numOfTermIntNode += NodeVec.get(NodeVec.size() - 1).totDesNodeNum;
				numOfTaxa += NodeVec.get(NodeVec.size() - 1).totDesTaxaNum;

							
				pNode2 = generateNode(); //new Node();
				pNode2.isoNd = pNode;
				pNode2.nodeNum = NodePosIdx;
				nodePos[NodePosIdx] = pNode;
				NodePosIdx++;
				NodeVec.get(NodeVec.size() - 1).isoNd = pNode2;

				pNode = pNode2;
				do {
					pNode.isoBig = pNode2;
					pNode = pNode.isoNd;
				} while (pNode != pNode2);

				pNode = pNode2;

				pNode.desNd = generateNode(); //new Node();

				pNode.desNd.desNd = pNode;
				pNode = pNode.desNd;

				pNode.desNd.totDesNodeNum = numOfTermIntNode + 1;
				pNode.totDesNodeNum = numOfTermIntNode + 1;

				pNode.totDesTaxaNum = numOfTaxa;
				pNode.desNd.totDesTaxaNum = numOfTaxa;

				pNode2 = pNode;
				
			
				for (k = 0; k<numMulti; k++) NodeVec.remove(NodeVec.size() - 1); 
				Node tmpNode = generateNode(); //new Node();
				tmpNode = pNode;
				NodeVec.add(tmpNode);
				
				if (BrPosIdx >= brPos.length) {
					System.err.print("\nSomething wrong in buildTree(..)");
					System.err.print("\ntree topology may end with addtional \":brlength\"; If this tree is from raxml, remove \":0.0\" before \";\" ");
					System.exit(0);				
				}
				brPos[BrPosIdx++] = tmpNode;

				for (k = 0; k<numMulti; k++) parenVec.remove(parenVec.size() - 1);

				if (Character.isDigit(pos.charAt(i + 1))) {
					i++;
					j = 0;
					char[] temp = new char[100];

					while (Character.isDigit(pos.charAt(i)) || pos.charAt(i) == '.') {
						temp[j++] = pos.charAt(i++);
					}

					temp[j] = '\0';
					
					pNode.bootProb = Double.parseDouble(String.valueOf(temp));
					pNode.desNd.bootProb = pNode.bootProb;
					i--;
					userBr = true;
				}
				

				if (pos.charAt(i + 1) == ':') {// topology with branch length
					i++;
					i++;

					j = 0;
					char[] temp = new char[100];

					while (Character.isDigit(pos.charAt(i)) || pos.charAt(i) == '.') {
						temp[j++] = pos.charAt(i++);
					}

					temp[j] = '\0';
					pNode.branchLength = Double.parseDouble(String.valueOf(new String(temp,0,j)));
					pNode.desNd.branchLength = pNode.branchLength;
					i--;
					userBr = true;
					//myFunc.print(String.format("\n%f", pNode.branchLength ));
					
				}

				pNode.desNd.idxBranchTopo = idxToBranchIdx;
				pNode.idxBranchTopo = idxToBranchIdx;
				idxToBranchIdx++;
			} // end of else if (pos.charAt(i) == ')') {
			else if (pos.charAt(i) != '(' && pos.charAt(i) != ')' && pos.charAt(i) != ',' && pos.charAt(i) != ':') {
				// If it is terminal node, or "C" in (A,B,C)
				pNode = generateNode(); //new Node();
				nodePos[NodePosIdx] = pNode;
				pNode.nodeNum = NodePosIdx;
				NodePosIdx++;
				pNode.desNd = generateNode(); //new Node();
				pNode.desNd.desNd = pNode;
				j = 0;
				char[] temp = new char[100];
				while (pos.charAt(i + j) != '(' && pos.charAt(i + j) != ')' && pos.charAt(i + j) != ','&& pos.charAt(i + j) != ':') {
					temp[j] = pos.charAt(i + j);
					j++;
				}
				temp[j] = '\0';

				pNode.taxonName = new String(temp,0,j);
				
				if (taxaNameListFromTreeTopoIdx >= taxaNameListFromTreeTopo.length) {
					System.err.print("\nSomething wrong in buildTree(..)");
					System.err.print("\ntaxaNum is not consisitent with tree topology (maybe smaller).");
					System.exit(0);
				}
				taxaNameListFromTreeTopo[taxaNameListFromTreeTopoIdx++] = pNode.taxonName;
				
				i = i + j;

				nodeOfTip[ptrToTipIdx++] = pNode;
				pNode.totDesNodeNum = 0; // set 1 if terminal
				pNode.totDesTaxaNum = 1; // set 1 if terminal

				pNode = pNode.desNd;

				Node tmpNd = generateNode(); //new Node();
				tmpNd = pNode;
				NodeVec.add(tmpNd);
				if (BrPosIdx == brPos.length) {
					System.err.print("\nSomething wrong in buildTree(..)");
					System.err.print("\ntaxaNum is not consisitent with tree topology (maybe smaller).");
					System.exit(0);
				}
				brPos[BrPosIdx++] = tmpNd;

				pNode.totDesNodeNum = 1; //
				pNode.totDesTaxaNum = 1; //

				pNode.desNd.idxBranchTopo = idxToBranchIdx;
				pNode.idxBranchTopo = idxToBranchIdx;
				idxToBranchIdx++;

				i--;
				
				if (Character.isDigit(pos.charAt(i + 1))) {
					i++;
					j = 0;
					//char[] temp = new char[100];

					while (Character.isDigit(pos.charAt(i)) ||pos.charAt(i) == '.') {
						temp[j++] = pos.charAt(i++);
					}
					temp[j] = '\0';
					pNode.bootProb = Double.parseDouble(String.valueOf(new String(temp,0,j)));
					pNode.desNd.bootProb = pNode.bootProb;
					i--;
				}
				if (pos.charAt(i + 1) == ':') {
					i++;
					i++;
					j = 0;
					//char[] temp = new char[100];
					while (Character.isDigit(pos.charAt(i)) || pos.charAt(i) == '.') {
						temp[j++] = pos.charAt(i++);
					}
					temp[j] = '\0';
					pNode.branchLength = Double.parseDouble(String.valueOf(new String(temp,0,j)));
					pNode.desNd.branchLength = pNode.branchLength;
					i--;
				}
			} // end of else if (pos.charAt(i) != '(' && pos.charAt(i) != ')' && pos.charAt(i) != ','....
			else {
				System.out.print("\npos.charAt(" + i + ")= " + pos.charAt(i));
				System.out.print("\nWrong topology3");
				System.exit(0);
			}
			i++;
		} // end of while (pos.charAt(i) != ';') { 
		
		brNum = BrPosIdx;
		if (brNum != 2*this.taxaNum -3) {
			System.err.print("\nSomething wrong in buildTree(..)");
			System.err.print("\ntaxaNum is not consisitent with tree topology (maybe larger).");
			System.exit(0);
		}
		nodeNum = NodePosIdx;
		ingroupTaxaNum = startNode.totDesTaxaNum;

		ingroupBrNum = 0;
		pNode = startNode.isoNd;
		do {
			ingroupBrNum += CountBr(pNode);
			pNode = pNode.isoNd;
		} while (pNode != startNode);

		ingroupNodeNum = startNode.totDesNodeNum; // ingroup node num is stored at startNode


		pNode = startNode;
		do { // find node whose iso_ptr is StartNodePtr
			pNode = pNode.isoNd;
		} while (pNode.isoNd != startNode);

		i = pNode.desNd.nodeNum;
		j = pNode.nodeNum;

		k = 0;
		while (nodePos[k++].nodeNum != i + 1);
		k--; // find node whose NodeNum() is i+1;
		pNode2 = nodePos[k];

		// exchange pNode and pNode2

		Node pNode3;
		pNode3 = pNode;
		do {
			pNode3.nodeNum = i + 1;
			pNode3 = pNode3.isoNd;
		} while (pNode3 != pNode);
		pNode3 = pNode2;
		do {
			pNode3.nodeNum = j;
			if (pNode3.isoNd != null) pNode3 = pNode3.isoNd;
		} while (pNode3 != pNode2);

		nodePos[i + 1] = pNode.isoNd.isoNd;
		nodePos[j] = pNode2;
		
		
		if (this.myJob == JobType.SIMUL && taxaNameList==null) { 
			// 'taxaNameList[0]==null' implies taxaNameList is not initialized yet. 
			taxaNameList = new String[taxaNum];
			for (i=0;i<taxaNameListFromTreeTopo.length;i++) {
				this.taxaNameList[i] = this.taxaNameListFromTreeTopo[i];
			}
		}
	
		// arbitrary initialization
		//if (brParam == null)
		
		brParam = new double[2*taxaNum-3]; 
		if (userBr) {
			for (i = 0; i < brPos.length; i++) {
				brParam[i] = brPos[i].branchLength;
			}
		}
		else {
			for (i=0;i<brPos.length;i++) {
				brParam[i] = 0.01; //0.01; //  
			}
			for (i=0;i<brPos.length;i++) {
				brPos[i].branchLength = brPos[i].desNd.branchLength = brParam[i];
			}
		}

	}
	
	public int CountBr(Node p)  {
		if (p.desNd.isoNd != null) {
			Node pNode;
			int n = 0;
			pNode = p.desNd.isoNd;
			do {
				n += CountBr(pNode);
				pNode = pNode.isoNd;
			}while(pNode != p.desNd);
			return n+1;

		}
		else {
			return 1;
		}
	}
	
	public void reorderBrIdx() {
		int i,j, k, id;
		Node pNode;
		
		myFunc.print(String.format("\r\n\r\nrunning reorderBrIdx()... \r\n"));
		
		
		/*
		///for debugging
		String[] topo = new String[4];
		this.getTree(topo);
		myFunc.print(String.format("\nBefore reorderBrIdx(): %s",topo[0]));
		PrintTreeTopo();
		*/
		

		// change node
		for (i=0;i<this.taxaNameList.length;i++) {
			if (!this.taxaNameList[i].equals(nodePos[i].taxonName) ) {
				id = -1;
				for (j=0;j<nodePos.length;j++) {
					if (this.taxaNameList[i].equals(nodePos[j].taxonName)) {
						id = j;
						break;
					}
				}
				pNode = nodePos[i];
				nodePos[i] = nodePos[id];
				nodePos[id] = pNode;
			}
		}
		
		//change node number
		for (i=0;i<this.taxaNameList.length;i++) {
			if (nodePos[i].nodeNum != i) {
				id = -1;
				for (j=0;j<nodePos.length;j++) {
					if (i == nodePos[j].nodeNum) {
						id = j;
						break;
					}
				}
				k = nodePos[i].nodeNum;
				nodePos[i].nodeNum = i;
				nodePos[id].nodeNum = k;
				if (nodePos[id].isoNd != null) {
					pNode = nodePos[id];
					do {
						pNode.nodeNum = k;
						pNode = pNode.isoNd;
					} while (pNode != nodePos[id]);
				}
			}
		}
		
		// change br idx
		for (i=0;i<this.taxaNameList.length;i++) {
			if (! this.taxaNameList[i].equals(brPos[i].desNd.taxonName) ) {
				id = -1;
				for (j=0;j<brPos.length;j++) {
					if (this.taxaNameList[i].equals(brPos[j].desNd.taxonName)) {
						id = j;
						break;
					}
				}
				pNode = brPos[i];
				brPos[i] = brPos[id];
				brPos[id] = pNode;
				
			}
		}
		
		
		////////////////////////
		
		/*
		for (i=0;i<this.taxaNum;i++) {
			if (brPos[i].desNd.isoNd != null) {
				do {
					pNode = brPos[i];
					for (j=i;j<this.brPos.length-1;j++) {
						brPos[j] = brPos[j+1];
					}
					brPos[this.brPos.length-1] = pNode;
				} while (brPos[i].desNd.isoNd != null);
			}
		}
		*/
		
		/// for debugging
		/*
		this.getTree(topo);
		myFunc.print(String.format("\nAfter reorderBrIdx(): %s",topo[0]));
		PrintTreeTopo();
		myFunc.print(String.format(" "));
		*/
		
	}
	
	public void PrintTreeTopo(FileWriter fout) {

		int i;
		
		/*
		fout.write(String.format("\nInput data order"));
		for (i=0;i<this.taxaNameList.length;i++) {
			fout.write("\n" + this.taxaNameList[i]);
		}
		*/
		try {
			fout.write(String.format("\r\n\r\n### Tree topology node information ###"));
			for (i=0;i<nodeNum;i++) {
				fout.write(String.format("\r\n"));
				Node pNode = nodePos[i];
				if (pNode.isoNd == null) { // if terminal node
					fout.write("Node " + i + ": " + pNode.taxonName);
				}
				else {
					fout.write("Node " + i + ":");
					pNode = nodePos[i].isoBig;

					if (pNode == startNode) {
						fout.write("(StartNode) ->");
						fout.write(pNode.desNd.nodeNum);
					}
					else {
						fout.write(pNode.desNd.nodeNum + "->");
					}
					pNode = nodePos[i].isoBig.isoNd;
					do {
						fout.write(", <-" + pNode.desNd.nodeNum);
						pNode = pNode.isoNd;
					}while(pNode != nodePos[i].isoBig);
				}
			}
			
			fout.write(String.format("\r\n\r\n### Tree topology branch information (check if reorderBrIdx() was run) ###"));
			for (i=0;i<this.brPos.length;i++) {
				fout.write(String.format("\r\nbr%d : %d <--> %d ", i, brPos[i].nodeNum, brPos[i].desNd.nodeNum));
				if (brPos[i].desNd.isoNd == null) {
					fout.write(String.format("; terminal br to %s", brPos[i].desNd.taxonName));
				}
				else {
					fout.write(String.format("; MRCA of %s and %s", this.getLeftBottomTaxon(brPos[i].desNd.isoNd), this.getRightBottomTaxon(brPos[i].desNd.isoNd.isoNd) ));
				}
			}
		}
		catch (IOException e) {
			System.err.println(e);
		} 
		/*// do not use finally{} block, because fout is still handled out of this function. 
		finally {
			try {
				fout.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
		*/

		
	}
	 
	
	public void PrintTreeTopo() {

		int i;
		
		/*
		myFunc.print(String.format("\nInput data order"));
		for (i=0;i<this.taxaNameList.length;i++) {
			System.out.print("\n" + this.taxaNameList[i]);
		}
		*/
		
		myFunc.print(String.format("\r\n\r\n### Tree topology node information ###"));
		for (i=0;i<nodeNum;i++) {
			System.out.println();
			Node pNode = nodePos[i];
			if (pNode.isoNd == null) { // if terminal node
				System.out.print("Node " + i + ": " + pNode.taxonName);
			}
			else {
				System.out.print("Node " + i + ":");
				pNode = nodePos[i].isoBig;

				if (pNode == startNode) {
					System.out.print("(StartNode) ->");
					System.out.print(pNode.desNd.nodeNum);
				}
				else {
					System.out.print(pNode.desNd.nodeNum + "->");
				}
				pNode = nodePos[i].isoBig.isoNd;
				do {
					System.out.print(", <-" + pNode.desNd.nodeNum);
					pNode = pNode.isoNd;
				}while(pNode != nodePos[i].isoBig);
			}
		}
		
		myFunc.print(String.format("\r\n\r\n### Tree topology branch information (check if reorderBrIdx() was run) ###"));
		for (i=0;i<this.brPos.length;i++) {
			myFunc.print(String.format("\r\nbr%d : %d <--> %d ", i, brPos[i].nodeNum, brPos[i].desNd.nodeNum));
			if (brPos[i].desNd.isoNd == null) {
				myFunc.print(String.format("; terminal br to %s", brPos[i].desNd.taxonName));
			}
			else {
				myFunc.print(String.format("; MRCA of %s and %s", this.getLeftBottomTaxon(brPos[i].desNd.isoNd), this.getRightBottomTaxon(brPos[i].desNd.isoNd.isoNd) ));
			}
		}
		
	}
	 

	Tree() {
		this.optMaxR = 3;
		//System.out.print("\nTree()");
	}

	
	//////////////////////
	//////////////////////
	
	
	
	public void functionCheck() {
		
		buildTree(this.oriTopo);
		this.PrintTreeTopo();
		
	}
	
	public void functionCheck2() {
		Node ndr;
		Node nd1 = new Node();
		Node nd2 = new Node();
		
		nd1.taxonName = "nd1";
		nd2.taxonName = "nd2";
		System.out.println(nd1.taxonName);
		ndr = nd1;
		ndr.taxonName = "ndr";
		System.out.println(nd1.taxonName);
		
		System.out.println(nd2.taxonName);
		
		nd1.idxBranchTopo = 1;
		nd2.idxBranchTopo = 2;
		nd1.bootProb = 1.0;
		nd2.bootProb = 2.0;
		
		
		nd2 = nd1;
		System.out.println(nd2.taxonName);
		System.out.println(nd2.bootProb);
		System.out.println(nd2.idxBranchTopo);
		

		
		
		System.exit(0);
		
	}
	
	public void replaceGapsEvenNumTaxa() {
		replaceGapsEvenNumTaxa_deterministic();
		//replaceGapsEvenNumTaxa_random(); // this seems to violate null distribution
	}
	
	public void replaceGapsEvenNumTaxa_random() {
		int j,i;
						
		for (i=0;i<alphabetData[0].length;i++) {
			//int idx = myFunc.myRand.nextInt(2);
			int idx = myRand.nextInt(2);
			if (idx==0) {
				for (j=0;j<taxaNameList.length;j++) {
					if (j%2==0)
						this.alphabetData[j][i] = '-';
				}
			}
		}
	}
	
	public void replaceGapsEvenNumTaxa_deterministic() {
		
		int j,i;
		for (j=0;j<taxaNameList.length;j++) {
			if (j%2==0) {
				for (i=alphabetData[j].length/2;i<alphabetData[j].length;i++) {
					this.alphabetData[j][i] = '-';
				}
			}
		}
		
		//calcSitewiseGapProp();
		
	}
	
	
	public void CalcAlphabetDataPairDiff() {
		int i, j, k, id, sizeT, sizeL;
		
		sizeT = this.alphabetData.length;
		sizeL = this.alphabetData[0].length;
		
		double[][] alphabetDataPairDiff;
		int[][] alphabetDataPairDiffGapPattern;	
		double[] sitewiseDiffAve;
		double[] sitewiseDiffGapPositionSum;
		double[] sitewiseInvalidProp;
		double[] sitewise2ndDeriv;
		double[] pRho;

		alphabetDataPairDiff = new double[sizeT*(sizeT-1)/2][sizeL];
		alphabetDataPairDiffGapPattern = new int[sizeT*(sizeT-1)/2][sizeL];	
		sitewiseDiffAve = new double[sizeL];
		sitewiseDiffGapPositionSum = new double[sizeL];	
		sitewiseInvalidProp = new double[sizeL];
		sitewise2ndDeriv = new double[sizeL];
		
		pRho = new double[sizeT*(sizeT-1)/2];
		
		int allTaxaGapSiteCnt;
		int allButOneTaxonGapSiteCnt;
		allTaxaGapSiteCnt = allButOneTaxonGapSiteCnt = 0;
		int totalGap = 0;
		for (k=0;k<sizeL;k++) {		
			int gap = 0;
			for (i=0;i<sizeT;i++) {
				if (myFunc.isMeaningful(alphabetData[i][k]))
					;
				else {
					gap++;
					totalGap++;
				}
			}
			if (gap==sizeT-1) 
				allButOneTaxonGapSiteCnt++;
			else if (gap==sizeT)
				allTaxaGapSiteCnt++;
		}
		
		myFunc.print(String.format("\nNumber of sites (all gaps) : %d", allTaxaGapSiteCnt)) ;
		myFunc.print(String.format("\nNumber of sites (all gaps except one taxon) : %d ", allButOneTaxonGapSiteCnt)) ;
		myFunc.print(String.format("\n(1-Gap proportion) in the aligned data : %f \n", 1.0-1.0*totalGap/(sizeL*sizeT) )) ;

		
		id = 0;
		int invalid;
		for (k=0;k<sizeL;k++) {		
			invalid = 0;
			id = 0;
			for (i=0;i<sizeT;i++) {
				for (j=i+1;j<sizeT;j++) {
					if (myFunc.isMeaningful(alphabetData[i][k]) && myFunc.isMeaningful(alphabetData[j][k])) {
						if (alphabetData[i][k]!=alphabetData[j][k]) 
							alphabetDataPairDiff[id][k] = 1;
						else
							alphabetDataPairDiff[id][k] = 0;
						alphabetDataPairDiffGapPattern[id][k] = 0;
					}
					else {
						alphabetDataPairDiff[id][k] = -1.0; // temporarily -1
						alphabetDataPairDiffGapPattern[id][k] = 1;
						invalid++;
					}
					id++;
				}
			}
			sitewiseInvalidProp[k] = 1.0*invalid / alphabetDataPairDiff.length;
		}
		
		
		//replace gap with average of meaningful position
		double val;
		int meaningfulCnt;
		double[] rowMeaninglessProp = new double[alphabetDataPairDiff.length];
		double[] rowOneProp  = new double[alphabetDataPairDiff.length];
		int cnt = 0;
		for (i=0;i<alphabetDataPairDiff.length;i++) {
			val = 0.0;
			meaningfulCnt = 0;
			cnt = 0;
			for (k=0;k<alphabetDataPairDiff[i].length;k++) {
				if (alphabetDataPairDiffGapPattern[i][k] == 0 ) { // if not gap
					val += alphabetDataPairDiff[i][k];
					meaningfulCnt++;
					cnt++;
				}
			}
			val /= meaningfulCnt;
			pRho[i] = 1.0*cnt/sizeL;
			rowMeaninglessProp[i] = 1.0 - 1.0*meaningfulCnt/sizeL;
			rowOneProp[i] = val;
			for (k=0;k<alphabetDataPairDiff[i].length;k++) {
				if (alphabetDataPairDiffGapPattern[i][k] == 1) { // if gap
					alphabetDataPairDiff[i][k] = val;
				}
			}
		}
		
		for (k=0;k<sizeL;k++) {
			val = 0.0;
			sitewiseDiffGapPositionSum[k] = 0.0;
			sitewise2ndDeriv[k] = 0.0;
			id = 0;
			for (i=0;i<alphabetDataPairDiff.length;i++) {
				val += alphabetDataPairDiff[i][k];
				if (alphabetDataPairDiffGapPattern[i][k] == 1) { // if gap
					sitewiseDiffGapPositionSum[k] +=  alphabetDataPairDiff[i][k];
				}
				else { // if not gap
					if (alphabetDataPairDiff[id][k] == 1) { // if different character
						sitewise2ndDeriv[k] += 1.0/(rowOneProp[id]*rowOneProp[id]);
					}
					else {
						sitewise2ndDeriv[k] += 1.0/((1.0-rowOneProp[id])*(1.0-rowOneProp[id]));
					}
				}
				id++;
			}
			sitewiseDiffAve[k] = val / alphabetDataPairDiff.length;
		}
		
		/// print

		
		myFunc.printArrayRstyle(sitewiseInvalidProp, "\r\nsitewiseInvalidProp");
		myFunc.printArrayRstyle(sitewise2ndDeriv, "\r\nsitewise2ndDeriv");		
		myFunc.print(String.format("\nplot(sitewiseInvalidProp, sitewise2ndDeriv, main=\"Relationship of ....\", xlab=\"Gap proportion\", ylab=\"sitewise2ndDeriv\")"));
		myFunc.print(String.format("\nfit <- lm(sitewise2ndDeriv ~ sitewiseInvalidProp)"));
		myFunc.print(String.format("\nabline(fit)"));
		myFunc.print(String.format("\nsummary(fit)\n\n"));
		
		
		
		myFunc.printArrayRstyle(sitewiseInvalidProp, "\r\nsitewiseInvalidProp");
		myFunc.printArrayRstyle(sitewiseDiffGapPositionSum, "\r\nsitewiseDiffGapPositionSum");		
		myFunc.print(String.format("\nplot(sitewiseInvalidProp, sitewiseDiffGapPositionSum, main=\"Relationship of ....\", xlab=\"Gap proportion\", ylab=\"sitewiseDiffGapPositionSum\")"));
		myFunc.print(String.format("\nfit <- lm(sitewiseDiffGapPositionSum ~ sitewiseInvalidProp)"));
		myFunc.print(String.format("\nabline(fit)"));
		myFunc.print(String.format("\nsummary(fit)\n\n"));
		
		myFunc.printArrayRstyle(sitewiseDiffAve, "\r\nsitewiseDiffAve");
		
		myFunc.print(String.format("\nplot(sitewiseInvalidProp, sitewiseDiff, main=\"Relationship of Gap and s-Diff\", xlab=\"Gap proportion\", ylab=\"s-Diff\")"));
		myFunc.print(String.format("\nfit <- lm(sitewiseDiff ~ sitewiseInvalidProp)"));
		myFunc.print(String.format("\nabline(fit)"));
		myFunc.print(String.format("\nsummary(fit)\n\n"));

		myFunc.printArrayRstyle(rowOneProp, "\r\nrowOneProp");
		myFunc.printArrayRstyle(rowMeaninglessProp, "\r\nrowMeaninglessProp");
		myFunc.print(String.format("\nplot(rowOneProp, rowMeaninglessProp, main=\"Relationship of ...\", xlab=\"rowOneProp\", ylab=\"rowMeaninglessProp\")"));
		myFunc.print(String.format("\nfit <- lm(rowMeaninglessProp ~ rowOneProp)"));
		myFunc.print(String.format("\nabline(fit)"));
		myFunc.print(String.format("\nsummary(fit)"));		
		myFunc.print(String.format("\ncor.test(rowOneProp, rowMeaninglessProp,method=\"pearson\")\n\n"));
		
		myFunc.printArrayRstyle(pRho, "\r\npRho");

	}
	
	public void rearrangeColumnsWithGapProp() {
		int i, j, k, l;
		char c;
		double tmp;
		for (i=0;i<this.alphabetDataPatternNum.length-1;i++) {
			for (j=i+1;j<alphabetDataPatternNum.length;j++) {
				if (sitewiseGapProp[i] > sitewiseGapProp[j]) {
					for (k=0;k<this.alphabetData.length;k++) {
						c = alphabetData[k][i];
						alphabetData[k][i] = alphabetData[k][j];
						alphabetData[k][j] = c;
					}
					tmp = sitewiseGapProp[i];
					sitewiseGapProp[i] = sitewiseGapProp[j];
					sitewiseGapProp[j] = tmp;
					l = alphabetDataPatternNum[i];
					alphabetDataPatternNum[i] = alphabetDataPatternNum[j];
					alphabetDataPatternNum[j] = l;
				}
			}
		}
	}
	
	public void calcSitewiseGapPropCDF() {

		if (includeAllSitesForGapPropCDF) 
			calcSitewiseGapPropCDFAllSites();
		else
			calcSitewiseGapPropCDFOnlyGappySites();
		
	}
	
	public void calcSitewiseGapPropCDFOnlyGappySites() {
		
		this.sitewiseGapPropCDF  = new double[this.alphabetDataPatternNum.length];	

		
		int i, j, k, l;
		char c;
		double tmp;
		int[] oriIdx = new int[sitewiseGapProp.length];
		int[] oriCnt = new int[sitewiseGapProp.length];
		double[] tmpSpace = new double[sitewiseGapProp.length];
		
		for (i=0;i<tmpSpace.length;i++) {
			tmpSpace[i] = sitewiseGapProp[i];
			oriIdx[i] = i;
			oriCnt[i] = alphabetDataPatternNum[i];
		}
		
		for (i=0;i<oriIdx.length-1;i++) {
			for (j=i+1;j<oriIdx.length;j++) {
				if (tmpSpace[i] > tmpSpace[j]) {

					tmp = tmpSpace[i];
					tmpSpace[i] = tmpSpace[j];
					tmpSpace[j] = tmp;
					
					k = oriIdx[i];
					oriIdx[i] = oriIdx[j];
					oriIdx[j] = k;
					
					k = oriCnt[i];
					oriCnt[i] = oriCnt[j];
					oriCnt[j] = k;
				}
			}
		}
		
		////
		
		int numOfCompleteColumn = 0;
		
		
		double[] tmpCDF  = new double[oriCnt.length];
		int start, end, partial, total;
		total = partial = start = end = 0;
		
		//fine non-zero gap-prop position
		for (i=0;i<tmpSpace.length;i++) {
			if (tmpSpace[i] < myFunc.EPSILON)
				numOfCompleteColumn += oriCnt[i];

			if (tmpSpace[i] > 0.0) {
				start = end = i;
				break;
			}
				
		}

		myFunc.print(String.format("\r\nincludeAllSitesForGapPropCDF==false,\r\nnumOfCompleteColumn= %d", numOfCompleteColumn));

		
		while (partial < this.seqLength - numOfCompleteColumn ) {
			while (partial < this.seqLength - numOfCompleteColumn &&tmpSpace[start] == tmpSpace[end] &&  end < oriCnt.length) {
				partial += oriCnt[end];
				end++;
			}
			for (i=start;i<end;i++) {
				tmpCDF[i] = partial;
			}
			start = end;
			//myFunc.print(String.format("\nend= %d, partial=%d", end, partial));
		}
		
		for (i=0;i<tmpCDF.length;i++) {
			tmpCDF[i] /= partial;
		}

		
		for (i=0;i<tmpCDF.length;i++) {
			sitewiseGapPropCDF[oriIdx[i]] = tmpCDF[i];
		}
		
			
		myFunc.print(String.format("\r\nsitewiseGapPropCDF <- c(...) omitted.."));
		myFunc.print(String.format("\r\nsitewiseGapPropCDF <- c(...) first 100"));
		//myFunc.printArrayRstyle(sitewiseGapPropCDF, "sitewiseGapPropCDF",100);
	
	}
	
	
	public void calcSitewiseGapPropCDFAllSites() {
		
		this.sitewiseGapPropCDF  = new double[this.alphabetDataPatternNum.length];	

		
		int i, j, k, l;
		char c;
		double tmp;
		int[] oriIdx = new int[sitewiseGapProp.length];
		int[] oriCnt = new int[sitewiseGapProp.length];
		double[] tmpSpace = new double[sitewiseGapProp.length];
		
		for (i=0;i<tmpSpace.length;i++) {
			tmpSpace[i] = sitewiseGapProp[i];
			oriIdx[i] = i;
			oriCnt[i] = alphabetDataPatternNum[i];
		}
		
		for (i=0;i<oriIdx.length-1;i++) {
			for (j=i+1;j<oriIdx.length;j++) {
				if (tmpSpace[i] > tmpSpace[j]) {

					tmp = tmpSpace[i];
					tmpSpace[i] = tmpSpace[j];
					tmpSpace[j] = tmp;
					
					k = oriIdx[i];
					oriIdx[i] = oriIdx[j];
					oriIdx[j] = k;
					
					k = oriCnt[i];
					oriCnt[i] = oriCnt[j];
					oriCnt[j] = k;
				}
			}
		}
		
		////
		
		
		double[] tmpCDF  = new double[oriCnt.length];
		int start, end, partial, total;
		total = partial = start = end = 0;
		while (partial < this.seqLength ) {
			while (partial < this.seqLength &&tmpSpace[start] == tmpSpace[end] &&  end < oriCnt.length) {
				partial += oriCnt[end];
				end++;
			}
			for (i=start;i<end;i++) {
				tmpCDF[i] = partial;
			}
			start = end;
			//myFunc.print(String.format("\nend= %d, partial=%d", end, partial));
		}
		
		for (i=0;i<tmpCDF.length;i++) {
			tmpCDF[i] /= partial;
		}

		
		for (i=0;i<tmpCDF.length;i++) {
			sitewiseGapPropCDF[oriIdx[i]] = tmpCDF[i];
		}
		
			
		myFunc.print(String.format("\nsitewiseGapPropCDF <- c(...) omitted.."));
		myFunc.print(String.format("\nsitewiseGapPropCDF <- c(...) first 100"));
		myFunc.printArrayRstyle(sitewiseGapPropCDF, "sitewiseGapPropCDF",100);
		
	}
	
	public boolean isGap(char c)
	{
		/*
		boolean dnamodel = true;
		if (this.subsModel == ModelType.WAG) 
			dnamodel = false;
		else if (this.subsModel == ModelType.mtREV24) 
			dnamodel = false;
		else if (this.subsModel == ModelType.LG)
			dnamodel = false;
		else if (this.subsModel == ModelType.Dayhoff)
			dnamodel = false;
			*/
		
		if (c=='-' || c=='?' ) // || (dnamodel && c=='N') ) 
			return true;
		else return false;
		
	}
	
	
	
	public void calcSitewiseGapProp() {
		this.sitewiseGapProp  = new double[this.alphabetDataPatternNum.length];
		this.taxonwiseGapProp = new double[alphabetData.length];
		//this.sitewiseGapPropBrMultFactorOri  = new double[this.alphabetDataPatternNum.length];
		this.sitewiseGapPropBrMultFactor  = new double[this.alphabetDataPatternNum.length];

		
		int i,j, L;
		double tmp;
		double mean = 0.0;
		L = 0;
		for (i=0;i<this.alphabetDataPatternNum.length;i++) { //
			tmp = 0.0;
			for (j=0;j<this.alphabetData.length;j++) {
				//if (this.alphabetData[j][i] == '-' || this.alphabetData[j][i] == '?' )
				if (this.isGap(this.alphabetData[j][i]))
					tmp += 1.0;
			}
			this.sitewiseGapProp[i] = tmp / alphabetData.length;
			mean += this.sitewiseGapProp[i] * alphabetDataPatternNum[i];
			L += alphabetDataPatternNum[i];
		}
		mean /= 1.0*L;
		this.gapOverallMean = mean;
		
		for (j=0;j<this.alphabetData.length;j++) { 
			tmp = 0.0;
			for (i=0;i<this.alphabetDataPatternNum.length;i++) { //
				//if (this.alphabetData[j][i] == '-' || this.alphabetData[j][i] == '?' )
				if (this.isGap(this.alphabetData[j][i]))
					tmp += 1.0 * alphabetDataPatternNum[i];
			}
			this.taxonwiseGapProp[j] = tmp / this.seqLength;
		}
		
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.NocalcGapPropMultFactor) {
			for (i=0;i<this.alphabetData[0].length;i++) {
				this.sitewiseGapPropBrMultFactor[i] = 1.0;
				//this.sitewiseGapPropBrMultFactorOri[i] = 1.0;
			}
		}
		else {
			for (i=0;i<this.alphabetData[0].length;i++) {
				;//this.sitewiseGapPropBrMultFactorOri[i] = this.sitewiseGapProp[i]; // / gapOverallMean;
			}
		}
		
		//// gap proporition of each taxon
		/*
		myFunc.print(String.format("\n\nGap proportion of each taxon"));
		for (i=0;i<this.alphabetData.length;i++) { //
			tmp = 0.0;
			for (j=0;j<this.alphabetDataPatternNum.length;j++) {
				if (this.alphabetData[i][j] == '-' || this.alphabetData[i][j] == '?' )
					tmp += 1.0;
			}
			myFunc.print(String.format("\ni=%d, %s, %f", i, this.taxaNameList[i], 1-tmp*1.0/L));
		}
		System.exit(0);
		*/
		
	}
	
	
	public void leastSquareMethod() {
	
		int i,j,k,n;
		
		this.calcPairDist2();
		this.setTopoMat();
		
		double[] estBr = new double[this.brPos.length];
		n = taxaNum;
		double[] pDist = new double[n*(n-1)/2];
		

		k = 0;
		for (i=0;i<n;i++) {
			for (j=i+1;j<n;j++) {
				pDist[k] = this.pairDist[i][j];
				k++;
			}
		}
		
		leastSquareMethodSub(estBr, this.topoMat, pDist);
		
		
		for (i=0;i<brPos.length;i++) {
			if (estBr[i] < 0.0)
				estBr[i] = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
			brPos[i].branchLength = brPos[i].desNd.branchLength = estBr[i];
		}
		
		// checking
		/*
		n = estBr.length;
		for (i=0;i<n;i++) {
			myFunc.print(String.format("\nestBr%d = %f", i, estBr[i]));
		}
		System.exit(0);
		*/
		
	}
	
	public void leastSquareMethodSub(double[] brEst, double[][] topoMat, double[] pDist) {
		
		double[][] At = new double[topoMat[0].length][topoMat.length];
		double[][] M = new double[topoMat[0].length][topoMat[0].length];
		double[][] invM = new double[topoMat[0].length][topoMat[0].length];
		
		myFunc.matrixTranspose(At, topoMat);
		myFunc.matrixMult(M, At, topoMat);
		myFunc.matrixInverse(invM, M);
		
		M = new double[topoMat[0].length][topoMat.length];
		
		myFunc.matrixMult(M, invM, At);
		myFunc.matrixVectorMult(brEst, M, pDist);
		
		
	}
	
	
	
	public void setTopoMat() {
		int i,j,n, k;
		n = this.taxaNum;
		topoMat = new double[n*(n-1)/2][this.brNum];
		
		k = 0;
		for (i=0;i<n;i++) {
			for (j=i+1;j<n;j++) {
				setIdxToBranch(i,j, k);
				k++;
			}
		}
		
		/// print out for checking
		myFunc.print(String.format("\ntopoMat (first three lines are shown)"));
		n = topoMat.length;
		for (i=0;i<3;i++) { //for (i=0;i<n;i++) {
			myFunc.print(String.format("\n"));
			for (j=0;j<topoMat[i].length;j++) {
				myFunc.print(String.format("%f ", topoMat[i][j]));
			}
		}
		
	}
	
	public void setIdxToBranch(int a, int b, int c) {
		// set all branch compo which connects taxon aaa and taxon bbb to 1.0. topoMat[c][..]
		
		Node nd = findNode(this.taxaNameList[a]);
		int id = findBrIdx(nd);
		int ret; 
		topoMat[c][id] = 1.0;
		
		Node ptr = nd.desNd.isoNd;
		do {
			ret = searchAndSet(ptr, b, c);
			if (ret == 1) {
				id = findBrIdx(ptr);
				topoMat[c][id] = 1.0;
			}
			ptr = ptr.isoNd;
		} while (ptr != nd.desNd);
		
	}
	
	public int findBrIdx(Node nd) {
		int i;
		for (i=0;i<this.brPos.length;i++) {
			if (nd.hashCode() == brPos[i].hashCode() || nd.hashCode() == brPos[i].desNd.hashCode())
				return i;
		}
		
		System.err.print(String.format("\nSomething wroing in findBrIdx(..)"));
		System.exit(0);
		
		return -1;
	}
	
	public int searchAndSet(Node ptr, int b, int c) {
		//search taxon b
		Node pNode;
		int id, ret, existent;
		
		existent = 0;
		if (ptr.desNd.isoNd == null) { // if terminal
			if (ptr.desNd.taxonName.equals(this.taxaNameList[b])) {
				id = findBrIdx(ptr);
				topoMat[c][id] = 1.0;
				existent = 1;
			}
		}
		else {
			pNode = ptr.desNd.isoNd;
			do {
				ret = searchAndSet(pNode, b, c);
				if (ret == 1) {
					id = findBrIdx(ptr);
					topoMat[c][id] = 1.0;
					existent = 1;
				}
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
		}
		
		return existent;
		
	}
	
	public double LRTComposite(double[] minCellCnt) {
		int i,j,k, cnt, iter;
		double[] ret = new double[2];
		//iter = 200;
		iter = alphabetData.length * (alphabetData.length-1) * (alphabetData.length-2) / 6;
		double[] diffSave = new double[iter];
		cnt = 0;

		double stat = 0.0;
		
		boolean debug = true;
		
		for (i=0;i<this.alphabetData.length;i++) {
			for (j=i+1;j<this.alphabetData.length;j++) {
				for (k=j+1;k<alphabetData.length;k++) {
					if (i==0 && j==10 && k==43)
						i=0;
					ret[0] = ret[1] = 0.0;
					if (debug) {
						System.err.print(String.format("\n(%d,%d,%d)", i,j,k));
						myFunc.print(String.format("\n\n(%d,%d,%d)", i,j,k));
					}

					LRTCompositeSub(ret, minCellCnt, i,j,k, cnt); // jeff's 
					diffSave[cnt] = 2.0*(ret[1] - ret[0]);
					
					//LRTCompositeSub2(ret, i,j,k); // triplet + 0-1
					//LRTCompositeSub3(ret, i,j,k);
					//diffSave[cnt] = ret[1] - ret[0];
					
					stat += diffSave[cnt];
					if (debug) {
						System.err.print(String.format("  2*logLikeDiff= %f ", diffSave[cnt]));
						myFunc.print(String.format("\n2*logLikeDiff= %f ", diffSave[cnt]));	
						myFunc.print(String.format("\n  sum of stat = %f ", stat));
					}
		
					cnt++;
					if (cnt == iter) {
						//myFunc.printArrayRstyle(diffSave, "diffSave");
						//return stat;
					}
				}
			}
		}
		
		if (debug) {
			myFunc.print(String.format("= %f ", stat));
			//System.exit(0);
		}

		return stat;
		
	}
	
	public void LRTCompositeSub3(double[] ret, int a, int b, int c) {
		
		int[] ret2;
		int nAAA, nAAB, nABA, nBAA, nABC;	
		
		ret2 = new int[5];
		LRTCompositeSubGetTripletCompoComplete(ret2, a, b, c);
		nAAA = ret2[0];
		nAAB = ret2[1];		
		nABA = ret2[2];		
		nBAA = ret2[3];
		nABC = ret2[4];	
		
		
		ret2 = new int[2];
		
		LRTCompositeSubGetTripletCompo(ret2, a, b, c, 0);
		if (ret2[0]+ret2[1]>0 && nAAA+nAAB+nABA+nBAA+nABC > 0) {
			ret[0] += 1.0 * (nAAB+nABA+nABC)/(nAAA+nAAB+nABA+nBAA+nABC);
			ret[1] += 1.0 * ret2[1]/(ret2[0]+ret2[1]);
		}
		LRTCompositeSubGetTripletCompo(ret2, a, b, c, 1);
		if (ret2[0]+ret2[1]>0 && nAAA+nAAB+nABA+nBAA+nABC > 0) {
			ret[0] += 1.0 * (nAAB+nBAA+nABC)/(nAAA+nAAB+nABA+nBAA+nABC);
			ret[1] += 1.0 * ret2[1]/(ret2[0]+ret2[1]);
		}
		LRTCompositeSubGetTripletCompo(ret2, a, b, c, 2);
		if (ret2[0]+ret2[1]>0 && nAAA+nAAB+nABA+nBAA+nABC > 0) {
			ret[0] += 1.0 * (nABA+nBAA+nABC)/(nAAA+nAAB+nABA+nBAA+nABC); 
			ret[1] += 1.0 * ret2[1]/(ret2[0]+ret2[1]);
		}
		

	}
	
	public void LRTCompositeSub2(double[] ret, int a, int b, int c) {
		int i, j;
		int [][] pairDiff = new int[3][this.alphabetData[a].length];
		boolean [] isCompleteSite = new boolean[this.alphabetData[a].length];
		for (i=0;i<isCompleteSite.length;i++) {
			isCompleteSite[i] = false;
		}
		for (i=0;i<pairDiff.length;i++) {
			for (j=0;j<pairDiff[i].length;j++) {
				pairDiff[i][j] = -1;
			}
		}
		for (i=0;i<this.alphabetData[a].length;i++) {
			if (myFunc.isMeaningful(alphabetData[a][i]) ) {
				if (myFunc.isMeaningful(alphabetData[b][i]) ) {
					if (myFunc.isMeaningful(alphabetData[c][i]) ) {
						if (alphabetData[a][i] == alphabetData[b][i])
							pairDiff[0][i] = 0;
						else
							pairDiff[0][i] = 1;
						
						if (alphabetData[a][i] == alphabetData[c][i])
							pairDiff[1][i] = 0;
						else
							pairDiff[1][i] = 1;
						
						if (alphabetData[b][i] == alphabetData[c][i])
							pairDiff[2][i] = 0;
						else
							pairDiff[2][i] = 1;
						
						isCompleteSite[i] = true;
					}
					else {
						if (alphabetData[a][i] == alphabetData[b][i])
							pairDiff[0][i] = 0;
						else
							pairDiff[0][i] = 1;
						
						pairDiff[1][i] = pairDiff[2][i] = -1;
					}
				} 
				else { // if  (!myFunc.isMeaningful(alphabetData[b][i]) ) 
					pairDiff[0][i] = pairDiff[2][i] = -1;
					if (myFunc.isMeaningful(alphabetData[c][i]) ) {
						if (alphabetData[a][i] == alphabetData[c][i])
							pairDiff[1][i] = 0;
						else
							pairDiff[1][i] = 1;
					}
				}
			}
			else { //if (!myFunc.isMeaningful(alphabetData[a][i]) )
				pairDiff[0][i] = pairDiff[1][i] = -1;
				if (myFunc.isMeaningful(alphabetData[b][i]) && myFunc.isMeaningful(alphabetData[c][i])) {
					if (alphabetData[b][i] == alphabetData[c][i])
						pairDiff[2][i] = 0;
					else
						pairDiff[2][i] = 1;
				}
				else
					pairDiff[2][i] = -1;
				
			}
		}
		
		/*
		myFunc.print(String.format("\npairDiff"));
		for (i=0;i<pairDiff.length;i++) {
			myFunc.print(String.format("\n"));
			for (j=0;j<pairDiff[i].length;j++) {
				myFunc.print(String.format("%d  ", pairDiff[i][j]));
			}
		}
		*/
		
		int oneCntComplete[] = new int[3];
		int zeroCntComplete[] = new int[3];
		
		int oneCntGappy[] = new int[3];
		int zeroCntGappy[] = new int[3];
		
		for (i=0;i<3;i++) {
			oneCntComplete[i] = zeroCntComplete[i] = oneCntGappy[i] = zeroCntGappy[i] = 0;
		}
		

		for (j=0;j<pairDiff[0].length;j++) {
			if (isCompleteSite[j]) {
				for (i=0;i<3;i++) {
					if (pairDiff[i][j] == 0)
						zeroCntComplete[i]++;
					else if (pairDiff[i][j] == 1)
						oneCntComplete[i]++;
					else 
						; // do nothing
				}
			}
			else {
				for (i=0;i<3;i++) {
					if (pairDiff[i][j] == 0)
						zeroCntGappy[i]++;
					else if (pairDiff[i][j] == 1)
						oneCntGappy[i]++;
					else 
						; // do nothing
				}
				
			}
		}
		
		
		/// under null
		double[] pOneMean = new double[3];
		for (i=0;i<3;i++) {
			pOneMean[i] = 1.0* (oneCntComplete[i] + oneCntGappy[i]) / (oneCntComplete[i] + oneCntGappy[i] + zeroCntComplete[i] + zeroCntGappy[i]); 
		}
		
		ret[0] = 0.0;
		for (i=0;i<3;i++) {
			if (oneCntComplete[i] > 0)
				ret[0] += oneCntComplete[i] * Math.log(pOneMean[i]);
			if (zeroCntComplete[i] > 0)
				ret[0] += zeroCntComplete[i] * Math.log(1.0-pOneMean[i]);
			if (oneCntGappy[i] > 0)
				ret[0] += oneCntGappy[i] * Math.log(pOneMean[i]);
			if (zeroCntGappy[i] > 0)
				ret[0] += zeroCntGappy[i] * Math.log(1.0-pOneMean[i]);
		}

		
		// under alternative
		double[] pOneMeanGappy = new double[3];
		for (i=0;i<3;i++) {
			pOneMean[i] = 1.0* oneCntComplete[i]/ (oneCntComplete[i] + zeroCntComplete[i]); 
			
			if (oneCntGappy[i] + zeroCntGappy[i] > 0)
				pOneMeanGappy[i] = 1.0* oneCntGappy[i]/ (oneCntGappy[i] + zeroCntGappy[i]); 
			else
				pOneMeanGappy[i] = 0.0;
		}
		
		ret[1] = 0.0;
		for (i=0;i<3;i++) {
			if (oneCntComplete[i] > 0)
				ret[1] += oneCntComplete[i] * Math.log(pOneMean[i]);
			if (zeroCntComplete[i] > 0)
				ret[1] += zeroCntComplete[i] * Math.log(1.0-pOneMean[i]);
			if (oneCntGappy[i] > 0) 
				ret[1] += oneCntGappy[i] * Math.log(pOneMeanGappy[i]);
			if (zeroCntGappy[i] > 0)
				ret[1] += zeroCntGappy[i] * Math.log(1.0-pOneMeanGappy[i]);
		}
		
		
		i = 0;
		
		//System.exit(0);
		
		
	}
	

	
	public void LRTCompositeSub(double[] ret, double[] minCellCnt, int a, int b, int c, int idx) {
		// Jeff's suggestion
		
	
		int nXAA, nXAB;
		int nAXA, nAXB;
		int nAAX, nABX;
		double m, M;
		int[] cntGappy = new int[6];

		int nAAA, nAAB, nABA, nBAA, nABC;
		int[] cntComplete = new int[5];
		
	
		int ret2[] = new int[5];
		LRTCompositeSubGetTripletCompoComplete(ret2, a, b, c);
		cntComplete[0] = nAAA = ret2[0];
		cntComplete[1] = nAAB = ret2[1];		
		cntComplete[2] = nABA = ret2[2];		
		cntComplete[3] = nBAA = ret2[3];
		cntComplete[4] = nABC = ret2[4];
		

		ret2 = new int[2];
		
		double aa, bb, cc, dd;
		int total;
		
		
		LRTCompositeSubGetTripletCompo(ret2, a, b, c, 0);
		cntGappy[0] = nXAA = ret2[0];
		cntGappy[1] = nXAB = ret2[1];
		/*
		m = (nXAA<nXAB)?nXAA:nXAB;
		m = (nAAA+nBAA<m)?(nAAA+nBAA):m;
		m = (nAAB+nABA+nABC<m)?(nAAB+nABA+nABC):m;		
		M = m;
		*/
		total = nAAB+nABA+nABC + nXAB + nAAA+nBAA + nXAA;
		aa = 1.0*(nAAB+nABA+nABC+ nXAB)*(nAAB+nABA+nABC+nAAA+nBAA)/total;
		bb = 1.0*(nAAB+nABA+nABC+ nXAB)*(nXAB+nXAA)/total;
		cc = 1.0*(nAAA+nBAA+ nXAA)*(nAAB+nABA+nABC+nAAA+nBAA)/total;
		dd = 1.0*(nAAA+nBAA+ nXAA)*(nXAB+nXAA)/total;
		m = (aa<bb)?aa:bb;
		m = (cc<m)?cc:m;
		m = (dd<m)?dd:m;		
		M = m;		
		myFunc.print(String.format("\n -YY   complete   gappy"));
		myFunc.print(String.format("\ndiff         %d      %d ",nAAB+nABA+nABC, nXAB  ));
		myFunc.print(String.format("\nno-diff      %d      %d ",nAAA+nBAA, nXAA ));

		////
		
		LRTCompositeSubGetTripletCompo(ret2, a, b, c, 1);
		cntGappy[2] = nAXA = ret2[0];
		cntGappy[3] = nAXB = ret2[1];
		/*
		m = (nAXA<nAXB)?nAXA:nAXB;
		m = (nAAA+nABA<m)?(nAAA+nABA):m;
		m = (nAAB+nBAA+nABC<m)?(nAAB+nBAA+nABC):m;		
		M = (m>M)?m:M;
		*/
		total = nAAB + nABA + nABC + nAXB + nAAA + nBAA + nAXA;
		aa = 1.0*(nAAB+nBAA+nABC+ nAXB)*(nAAB+nABA+nABC+nAAA+nBAA)/total;
		bb = 1.0*(nAAB+nBAA+nABC+ nAXB)*(nAXB+nAXA)/total;
		cc = 1.0*(nAAA+nABA+nAXA)*(nAAB+nABA+nABC+nAAA+nBAA)/total;
		dd = 1.0*(nAAA+nABA+ nAXA)*(nAXB+nAXA)/total;
		m = (aa<bb)?aa:bb;
		m = (cc<m)?cc:m;
		m = (dd<m)?dd:m;	
		M = (m>M)?m:M;		
		myFunc.print(String.format("\n Y-Y   complete   gappy"));
		myFunc.print(String.format("\ndiff         %d      %d ",nAAB+nBAA+nABC, nAXB  ));
		myFunc.print(String.format("\nno-diff      %d      %d ",nAAA+nABA, nAXA ));
		
		/////
		
		LRTCompositeSubGetTripletCompo(ret2, a, b, c, 2);
		cntGappy[4] = nAAX = ret2[0];
		cntGappy[5] = nABX = ret2[1];
		/*
		m = (nAAX<nABX)?nAAX:nABX;
		m = (nAAA+nAAB<m)?(nAAA+nAAB):m;
		m = (nABA+nBAA+nABC<m)?(nABA+nBAA+nABC):m;		
		M = (m>M)?m:M;		
		*/
		total = nAAB + nABA + nABC + nABX + nAAA + nBAA + nAAX;
		aa = 1.0*(nABA+nBAA+nABC+ nABX )*(nAAB+nABA+nABC+nAAA+nBAA)/total;
		bb = 1.0*(nABA+nBAA+nABC+ nABX)*(nABX+nAAX)/total;
		cc = 1.0*(nAAA+nAAB+ nAAX)*(nAAB+nABA+nABC+nAAA+nBAA)/total;
		dd = 1.0*(nAAA+nAAB+ nAAX)*(nABX+nAAX)/total;
		m = (aa<bb)?aa:bb;
		m = (cc<m)?cc:m;
		m = (dd<m)?dd:m;	
		M = (m>M)?m:M;			
		myFunc.print(String.format("\n YY-   complete   gappy"));
		myFunc.print(String.format("\ndiff         %d      %d ",nABA+nBAA+nABC, nABX  ));
		myFunc.print(String.format("\nno-diff      %d      %d ",nAAA+nAAB, nAAX ));
		

		minCellCnt[idx] = M;
				
		LRTCompositeSubGetTripletLogLike(ret, cntGappy, cntComplete);
		
		myFunc.print(String.format("\nM= %f", M));

		
		
		
	}
	
	public void LRTCompositeSubGetTripletCompo(int[] ret, int a, int b, int c, int idx) {
		int i;
		ret[0] = ret[1] = 0;
		int ida, idb;

		for (i=0;i<this.alphabetData[0].length;i++) {
			if (idx == 0 
				&& !myFunc.isMeaningful(alphabetData[a][i])
				&& myFunc.isMeaningful(alphabetData[b][i]) 
				&& myFunc.isMeaningful(alphabetData[c][i])) {
				if (alphabetData[b][i]==alphabetData[c][i]) 
					ret[0]++;
				else if (alphabetData[b][i]!=alphabetData[c][i]) 
					ret[1]++;
			}
			else if (idx == 1 
					&& myFunc.isMeaningful(alphabetData[a][i])
					&& !myFunc.isMeaningful(alphabetData[b][i]) 
					&& myFunc.isMeaningful(alphabetData[c][i])) {
				if (alphabetData[a][i]==alphabetData[c][i]) 
					ret[0]++;
				else if (alphabetData[a][i]!=alphabetData[c][i]) 
					ret[1]++;
			}
			else if (idx == 2 
					&& myFunc.isMeaningful(alphabetData[a][i])
					&& myFunc.isMeaningful(alphabetData[b][i])
					&& !myFunc.isMeaningful(alphabetData[c][i])) {
				if (alphabetData[a][i]==alphabetData[b][i]) 
					ret[0]++;
				else if (alphabetData[a][i]!=alphabetData[b][i]) 
					ret[1]++;
			}
		}
	
		i=0;
		
	}
	
	
	public void LRTCompositeSubGetTripletCompoComplete(int[] ret, int a, int b, int c) {
		int i;
		for (i=0;i<ret.length;i++) 
			ret[i] = 0;
		for (i=0;i<this.alphabetData[0].length;i++) {
			if (myFunc.isMeaningful(alphabetData[a][i]) && myFunc.isMeaningful(alphabetData[b][i])
					&& myFunc.isMeaningful(alphabetData[c][i])) {
				
				if (alphabetData[a][i]==alphabetData[b][i] && alphabetData[a][i]==alphabetData[c][i]) 
					ret[0]++; //nAAA
				else if (alphabetData[a][i]==alphabetData[b][i] && alphabetData[a][i]!=alphabetData[c][i]) 
					ret[1]++; //nAAB
				else if (alphabetData[a][i]!=alphabetData[b][i] && alphabetData[a][i]==alphabetData[c][i]) 
					ret[2]++; //nABA
				else if (alphabetData[a][i]!=alphabetData[b][i] && alphabetData[b][i]==alphabetData[c][i]) 	
					ret[3]++; //nBAA
				else if (alphabetData[a][i]!=alphabetData[b][i] && alphabetData[b][i]!=alphabetData[c][i]
						&&alphabetData[a][i]!=alphabetData[c][i]) 
					ret[4]++; //nABC
				else {
					System.err.print(String.format("\nSomething Wrong in LRTCompositeSubGetTripletCompoComplete(..)"));
					System.exit(0);
				}
				
			}
			
		}
		
	}
	public void LRTCompositeSubGetTripletLogLike(double[] ret, int[] cntGappy, int[] cntComplete) {
		
		LRTCompositeSubGetTripletLogLikeSub1(ret, cntGappy, cntComplete);
		//LRTCompositeSubGetTripletLogLikeSub2(ret, cntGappy, cntComplete);
		
	}
	
	public void LRTCompositeSubGetTripletLogLikeSub1(double[] ret, int[] cntGappy, int[] cntComplete) {
		
		// Jeff's suggestion.
		
		/*
		cntGappy[0] = nXAA;
		cntGappy[1] = nXAB;
		cntGappy[2] = nAXA;
		cntGappy[3] = nAXB;
		cntGappy[4] = nAAX;
		cntGappy[5] = nABX;
		
		cntComplete[0] = nAAA;
		cntComplete[1] = nAAB;		
		cntComplete[2] = nABA;		
		cntComplete[3] = nBAA;
		cntComplete[4] = nABC;
		*/
		
		double[] pGappy = new double[cntGappy.length];
		double[] pGappyEM = new double[cntGappy.length];
		double[] pComplete = new double[cntComplete.length];
		double[] pCompleteEM = new double[cntComplete.length];		
		
		int i;
		double sum;
		/*// this is what Tae-Kun misunderstood
		sum = 0.0;
		for (i=0;i<cntGappy.length;i++) {
			sum += cntGappy[i];
		}
		if (sum > myFunc.EPSILON) {
			for (i=0;i<cntGappy.length;i++) {
				pGappy[i] = 1.0 * cntGappy[i]/sum;
			}
		}
		*/
		
		if (cntGappy[0]+cntGappy[1]>0) {
			pGappy[0] = 1.0*cntGappy[0]/(cntGappy[0]+cntGappy[1]);
			pGappy[1] = 1.0*cntGappy[1]/(cntGappy[0]+cntGappy[1]);
		}
		else {
			pGappy[0] = 0.0;
			pGappy[1] = 0.0;
		}
		if (cntGappy[2]+cntGappy[3]>0) {
			pGappy[2] = 1.0*cntGappy[2]/(cntGappy[2]+cntGappy[3]);
			pGappy[3] = 1.0*cntGappy[3]/(cntGappy[2]+cntGappy[3]);
		}
		else {
			pGappy[2] = 0.0;
			pGappy[3] = 0.0;
		}
		if (cntGappy[4]+cntGappy[5]>0) {
			pGappy[4] = 1.0*cntGappy[4]/(cntGappy[4]+cntGappy[5]);
			pGappy[5] = 1.0*cntGappy[5]/(cntGappy[4]+cntGappy[5]);	
		}
		else {
			pGappy[4] = 0.0;
			pGappy[5] = 0.0;				
		}

		sum = 0.0;
		for (i=0;i<cntComplete.length;i++) {
			sum += cntComplete[i];
		}
		if (sum > myFunc.EPSILON) {
			for (i=0;i<cntComplete.length;i++) {
				pComplete[i] = 1.0 * cntComplete[i]/sum;
			}
		}

		
		// loglike under alternative
		sum = 0.0;
		for (i=0;i<cntGappy.length;i++) {
			if (pGappy[i]<myFunc.EPSILON)
				sum += 0.0;
			else
				sum += cntGappy[i] * Math.log(pGappy[i]);
		}
		for (i=0;i<cntComplete.length;i++) {
			if (pComplete[i]<myFunc.EPSILON)
				sum += 0.0;
			else
				sum += cntComplete[i] * Math.log(pComplete[i]);
		}
		ret[1] = sum;
		
		
		// loglike under null
		LRTCompositeSubEM(pGappyEM, pCompleteEM, pGappy, pComplete, cntGappy, cntComplete);
		sum = 0.0;
		for (i=0;i<cntGappy.length;i++) {
			if (pGappyEM[i]<myFunc.EPSILON)
				sum += 0.0;
			else
				sum += cntGappy[i] * Math.log(pGappyEM[i]);
		}
		for (i=0;i<cntComplete.length;i++) {
			if (pCompleteEM[i]<myFunc.EPSILON)
				sum += 0.0;
			else
				sum += cntComplete[i] * Math.log(pCompleteEM[i]);
		}
		ret[0] = sum;
		
	}
	
	public void LRTCompositeSubGetTripletLogLikeSub2(double[] ret, int[] cntGappy, int[] cntComplete) {
		
		// Not using EM.
		
		/*
		cntGappy[0] = nXAA;
		cntGappy[1] = nXAB;
		cntGappy[2] = nAXA;
		cntGappy[3] = nAXB;
		cntGappy[4] = nAAX;
		cntGappy[5] = nABX;
		
		cntComplete[0] = nAAA;
		cntComplete[1] = nAAB;		
		cntComplete[2] = nABA;		
		cntComplete[3] = nBAA;
		cntComplete[4] = nABC;
		*/
		
		double[] pGappy = new double[cntGappy.length];
		double[] pComplete = new double[cntComplete.length];
		
		int i;
		double sum;
		sum = 0.0;
		for (i=0;i<cntGappy.length;i++) {
			sum += cntGappy[i];
		}
		if (sum > myFunc.EPSILON) {
			for (i=0;i<cntGappy.length;i++) {
				pGappy[i] = 1.0 * cntGappy[i]/sum;
			}
		}

		
		sum = 0.0;
		for (i=0;i<cntComplete.length;i++) {
			sum += cntComplete[i];
		}
		if (sum > myFunc.EPSILON) {
			for (i=0;i<cntComplete.length;i++) {
				pComplete[i] = 1.0 * cntComplete[i]/sum;
			}
		}

		
		// loglike under alternative
		sum = 0.0;
		for (i=0;i<cntGappy.length;i++) {
			if (pGappy[i]<myFunc.EPSILON)
				sum += 0.0;
			else
				sum += cntGappy[i] * Math.log(pGappy[i]);
		}
		for (i=0;i<cntComplete.length;i++) {
			if (pComplete[i]<myFunc.EPSILON)
				sum += 0.0;
			else
				sum += cntComplete[i] * Math.log(pComplete[i]);
		}
		ret[0] = sum;
		
		
		// loglike under null
		
		/*
		cntGappy[0] = nXAA;
		cntGappy[1] = nXAB;
		cntGappy[2] = nAXA;
		cntGappy[3] = nAXB;
		cntGappy[4] = nAAX;
		cntGappy[5] = nABX;
		
		cntComplete[0] = nAAA;
		cntComplete[1] = nAAB;		
		cntComplete[2] = nABA;		
		cntComplete[3] = nBAA;
		cntComplete[4] = nABC;
		*/
		if (cntGappy[0]>0)
			pGappy[0] = pComplete[0] + pComplete[3];
		else
			pGappy[0] = 0.0;		
		if (cntGappy[1]>0)
			pGappy[1] = pComplete[1] + pComplete[2] + pComplete[4];	
		else
			pGappy[1] = 0.0;
		if (cntGappy[2]>0)
			pGappy[2] = pComplete[0] + pComplete[2];
		else
			pGappy[2] = 0.0;
		if (cntGappy[3]>0)
			pGappy[3] = pComplete[1] + pComplete[3] + pComplete[4];	
		else
			pGappy[3] = 0.0;
		if (cntGappy[4]>0)
			pGappy[4] = pComplete[0] + pComplete[1];
		else
			pGappy[4] = 0.0;
		if (cntGappy[5]>0)
			pGappy[5] = pComplete[2] + pComplete[3] + pComplete[4];	
		
		else
			pGappy[5] = 0.0;
		
		sum = 0.0;
		for (i=0;i<pGappy.length;i++) {
			sum += pGappy[i];
		}		
		if (sum > myFunc.EPSILON) {
			for (i=0;i<pGappy.length;i++) {
				pGappy[i] /= sum;
			}
		}

		
		
		
		sum = 0.0;
		for (i=0;i<cntGappy.length;i++) {
			if (pGappy[i]<myFunc.EPSILON)
				sum += 0.0;
			else
				sum += cntGappy[i] * Math.log(pGappy[i]);
		}
		for (i=0;i<cntComplete.length;i++) {
			if (pComplete[i]<myFunc.EPSILON)
				sum += 0.0;
			else
				sum += cntComplete[i] * Math.log(pComplete[i]);
		}
		ret[1] = sum;
		
		
		
	}
	
	
	
	
	
	public void LRTCompositeSubEM(double[] pGappyEM, double[] pCompleteEM, double[] pGappy, 
			double[] pComplete, int[] cntGappy, int[] cntComplete) {
		
		/*
		cntGappy[0] = nXAA;
		cntGappy[1] = nXAB;
		cntGappy[2] = nAXA;
		cntGappy[3] = nAXB;
		cntGappy[4] = nAAX;
		cntGappy[5] = nABX;
		
		cntComplete[0] = nAAA;
		cntComplete[1] = nAAB;		
		cntComplete[2] = nABA;		
		cntComplete[3] = nBAA;
		cntComplete[4] = nABC;
		*/
		
		int i, total, total2;
		int nXYY, nYXY, nYYX, nYYY;
		double[] pCompleteEMtmp = new double[pCompleteEM.length];
		
		total=total2 = 0;
		nYYY = 0;
		for (i=0;i<cntGappy.length;i++) {
			total += cntGappy[i];
		}
		for (i=0;i<cntComplete.length;i++) {
			total += cntComplete[i];
			nYYY += cntComplete[i];
			pCompleteEM[i] = pCompleteEMtmp[i] = pComplete[i];
			
		}
		
		nXYY = cntGappy[0] + cntGappy[1];
		nYXY = cntGappy[2] + cntGappy[3];
		nYYX = cntGappy[4] + cntGappy[5];
		
		int nXAA = cntGappy[0];
		int nXAB = cntGappy[1];
		int nAXA = cntGappy[2];
		int nAXB = cntGappy[3];
		int nAAX = cntGappy[4];
		int nABX = cntGappy[5];
		
		
		double diff = 1.0;
		
		do {
			
			for (i=0;i<pCompleteEM.length;i++) {
				pCompleteEMtmp[i] = pCompleteEM[i];
			}
			
			/*
			cntGappy[0] = nXAA;
			cntGappy[1] = nXAB;
			cntGappy[2] = nAXA;
			cntGappy[3] = nAXB;
			cntGappy[4] = nAAX;
			cntGappy[5] = nABX;
			
			cntComplete[0] = nAAA;
			cntComplete[1] = nAAB;		
			cntComplete[2] = nABA;		
			cntComplete[3] = nBAA;
			cntComplete[4] = nABC;
			*/
			
			//pAAA
			pCompleteEM[0] = 0.0;
			if (nAAX != 0 && (pCompleteEMtmp[0] + pCompleteEMtmp[1]) > myFunc.EPSILON)
				pCompleteEM[0] += nAAX * pCompleteEMtmp[0]/(pCompleteEMtmp[0] + pCompleteEMtmp[1]);
			if (nAXA != 0 && (pCompleteEMtmp[0] + pCompleteEMtmp[2])  > myFunc.EPSILON)
				pCompleteEM[0] += nAXA * pCompleteEMtmp[0]/(pCompleteEMtmp[0] + pCompleteEMtmp[2]);
			if (nXAA != 0 && (pCompleteEMtmp[0] + pCompleteEMtmp[3]) >  myFunc.EPSILON)
				pCompleteEM[0] += nXAA * pCompleteEMtmp[0]/(pCompleteEMtmp[0] + pCompleteEMtmp[3]);
			pCompleteEM[0] += cntComplete[0];
			pCompleteEM[0] /= 1.0 * total;
			
			/*
			cntGappy[0] = nXAA;
			cntGappy[1] = nXAB;
			cntGappy[2] = nAXA;
			cntGappy[3] = nAXB;
			cntGappy[4] = nAAX;
			cntGappy[5] = nABX;
			
			cntComplete[0] = nAAA;
			cntComplete[1] = nAAB;		
			cntComplete[2] = nABA;		
			cntComplete[3] = nBAA;
			cntComplete[4] = nABC;
			*/
			
			// pAAB
			pCompleteEM[1] = 0.0;
			if (nAAX != 0 && (pCompleteEMtmp[0] + pCompleteEMtmp[1]) >  myFunc.EPSILON)
				pCompleteEM[1] += nAAX * pCompleteEMtmp[1]/(pCompleteEMtmp[0] + pCompleteEMtmp[1]);
			if (nAXB > 0 && (pCompleteEMtmp[1] + pCompleteEMtmp[3] +  pCompleteEMtmp[4]) >  myFunc.EPSILON)
				pCompleteEM[1] += nAXB * pCompleteEMtmp[1]/(pCompleteEMtmp[1] + pCompleteEMtmp[3] +  pCompleteEMtmp[4]);	
			if (nXAB > 0 && (pCompleteEMtmp[1] + pCompleteEMtmp[2] +  pCompleteEMtmp[4]) >  myFunc.EPSILON)
				pCompleteEM[1] += nXAB * pCompleteEMtmp[1]/(pCompleteEMtmp[1] + pCompleteEMtmp[2] +  pCompleteEMtmp[4]);
			pCompleteEM[1] += cntComplete[1];
			pCompleteEM[1] /= 1.0 * total;
			
			
			/*
			cntGappy[0] = nXAA;
			cntGappy[1] = nXAB;
			cntGappy[2] = nAXA;
			cntGappy[3] = nAXB;
			cntGappy[4] = nAAX;
			cntGappy[5] = nABX;
			
			cntComplete[0] = nAAA;
			cntComplete[1] = nAAB;		
			cntComplete[2] = nABA;		
			cntComplete[3] = nBAA;
			cntComplete[4] = nABC;
			*/
			//pABA
			pCompleteEM[2] = 0.0;
			if (nABX>0 && (pCompleteEMtmp[2] + pCompleteEMtmp[3] +  pCompleteEMtmp[4]) >  myFunc.EPSILON)
				pCompleteEM[2] += nABX *  pCompleteEMtmp[2]/(pCompleteEMtmp[2] + pCompleteEMtmp[3] +  pCompleteEMtmp[4]);
			if (nAXA>0 && (pCompleteEMtmp[0] + pCompleteEMtmp[2]) >  myFunc.EPSILON)
				pCompleteEM[2] += nAXA * pCompleteEMtmp[2]/(pCompleteEMtmp[0] + pCompleteEMtmp[2]);	
			if (nXAB>0 && (pCompleteEMtmp[1] + pCompleteEMtmp[2] +  pCompleteEMtmp[4]) >  myFunc.EPSILON)
				pCompleteEM[2] += nXAB * pCompleteEMtmp[2]/(pCompleteEMtmp[1] + pCompleteEMtmp[2] +  pCompleteEMtmp[4]);
			pCompleteEM[2] += cntComplete[2];
			pCompleteEM[2] /= 1.0 * total;
			
			/*
			cntGappy[0] = nXAA;
			cntGappy[1] = nXAB;
			cntGappy[2] = nAXA;
			cntGappy[3] = nAXB;
			cntGappy[4] = nAAX;
			cntGappy[5] = nABX;
			
			cntComplete[0] = nAAA;
			cntComplete[1] = nAAB;		
			cntComplete[2] = nABA;		
			cntComplete[3] = nBAA;
			cntComplete[4] = nABC;
			*/
			//pABB
			pCompleteEM[3] = 0.0;
			if (nABX>0 && (pCompleteEMtmp[2] + pCompleteEMtmp[3] +  pCompleteEMtmp[4]) >  myFunc.EPSILON)
				pCompleteEM[3] += nABX *  pCompleteEMtmp[3]/(pCompleteEMtmp[2] + pCompleteEMtmp[3] +  pCompleteEMtmp[4]);
			if (nAXB>0 && (pCompleteEMtmp[1] + pCompleteEMtmp[3] +  pCompleteEMtmp[4]) >  myFunc.EPSILON)
				pCompleteEM[3] += nAXB * pCompleteEMtmp[3]/(pCompleteEMtmp[1] + pCompleteEMtmp[3] +  pCompleteEMtmp[4]);
			if (nXAA>0 && (pCompleteEMtmp[0] + pCompleteEMtmp[3]) >  myFunc.EPSILON)
				pCompleteEM[3] += nXAA * pCompleteEMtmp[3]/(pCompleteEMtmp[0] + pCompleteEMtmp[3]);
			pCompleteEM[3] += cntComplete[3];
			pCompleteEM[3] /= 1.0 * total;
			
			//pABC
			pCompleteEM[4] = 1.0 - (pCompleteEM[0]+pCompleteEM[1]+pCompleteEM[2]+pCompleteEM[3]);
			
			diff = 0.0;
			for (i=0;i<pCompleteEM.length;i++) 
				diff += Math.abs(pCompleteEM[i] - pCompleteEMtmp[i]);
			
			//myFunc.print(String.format("\ndiff=%f", diff));
			
		} while (diff > 1.0e-5);
		
		
		/*
		cntGappy[0] = nXAA;
		cntGappy[1] = nXAB;
		cntGappy[2] = nAXA;
		cntGappy[3] = nAXB;
		cntGappy[4] = nAAX;
		cntGappy[5] = nABX;
		
		cntComplete[0] = nAAA;
		cntComplete[1] = nAAB;		
		cntComplete[2] = nABA;		
		cntComplete[3] = nBAA;
		cntComplete[4] = nABC;
		*/
		
		pGappyEM[0] = pCompleteEM[0] + pCompleteEM[3];
		pGappyEM[1] = pCompleteEM[1] + pCompleteEM[2] + pCompleteEM[4];	
		pGappyEM[2] = pCompleteEM[0] + pCompleteEM[2];
		pGappyEM[3] = pCompleteEM[1] + pCompleteEM[3] + pCompleteEM[4];	
		pGappyEM[4] = pCompleteEM[0] + pCompleteEM[1];
		pGappyEM[5] = pCompleteEM[2] + pCompleteEM[3] + pCompleteEM[4];	
		
		/*
		double sum = 0.0;
		for (i=0;i<pGappyEM.length;i++) {
			sum += pGappyEM[i];
		}		
		for (i=0;i<pGappyEM.length;i++) {
			pGappyEM[i] /= sum;
		}
		*/

		
		
		myFunc.print(String.format("\npComplete[] : "));
		for (i=0;i<pComplete.length;i++) {
			myFunc.print(String.format("%f  ", pComplete[i]));
		}
		
		myFunc.print(String.format("\npCompleteEM[] : "));
		for (i=0;i<pCompleteEM.length;i++) {
			myFunc.print(String.format("%f  ", pCompleteEM[i]));
		}
	
		myFunc.print(String.format("\npGappy[] : "));
		for (i=0;i<pGappyEM.length;i++) {
			myFunc.print(String.format("%f  ", pGappy[i]));
		}
		
		myFunc.print(String.format("\npGappyEM[] : "));
		for (i=0;i<pGappyEM.length;i++) {
			myFunc.print(String.format("%f  ", pGappyEM[i]));
		}
		
		myFunc.print(String.format("\ncntGappy[] : "));
		for (i=0;i<cntGappy.length;i++) {
			myFunc.print(String.format("%d  ", cntGappy[i]));
		}
		
		myFunc.print(String.format("\ncntComplete[] : "));
		for (i=0;i<cntComplete.length;i++) {
			myFunc.print(String.format("%d  ", cntComplete[i]));
		}
		
		/*		
		System.exit(0);
		*/
		
		
	}
	
	public void BuildNJTree() {
		

		if (OPT.subsModel == ModelType.JC) {
			//this.calcPairDist();
			this.calcPairDist2();
		}
		else if (OPT.subsModel == ModelType.TN93 || OPT.subsModel == ModelType.GTR ) {
			//this.calcPairDistTN93();
			//this.calcPairDistTN93Gamma(0.26);
			this.calcPairDistTN93Gamma(1.0);
			//this.calcPairMLDist();  // use much time...
		}
		else { // amino acid model
			//this.calcPairMLDist();
			calcPairDist2();
		}

		
		String topo;
		topo = myFunc.BuildNJTree(this.pairDist, this.taxaNameList);
		
		this.oriTopo = topo;
		//System.out.print("\n" + topo + "\n");
		
		this.buildTree(oriTopo);
		
	}

	
	public void calcPairMLDist() {

		
	}
	

	public double calcPairMLDistSub(int id1, int id2) {
		
		return 0.0;
	}
	

	public void recalCentroids() {
		int i, j, k, cnt;
		for (i=0;i<numCluster;i++) {
			for (k=0;k<centroidVec[i].length;k++) {
				centroidVec[i][k] = 0.0;
			}
			cnt = 0;
			for (j=0;j<alphabetData2Double.length;j++) {
				if (clusterMember[j] == i) {
					cnt++;
					for (k=0;k<centroidVec[i].length;k++) {
						centroidVec[i][k] += alphabetData2Double[j][k];
					}
				}
			}
			for (k=0;k<centroidVec[0].length;k++) {
				centroidVec[i][k] /= cnt;
			}
		}
	}
	
	
	public void assignClusterNumber() {
		int i,j,k,id;
		double sum, tmp, minS;
		
		// calc dist sqaure
		for (j=0;j<alphabetData2Double.length;j++) {
			for (i=0;i<numCluster;i++) {
				sum = 0.0;
				for (k=0;k<alphabetData2Double[j].length/3;k++) {
					tmp = 0.0;
					tmp += (centroidVec[i][3*k] - alphabetData2Double[j][3*k]) * (centroidVec[i][3*k] - alphabetData2Double[j][3*k]);
					tmp += (centroidVec[i][3*k+1] - alphabetData2Double[j][3*k+1]) * (centroidVec[i][3*k+1] - alphabetData2Double[j][3*k+1]);
					tmp += (centroidVec[i][3*k+2] - alphabetData2Double[j][3*k+2]) * (centroidVec[i][3*k+2] - alphabetData2Double[j][3*k+2]);
					sum += tmp * this.alphabetDataPatternNum[k];
				}
				distCenterTaxa[j][i] = sum;
			}
		}
		
		// assign cluster number
		for (j=0;j<alphabetData2Double.length;j++) {
			id = -1;
			minS = 1.0e100;
			for (i=0;i<numCluster;i++) {
				if (distCenterTaxa[j][i]<minS) {
					id = i;
					minS = distCenterTaxa[j][i];
				}
			}
			clusterMember[j] = id;
		}
		
	}
	
	
	public void convertNuc2Double(double[] v, char ch)
	{
		if (ch == 'A') {
			v[0] = Math.sqrt(2.0)/4;
			v[1] = 1.0/2;
			v[2] = 0.0;
		}
		else if (ch == 'G') {
			v[0] = Math.sqrt(2.0)/4;
			v[1] = -1.0/2;
			v[2] = 0.0;
		}
		else if (ch == 'T') {
			v[0] = -Math.sqrt(2.0)/4;
			v[1] = 0.0;
			v[2] = 1.0/2;
		}	
		else if (ch == 'C') {
			v[0] = -Math.sqrt(2.0)/4;
			v[1] = 0.0;
			v[2] = -1.0/2;
		}	
		else if (ch == '-') {
			v[0] = 0.0;
			v[1] = 0.0;
			v[2] = 0.0;
		}	
		else if (ch == '?') {
			v[0] = 0.0;
			v[1] = 0.0;
			v[2] = 0.0;
		}	
		else {
			System.err.print(String.format("\r\nNot implemented yet in convertNuc2Double()"));
			System.exit(0);
		}
	}
	
	public void clusterVecSub(int[] idx) {
		int i,j,k,id;
		boolean debug;
		debug = false;
		
		for (i=0;i<numCluster;i++) {
			id = idx[i];
			if (debug)
				myFunc.print(String.format("\r\nid=%d",id));			
			for (j=0;j<alphabetData2Double[0].length;j++) {
				centroidVec[i][j] = alphabetData2Double[id][j];
			}
		}
		

		
		double[][] centroidVecTmp = new double[numCluster][alphabetData2Double[0].length];
		double sum, diffsq, tmp;
		int R = 0;;
		do {
			for (i=0;i<numCluster;i++) {
				for (j=0;j<alphabetData2Double[0].length;j++) {
					centroidVecTmp[i][j] = centroidVec[i][j];
				}
			}
			assignClusterNumber();
			recalCentroids();
			
			sum = 0.0;
			diffsq = 0.0;
			for (i=0;i<numCluster;i++) {
				for (j=0;j<alphabetData2Double[0].length/3;j++) {
					tmp = 0.0;
					tmp += (centroidVecTmp[i][3*j] - centroidVec[i][3*j]) * (centroidVecTmp[i][3*j] - centroidVec[i][3*j]);
					tmp += (centroidVecTmp[i][3*j+1] - centroidVec[i][3*j+1]) * (centroidVecTmp[i][3*j+1] - centroidVec[i][3*j+1]);
					tmp += (centroidVecTmp[i][3*j+2] - centroidVec[i][3*j+2]) * (centroidVecTmp[i][3*j+2] - centroidVec[i][3*j+2]);
					diffsq += tmp * this.alphabetDataPatternNum[j];
				}
			}
			if (debug) {
				myFunc.print(String.format("\r\nR=%d, diffsq=%f",R,diffsq));
				showClusterAssignment();
			}

			sum = 0.0;
			for (j=0;j<alphabetData2Double.length;j++) {
				for (k=0;k<alphabetData2Double[0].length/3;k++) {
					tmp = 0.0;
					tmp += (alphabetData2Double[j][3*k] - centroidVec[clusterMember[j]][3*k]) * (alphabetData2Double[j][3*k] - centroidVec[clusterMember[j]][3*k]);
					tmp += (alphabetData2Double[j][3*k+1] - centroidVec[clusterMember[j]][3*k+1]) * (alphabetData2Double[j][3*k+1] - centroidVec[clusterMember[j]][3*k+1]);
					tmp += (alphabetData2Double[j][3*k+2] - centroidVec[clusterMember[j]][3*k+2]) * (alphabetData2Double[j][3*k+2] - centroidVec[clusterMember[j]][3*k+2]);
					sum += tmp * this.alphabetDataPatternNum[k];
				}
			}
			if (debug)
				myFunc.print(String.format("\r\nsumsq=%f",sum));
			
			KMeanClusterVecSumSq = sum;
			
		} while(diffsq > 0.001);
		
		if (debug)
			showClusterAssignment();

	}
	
	public void clusterVec(int numClust) {
		
		if (OPT.subsModel == ModelType.JC || OPT.subsModel == ModelType.TN93 || OPT.subsModel == ModelType.GTR )
			;
		else {
			System.err.print(String.format("\r\nNot implemented for AA models"));
			System.exit(0);
		}
		
		boolean debug = false;
		boolean debug2 = true;
		
		this.alphabetData2Double = new double[this.alphabetData.length][this.alphabetData[0].length*3];
	
		if (debug)
			myFunc.print(String.format("\r\nPSL=%d",this.alphabetData[0].length));

		
		int i,j,k,id;
		char c;
		double[] ret = new double[3];
		for (i=0;i<alphabetData.length;i++) {
			for (j=0;j<alphabetData[i].length;j++) {
				c = alphabetData[i][j];
				this.convertNuc2Double(ret, c);
				alphabetData2Double[i][j*3] = ret[0];
				alphabetData2Double[i][j*3+1] = ret[1];
				alphabetData2Double[i][j*3+2] = ret[2];
			}
		}
		
		numCluster = numClust;
		this.centroidVec = new double[numCluster][alphabetData2Double[0].length];
		distCenterTaxa = new double[this.taxaNameList.length][numCluster];
		clusterMember = new int[this.taxaNameList.length];
		
		// randomly assign centroids
		
		int[] idx = new int[alphabetData.length];
		int[] idxMin = new int[alphabetData.length];
		double minS = 1.0e100;
		int iter = 10;
		for (i=0;i<iter;i++) {
			myFunc.permute(alphabetData.length, idx);
			clusterVecSub(idx);
			if (KMeanClusterVecSumSq < minS) {
				for (j=0;j<idx.length;j++) {
					idxMin[j] = idx[j];
					minS = KMeanClusterVecSumSq;
				}
			}
			if (debug2) {
				myFunc.print(String.format("\r\ni=%d, KMeanClusterVecSumSq=%f",i,KMeanClusterVecSumSq));

			}
		}
		
		myFunc.print(String.format("\r\nFinal.."));
		clusterVecSub(idxMin);
		myFunc.print(String.format("\r\nKMeanClusterVecSumSq=%f",KMeanClusterVecSumSq));

		
	}
	
	public void clusteringTest2() {
		
		clusterVec(3);
		showClusterAssignment();
		
	}
	
	public void clusteringTest() {
		// centroids are along the branches of phylogeny
		String[] topo;
		topo = new String[4];
		
		//topo[0] = "(((T1:0.8,T2:0.7):0.6,(T3:0.5,T4:0.7):0.8):1.5,((T5:0.4,(T6:0.000001,T6b:0.000001):0.8):0.5,(T7:0.7,T8:0.2):0.4):2.5,((T9:0.1,T10:0.2):0.3,(T11:0.2,((T12:0.000001,T12b:0.000001):0.000001,T12c:0.000001):0.4):0.5):2.0);";
		//topo[0] = "((T1:0.1,T2:0.1):0.1,T3:0.1,T4:0.1);";
		//topo[0] = "((T1:0.1,T2:0.1):0.1,T3:0.2,T4:0.1);";
		
		//topo[0] = "(((T1:0.1,T2:0.1):0.1,(T3:0.1,T4:0.1):0.1):0.1,((T5:0.1,T6:0.1):0.1,(T7:0.1,T8:0.1):0.1):0.1,((T9:0.1,T10:0.1):0.1,(T11:0.1,T12:0.1):0.1):0.1);";

		//topo[0] = "(((T1:0.1,T2:0.15):0.1,(T3:0.2,T4:0.25):0.1):0.5,((T5:0.1,T6:0.15):0.1,(T7:0.2,T8:0.25):0.1):0.5,((T9:0.1,T10:0.15):0.1,(T11:0.2,T12:0.25):0.1):0.5);";
		//topo[0] = "(((T1:0.1,T2:0.15):0.1,(T3:0.2,T4:0.25):0.1):2.0,((T5:0.11,T6:0.151):0.1,(T7:0.21,T8:0.251):0.1):1.5,((T9:0.12,T10:0.152):0.1,(T11:0.22,T12:0.252):0.1):2.0);";
		//topo[0] = "((((T1:0.1,T2:0.15):0.1,(T3:0.2,T4:0.25):0.1):0.1,((T1b:0.1,T2b:0.15):0.1,(T3b:0.2,T4b:0.25):0.1):0.1):0.5,((T5:0.1,T6:0.15):0.1,(T7:0.2,T8:0.25):0.1):0.5,((T9:0.1,T10:0.15):0.1,(T11:0.2,T12:0.25):0.1):0.5);";
		//topo[0] = "((((T1:0.1,T2:0.15):0.1,(T3:0.2,T4:0.25):0.1):0.1,((T1b:0.11,T2b:0.151):0.1,(T3b:0.21,T4b:0.251):0.1):0.1):0.5,((T5:0.12,T6:0.152):0.1,(T7:0.22,T8:0.252):0.1):0.5,((T9:0.13,T10:0.153):0.1,(T11:0.23,T12:0.253):0.1):0.5);";

		topo[0] = "(((T1:0.1,T2:0.2):0.1,(T3:0.3,T4:0.4):0.1):0.1,((T5:0.5,T6:0.6):0.1,(T7:0.7,T8:0.8):0.1):0.1,((T9:0.9,T10:1.0):0.1,(T11:1.1,T12:1.2):0.1):0.1);";

		topo[0] = "(((T1:0.1,T2:0.2):0.1,(T3:0.3,T4:0.4):0.1):5.0,((T5:0.5,T6:0.6):0.1,(T7:0.7,T8:0.8):0.1):5.0,((T9:0.9,T10:1.0):0.1,(T11:1.1,T12:1.2):0.1):5.0);";

		
		//topo[0] = this.oriTopo;
	
		
		
		this.buildTree(topo[0]);
		this.getTree(topo);
		
		myFunc.print(String.format("\r\n##### Note: This clusteringTest() is not perfect. Cluster assignment is performed for multiple taxa."));
		myFunc.print(String.format("\r\n##### Cluster assignment needs to be done one by one. "));
		
		
		myFunc.print(String.format("\r\nPhylogeny: %s",  topo[0]));
		PrintTreeTopo();
		

		int[] taxaOrderDispersion = new int[this.alphabetData.length];
		
		taxaOrderDistanceDispersion(taxaOrderDispersion);
		
		int maxK = 10;
		this.silhouetteCoeff = new double[maxK];
		
		int i;
		for (i=2;i<maxK;i++) {
			if (i==7) 
				System.out.print("");
			myFunc.print(String.format("\r\n\r\n#### i=%d clusters, ", i));
			clusterSubtree(i, taxaOrderDispersion);
			showClusterAssignment();
			calcSilhouetteCoeff(i);
		}
		
		myFunc.printArrayRstyle(silhouetteCoeff, "silhouetteCoeff");

		
		
	}
	
	public void calcSilhouetteCoeff(int id) {
		int i, j;
		double a, b, s, sumS, c;
		sumS = 0.0;
		for (i=0;i<this.taxaNameList.length;i++) {
			a = calcSilhouetteCoeffWithinCluster(i);
			b = calcSilhouetteCoeffBetweenCluster(i);
			c = Math.max(a, b);
			if (Math.abs(c)<myFunc.EPSILON)
				s = 0.0; // this does not happen singleton-singleton for b
			else
				s = (b-a)/c;
			sumS += s;
		}
		sumS /= taxaNameList.length;
		silhouetteCoeff[id] = sumS;
	}
	
	public double calcSilhouetteCoeffWithinCluster(int id) {
		int i, cnt;
		double sum;
		sum = 0.0;
		cnt = 0;
		for (i=0;i<taxaNameList.length;i++) {
			if (i != id && clusterMember[i] == clusterMember[id]) {
				sum += patristicDistance[i][id];
				cnt++;
			}
		}
		if (cnt==0)
			sum = 0.0;
		else
			sum /= cnt;
		return sum;
	}
	
	public double calcSilhouetteCoeffBetweenCluster(int id) {
		int i,j, cnt, idx;
		double sum, minS;
		
		double meanD[] = new double[numCluster];
		
		for (i=0;i<this.numCluster;i++) {
			if (i == clusterMember[id]) {
				meanD[i] = 1.0e100; // arbitrarily big number
			}
			else {
				sum = 0.0;
				cnt = 0;
				for (j=0;j<taxaNameList.length;j++) {
					if (clusterMember[j] == i) {
						sum += patristicDistance[j][id];
						cnt++;
					}
				}
				if (cnt > 1) {
					sum /= cnt;
					meanD[i] = sum;
				}
				else {
					//meanD[i] = 0.0;
					
					// do same thing even when cnt == 1
					sum /= cnt;
					meanD[i] = sum;
				}

			}
		}
		
		minS = 1.0e100;
		idx = -1;
		for (i=0;i<this.numCluster;i++) {
			if (meanD[i] < minS) {
				minS = meanD[i];
				idx = i;
			}
		}
		
		return minS;
		
	}
	
	
	public void clusterSubtree(int numClust, int[] idx) {

		int i,j;
		
		numCluster = numClust;
		
		distCenterTaxa = new double[this.taxaNameList.length][numCluster];
		clusterMember = new int[this.taxaNameList.length];
		centerPos = new Node[numCluster];
		centerBrRatio = new double[numCluster];
		
		for (i=0;i<numClust;i++) {
			for (j=0;j<this.brPos.length;j++) {
				if (this.taxaNameList[idx[i]].equals(this.brPos[j].desNd.taxonName)) {
					centerPos[i] = brPos[j];
					centerBrRatio[i] = 0.5; // temporary
				}
			}
		}
		
		//showCentroidsPhylogeny();
		
		calcClusterDistance();
		clusterMemberUpdate();
		
		findCentroids();
		showCentroidsPhylogeny();
		
		
	}
	
	
	public void clusterMemberUpdate() {
		
		int i,j,id;
		double minS;
		boolean debug = false;
		
		for (i=0;i<distCenterTaxa.length;i++) {
			id = -1;
			minS = 1.0e100;
			for (j=0;j<distCenterTaxa[i].length;j++) {
				if (distCenterTaxa[i][j] < minS) {
					id = j;
					minS = distCenterTaxa[i][j];
				}
			}
			// check if clusterMember[i] is singleton
			int ori = clusterMember[i];
			int cnt = 0;
			for (j=0;j<clusterMember.length;j++) {
				if (ori == clusterMember[j])
					cnt++;
			}
			if (cnt>1) 
				this.clusterMember[i] = id;
			else
				; // not change when singleton
		}
		
		
		for (j=0;j<this.taxaNameList.length;j++) {
			id = -1;
			for (i=0;i<this.brPos.length;i++) {				
				if (taxaNameList[j].equals(brPos[i].desNd.taxonName)) {
					brPos[i].desNd.clusterID = clusterMember[j];
					break;
				}
			}
		}
		

		if (debug) {
			// checking
			myFunc.print(String.format("\r\n"));
			for (i=0;i<taxaNameList.length;i++) {
				myFunc.print(String.format("\r\n%s | ", this.taxaNameList[i]));
				for (j=0;j<distCenterTaxa[i].length;j++) {
					myFunc.print(String.format("%f ", distCenterTaxa[i][j]));
				}
				myFunc.print(String.format(" | belongs to %dth cluster",  clusterMember[i]));
			}
			System.out.print("");	
			/// checking
		}

	}

	public void taxaOrderDistanceDispersion(int [] taxaOrderDispersion) {
		
		// this is not fully implemented yet...
		
		int i, j, k;
		double d;
		boolean debug = true;
		
		patristicDistance = new double[taxaNameList.length][taxaNameList.length];
		for (i=0;i<this.taxaNameList.length-1;i++) {
			patristicDistance[i][i] = 0.0;
			for (j=i+1;j<this.taxaNameList.length;j++) {
				patristicDistance[i][j] = patristicDistance[j][i] = calcDist(i, j);
			}
		}
		
		double maxD = -1.0e100;
		int id1, id2, id3, idx;
		id1=id2=id3=-1;
		
		// find most distance pair
		for (i=0;i<this.taxaNameList.length-1;i++) {
			for (j=i+1;j<this.taxaNameList.length;j++) {
				if (patristicDistance[i][j] > maxD) {
					maxD = patristicDistance[i][j];
					id1 = i;
					id2 = j;
				}
			}
		}
		// find third taxon
		maxD = -1.0e100;
		id3 = -1;
		for (k=0;k<taxaNameList.length;k++) {
			if (k!=id1 && k!= id2) {
				d = patristicDistance[id1][k] + patristicDistance[id2][k] + patristicDistance[id1][id2];
				if (maxD < d) {
					maxD = d;
					id3 = k;
				}
			}
		}
		
		taxaOrderDispersion[0] = id1;
		taxaOrderDispersion[1] = id2;
		taxaOrderDispersion[2] = id3;
		idx = 3;
		// find order of dispersed distances
		// this is ad hoc version
		// instead of maximizing total br sums, 
		// maximizing pairwise dist -> select taxon
		
		
		for (k=3;k<taxaOrderDispersion.length;k++) {
			maxD = -1.0e100;
			id3 = -1;			
			double minDsq = 1.0e100; // if brSum is same, choose taxon sum(br^2) is minimum
			for (i=0;i<taxaNameList.length;i++) {
				boolean alreadyChosen = false;
				for (j=0;j<idx;j++) {
					if (taxaOrderDispersion[j] == i) {
						alreadyChosen = true;
						break;
					}
				}
				if (!alreadyChosen) {
					double ret[] = new double[2];
					taxaOrderDispersion[idx] = i;
					calcFarDist(ret, taxaOrderDispersion, idx+1);
					if (maxD < ret[0]) {
					//if (maxD < ret[0]-myFunc.EPSILON) { (bad! for checking equality)
						maxD = ret[0];
						minDsq = ret[1];
						id3 = i;
					}
					else if (Math.abs(maxD - ret[0]) <= myFunc.EPSILON) {
					//else if (maxD < ret[0] +  myFunc.EPSILON) { (bad! for checking equality)
						if (minDsq > ret[1]) {
							maxD = ret[0];
							minDsq = ret[1];
							id3 = i;
						}
						else;
					}
					else ;
				}
			}
			taxaOrderDispersion[k] = id3;
			idx++;
			if (taxaNameList[id3].equals("T8"))
				System.out.print("");
			myFunc.print(String.format("\r\n## %s added", this.taxaNameList[id3]));
		}
		
		if (debug) {
			//myFunc.printArrayRstyle(taxaOrderDispersion, "taxaOrderDispersion");
			myFunc.print(String.format("\r\ntaxaOrderDispersion"));
			for (i=0;i<taxaOrderDispersion.length;i++) {
				myFunc.print(String.format("\r\ni=%d, %s",i,taxaNameList[taxaOrderDispersion[i]]));
			}
			//System.exit(0);
		}
		
	}

	public void calcFarDist(double[] ret, int[] taxaOrderDispersion, int size) {
		String[] topo;
		topo = new String[4];
		this.getTree(topo);
		String oriPhylogeny = topo[0];
		//myFunc.print(String.format("\r\nPhylogeny: %s",  topo[0]));
		
		Node pNode;
		pNode = findNode(this.taxaNameList[taxaOrderDispersion[0]]);
		this.startNode = pNode.desNd;
		
		int i,j;
		
		for (i=0;i<this.taxaNameList.length;i++) {
			boolean selected = false;
			for (j=0;j<size;j++) {
				if (taxaNameList[i].equals(taxaNameList[taxaOrderDispersion[j]])) {
					selected = true;
					break;
				}
			}
			if (!selected) {
				pNode = findNode(taxaNameList[i]);
				if (pNode.desNd.isoNd.desNd.isoNd != null) {
					pNode = pNode.desNd.isoNd.desNd;
					this.deleteBr(pNode, true);
				}
				else { // neighbor is terminal
					pNode = pNode.desNd.isoNd.isoNd.desNd;
					this.exchangeLeftRight(pNode);
					this.deleteBr(pNode, true);
				}
			}
		}
		
		this.getBrTotalSum(ret);
		
		boolean debug = false;
		if (debug) {
			this.getTree(topo);
			myFunc.print(String.format("\r\ntrying %s", taxaNameList[taxaOrderDispersion[size-1]]));
			myFunc.print(String.format("\r\nphylogeny: %s", topo[0]));
			myFunc.print(String.format("\r\nbr sum is %f",  ret[0]));
			myFunc.print(String.format("\r\nbr sumsq is %f",  ret[1]));
			myFunc.print(String.format("\r\n")); //###########################"));
		}

		this.buildTree(oriPhylogeny);
	}
	
	public void calcClusterDistance() {
		int i, j, id, id2;
		double d; 
		Node pNode;
		
		boolean debug = false;
		
		for (i=0;i<numCluster;i++) {

			d = centerPos[i].branchLength;
			pNode = generateDoubleBr(String.format("Cluster%d", i));
			insertBr(centerPos[i], pNode, false);	
			//pNode is connected to B taxa
			//pNode.desNd.isoNd is connected to A taxa
			//pNode.branchLength is rb
			//pNode.desNd.isoNd.branchLength is (1-r)b
			
			pNode.branchLength = pNode.desNd.branchLength = d * centerBrRatio[i];
			pNode.desNd.isoNd.branchLength = pNode.desNd.isoNd.desNd.branchLength = d * (1.0-centerBrRatio[i]);
			
			calcDistCenterToTerm(pNode.desNd, 0.0, i);
			calcDistCenterToTerm(pNode.desNd.isoNd, 0.0, i);

			pNode = this.deleteBr(pNode, false);
			centerPos[i].branchLength = centerPos[i].desNd.branchLength = d;

		}
		
		if (debug) {
			/// checking
			/*
			myFunc.print(String.format("\r\n"));
			for (j=0;j<distCenterTaxa.length;j++) {
				for (i=0;i<numCluster;i++) {
					myFunc.print(String.format("\r\nd(%dth Taxon, %dth Center) = %f", j,i,distCenterTaxa[j][i]));
				}
			}
			System.out.print("");
			*/
			
			myFunc.print(String.format("\r\n"));
			for (i=0;i<taxaNameList.length;i++) {
				myFunc.print(String.format("\r\n%s | ", this.taxaNameList[i]));
				for (j=0;j<distCenterTaxa[i].length;j++) {
					myFunc.print(String.format("%f ", distCenterTaxa[i][j]));
				}
			}
			
			/// checking
		}
	}
	
	public double calcDist(int id1, int id2) {
		Node pNode;
		pNode = this.startNode;
		double d = 0.0;
		do {
			d += calcDist(pNode, id1, id2);
			pNode = pNode.isoNd;
		} while (pNode != startNode);
		return d;
	}
	
	public double calcDist(Node ptr, int id1, int id2) {
		Node pNode;
		double d = 0.0;
		if (ptr.desNd.isoNd != null) {
			d = 0.0;
			pNode = ptr.desNd.isoNd;
			do {
				d += calcDist(pNode, id1, id2);
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
			if (d > 0.0) {
				return d + ptr.branchLength;
			}
			else
				return 0.0;
		}
		else { // terminal
			if (ptr.desNd.taxonName.equals(this.taxaNameList[id1]))
				return ptr.branchLength;
			else if (ptr.desNd.taxonName.equals(this.taxaNameList[id2]))
				return ptr.branchLength;
			else
				return 0.0;
		}
	
	}
	
	public void calcDistCenterToTerm(Node ptr, double prevBr, int clusterIdx) {
		Node pNode;
		if (ptr.desNd.isoNd != null) {
			pNode = ptr.desNd.isoNd;
			do {
				calcDistCenterToTerm(pNode, prevBr + ptr.branchLength, clusterIdx);
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
		}
		else { // terminal
			int id = -1;
			int i;
			for (i=0;i<this.taxaNameList.length;i++) {
				if (taxaNameList[i].equals(ptr.desNd.taxonName)) {
					id = i;
					break;
				}
			}
			
			//if (clusterIdx == ptr.desNd.clusterID)
				distCenterTaxa[id][clusterIdx] = prevBr + ptr.branchLength;
			//else
				//distCenterTaxa[id][clusterIdx] = -1.0;
		}
	}
	
	public void showClusterAssignment() {
		int i;
		System.out.print("\r\nshowClusterAssignment()");
		for (i=0;i<this.taxaNameList.length;i++) {
			myFunc.print(String.format("\r\n%dth %s belongs to %dth cluster", i, this.taxaNameList[i], this.clusterMember[i]));
		}
		
	}
	
	public void showCentroidsPhylogeny() {
		int i;
		Node pNode;
		double d, r;
		
		for (i=0;i<this.numCluster;i++) {
			d = centerPos[i].branchLength;		
			pNode = generateDoubleBr(String.format("centroid%d", i));
			insertBr(centerPos[i], pNode, true);
			r = centerBrRatio[i];
			pNode.branchLength = pNode.desNd.branchLength = (1.0-r)*d;
			pNode.desNd.isoNd.branchLength = pNode.desNd.isoNd.desNd.branchLength = r*d;
			pNode.desNd.isoNd.isoNd.branchLength = pNode.desNd.isoNd.isoNd.desNd.branchLength = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
			
		}
		
		String[] topo;
		topo = new String[4];
		this.getTree(topo);
		myFunc.print(String.format("\r\nPhylogeny with centroids: %s",  topo[0]));
		
		
		showCentroidsPhylogenySub();
		
		/// remove
		for (i=0;i<this.numCluster;i++) {
			d = centerPos[i].branchLength + centerPos[i].isoNd.isoNd.branchLength;		
			pNode = centerPos[i].isoNd.isoNd.desNd;
			
			pNode = this.deleteBr(pNode, true);
			centerPos[i].branchLength = centerPos[i].desNd.branchLength = d;
		
		}
		
	}
	
	public void showCentroidsPhylogenySub() {
		
		String[] topo;
		topo = new String[4];
		getTree(topo);
		
		String fileName = new String();
		fileName = String.format("%s_cluster%d_tree.txt", oriSeqFile, numCluster);
		int i;	
		
		try {
		
			FileWriter fout = new FileWriter(fileName);
		
			fout.write(String.format("\r\n\r\n##################Phylogeny + cluster info "));
			
			fout.write(String.format("\r\n# if (!requireNamespace(\"BiocManager\", quietly = TRUE)) "));
			fout.write(String.format("\r\n# 		install.packages(\"BiocManager\")"));	
			fout.write(String.format("\r\n# BiocManager::install(\"ggtree\")"));
			fout.write(String.format("\r\n#library(ggtree)"));			
			fout.write(String.format("\r\n#library(treeio)"));	
			fout.write(String.format("\r\n#library(tidyverse)"));	
			fout.write(String.format("\r\ntree <- read.tree(text = \"%s\")",topo[0]));			
			fout.write(String.format("\r\np <- ggtree(tree)"));	
	
			fout.write(String.format("\r\ndd <- data.frame(taxa  = c("));	
			for (i=0;i<this.taxaNameList.length;i++) 
				fout.write(String.format("\"%s\",",taxaNameList[i]));	
			for (i=0;i<this.numCluster-1;i++)
				fout.write(String.format("\"centroid%d\",",i));	
			fout.write(String.format("\"centroid%d\")",i));
			
			fout.write(String.format(", cluster = c("));	
			for (i=0;i<this.taxaNameList.length;i++) 
				fout.write(String.format("\"cluster%d\",",this.clusterMember[i]));	
			for (i=0;i<this.numCluster-1;i++)
				fout.write(String.format("\"cluster%d\",",i));	
			fout.write(String.format("\"cluster%d\"))",i));		
			
			fout.write(String.format("\r\nrow.names(dd) <- NULL"));	
			fout.write(String.format("\r\n#print(dd)"));	
			fout.write(String.format("\r\np2 <- p %%<+%% dd + geom_tiplab(size=5, color=\"purple\") + geom_tippoint(size=5,aes(color=cluster))"));	
			fout.write(String.format("\r\np2+theme(legend.position=\"right\")"));	
			
		
			fout.write(String.format("\r\n#################\r\n"));
			
			fout.close();
		
		}
		catch (IOException e) {
			myFunc.print(String.format("\n%s error", fileName));
		}
	
		
	}
	
	
	public void findCentroids() {
		
		boolean debug, debug2;
		debug = false;
		debug2 = true;
		
		if (debug)
			myFunc.print(String.format("\r\n\r\nStarting findCentroids()..."));
		
		double scoreOld, scoreNew;
		int i, j, id;
		Node pNode;
		double[] ret; // ret[0]: optimal ratio r//; ret[1]: sum of sq; 
		ret = new double[2];
		
		int[] centPosIdx;
		double[] centBrRatio;
		centPosIdx = new int[numCluster];
		centBrRatio = new double[numCluster];
		
		double[][] localSaveScore = new double[numCluster][brPos.length];
		double[][] localBrRatio = new double[numCluster][brPos.length];
		double[][] localSaveScoreOld = new double[numCluster][brPos.length];
		double[][] localBrRatioOld = new double[numCluster][brPos.length];	
		
		double KMeanClusterSubtreeSumSqOld;
		int R = 0;
		

		KMeanClusterSubtreeSumSqOld = KMeanClusterSubtreeSumSq = 0.0;
		
		do {

			KMeanClusterSubtreeSumSqOld = KMeanClusterSubtreeSumSq;
	
			if (debug2) {
				if (R==1)
					System.out.print("");
				myFunc.print(String.format("\r\nR=%d",R));
			}

			
			for (i=0;i<this.numCluster;i++) {
				if (i==1)
					System.out.print("");
				for (j=0;j<this.brPos.length;j++) {
					pNode = this.brPos[j];
					getOptRatio(ret, pNode, i);
					localSaveScore[i][j] = ret[1];
					localBrRatio[i][j] = ret[0];
				}
				double minS = 1.0e10;
				id = -1;
				for (j=0;j<localSaveScore[0].length;j++) {
					if (localSaveScore[i][j] < minS) {
						minS = localSaveScore[i][j];
						id = j;
					}
				}
				centerPos[i] = brPos[id];
				centerBrRatio[i] = localBrRatio[i][id];		
				
				if (debug) {
					myFunc.print(String.format("\r\n%dth cluster, OptimalPos=brPos[%d], s=%f, r=%f", i, id, localSaveScore[i][id], centerBrRatio[i]));
				}
			}

			if (debug) {
					//checking			
				myFunc.print(String.format("\r\n"));			
				for (i=0;i<this.numCluster;i++) {
					for (j=0;j<localSaveScore[i].length;j++) {
						myFunc.print(String.format("\r\nlocalSaveScore[%d][%d]=%f | localBrRatio[%d][%d]=%f", i,j, localSaveScore[i][j], i,j,localBrRatio[i][j]));
					}
				}
			}			
			
			calcClusterDistance();
			clusterMemberUpdate();
			
			//showCentroidsPhylogeny();
			
			KMeanClusterSubtreeSumSq = 0.0;

			for (j=0;j<localSaveScore[0].length;j++) {
				for (i=0;i<this.numCluster;i++) {
					if (clusterMember[i] == i) {
						KMeanClusterSubtreeSumSq += localSaveScore[i][j];
					}
				}
			}			
			
			System.out.print("");
			R++;
			if (debug2) {
				myFunc.print(String.format("\r\nKMeanClusterSubtreeSumSq=%f",KMeanClusterSubtreeSumSq));					
			}

		}while(Math.abs(KMeanClusterSubtreeSumSqOld - KMeanClusterSubtreeSumSq) > 1.0e-5 && R < 20);
		
		if (debug) {
			//checking
			myFunc.print(String.format("\r\n"));
			for (j=0;j<numCluster;j++) {
				id = -1;
				for (i=0;i<brPos.length;i++) {
					if (brPos[i] == centerPos[j]) {
						id = i;
					}
				}
				myFunc.print(String.format("\r\n%dth cluster, OptimalPos=brPos[%d], s=%f, r=%f", j, id, localSaveScore[j][id], localBrRatio[j][id]));
			}
		}

		
		
		//// insert br
		
		
		
	}
	
	
	public void getOptRatio(double[] ret, Node ptr, int clusterIdx) {
		//ptr.desNd is connected to B taxa
		//ptr is connected to A taxa
		//ptr.branchLength is b; rb + (1-r)b
		int i,j;
		double[] localRet;
		localRet = new double[2];
		
		double r, sum, sum2, d;
		Node pNode;
		
		d = ptr.branchLength;		
		pNode = generateDoubleBr(String.format("Cluster%d", clusterIdx));
		insertBr(ptr, pNode, false);	
		//pNode is connected to B taxa
		//pNode.desNd.isoNd is connected to A taxa
		//pNode.branchLength is (1-r)*b
		//pNode.desNd.isoNd.branchLength is r*b
		
		// first set 0.0
		pNode.branchLength = pNode.desNd.branchLength = 0.0;
		pNode.desNd.isoNd.branchLength = pNode.desNd.isoNd.desNd.branchLength = 0.0;	
		
		sum = sum2 = 0.0;
		getBrSum(localRet, pNode.desNd, clusterIdx);
		sum += localRet[0];
		sum2 += localRet[1];
		double Bcnt = sum;
		double Bsum = sum2; 
		
		sum = sum2 = 0.0;
		getBrSum(localRet, pNode.desNd.isoNd, clusterIdx);
		sum += localRet[0];
		sum2 += localRet[1];
		double Acnt = sum;
		double Asum = sum2; 
		
		double verySmallRatio = 0.0; //0.00001;
		
		if (Acnt + Bcnt < myFunc.EPSILON) {
			// if denomenator is zero
			r = verySmallRatio;
		}
		else {
			r = (d * Bcnt - Asum + Bsum)/((Acnt+Bcnt)*d);
		}
		


		if (r<0.0)
			r = verySmallRatio;
		else if (r>1.0)
			r = 1.0 - verySmallRatio;
		else
			; // do nothing
		
		ret[0] = r;
		
		/// update distances using new r (start)	
		pNode.branchLength = pNode.desNd.branchLength = (1.0-r)*d;
		pNode.desNd.isoNd.branchLength = pNode.desNd.isoNd.desNd.branchLength = r*d;	
		
		calcDistCenterToTerm(pNode.desNd, 0.0, clusterIdx);
		calcDistCenterToTerm(pNode.desNd.isoNd, 0.0, clusterIdx);
		
		sum = 0.0;
		for (i=0;i<distCenterTaxa.length; i++) {
			if (clusterMember[i] == clusterIdx)
				sum += distCenterTaxa[i][clusterIdx] * distCenterTaxa[i][clusterIdx];
		}
		
		ret[1] = sum;
		
		pNode = this.deleteBr(pNode, false);
		ptr.branchLength = ptr.desNd.branchLength = d;		
	
	}
	
	public void getBrTotalSum(double[] ret) {
		Node pNode;
		pNode = this.startNode;
		double[] localRet = new double[2];
		do {
			getBrTotalSum(ret, pNode);
			//ret[0] += localRet[0];
			//ret[1] += localRet[1];
			pNode = pNode.isoNd;
		} while (pNode != startNode);
		//ret[0] = localRet[0];
		//ret[1] = localRet[1];		
	}
	
	
	public void getBrTotalSum(double[] ret, Node ptr) {
		Node pNode;
		double[] localRet = new double[2];
		if (ptr.desNd.isoNd != null) {
			pNode = ptr.desNd.isoNd;
			do {
				getBrTotalSum(ret, pNode);
				//ret[0] += localRet[0];
				//ret[1] += localRet[1];
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
			ret[0] += ptr.branchLength;
			ret[1] += ptr.branchLength*ptr.branchLength;
		}
		else { // terminal
			ret[0] += ptr.branchLength;
			ret[1] += ptr.branchLength*ptr.branchLength;
		}
	}
	
	public void getBrSum(double[] ret, Node ptr, int clusterIdx) {

		// ret[0]:number of des having clusterID
		// ret[1]:sum of br below des
		
		if (ptr.desNd.isoNd == null) {
			if (ptr.desNd.clusterID == clusterIdx) {
				ret[0] = 1.0;
				ret[1] = ptr.branchLength;
			}
			else {
				ret[0] = 0.0;
				ret[1] = 0.0;
			}
				
		}
		else {
			Node pNode;
			pNode = ptr.desNd.isoNd;
			double sum, sum2;
			sum = sum2 = 0.0;
			double[] localRet;
			localRet = new double[2];
			do {
				getBrSum(localRet, pNode, clusterIdx);
				sum += localRet[0];
				sum2 += localRet[1];
				pNode = pNode.isoNd;
			} while (pNode != ptr.desNd);
			ret[0] = sum;
			ret[1] = sum2 + ptr.branchLength*sum;
		}
		
	}
	
	
	public void insertBr(Node ndA, Node ndB, boolean updateBrPos) {
		// place ndB to the position of ndA
		// then ndA becomes the leftwing of ndB
		
		Node pNode, pNode2;
		
		pNode = ndB.desNd.isoNd; // because leftwing is empty, this is rightwing. 
		pNode2 = ndA.isoNd;
		
		ndB.isoNd = pNode2;
		ndB.isoNd.isoNd.isoNd = ndB;
		
		ndB.desNd.isoNd = ndA;
		ndB.desNd.isoNd.isoNd = pNode;
		ndB.desNd.isoNd.isoNd.isoNd = ndB.desNd;
		
		// exchange brlengths of ndA and ndB
		double d = ndA.branchLength;
		ndA.branchLength = ndA.desNd.branchLength = ndB.branchLength;
		ndA.branchLength = ndA.desNd.branchLength = d;
		
		this.setRecalNeeded(ndB);
		
		if (updateBrPos) {
			brPos = myFunc.addToEnd(brPos, ndB);
			brParam = myFunc.addToEnd(brParam, ndB.branchLength);
			
			brPos = myFunc.addToEnd(brPos, ndB.desNd.isoNd.isoNd);
			brParam = myFunc.addToEnd(brParam, ndB.branchLength);
			
			this.backupBrParam(brParam);
		}
	}
	
	
	public void backupBrParam(double[] tmp) {
		int i;
		for (i=0;i<brParam.length;i++) {
			brParam[i] = brPos[i].branchLength;
			tmp[i] = brParam[i];
		}
	}
	public void recoverBrParam(double[] tmp) {
		int i;
		for (i=0;i<brParam.length;i++) {
			brParam[i] = tmp[i];
			brPos[i].branchLength = brPos[i].desNd.branchLength = tmp[i];
		}
	}
	
	
	public Node deleteBr(Node nd, boolean updateBrPos) {
		// delete nd
		// delete nd.desNd.isoNd.isoNd
		// place leftwing of nd to nd's position
		
		int[] deletedID = new int[1];
		deletedID[0] = -1;

		double d = nd.branchLength;
		
		if (updateBrPos) {
			brPos = myFunc.deleteElement(brPos, nd.desNd.isoNd.isoNd, deletedID);
			brParam = myFunc.deleteElement(brParam, deletedID);	
			
			brPos = myFunc.deleteElement(brPos, nd, deletedID);
			brParam = myFunc.deleteElement(brParam, deletedID);
		}

		
		Node pNode, pNode2;
		pNode = nd.isoNd;
		
		pNode2 = nd.desNd.isoNd;
		
		nd.desNd.isoNd = pNode2.isoNd; // this is temporal
		
		pNode2.isoNd = pNode;
		pNode2.isoNd.isoNd.isoNd = pNode2;
		pNode2.branchLength = pNode2.desNd.branchLength = pNode2.branchLength + d;
		
		return nd;
		
	}
	
	public Node generateDoubleBr(String tname) { // , double d) {
		
		Node pNode;
		pNode = generateNode();
		pNode.desNd = generateNode();
		//pNode.branchLength = pNode.desNd.branchLength = d;
		pNode.desNd.isoBig = pNode.desNd;
		pNode.desNd.desNd = pNode;
		pNode.desNd.taxonName = tname;
		pNode.desNd.isoNd = null;
		
		int patt_size = alphabetDataPatternNum.length;
		pNode.subLikelihood = new double[gammaCateNum*patt_size*stateDim];
		pNode.desNd.subLikelihood = new double[gammaCateNum*patt_size*stateDim];
		
		pNode.isoNd = generateNode();
		//pNode.isoNd.branchLength = pNode.isoNd.desNd.branchLength = d;
		pNode.isoNd.isoNd = pNode; // temporal index
		pNode.isoNd.desNd = generateNode();
		pNode.isoNd.desNd.desNd = pNode.isoNd;
		
		pNode = pNode.isoNd.desNd;
		
		pNode.subLikelihood = new double[gammaCateNum*patt_size*stateDim];
		pNode.desNd.subLikelihood = new double[gammaCateNum*patt_size*stateDim];
		
		return pNode;
	}
	

}
