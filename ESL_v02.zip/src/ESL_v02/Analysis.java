package ESL_v02;

public interface Analysis {

	void preSolution();
	void getSolution();
	void printResult();
	
	void optMultiTree();
	
	void job20200611(); 
	
	void job20200727(); // ml topology estimation
	
	
}
