package ESL_v02;

public class Node {
	Node desNd; //des_ptr;
	Node isoNd;
	Node isoBig;
	
	int totDesTaxaNum;
	int totDesNodeNum; 
	int nodeNum;
	int idxBranchTopo;
	
	
	double bootProb, branchLength;
	
	String taxonName;
	
	double[] subLikelihood; //[rate_cat][patternCnt][dim=4,20,61]
	
	int[] randSequence;
	int[] randGammaCate;

	boolean recalNeeded;
	
	String treeTopo;

	int clusterID;
	
	public Node() {
		isoNd = null;
		desNd = null;
		isoBig = null;
		idxBranchTopo = -1;
		branchLength = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
		bootProb = -1.0; // initial value is negative
		taxonName = "";
		recalNeeded = true;
		clusterID = -1;
		

	}
	
	public Node traverse() {
		Node ret;
		if (this.desNd.isoNd != null) 
			ret = this.desNd.isoNd;
		else {
			ret = this.isoNd;
		}
		return ret;
	}
	
	public String getTreeTopo() {
		if (this.desNd.isoNd == null) {
			this.treeTopo = this.desNd.taxonName;
		}
		else {
			this.desNd.isoNd.getTreeTopo();
			this.desNd.isoNd.isoNd.getTreeTopo();
			String strA, strB;
			strA = desNd.isoNd.treeTopo;
			strB = desNd.isoNd.isoNd.treeTopo;
			
			if (strA.compareTo(strB)<0) 
				treeTopo = "(" + strA + "," + strB + ")";
			else
				treeTopo = "(" + strB + "," + strA + ")";
		}
		return treeTopo;
	}

}
