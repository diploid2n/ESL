package ESL_v02;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

public class DerivativeData {
	
	// U: Igfii
	// V: Igfjj
	// W: tildeIffii
	// X: Iffii
	// Y: Iffjj
	// Z: tildeIffjj
	
	// 
	double[][] oriDerivData;
	boolean[][] gapInfo; // true if gap
	
	// for beta
	/*
	double[] sum_U; //sum_V == sumU;	
	double[] sum_W;	 // sum_Z == sum_W
	double[] sum_X; //sum_Y == sum_X,	
	double[] sum_Wsq;
	double[][] sum_UV;	
	double[][] sum_XYZ, sum_XY; //, sum_XZ; //, sum_YZ;	
	double[][] sum_WXYZ, sum_WXY, sum_WXZ, sum_WYZ, sum_WX, sum_WZ;
	double[][] sum_UXYV, sum_UXY, sum_UXZ, sum_UYZ, sum_UX,sum_UZ;
	double[][] sum_UXV, sum_UYV, sum_XYV, sum_UXYZ;
	*/
	
	/*
	// for rho
	double[][] sum_XsqYsq, sum_XsqY, sum_XYsq;
	double[][] sum_WXYsq, sum_WYsq;
	*/
	
	double[][] trueGappyData;

	double[] rho, beta, rhoStd, betaStd, betaStat, rhoStat, rhoPval, betaPval;
	
	
	//double[][] WBoot, XBoot, UBoot;
	
	double pValueBoot;
	
	
	//double[] A1i, C1i;
	//double[][] A2ij, B1ij, C2ij;
	
	boolean[] valid;
	
	double globalBeta;
	double globalBetaStat;
	double globalBetaDiffForm;
	double globalBetaDiffFormVar;
	
	double betaVarNumerator;  // this variable may not be needed; same as globalBetaDiffFormVar?
	double betaVarDenominator;
	
	double globalBetaVar; // from bootstrap
	double globalBetaStd;
	double globalBetaVarAnalytic;
	double globalBetaStatAnalytic;
	
	double globalRho;
	double rhoVarNumerator;
	double rhoVarDenominator;
	double globalRhoVar;
	double globalRhoStd;
	
	int totalSimulLength;
	int oriGappyLength;
	
	int simulInputCnt;
	
	
	int[] invalidBootstrappedPBeta; // # of invalid pBeta[i] ; out of  [0,2] 
	int[] invalidBootstrappedPRho; // # of invalid pRho[i]; out of  [0,2]
	int invalidBootstrappedGBeta, invalidBootstrappedGRho; 
	int bootIter;
	
	double pBetaMin, pBetaMax, pRhoMin, pRhoMax;
	
	public void setupTrueGappyData(double[][] Deriv,  boolean[] DerivValid) {
		int i,j;
		this.trueGappyData = new double[Deriv.length][Deriv[0].length];
		for (i=0;i<Deriv.length;i++) {
			for (j=0;j<Deriv[i].length;j++) {
				trueGappyData[i][j] = Deriv[i][j];
			}
		}
		valid = new boolean[DerivValid.length];
		for (i=0;i<DerivValid.length;i++) {
			valid[i] = DerivValid[i];
		}
		
		this.oriGappyLength = Deriv[0].length;
		
		
		rho = new double[Deriv.length];
		beta = new double[Deriv.length];
		rhoStd = new double[Deriv.length];
		betaStd = new double[Deriv.length];
		rhoPval = new double[Deriv.length];
		betaPval = new double[Deriv.length];
		betaStat = new double[Deriv.length];
		rhoStat = new double[Deriv.length];
		

		
		valid = new boolean[DerivValid.length];
		for (i=0;i<DerivValid.length;i++) {
			valid[i] = DerivValid[i];
		}

		totalSimulLength = 0;
		
		
		for (i=0;i<Deriv.length;i++) {
			rho[i] = beta[i] = rhoStd[i] = betaStd[i] = rhoPval[i] = betaPval[i] = 0.0;
		}
				
		
		simulInputCnt=0;
		
		
		
		
	}
	
	public void saveGapInfo(char[][] alphabetData) {
		int i,j;
		char c;
		
		this.gapInfo = new boolean[alphabetData.length][alphabetData[0].length];
		
		//m times gap copying
		for (i=0;i<alphabetData.length;i++) {
			for (j=0;j<alphabetData[i].length;j++) {
				c = alphabetData[i][j];
				if ( c== '-' || c== '?' )
					gapInfo[i][j] = true;
				else
					gapInfo[i][j] = false;
			}
		}
	}
	
	public void analyzeDerivMeasure(boolean saveResult, double [] retBeta, double[][] parameterwiseBeta, double[] retRho, double[][] parameterwiseRho,
			boolean[] localValid, double[][] oriDeriv, double[][] fullSimulDeriv, double[][] gappySimulDeriv) {

		//testMediant(localValid,fullSimulDeriv, gappySimulDeriv);
		
		/////////////////////////////////////////////
		this.analyzeDerivMeasure_onlyBetaRho(saveResult,localValid, retBeta, parameterwiseBeta, retRho, parameterwiseRho, oriDeriv, fullSimulDeriv, gappySimulDeriv );
		///////////////////////////////////////////////

		
	}
	
	public void testMediant(boolean[] localValid, double[][] fullSimulDeriv, double[][] gappySimulDeriv) {
		//Olivier's suggestion
		int i,j,k, mulF, L, r;
		double sum;
		
		mulF = 100;
		L = fullSimulDeriv[0].length / mulF;
		
		System.out.print(String.format("\n\n## testing mediant"));
		System.err.print(String.format("\n\n## testing mediant"));
		
		String fileName = new String();
		fileName = "mediant_sp-ESL.txt";
		
		k = 0;
		for (j=0;j<gappySimulDeriv.length;j++ ) {
			if (!localValid[j]) {
				k++;
			}
		}
		
		double indRatio[][] = new double[fullSimulDeriv.length-k][L];
		
		
		
		
		//////
		
		try {
			FileWriter fout = new FileWriter(fileName);
			
			fout.write(String.format("\n\n#For mediant test...\ngappySimulDeriv <- matrix(c("));

			k=0;
			int validID = 0;
			for (j=0;j<gappySimulDeriv.length;j++ ) {
				if (localValid[j]) {
					for (i=0;i<L;i++) {
						sum = 0.0;
						for (r=0;r<mulF;r++) {
							sum += gappySimulDeriv[j][i+r*L];
						}
						if (j==gappySimulDeriv.length-1 && i==L-1) {
							fout.write(String.format("%f)", sum));
							k++;
						}
						else {
							fout.write(String.format("%f,", sum));
							k++;
						}
						if (k%50==0)
							fout.write(String.format("\n"));
						indRatio[validID][i] = sum;
					}
					validID++;
				}
			}	
			fout.write(String.format(",byrow=T, nrow=%d,ncol=%d)\n\n",indRatio.length,L));
			
			//
			fout.write(String.format("\n\n#For mediant test...\nfullSimulDeriv <- matrix(c("));
			validID = 0;
			k=0;
			for (j=0;j<fullSimulDeriv.length;j++ ) {
				if (localValid[j]) {
					for (i=0;i<L;i++) {
						sum = 0.0;
						for (r=0;r<mulF;r++) {
							sum += fullSimulDeriv[j][i+r*L];
						}
						if (j==fullSimulDeriv.length-1 && i==L-1) {
							fout.write(String.format("%f)", sum));
							k++;
						}
						else {
							fout.write(String.format("%f,", sum));
							k++;
						}
						if (k%50==0)
							fout.write(String.format("\n"));
						indRatio[validID][i] /= sum;
					}
					validID++;
				}
			}	
			fout.write(String.format(",byrow=T, nrow=%d,ncol=%d)\n\n",indRatio.length,L));
	
			//
			
			fout.write(String.format("\n\nindRatio <- matrix(c("));
			k=0;
			for (j=0;j<indRatio.length;j++ ) {
				for (i=0;i<L;i++) {
					if (j==indRatio.length-1 && i==L-1) {
						fout.write(String.format("%f)", indRatio[j][i]));
						k++;
					}
					else {
						fout.write(String.format("%f,", indRatio[j][i]));
						k++;
					}
					if (k%50==0)
						fout.write(String.format("\n"));
				}
			}		
			fout.write(String.format(",byrow=T, nrow=%d,ncol=%d)\n\n",indRatio.length,L));		
			

			
			
			fout.close();
			
			
		}
		catch (IOException e) {
			System.out.print(String.format("\n%s error", fileName));
		}
		

		System.exit(0);
		
		
	}
	
	public void analyzeDerivMeasure_onlyBetaRho(boolean saveResult, boolean[] localValid,  double [] retBeta, double[][] parameterwiseBeta, double[] retRho, double[][] parameterwiseRho, double[][] oriDeriv, double[][] fullSimulDeriv, double[][] gappySimulDeriv) {
		int i,n;
		n = fullSimulDeriv.length;
		double tmp1 = 0.0;
		double[] ret = new double[2];
		double a, b;
		
		tmp1 = 0.0;
		for (i=0;i<n;i++) {
			if (localValid[i]) {
				myFunc.calcMeanVar(ret, fullSimulDeriv[i]);
				a = ret[0];
				myFunc.calcMeanVar(ret, oriDeriv[i]);
				b = ret[0];
				tmp1 += a * b;
			}
		}	
		
		double tmp2 = 0.0;
		for (i=0;i<n;i++) {
			if (localValid[i]) {
				myFunc.calcMeanVar(ret, fullSimulDeriv[i]);
				a = ret[0];
				myFunc.calcMeanVar(ret, gappySimulDeriv[i]);
				b = ret[0];
				tmp2 += a * b;
			}
		}
		retBeta[2] = tmp2; //denominator of beta; numerator == retBeta[0]*retBeta[2];
		retBeta[0] = tmp1/tmp2; //beta
		this.globalBeta = retBeta[0];
		this.globalBetaVar = -1.0; // this is temporal
		
		
		//////
		
		tmp1 = 0.0;
		for (i=0;i<n;i++) {
			if (localValid[i]) {
				myFunc.calcMeanVar(ret, fullSimulDeriv[i]);
				a = ret[0];
				myFunc.calcMeanVar(ret, gappySimulDeriv[i]);
				b = ret[0];
				tmp1 += a * b;
			}
		}	
		
		tmp2 = 0.0;
		for (i=0;i<n;i++) {
			if (localValid[i]) {
				myFunc.calcMeanVar(ret, fullSimulDeriv[i]);
				a = ret[0];
				tmp2 += a * a;
			}
		}
		//retRho[0] : rho
		//retRho[1] : variance of rho
		retRho[0] = tmp1/tmp2;
		this.globalRho = retRho[0];
		this.globalRhoVar = -1.0; // this is temporal
		
		
		/////
		
		
		if (saveResult) {
			for (i=0;i<localValid.length;i++) {
				if (localValid[i]) {
					myFunc.calcMeanVar(ret, fullSimulDeriv[i]);
					tmp1 = ret[0];
					myFunc.calcMeanVar(ret, gappySimulDeriv[i]);
					tmp2 = ret[0];
					tmp1 = tmp2/tmp1;
					this.rho[i]  = parameterwiseRho[0][i] = tmp1; 
					
					myFunc.calcMeanVar(ret, gappySimulDeriv[i]);
					tmp1 = ret[0];
					myFunc.calcMeanVar(ret, oriDeriv[i]);
					tmp2 = ret[0];
					tmp1 = tmp2/tmp1;
					this.beta[i] = parameterwiseBeta[0][i] = tmp1; 
				}
			}
		}
		
		//for debugging
		
		/*
		double[] wForGFactor, wForMFactor;
		wForGFactor = new double[n];
		wForMFactor = new double[n];
		
		int invalidCnt = 0;
		for (i=0;i<n;i++) {
			if (valid[i]) {
				myFunc.calcMeanVar(ret, fullSimulDeriv[i]);
				tmp1 = ret[0];
				myFunc.calcMeanVar(ret, gappySimulDeriv[i]);
				tmp2 = ret[0];
				wForMFactor[i] = tmp1*tmp2;
				wForGFactor[i] = tmp1*tmp1;
			}
			else {
				wForMFactor[i] = 0.0;
				wForGFactor[i] = 0.0;
			}
		}
		
		tmp1 = tmp2 = 0.0;
		for (i=0;i<n;i++) {
			if (valid[i]) {
				tmp1 += wForMFactor[i];
				tmp2 += wForGFactor[i];
			}
			else 
				;
		}
		for (i=0;i<n;i++) {
			if (valid[i]) {
				wForMFactor[i] /= tmp1;
				wForGFactor[i] /= tmp2;
			}
			else 
				;
		}
		
		tmp1 = tmp2 = 0.0;
		for (i=0;i<n;i++) {
			if (valid[i]) {
				tmp1 += wForMFactor[i] * beta[i];
				tmp2 += wForGFactor[i] * rho[i];
			}
			else 
				;
		}
		
		System.out.print(String.format("\n\n###############################################"));
		
		System.out.print(String.format("\n\n#### globaBeta (M-Factor) = %f", globalBeta ));
		System.out.print(String.format(  "\n#### globaRho (G-Factor) = %f ", globalRho));

		
		System.out.print(String.format("\n\n#### globaBeta_debugged (M-Factor) = %f", tmp1 ));
		System.out.print(String.format(  "\n#### globaRho_debugged (G-Factor) = %f ", tmp2));

		
		System.out.print(String.format("\n\n###############################################"));
		
		*/

	}
	

	
	public void printGFMFInfo() {
		int i,j;

		/*
		System.out.print(String.format("\ncalcDerivMeasure(), this.betaVarNumerator : %f", this.betaVarNumerator));
		System.out.print(String.format("\ncalcDerivMeasure(), this.betaVarDenominator : %f", this.betaVarDenominator));
		System.out.print(String.format("\ncalcDerivMeasure(), this.rhoVarNumerator : %f", this.rhoVarNumerator));
		System.out.print(String.format("\ncalcDerivMeasure(), this.rhoVarDenominator : %f", this.rhoVarDenominator));
		*/
		
		System.out.print(String.format("\n\n###############################################"));
		System.out.print(String.format("\n###### Parameter-wise M-Factors (beta's) ######\n"));
		myFunc.printArrayRstyle(betaStat, "\r\nParameterwiseBetaTestStat");
		System.out.print(String.format("\n#### Individual beta (M-Factor)"));
		System.out.print(String.format("\n          estimate +- std (# of extreme bootstrapped beta, out of [%f, %f])", this.pBetaMin, this.pBetaMax));
		for (i=0;i<beta.length;i++) {
			if (valid[i])
				System.out.print(String.format("\nbeta[%d] = %f +- %f (%d)", i, beta[i], betaStd[i], this.invalidBootstrappedPBeta[i]));
			else
				System.out.print(String.format("\nbeta[%d] = NA",i));
		}
		System.out.print(String.format("\n\n#### Individual Rho (G-Factor)"));
		System.out.print(String.format("\n         estimate +- std (# of extreme bootstrapped rho, out of [%f, %f])", this.pRhoMin, this.pRhoMax));

		for (i=0;i<rho.length;i++) {
			if (valid[i])
				System.out.print(String.format("\nrho[%d] = %f +- %f (%d)", i, rho[i], rhoStd[i], this.invalidBootstrappedPRho[i]));
			else
				System.out.print(String.format("\nrho[%d] = NA",i));
		}
		
		System.out.print(String.format("\n\n#### globaBeta (M-Factor) = %f +- %f ; (TestStat = %f; pValue from bootstrap = %f) (# of extreme bootstrapped samples = %d, out of %d)", globalBeta, Math.sqrt(globalBetaVar), (globalBeta-1.0)/Math.sqrt(globalBetaVar),this.pValueBoot, this.invalidBootstrappedGBeta, this.bootIter));
		//System.out.print(String.format("\n betaVarNumerator = %f", betaVarNumerator));
		//System.out.print(String.format("\n globalBetaDiffForm = %f", globalBetaDiffForm));
		System.out.print(String.format(  "\n#### globaRho (G-Factor) = %f +- %f ; (# of extreme bootstrapped samples = %d, out of %d)", globalRho, Math.sqrt(globalRhoVar),this.invalidBootstrappedGRho, this.bootIter));
		//System.out.print(String.format("\n #### rho Var = %f", this.rhoVar));
		//System.out.print(String.format("\n #### beta Var = %f\n", this.betaVar));
		
		
		
		//System.out.print(String.format("\n #### MyDerivData information (end) #####\n"));
	}

	

	
	public double vecMedian(double[] A) {
		double[] tmp = new double[A.length];
		int i;
		for (i=0;i<tmp.length;i++) {
			tmp[i] = A[i];
		}
		Arrays.sort(tmp);
		if (tmp.length%2==0) 
			return (tmp[tmp.length/2-1] + tmp[tmp.length/2]);
		else
			return tmp[tmp.length/2];
	}
	

}



