package ESL_v02;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;
import java.util.Random;
import java.util.Arrays;

public class TreeMLAA extends TreeML implements Analysis {

	Vector<Vector<Double>>  AARate;

	


	
	TreeMLAA() {
		nameTag = "";
		multiThrId = 0;
		this.mlFineTuning = true;
	}
	TreeMLAA(String tag) {
		nameTag = tag;
		multiThrId = 0;
		this.mlFineTuning = true;
	}
	TreeMLAA(String tag, int k) {
		nameTag = tag;
		multiThrId = k;
		this.mlFineTuning = true;
	}

	public void job20200611() {
		
	       
		this.version = 20210619;	
		if (this.multiThrId==0)
			System.out.println("Version: ESL_v02_"+this.version);
		
		preSolution();
		getSolution(); 
		//printResult();
		

	}
	
	public void job20200727() {
		
	}

	
	public void replaceGaps20191222() {
	
		//first half is complete
		//second half is half gap for T1, T2, T3, T4
		
		int start = alphabetData[0].length * 6/10;
		int end = alphabetData[0].length;
		
		int i,j;
		
		/*
		for (i=0;i<4;i++) {//T1, T2, T3, T4
			for (j=start;j<end;j++) { 
				this.alphabetData[i][j] = '-';
			}
		}
		*/
		
		for (j=start;j<end;j++) { // T1
			this.alphabetData[0][j] = '-';
		}
		for (j=start;j<end;j++) { // T3
			this.alphabetData[2][j] = '-';
		}
		/*
		for (j=start;j<end;j++) { // T5
			this.alphabetData[4][j] = '-';
		}
		for (j=start;j<end;j++) { // T7
			this.alphabetData[6][j] = '-';
		}
		for (j=start;j<end;j++) { // T9
			this.alphabetData[8][j] = '-';
		}
		*/
	}
	
	
	public void replaceGaps20191123() {
		//String[] gapTaxon = {"T1", "T2", "T3"};
		String[] gapTaxon = {"T1","T2","T3", "T4"};
		
		int i,j,id;
		
		double gap_p = myFunc.propInsertedGap; // proportion of single gap	in data X
		double incorr_p = myFunc.propIncorrectAlign; // proportion of incorrect position of T1 and T2
		
		int start = alphabetData[0].length * 3/4;
		int end;
		for (i=0;i<2;i++) {//T1, T2
			for (j=start;j<alphabetData[i].length;j++) { 
				this.alphabetData[i][j] = '-';
			}
		}
		start = alphabetData[0].length /2;
		end = alphabetData[0].length * 3/4;
		for (i=2;i<4;i++) {//T3, T4
			for (j=start;j<end;j++) { 
				this.alphabetData[i][j] = '-';
			}
		}
		
		start = end;
		end = alphabetData[0].length;
		for (i=7;i<9;i++) {//T8, T9
			for (j=start;j<end;j++) { 
				this.alphabetData[i][j] = '-';
			}
		}
		
		//if (idx==1) {
			

			start = alphabetData[0].length * 3/4;

			end = alphabetData[0].length * 3/4 - (int) (alphabetData[0].length/2 * incorr_p);
			for (i=start;i>end;i--) {
				this.alphabetData[0][i] = this.alphabetData[0][i-1];
				this.alphabetData[1][i] = this.alphabetData[1][i-1];
			}
			this.alphabetData[0][i] = '-';
			this.alphabetData[1][i] = '-';
		//}


		start = 0;
		end = (int) (alphabetData[0].length/2 * gap_p);
		
		for (i=0;i<end;i++) {
			this.alphabetData[4+i%5][i] = '-';
		}
		

	}
	
	
	public void replaceGaps() {
		String[] gapTaxon = {"Taxon1", "Taxon3"};
		
		int i,j,id;
		for (i=0;i<gapTaxon.length;i++) {
			id=-1;
			for (j=0;j<taxaNameList.length;j++) {
				if (taxaNameList[j].equals(gapTaxon[i])) {
					id = j;
					break;
				}
			}
			if (id==-1) {
				System.err.print("Something wrong...in replaceGaps()");
				System.exit(0);
			}
			for (j=alphabetData[id].length/2;j<alphabetData[id].length;j++) {
				this.alphabetData[id][j] = '-';
			}
		}
	}
	

	public void replaceGaps(int taxID) {
		String[] gapTaxon = {"Taxon1", "Taxon3"};
		
		int j,id;
			id=-1;
		for (j=0;j<taxaNameList.length;j++) {
			if (taxaNameList[j].equals(gapTaxon[taxID])) {
				id = j;
				break;
			}
		}
		if (id==-1) {
			System.err.print("Something wrong...in replaceGaps(..)");			
			System.exit(0);
		}
		for (j=alphabetData[id].length/2;j<alphabetData[id].length;j++) {
			this.alphabetData[id][j] = '-';
		}
	}
	

	public void simulation20200125(double [] rho, double [] beta) {
		
	}
	
	
	public void simulation20191222() {

	}

	
	
	public void simulation20191130GapFill() {
			
	}


	
	
	public void simulation20191015() {
		
		
	}
	
	
	public void getSolution() {
		
		
		if (myJob == JobType.INDEL_SUBS_DEPENDENCY) {
			
			tripletIndelSubsDependencyTestJob();
			

			
		}
		else if (myJob == JobType.SIMUL) {

			//myFunc.print(String.format("\nNot implemented..\n\n "));
			//System.exit(0);
			
			int i,j,iter;
			iter = 200;
			//double[][] eslSave = new double[iter][2];
			double [] beta = new double[iter];
			double [] rho = new double[iter];
			
			
			myFunc.print(String.format("\n\nTotal outer iteration of simulation: %d  ", iter));

			
			//this.simulation20191015(); // effect of outgroup selection
			//this.simulation20191130();// maybe best ; partition homogeneity test alt20191206.pdf
			//simulation20191130GapFill(); // Olivier's suggestion
			//this.simulation20191222(); // run codeml
			this.simulation20200125(rho, beta);   
			
			myFunc.print(String.format("\n\n###### Summary of rhoEst ###### \n"));
			myFunc.printArrayRstyle(rho, "savedRho");
			myFunc.print(String.format("\n\n###### Summary of betaEst ###### \n"));
			myFunc.printArrayRstyle(beta, "savedBeta");
			myFunc.print(String.format("\nmean(savedBeta) \nvar(savedBeta) \nsd(savedBeta) \nsd(savedBeta)/mean(savedBeta) \n\n"));

		}
		else if (myJob == JobType.EST_BR_HESS_ESL || myJob == JobType.READ_INFO_PAML) {
			LoadSeqFile(oriSeqFile);
			if (this.myFreqOpt == FreqType.DATAFREQ) {
				this.getEmpiricalPI();
				calRateMat();
			}
			
			this.estimateRhoBeta();

			boolean doNotRunThis = false;
			if (doNotRunThis) { //  if (bootIter > 0) {
				int i;
				int[] bootSize = new int[bootIter];
				for (i=0;i<bootIter;i++) 
					bootSize[i]= this.BootstrapUsingESL(i);
				this.PrintRaxmlCommand(bootIter);
				
				myFunc.print(String.format("\nbootSize <- c("));
				for (i=0;i<bootIter-1;i++)  {
					myFunc.print(String.format("%d, ",bootSize[i]));
				}
				myFunc.print(String.format("%d)\n\n ",bootSize[bootIter-1]));
			}
		}
		else if (myJob == JobType.EST_BR_HESS) {
			/*
			myFunc.print(String.format("\nNot implemented..\n\n "));
			System.exit(0);
			
			LoadSeqFile(oriSeqFile);
			if (this.myFreqOpt == FreqType.DataFreq) {
				this.getEmpiricalPI();
				calRateMat();
			}

			this.estimateRhoBeta();
			*/
			
			estimateParamOnly();

		}
		else if (myJob == JobType.EST_HESS_ESL || myJob == JobType.READ_INFO) {
			
			myFunc.print(String.format("\nNot implemented..\n\n "));
			System.exit(0);
			
			/*
			if (this.dataSortingPass) {
				// do nothing
			}
			else {
				this.recoverAlphabetData();
				alphabetDataPatternNum = new int[this.alphabetData[0].length];
				int i;
				for (i=0;i<alphabetDataPatternNum.length;i++) {
					alphabetDataPatternNum[i] = 1;
				}
				InitML();
			}
			calc2ndDeriv();
			Print2ndDeriv();
			*/
			LoadSeqFile(oriSeqFile);
			if (this.myFreqOpt == FreqType.DATAFREQ) {
				this.getEmpiricalPI();
				calRateMat();
			}
			
			this.estimateRhoBeta();
			
			
			
			boolean doNotRunThis = false;
			if (doNotRunThis) { //  if (bootIter > 0) {
				int i;
				int[] bootSize = new int[bootIter];
				for (i=0;i<bootIter;i++) 
					bootSize[i]= this.BootstrapUsingESL(i);
				this.PrintRaxmlCommand(bootIter);
				
				myFunc.print(String.format("\nbootSize <- c("));
				for (i=0;i<bootIter-1;i++)  {
					myFunc.print(String.format("%d, ",bootSize[i]));
				}
				myFunc.print(String.format("%d)\n\n ",bootSize[bootIter-1]));
			}

		}
		else if (myJob == JobType.INDEL_SUBS_TEST) {
			LoadSeqFile(oriSeqFile);
			this.CalcAlphabetDataPairDiff();
		}
		else {
			myFunc.print(String.format("\nNot implemented..\n\n "));
			System.exit(0);
		}

	}

	/*
	public void copyGapPatternFromOriginalData() {
		int i, j, iter, r;
		iter = this.alphabetData[0].length;
		for (i=0;i<iter;i++) {
			r = myFunc.myRand.nextInt(this.alphabetDataOriUnsorted[0].length);
			for (j=0;j<this.alphabetDataOriUnsorted.length;j++) {
				char c = alphabetDataOriUnsorted[j][r];
				if ( c== '-' || c== '?') {
					this.alphabetData[j][i] = c;
				}
			}
		}
	}
	*/



	
		
	/*
	public void printFisherInfoToScreen() {
		
		int i;
		double sum = 0.0;
		
		myFunc.print(String.format("\n\n---(imaginary ESL)--------------"));
		myFunc.print(String.format("\n%dth thread",this.multiThrId));
		myFunc.print(String.format("\nPSL(imaginary gappy)=%d",seqLength));
		sum = 0.0;
		for (i=0;i<oriFisherInfo.length;i++) {
			myFunc.print(String.format("\nESL_of_br[%d]=%f/%f*n= %f",i,simulFisherInfo[1][i],
					simulFisherInfo[0][i], brESL[1][i] ));
			if (!valid[i])
				myFunc.print(String.format("<- invalid p-ESL"));
			sum += brESL[1][i] * simulFisherInfo[0][i] * simulFisherInfo[0][i] / w_denom ;
		}
		myFunc.print(String.format("\n(weighted)Mean ESL=%f",sum));
		
		myFunc.print(String.format("\nw_denom=%f\n",w_denom));
		for (i=0;i<oriFisherInfo.length-1;i++) {
			if (valid[i])
				myFunc.print(String.format("%f*%f+",simulFisherInfo[0][i],simulFisherInfo[0][i]));
			else 
				myFunc.print(String.format("%f*%f+",0.0,0.0));
		}
		if (valid[i])
			myFunc.print(String.format("%f*%f",simulFisherInfo[0][i],simulFisherInfo[0][i]));
		else
			myFunc.print(String.format("%f*%f",0.0,0.0));
		
		myFunc.print(String.format("\nn_e=%f\n",this.meanESL[1]));
		for (i=0;i<oriFisherInfo.length-1;i++) {
			if (valid[i])
				myFunc.print(String.format("%f*%f/w_denom*%f+",simulFisherInfo[0][i], simulFisherInfo[0][i],brESL[1][i] ));
			else
				myFunc.print(String.format("%f*%f/w_denom*%f+",0.0, 0.0,0.0 ));
		}
		if (valid[i])
			myFunc.print(String.format("%f*%f/w_denom*%f",simulFisherInfo[0][i], simulFisherInfo[0][i],brESL[1][i] ));
		else
			myFunc.print(String.format("%f*%f/w_denom*%f",0.0, 0.0,0.0 ));
		
		
		myFunc.print(String.format("\nmodelMisFactor_beta=%f",this.modelMisFactor_beta));
		myFunc.print(String.format("\nESL_PSL_ratio_rho=%f\n",this.ESL_PSL_ratio_rho));
		
		/////
		//  ESL of real data
		sum = 0.0;
		myFunc.print(String.format("\n\n--(real ESL)---------------"));
		myFunc.print(String.format("\n%dth thread",this.multiThrId));
		myFunc.print(String.format("\nPSL=%d",seqLength));
		for (i=0;i<oriFisherInfo.length;i++) {
			myFunc.print(String.format("\nESL_of_br[%d]=%f/%f*n/modelMisFactor_beta= %f",i,oriFisherInfo[i],
					simulFisherInfo[0][i], brESL[0][i] ));
			if (!valid[i])
				myFunc.print(String.format("<- invalid p-ESL"));
			sum += brESL[0][i] * simulFisherInfo[0][i] * simulFisherInfo[0][i] / w_denom ;
		}
		
		myFunc.print(String.format("\n(weighted)Mean ESL=%f",sum));
		
		myFunc.print(String.format("\nw_denom=%f\n",w_denom));
		for (i=0;i<oriFisherInfo.length-1;i++) {
			if (valid[i])
				myFunc.print(String.format("%f*%f+",simulFisherInfo[0][i],simulFisherInfo[0][i]));
			else 
				myFunc.print(String.format("%f*%f+",0.0,0.0));
		}
		if (valid[i])
			myFunc.print(String.format("%f*%f",simulFisherInfo[0][i],simulFisherInfo[0][i]));
		else
			myFunc.print(String.format("%f*%f",0.0,0.0));
		
		myFunc.print(String.format("\nn_e=%f\n",this.meanESL[0]));
		for (i=0;i<oriFisherInfo.length-1;i++) {
			if (valid[i])
				myFunc.print(String.format("%f*%f/w_denom*%f+",simulFisherInfo[0][i], simulFisherInfo[0][i],brESL[0][i] ));
			else
				myFunc.print(String.format("%f*%f/w_denom*%f+",0.0, 0.0,0.0 ));
		}
		if (valid[i])
			myFunc.print(String.format("%f*%f/w_denom*%f",simulFisherInfo[0][i], simulFisherInfo[0][i],brESL[0][i] ));
		else
			myFunc.print(String.format("%f*%f/w_denom*%f",0.0, 0.0,0.0 ));
		
		myFunc.print(String.format("\n\nFor simple arithmetic mean...\nz<-c("));
		for (i=0;i<brESL[0].length;i++) {
			if (valid[i]) {
				myFunc.print(String.format("%f",brESL[0][i]));
				if (i==brESL[0].length-1 || i==brESL[0].length-2 && valid[brESL[0].length-1] == false)
					System.out.print(") ");
				else 
					System.out.print(", ");
			}
		}
		myFunc.print(String.format("\nmean(z) \nvar(z) \nsd(z) \nsd(z)/mean(z) \n\n"));
		
		
		myFunc.print(String.format("\n\n#Relationship of br vs. 2ndDeriv or brESL.."));
		myFunc.print(String.format("\nx<-c("));
		for (i=0;i<this.brParam.length;i++) {
			if (valid[i]) {
				myFunc.print(String.format("%f",brParam[i]));
				if (i==brParam.length-1 || i==brParam.length-2 && valid[brParam.length-1] == false)
					System.out.print(") ");
				else 
					System.out.print(", ");
			}
		}
		
		myFunc.print(String.format("\ny<-c("));
		for (i=0;i<this.oriFisherInfo.length;i++) {
			if (valid[i]) {
				myFunc.print(String.format("%f",oriFisherInfo[i]));
				if (i==oriFisherInfo.length-1 || i==oriFisherInfo.length-2 && valid[oriFisherInfo.length-1] == false)
					System.out.print(") ");
				else 
					System.out.print(", ");
			}
		}
		

		myFunc.print(String.format("\n\nplot(x,y,xlab=\"br\", ylab=\"Fisher Info\") \nplot(x,z,xlab=\"br\", ylab=\"ESL\")\n"));
	
		
	}
	*/
	
	
	
	
	public void preSolution() {
		
		this.getOption();
		
		LoadSeqFile(oriSeqFile); // to get taxaNum etc..., this function will be called again
		
		if (this.myJob != JobType.EST_HESS_ESL && this.multiThrId > 0) {
			myFunc.errPrint(String.format("\nOnly EST_HESS_ESL option can be used with multi thread."));
			System.exit(0);
		}
		
		myFunc.myRand = new Random(this.randSeed + this.multiThrId);
		myRand = new Random(this.randSeed + this.multiThrId);
		
		stateDim = 20;
		gammaCateNum = 5;
		this.allocateSpace();
		
		PI = new double[stateDim];
		String filename = "";
		if (this.subsModel == ModelType.WAG) 
			filename = "wag.txt";
		else if (this.subsModel == ModelType.MTREV24) 
			filename = "mtREV24.txt";
		else if (this.subsModel == ModelType.LG)
			filename = "lg.txt";
		else if (this.subsModel == ModelType.JONES)
			filename = "jones.txt";
		else if (this.subsModel == ModelType.DAYHOFF)
			filename = "dayhoff.txt";
		else {
			System.err.print("wrong model");
			System.exit(0);
		}

		this.getAAMatrix(filename);
		
		this.readAAFreqToPI();
		calRateMat();
		
		this.setAlpha(initial_alpha);
		
		buildTree(oriTopo);		
		if (this.multiThrId==0)
			PrintTreeTopo();
		
		//super.preSolution();

		
		//System.err.print("\n End of preSolution()"); 
	
		
	}
	
	public void preSolutionAA20200720() {
		
		// buildTree(oriTopo) is not here
		
		this.getOption();
		
		if (this.myJob != JobType.EST_HESS_ESL && this.multiThrId > 0) {
			myFunc.errPrint(String.format("\nOnly EST_HESS_ESL option can be used with multi thread."));
			System.exit(0);
		}
		
		myFunc.myRand = new Random(this.randSeed + this.multiThrId);
		myRand = new Random(this.randSeed + this.multiThrId);
		
		stateDim = 20;
		gammaCateNum = 5;
		this.allocateSpace();
		
		PI = new double[stateDim];
		String filename = "";
		if (this.subsModel == ModelType.WAG) 
			filename = "wag.txt";
		else if (this.subsModel == ModelType.MTREV24) 
			filename = "mtREV24.txt";
		else if (this.subsModel == ModelType.LG)
			filename = "lg.txt";
		else if (this.subsModel == ModelType.JONES)
			filename = "jones.txt";
		else if (this.subsModel == ModelType.DAYHOFF)
			filename = "dayhoff.txt";
		else {
			System.err.print("wrong model");
			System.exit(0);
		}

		this.getAAMatrix(filename);
		
		this.readAAFreqToPI();
		calRateMat();
		
		this.setAlpha(initial_alpha);
		

		
	}
	
	
	public void readAAFreqToPI() {
		for (int i=0;i<this.alphabetFreq.size();i++) 
			PI[i] = this.alphabetFreq.get(i);		
	}
	
	
	public void calRateMat() {
		//myFunc.print(String.format("\ncalRateMatAA() is run"));
		calRateMatAA();
		
	}
	
	
	public void calRateMatAA() {
	
		int i,j,dim;
		dim =this.alphabetVec.size();
	
		for (i=0;i<dim;i++) {
			for (j=i+1;j<dim;j++) {	
				rateMat[i*dim+j] = AARate.get(i).get(j)*PI[j];
				rateMat[j*dim+i] = AARate.get(j).get(i)*PI[i];
			}
		}
	
	
		for (i=0;i<dim;i++) {
			double tmp = 0.0;
			for (j=0;j<dim;j++) {
				if (i != j) tmp += rateMat[i*dim+j];
			}
			rateMat[i*dim+i] = -tmp;
		}
	
		double normal = 0;
		for (i=0;i<dim;i++)
			normal += -rateMat[i*dim+i] * PI[i];
	
		for (i=0;i<dim*dim;i++) {
			rateMat[i] /= normal;
		}
	
	
	
		/// Ziheng Yang's code
		myFunc.eigen(1,rateMat,dim,EigenRoot,ri,LeftModal,RightModal,space, dim);
		/*
		for (i=0;i<dim;i++) {
			System.out.print("\nEigenRoot["+i+"]="+EigenRoot[i]);
		}
		for (i=0;i<dim;i++) {
			System.out.print("\nLeftModal["+i+"]["+i+"]="+LeftModal[i*dim+i]);
		}
		System.exit(0);
		*/
	    myFunc.xtoy (LeftModal, RightModal, dim*dim);
		myFunc.matinv (RightModal, dim, dim, space);
	
		rateMatRecalNeeded = false;
	
		
	}
	
	
	public void getAAMatrix(String filename) {
		
		//// read-in Wag file...
		int i,j;
		double d;
		Character c;
		
		myFunc.print(String.format("\nAmino acid matrix %s was read in", filename));
		
		this.stateDim = 20;
		
		AARate= new Vector<Vector<Double>>();
		AARate.setSize(20);
		for (i=0;i<20;i++) {
			//Vector<Double> r = new Vector<Double> (20);
			Vector<Double> r = new Vector<Double> ();
			r.setSize(20);
			AARate.set(i, r);
		}

		alphabetVec = new Vector<Character>();
		alphabetVec.setSize(20);
		
		alphabetFreq = new Vector<Double>();
		alphabetFreq.setSize(20);
		
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			Scanner scanner = new Scanner(fis);
			
			for (i=1;i<20;i++) {
				for (j=0;j<i;j++) {
					d = scanner.nextDouble();
					AARate.get(i).set(j, d);
					AARate.get(j).set(i, d);
				}
			}
			for (i=0;i<20;i++) 
				AARate.get(i).set(i, 0.0);
			
			for (i=0;i<20;i++) {
				d = scanner.nextDouble();
				alphabetFreq.set(i, d);
			}
			
			for (i=0;i<20;i++) {
				c = scanner.next().charAt(0);
				alphabetVec.set(i, c);
			}
			
			scanner.close();	
			
		}
		catch (IOException e) {
			System.out.println(e);
			System.out.print("Something wrong in reading AA model file\n");
			System.err.print("Something wrong in reading AA model file\n");
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
		
		//test
		/*
		for (i=0;i<20;i++) {
			myFunc.print(String.format("\n%c", AAVec.get(i)));
			for (j=0;j<20;j++) {
				myFunc.print(String.format("  %f", AARate.get(i).get(j)));
			}
		}
		*/

	}
	
	@Override
	public void printEstimatedParam() {
		
		myFunc.print(String.format("\nEstimates under amino acid model"));
		
		super.printEstimatedParam();
		
		//myFunc.printArrayRstyle(this.sitewiseGapProp, "sitewiseGapProp");
			

	}
	
	@Override
	public void optimizeSub_pruning_paramSets(boolean print2screen) {
		
		super.optimizeSub_pruning_paramSets(print2screen);
		
		/*
		if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor) {
			optGapPropMultFactor();
			if (this.gammaCateNum > 1)
				optAlpha();	
			optAllBranches();
		}

		else {
			optAllBranches();
			if (this.gammaCateNum > 1)
				optAlpha();	
		}
		*/

	}
	
	public void optimizeSub_pruning_paramSets_2(boolean print2screen) {
		////////////////////////////////////
		// this is only for slope estimation
		// if (this.gapPropMultFactorOpt == GapPropMultFactorType.CalcGapPropMultFactor)
		//////////////////////////////////////
		String str = String.format("\nAfter only optGapPropMultFactor() opt");
		System.out.print(str);
		Print2ndDerivScreen();

		if (this.gammaCateNum > 1)
			optAlpha(print2screen);	
		optAllBranches(print2screen);

		this.setRecalNeeded();
		this.calcLogLike();	
		str = String.format("\n\nAfter 1-R the other opt's");
		System.out.print(str);
		Print2ndDerivScreen();
	}
	

	public void fillTermLikelihood(char c, double[] v, int pos, double a, int[] ii)
	{
		/// general model
		int i, sameFound;
		
		sameFound = 0;
		for (i=0;i<this.alphabetVec.size();i++) {
			if (this.alphabetVec.get(i).equals(c)) {
				v[pos + i] = a; 
				ii[0] =1;
				sameFound = 1;
			}
			else if (c=='-') {
				v[pos + i] = a; 
				ii[0] =1;
				sameFound = 1;
			}
			else if (c=='?') {
				v[pos + i] = a; 
				ii[0] =1;
				sameFound = 1;
			}
		}
	
		if (sameFound == 0) {
			System.err.print("\n Invalid alphabet " + c + " ... in fillTermLikelihood(..)"); 
			System.exit(0);
		}
	
		
	}

}
