package ESL_v02;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

public class myFunc {

	static int BASE = 2;
	static int DIGITS = 40;
	static int MAXITER = 30;
	
	static int maxNewtonR =  10;
	
	static double BRANCH_LENGTH_LOWER_LIMIT = 1.0e-6; // 1.0e-8; // 
	static double BRANCH_LENGTH_UPPER_LIMIT = 20.0;
	
	static double RATE_PARAM_LOWER_LIMIT = 1.0e-6;
	static double RATE_PARAM_UPPER_LIMIT = 10000;
	
	static double EPSILON = 2.220446e-16;
	static double ALPHA_LOWER_LIMIT = 0.005;
	static double ALPHA_UPPER_LIMIT = 1000.0;
	static double GapMultFactorSlope_LOWER_LIMIT = 1.0e-3;
	
	static double DELTA_RATIO_derivative_br = 1.0e-5; // 1.0e-4; //1.0e-5;
	
	static double DELTA_RATIO_derivative_rateParam = 1.0e-4; // 1.0e-4 (good for 100000 nuc) // 1.0e-5; //1.0e-2; //1.0e-3; //
	//static double DELTA_RATIO_derivative_rateParam = 1.0e-2; // 1.0e-3 (good for 200 nuc??) // 1.0e-5; //1.0e-2; //1.0e-3; //
	
	static double DELTA_RATIO_derivative_alpha = 1.0e-3; // 1.0e-5 (good for 100000 nuc) // 1.0e-3; // 1.0e-5; //1.0e-2; // 5.0e-3; //  
	static double DELTA_RATIO_derivative_gapMultFactor = 1.0e-3; // 1.0e-5 (good for 100000 nuc) // 1.0e-3; // 1.0e-5; //1.0e-2; // 5.0e-3; //  
	
	static double SmallFirstDerivative = 0.1; // 1.0e-3;
	static double SmallFirstDerivativeAlpha = 0.1; //0.001; // (very small number required for CalcScoreS() // 1.0; //  0.1; //  1.0e-2;
	static double SmallFirstDerivativeGapMultSlope = 0.1; //0.001; // (very small number required for CalcScoreS() // 1.0; //  0.1; //  1.0e-2;

	static double SmallFirstDerivativeRateParam = 0.001; // 1.0e-2; 0.001 may be small. it is for composite likelihood? 
	
	static Random myRand;
	
	static double[] brParamHessBackup; 
	
	static double propInsertedGap; 
	static double propIncorrectAlign;
	static int DxDySize;
	static int statIter, bootIter;

	static double NNITemp_Lower_Limit = 0.00001;
	
	static void Test() {
		
		/*
		double[] data = new double[2];
		data[0] = 0.0;
		data[1] = 1.0;
		*/
		
		double[] data = null;
		
		data = myFunc.addToEnd(data, 2.0);
		data = myFunc.addToEnd(data, 3.0);
		myFunc.printArrayRstyle(data, "\r\naddedVec");
		
		data = null;
		
		data = myFunc.addToEnd(data, 4.0);
		data = myFunc.addToEnd(data, 5.0);
		myFunc.printArrayRstyle(data, "\r\naddedVec");
		
		System.exit(0);
	}
	
	static String[] addToEnd(String[] data, String d) {
		int L;
		String[] tmp;
		if (data == null) {
			L = 1;
			tmp = new String[L];
			tmp[0] = d;
		}
		else {
			tmp = new String[data.length+1];
			int i;
			for (i=0;i<data.length;i++) {
				tmp[i] = data[i];
			}
			tmp[i] = d;
		}
		return tmp;
	}
	
	static Node[] addToEnd(Node[] data, Node d) {
		int L;
		Node[] tmp;
		if (data == null) {
			L = 1;
			tmp = new Node[L];
			tmp[0] = d;
		}
		else {
			tmp = new Node[data.length+1];
			int i;
			for (i=0;i<data.length;i++) {
				tmp[i] = data[i];
			}
			tmp[i] = d;
		}
		return tmp;
	}
	
	static Node[] deleteElement(Node[] data, Node d, int deletedID[]) {
		int i, j, idx, L;
		Node[] tmp;
		
		idx = -1;
		deletedID[0] = -1;
		
		for (i=0;i<data.length;i++) {
			if (data[i] == d || data[i] == d.desNd) {
				idx = i;
				deletedID[0] = i;
				break;
			}
		}
		
		if (idx != -1) {
			L = data.length-1;
			tmp = new Node[L];
			j = 0;
			for (i=0;i<data.length;i++) {
				if (data[i] == d || data[i] == d.desNd) {
					; // do nothing
				}
				else {
					tmp[j] = data[i];
					j++;
				}
			}
			return tmp;
		}
		else 
			return data;
	}
	
	static double[] deleteElement(double[] data, int deletedID[]) {
		int i, j, L;
		double[] tmp;
		
		L = data.length-1;
		tmp = new double[L];
		j = 0;
		for (i=0;i<data.length;i++) {
			if (i == deletedID[0]) {
				; // do nothing
			}
			else {
				tmp[j] = data[i];
				j++;
			}
		}
		return tmp;
	}
	
	static double[] addToEnd(double[] data, double d) {
		int L;
		double[] tmp;
		if (data == null) {
			L = 1;
			tmp = new double[L];
			tmp[0] = d;
		}
		else {
			tmp = new double[data.length+1];
			int i;
			for (i=0;i<data.length;i++) {
				tmp[i] = data[i];
			}
			tmp[i] = d;
		}
		return tmp;
	}
	
	static int[] addToEnd(int[] data, int d) {
		int L;
		int[] tmp;
		if (data == null) {
			L = 1;
			tmp = new int[L];
			tmp[0] = d;
		}
		else {
			tmp = new int[data.length+1];
			int i;
			for (i=0;i<data.length;i++) {
				tmp[i] = data[i];
			}
			tmp[i] = d;
		}
		return tmp;
	}
	
	static void bootstrapSeqData(char[][] retData, char[][] oriData) {
		//[taxon idx][seqLength idx]
		int i, j, k,  L, idx;
		L = oriData[0].length;
		for (k=0;k<L;k++) {		
			idx = myRand.nextInt(L);				
			for (j=0;j<oriData.length;j++) {
				retData[j][k] = oriData[j][idx];
			}
		}
	}
	
	static void bootstrapSeqData(char[][][] retData, char[][][] oriData) {
		//[complete or gappy][taxon idx][seqLength idx]

		int i, j, k,  L, idx;
		for (i=0;i<2;i++) {
			L = oriData[i][0].length;
			for (k=0;k<L;k++) {		
				idx = myRand.nextInt(L);				
				for (j=0;j<oriData[i].length;j++) {
					retData[i][j][k] = oriData[i][j][idx];
				}
			}
		}
	}
	
	
	static void bootstrapMat(long seed, double[][] destOri,  double[][] destFull, double[][] destGappy, double[][] sourceOri,  double[][] sourceFull, double[][] sourceGappy) {
		// correlated resampling of complete and gappy data
		int i, j, L, idx;
		L = sourceFull[0].length;
		Random localRand;
		if (seed == -1)
			localRand = new Random();
		else 
			localRand = new Random(seed);
		for (i=0;i<L;i++) {
			idx = localRand.nextInt(L);
			for (j=0;j<sourceFull.length;j++) {
				destFull[j][i] = sourceFull[j][idx];
				destGappy[j][i] = sourceGappy[j][idx];
				destOri[j][i] = sourceOri[j][idx];
			}
		}
	}
	
	static void bootstrapMat(long seed, double[][] destFull, double[][] destGappy, double[][] sourceFull, double[][] sourceGappy) {
		// correlated resampling of complete and gappy data
		int i, j, L, idx;
		L = sourceFull[0].length;
		Random localRand;
		if (seed == -1)
			localRand = new Random();
		else 
			localRand = new Random(seed);
		for (i=0;i<L;i++) {
			idx = localRand.nextInt(L);
			for (j=0;j<sourceFull.length;j++) {
				destFull[j][i] = sourceFull[j][idx];
				destGappy[j][i] = sourceGappy[j][idx];
			}
		}
	}
	
	static void bootstrapShiftMat(int[] bootIdx, int bootIdxStart, double[] transloc, double[][] dest, double[][] source) {
		int i, j, idx;
		//oriMean was already determined by bootIdx
		for (i=0;i<dest[0].length;i++) {
			idx = bootIdx[i%bootIdx.length];
			for (j=0;j<source.length;j++) {
				dest[j][i] = source[j][(i/bootIdx.length)*bootIdx.length + idx] + transloc[j];
			}
		}
	}
		
	static void bootstrapMat(int[] bootIdx, char[][] dest, char[][] source) {
		if (dest[0].length != source[0].length) {
			System.err.print(String.format("Some thing wrong in  bootstrapMat(..)"));
			System.exit(0);
		}
		int i, j, k, idx, iter;
		
		iter = dest[0].length / bootIdx.length;
		
		for (i=0;i<bootIdx.length;i++) {
			idx = bootIdx[i];
			for (j=0;j<iter;j++) {
				for (k=0;k<dest.length;k++) {
					dest[k][j*bootIdx.length+i] = source[k][j*bootIdx.length+idx];
				}
			}
		}
	}
	
	
	
	static void bootstrapMat(int[] bootIdx, double[][] dest, double[][] source) {
		if (dest[0].length != source[0].length) {
			System.err.print(String.format("Some thing wrong in  bootstrapMat(..)"));
			System.exit(0);
		}
		int i, j, k, idx, iter;
		
		iter = dest[0].length / bootIdx.length;
		
		for (i=0;i<bootIdx.length;i++) {
			idx = bootIdx[i];
			for (j=0;j<iter;j++) {
				for (k=0;k<dest.length;k++) {
					dest[k][j*bootIdx.length+i] = source[k][j*bootIdx.length+idx];
				}
			}
		}
		
		/*
		for (i=0;i<dest[0].length;i++) {
			idx = bootIdx[i%bootIdx.length];
			for (j=0;j<source.length;j++) {
				dest[j][i] = source[j][idx];
			}
		}
		*/
		
	}
	
	static void bootstrapMat(long seed, double[][] dest, double[][] source) {
		int i, j, L, idx;
		L = source[0].length;
		Random localRand;
		if (seed == -1)
			localRand = new Random();
		else 
			localRand = new Random(seed);
		for (i=0;i<dest[0].length;i++) {
			if (seed == -1) 
				idx = localRand.nextInt(L);
			else
				idx = localRand.nextInt(L);
			for (j=0;j<source.length;j++) {
				dest[j][i] = source[j][idx];
			}
		}
	}
	
	static void bootstrapVec(long seed, double[] dest, double[] source) {
		int i, L, idx;
		L = source.length;
		Random localRand = new Random(seed);
		if (L!=dest.length) {
			System.out.print(String.format("\n\nSomething wrong in bootstrapVec(..)"));
			System.exit(0);
		}
		for (i=0;i<L;i++) {
			idx = localRand.nextInt(L);
			dest[i] = source[idx];
		}
	}
	
	static void bootstrapVec(double[] dest, double[] source) {
		int i, L, idx;
		L = source.length;
		if (L!=dest.length) {
			System.out.print(String.format("\n\nSomething wrong in bootstrapVec(..)"));
			System.exit(0);
		}
		for (i=0;i<L;i++) {
			idx = myRand.nextInt(L);
			dest[i] = source[idx];
		}
	}
	
	static double bootstrapTest(double mean, double[] data) {
		int i, iter;
		double[] ret = new double[2];
		double[] bootData = new double[data.length];
		double stat, mean_data, var_data;
		
		myFunc.calcMeanVar(ret, data);
		mean_data = ret[0];
		var_data = ret[1];
		stat = (mean_data-mean)/Math.sqrt(var_data/data.length);
		//stat = (mean_data-mean);
		
		iter = 1000;
		double[] statSave = new double[iter];
		for (i=0;i<iter;i++) {
			myFunc.bootstrapVec(bootData, data);
			myFunc.calcMeanVar(ret, bootData);
			statSave[i] = (ret[0]-mean_data)/Math.sqrt(ret[1]/bootData.length);
			//statSave[i] = (ret[0]-mean_data);
		}
		
		int k = 0;
		for (i=0;i<iter;i++) {
			if (stat < statSave[i]) {
				k++;
			}
		}
		
		return 1.0*k/iter;
	}
	
	static void copyDataMatrix(char[][] retData, char[][] oriData) {
		int i,j;
		for (i=0;i<oriData.length;i++) {
			for (j=0;j<oriData[0].length;j++) {
				retData[i][j] = oriData[i][j];
			}
		}
	}
	
	static void randomCopyDataXDataY20191130(char[][][] retData, char[][][] oriData) {
		//[complete or gappy][taxon idx][seqLength idx]

		int i, j, L1, L2, L, idx1, idx2;
		
		L1 = retData[0][0].length;
		L2 = retData[1][0].length;
		
		if (L1 > L2) 
			L = L1;
		else 
			L = L2;
			
		for (i=0;i<L;i++) {
			if (i>L1-1 && i > L2-1)
				break;
			idx1 = myRand.nextInt(oriData[0][0].length);
			idx2 = myRand.nextInt(oriData[1][0].length);
			for (j=0;j<retData[0].length;j++) { // num of taxa
				if (myFunc.isMeaningful(oriData[0][j][idx1]) && myFunc.isMeaningful(oriData[1][j][idx2])) {
					if (i<L1)
						retData[0][j][i] = oriData[0][j][idx1];
					if (i<L2)
						retData[1][j][i] = oriData[1][j][idx2];
				}
				else if (!myFunc.isMeaningful(oriData[0][j][idx1]) && myFunc.isMeaningful(oriData[1][j][idx2])) {
					if (i<L1)
						retData[0][j][i] = oriData[0][j][idx1];
					if (i<L2)
						retData[1][j][i] = '-';
				}
				else if (myFunc.isMeaningful(oriData[0][j][idx1]) && !myFunc.isMeaningful(oriData[1][j][idx2])) {
					if (i<L1)
						retData[0][j][i] = '-';
					if (i<L2)
						retData[1][j][i] = oriData[1][j][idx2];
				}
				else if (!myFunc.isMeaningful(oriData[0][j][idx1]) && !myFunc.isMeaningful(oriData[1][j][idx2])) {
					if (i<L1)
						retData[0][j][i] = '-';
					if (i<L2)
						retData[1][j][i] = '-';
				}
				else {
					System.err.println("Something wrong...");
					System.exit(0);
				}
			}
		}
	}
	
	
	static char fillGap(char c, Vector<Character> alphabetVec, double[] gammaRateFreq, int patt_size, int stateDim, double[] probMat, 	Random myRand) {
		
		int i,j,k, l;
		
		double[][] Prob = new double[stateDim][stateDim];
		
		for (i=0;i<stateDim;i++) {
			for (j=0;j<stateDim;j++) {
				Prob[i][j] = 0.0;
			}
		}
	
		for (i=0;i<gammaRateFreq.length;i++) {
			for (k=0;k<stateDim;k++) {
				for (l=0;l<stateDim;l++) {
					Prob[k][l] += probMat[i*stateDim*stateDim + k*stateDim + l] * gammaRateFreq[i];
				}
			}
		}
		
		int id = -1;
		
		for (i=0;i<alphabetVec.size();i++) {
			if (alphabetVec.get(i).equals(c)) {
				id = i;
				break;
			}
		}
		
		double sum;
		sum = 0.0;
		
		for (i=0;i<stateDim;i++) {
			sum += Prob[id][i];
		}
		
		for (i=0;i<stateDim;i++) {
			Prob[id][i] /= sum;
		}
		
		for (i=1;i<stateDim;i++) {
			Prob[id][i] = Prob[id][i] + Prob[id][i-1];
		}
		
		double tmp = myRand.nextDouble();
		
		int pos = id;
		
		id = -1;
		if (tmp <= Prob[pos][0])
			id = 0;
		else {
			for (i=1;i<stateDim;i++) {
				if (tmp > Prob[pos][i-1] && tmp <= Prob[pos][i]) {
					id = i;
					break;
				}
			}
		}
		
		char ctmp = alphabetVec.get(id);
		
		return ctmp;
		
	}
	
	static void findNonGapPos(int[] nonGapTaxonID, double[] dist, int posA, int posB, Node terminalNd[], int tNameId[], String[] taxaNameList, char[][] alphabetData) {
		
		Node pNode, fromNd;
		
		double sum = 0.0;
		
		fromNd = pNode = terminalNd[tNameId[posA]];
		
		pNode = pNode.desNd;
		sum += pNode.branchLength;
		
		boolean found = false;
		int id, i;
		id = -1;
		do { 
			pNode = pNode.isoNd.desNd;
			sum += pNode.branchLength;
			if (pNode.isoNd == null) {
				id = -1;
				String str = pNode.taxonName;
				for (i=0;i<taxaNameList.length;i++) {
					if (str.equals(taxaNameList[i]) ) {
						id = i;
						break;
					}
				}
				if (id == -1) {
					System.err.print("\n Something wrong in fillGaps(..) ");
					System.exit(0);
				}
				
				if (alphabetData[id][posB] == '-' || alphabetData[id][posB] == '?') {
					sum -= pNode.branchLength;
				}
				else {
					found = true;
					break;
				}
				pNode = pNode.desNd;
			}
		} while (pNode != fromNd);

		if (!found) {
			System.err.print("\n Something wrong in fillGaps(..) ");
			System.exit(0);
		}
		
		if (pNode == fromNd) {
			System.err.print("\n Something wrong in fillGaps(..) ");
			System.exit(0);
		}
		
		dist[0] = sum;
		nonGapTaxonID[0] = id;
		
		//// the other direction traverse
		sum = 0.0;
		fromNd = pNode = terminalNd[tNameId[posA]];
		
		pNode = pNode.desNd;
		sum += pNode.branchLength;
		
		found = false;
		id = -1;
		do { 
			pNode = pNode.isoNd.isoNd.desNd;
			sum += pNode.branchLength;
			if (pNode.isoNd == null) {
				id = -1;
				String str = pNode.taxonName;
				for (i=0;i<taxaNameList.length;i++) {
					if (str.equals(taxaNameList[i]) ) {
						id = i;
						break;
					}
				}
				if (id == -1) {
					System.err.print("\n Something wrong in fillGaps(..) ");
					System.exit(0);
				}
				
				if (alphabetData[id][posB] == '-' || alphabetData[id][posB] == '?') {
					sum -= pNode.branchLength;
				}
				else {
					found = true;
					break;
				}
				pNode = pNode.desNd;
			}
		} while (pNode != fromNd);
		
		if (sum < dist[0]) {
			dist[0] = sum;
			nonGapTaxonID[0] = id;
		}
		
		/*
		System.out.print(String.format("\n dist ") + taxaNameList[posA] + 
				String.format("(%c)--(%c)",alphabetData[posA][posB],alphabetData[nonGapTaxonID[0]][posB]) + taxaNameList[nonGapTaxonID[0]] + String.format(" : %f",sum));
		*/
	}
	
	static void printAlphabetData(String[] taxaNameList, char[][] alphabetData, String tag) {
		int i,j;
		System.out.print("\n\n" + tag);
		System.out.print(String.format("\n%d %d", taxaNameList.length, alphabetData[0].length));
		for (i=0;i<taxaNameList.length;i++) {
			System.out.print(String.format("\n%s   ", taxaNameList[i]));
			for (j=0;j<alphabetData[i].length;j++) {
				System.out.print(String.format("%c", alphabetData[i][j]));
			}
		}
	}
	
	static double getLogLike(String fileName) {
		FileInputStream fis = null;
		
		double ret = 0.0;
		
		try {
			fis = new FileInputStream(fileName + "_res.txt");

			Scanner scanner = new Scanner(fis);

			while(scanner.hasNextLine()) {
				String str;
				String[] splitStr;
				do {
					str = scanner.nextLine();
					str = str.trim();
					splitStr = str.split("\\s+");
					str = splitStr[0]; 
				} while (!str.equals("lnL(ntime:"));
				
				ret = Double.parseDouble(splitStr[4]);
				break;
			}
			scanner.close();	
		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
		return ret;
	}
	
	static void generateCodemlCtl(String tag) {
		try {
			FileWriter fout = new FileWriter("codeml.ctl");
			fout.write(String.format("seqfile = %s * sequence data filename", tag));			
			//fout.write(String.format("\ntreefile = 9taxa_tree.txt      * tree structure file name"));
			fout.write(String.format("\ntreefile = 4taxa_tree.txt      * tree structure file name"));
			fout.write(String.format("\noutfile = %s_res.txt           * main result file name ", tag));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n noisy = 9  * 0,1,2,3,9: how much rubbish on the screen"));
			fout.write(String.format("\n verbose = 1  * 0: concise; 1: detailed, 2: too much"));
			fout.write(String.format("\n runmode = 0  * 0: user tree;  1: semi-automatic;  2: automatic"));
			fout.write(String.format("\n              * 3: StepwiseAddition; (4,5):PerturbationNNI; -2: pairwise"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n seqtype = 2  * 1:codons; 2:AAs; 3:codons-->AAs"));
			fout.write(String.format("\n  CodonFreq = 2  * 0:1/61 each, 1:F1X4, 2:F3X4, 3:codon table"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n *        ndata = 10"));
			fout.write(String.format("\n clock = 0  * 0:no clock, 1:clock; 2:local clock; 3:CombinedAnalysis"));
			fout.write(String.format("\n aaDist = 0  * 0:equal, +:geometric; -:linear, 1-6:G1974,Miyata,c,p,v,a"));
			fout.write(String.format("\n aaRatefile = lg.dat    * only used for aa seqs with model=empirical(_F)"));
			fout.write(String.format("\n * dayhoff.dat, jones.dat, wag.dat, mtmam.dat, or your own"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n model = 2 "));
			fout.write(String.format("\n * models for codons:"));
			fout.write(String.format("\n * 0:one, 1:b, 2:2 or more dN/dS ratios for branches"));
			fout.write(String.format("\n * models for AAs or codon-translated AAs:"));
			fout.write(String.format("\n * 0:poisson, 1:proportional, 2:Empirical, 3:Empirical+F"));
			fout.write(String.format("\n * 6:FromCodon, 7:AAClasses, 8:REVaa_0, 9:REVaa(nr=189)"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n NSsites = 0  * 0:one w;1:neutral;2:selection; 3:discrete;4:freqs;"));
			fout.write(String.format("\n * 5:gamma;6:2gamma;7:beta;8:beta&w;9:beta&gamma;"));
			fout.write(String.format("\n * 10:beta&gamma+1; 11:beta&normal>1; 12:0&2normal>1;"));
			fout.write(String.format("\n * 13:3normal>0"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n icode = 0  * 0:universal code; 1:mammalian mt; 2-10:see below"));
			fout.write(String.format("\n Mgene = 0"));
			fout.write(String.format("\n * codon: 0:rates, 1:separate; 2:diff pi, 3:diff kapa, 4:all diff"));
			fout.write(String.format("\n * AA: 0:rates, 1:separate"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n fix_kappa = 0  * 1: kappa fixed, 0: kappa to be estimated"));
			fout.write(String.format("\n kappa = 2  * initial or fixed kappa"));
			fout.write(String.format("\n fix_omega = 0  * 1: omega or omega_1 fixed, 0: estimate "));
			fout.write(String.format("\n omega = .4 * initial or fixed omega, for codons or codon-based AAs"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n fix_alpha = 0  * 0: estimate gamma shape parameter; 1: fix it at alpha"));
			fout.write(String.format("\n alpha = 0.5 * initial or fixed alpha, 0:infinity (constant rate)"));
			fout.write(String.format("\n Malpha = 0  * different alphas for genes"));
			fout.write(String.format("\n  ncatG = 5  * # of categories in dG of NSsites models"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n getSE = 0  * 0: don't want them, 1: want S.E.s of estimates"));
			fout.write(String.format("\n RateAncestor = 1  * (0,1,2): rates (alpha>0) or ancestral states (1 or 2)"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n Small_Diff = .5e-6"));
			fout.write(String.format("\n cleandata = 0  * remove sites with ambiguity data (1:yes, 0:no)?"));
			fout.write(String.format("\n *  fix_blength = 1  * 0: ignore, -1: random, 1: initial, 2: fixed, 3: proportional"));
			fout.write(String.format("\n  method = 1  * Optimization method 0: simultaneous; 1: one branch a time"));
			fout.write(String.format("\n "));
			
			fout.write(String.format("\n * Genetic codes: 0:universal, 1:mammalian mt., 2:yeast mt., 3:mold mt.,"));
			fout.write(String.format("\n * 4: invertebrate mt., 5: ciliate nuclear, 6: echinoderm mt., "));
			fout.write(String.format("\n * 7: euplotid mt., 8: alternative yeast nu. 9: ascidian mt., "));
			fout.write(String.format("\n * 10: blepharisma nu."));
			fout.write(String.format("\n * These codes correspond to transl_table 1 to 11 of GENEBANK."));
				
			fout.write(String.format("\n\n"));
			fout.close();
		}
		catch (IOException e) {
			System.out.print(String.format("\n%s error", tag));
		}
	}
	

	static double calcTstat20191128(double[] cdfY, double[] cdfYPrime) {
		
		// a X' + b = X
		
		int j;
		
		double sum, sumsq;
		sum = sumsq = 0.0;
		
		for (j=0;j<cdfY.length;j++) {
			sum += cdfY[j];
			sumsq += cdfY[j]*cdfY[j];
		}
		
		double varY = sumsq/(cdfY.length-1) - 1.0*cdfY.length/(cdfY.length-1) * (sum/cdfY.length)* (sum/cdfY.length);
		// var = sumsq/(n-1) - n/(n-1)*(sum/n)*(sum/n)
		
		double muY = sum/cdfY.length;
		
		sum=0.0;
		for (j=0;j<cdfYPrime.length;j++) {
			sum += cdfYPrime[j];
		}
		double muYPrime = sum/cdfYPrime.length;

		return (muY-muYPrime)/Math.sqrt(varY/cdfY.length);
	}
	

	static public void calcCovMultGeneral(long seed, double[][] result, double[][] saveSecondDeriv) {
		
		int i, j, L;
		L = result.length;
		for (i=0;i<L;i++) {
			for (j=0;j<L;j++) {
				result[i][j] = 0.0;
			}
		}
		
		for (i=0;i<L;i++) {
			for (j=i;j<L;j++) {
				result[i][j] = myFunc.calcCov(saveSecondDeriv[i],saveSecondDeriv[j]);
			}
		}
		
	}
	
	static public void calcCovMultSpecialForBeta(long seed, double[] resultInvF, double[][] result, double[][] saveSecondDeriv) {
		// this is special for calc cov(beta_i, beta_j
		
		int i, j, k , L, iter;
		L = result.length;
		for (i=0;i<L;i++) {
			for (j=0;j<L;j++) {
				result[i][j] = 0.0;
			}
		}
		
		iter = 1000;
		L = saveSecondDeriv[0].length;
		double[] bootA = new double[L];
		double[] bootB = new double[L];
		double[] resA = new double[iter];
		double[] resB = new double[iter];
		
		double m1, m2;
		double[] ret = new double[2];
		
		for (i=0;i<saveSecondDeriv.length;i++) {
			for (j=i;j<saveSecondDeriv.length;j++) {
				for (k=0;k<iter;k++) {
					myFunc.bootstrapVec(seed+k, bootA, saveSecondDeriv[i]);
					myFunc.bootstrapVec(seed+k, bootB, saveSecondDeriv[j]);
					myFunc.calcMeanVar(ret, bootA);
					resA[k] = 1.0/ret[0];
					myFunc.calcMeanVar(ret, bootB);
					//resB[k] = 1.0/ret[0];
					resA[k] *= 1.0/ret[0];
				}
				//result[i][j] = myFunc.calcCov(resA,resB);
				myFunc.calcMeanVar(ret, resA);
				result[i][j] = ret[0];
			}
		}
		
		for (i=0;i<saveSecondDeriv.length;i++) {
			for (k=0;k<iter;k++) {
				myFunc.bootstrapVec(seed+k, bootA, saveSecondDeriv[i]);
				myFunc.calcMeanVar(ret, bootA);
				resA[k] = 1.0/ret[0];
			}
			myFunc.calcMeanVar(ret, resA);
			resultInvF[i] = ret[0];
		}
	}


	
	static double calcCov(double[] A, double[] B) {
		double m1, m2, sum;
		m1 = 0.0;
		m2 = 0.0;
		int i, iter;
		iter = A.length;
		
		for (i=0;i<iter;i++) {
			m1 += A[i];
			m2 += B[i];
		}
		m1 /= A.length;
		m2 /= B.length;
		
		sum = 0.0;
		for (i=0;i<iter;i++) {
			sum += (A[i] - m1)*(B[i] - m2);
		}
		sum /= (iter-1);
		
		return sum;
	}
	
	static void calcRhoMeanVar(long seed, double[] ret, double[] retInvGappyFisher, double[] secondDerivGappy, double[] secondDerivComplete) {
		int i, j, L, idx, iter;
		
		iter = 1000;
		L = secondDerivComplete.length;
		double[] tmpRet = new double[2];
		double[] bootCompl = new double[L];
		double[] bootGappy = new double[L];
		double[] resultSave = new double[iter];
		double[] resultInvSave = new double[iter];
		
		double meanRatio;
		double invFisher;
		
		Random localRand = new Random(seed);
		
		// for test
		/*
		idx = localRand.nextInt(L);
		System.out.print(String.format("\n"));
		System.out.print(String.format("%d ", idx));
		idx = localRand.nextInt(L);	
		System.out.print(String.format("%d ", idx));
		*/
		
		for (i=0;i<iter;i++) {
			for (j=0;j<L;j++) {
				idx = localRand.nextInt(L);
				bootCompl[j] =  secondDerivComplete[idx];
				bootGappy[j] =  secondDerivGappy[idx];
			}
			myFunc.calcMeanVar(tmpRet, bootGappy);
			meanRatio = tmpRet[0];
			invFisher = 1.0/tmpRet[0];
			resultInvSave[i] = invFisher;
			myFunc.calcMeanVar(tmpRet, bootCompl);
			meanRatio /= tmpRet[0];
			resultSave[i] = meanRatio;
		}
		
		myFunc.calcMeanVar(tmpRet, resultSave);
		ret[0] = tmpRet[0];
		ret[1] = tmpRet[1];
		
		myFunc.calcMeanVar(tmpRet, resultInvSave);
		retInvGappyFisher[0] = tmpRet[0];
		retInvGappyFisher[1] = tmpRet[1];
	}
	
	static void calcBootMeanVar(double[] ret, double[] data) {
		int j, L, idx, iter;
		
		iter = 1000;
		double[] bootData  = new double[data.length];
		L = data.length;
		for (j=0;j<L;j++) {
			idx = myFunc.myRand.nextInt(L);
			bootData[j] = data[idx];
		}
		myFunc.calcMeanVar(ret, bootData);
	}
	
	static double calcVarOfMeanWithBoot(double[] data) {
		int i, iter;
		iter = 1000;
		double[] save = new double[iter];
		double[] ret = new double[2];
		for (i=0;i<iter;i++) {
			myFunc.calcBootMeanVar(ret, data);
			//save[i] = ret[1]/data.length;
			save[i] = ret[0];
		}
		myFunc.calcMeanVar(ret, save);
		return ret[1];
	}
	
	static void calcParametewiseBetaSignificance(double[]ret, double[] data, double FisherInfo, double FisherInfoVar) {
		// ret[0]: Parameterwise Beta returned
		// ret[1]: Var of ret[0] returned
		// ret[2]: p value of test stat
		// data[] contain only 2nd Deriv
		// FisherInfo: average over site of 2nd deriv of long seq
		// FisherInfoVar: Var of FisherInfo
		int i, iter;
		iter = 1000;		
		double testStat, oriVar, testStatBoot, varBoot;
		double[] tmpRet = new double[2];
		double[] bootData = new double[data.length];
		
		double[] bootStat = new double[iter];
		double[] bootStatVar = new double[iter];
		double tmp; 
		
		myFunc.calcMeanVar(tmpRet, data);
		ret[0] = tmpRet[0]/FisherInfo;
		
		oriVar = tmpRet[1]/data.length + FisherInfoVar;
		testStat = (tmpRet[0] - FisherInfo)/Math.sqrt(oriVar);

		for (i=0;i<iter;i++) {
			myFunc.bootstrapVec(bootData, data);
			myFunc.calcMeanVar(tmpRet, bootData);
			bootStat[i] = tmpRet[0] - FisherInfo;
			bootStatVar[i] = tmpRet[1]/bootData.length + FisherInfoVar;
		}
		tmp = 0.0;
		for (i=0;i<iter;i++) {
			tmp += bootStat[i];
		}
		tmp /= iter;
		for (i=0;i<iter;i++) {
			bootStat[i] -= tmp;
			bootStat[i] /= Math.sqrt(bootStatVar[i]);
		}
		
		myFunc.calcMeanVar(tmpRet, bootStat);
		ret[1] = tmpRet[1] * oriVar * oriVar / FisherInfo / FisherInfo;
		
		int k = 0;
		for (i=0;i<iter;i++) {
			if (testStat < bootStat[i])
				k++;
		}
		ret[2] = 1.0*k/iter;

		/// do pvalue again 

		double[] tmpOriData = new double[data.length];
		for (i=0;i<tmpOriData.length;i++) {
			tmpOriData[i] = data[i]; //FisherInfo;
		}
		
		myFunc.calcMeanVar(tmpRet, tmpOriData);
		testStat = (tmpRet[0] - FisherInfo)/Math.sqrt(tmpRet[1]/tmpOriData.length + FisherInfoVar);
		double oriMean = tmpRet[0] - FisherInfo;
		oriVar = tmpRet[1]/tmpOriData.length;

		for (i=0;i<iter;i++) {
			myFunc.bootstrapVec(bootData, tmpOriData);
			myFunc.calcMeanVar(tmpRet, bootData);
			bootStat[i] = (tmpRet[0] - FisherInfo - oriMean)/Math.sqrt(tmpRet[1]/bootData.length + FisherInfoVar);
		}
		/*		*/
		/*
		tmp = 0.0;
		for (i=0;i<iter;i++) {
			tmp += bootStat[i];
		}
		tmp /= iter;
		for (i=0;i<iter;i++) {
			bootStat[i] -= tmp;
		}
		*/
		k = 0;
		for (i=0;i<iter;i++) {
			if (testStat < bootStat[i])
				k++;
		}
		ret[2] = 1.0*k/iter;
	}
	
	static void multVec(double a, double[] B) {
		int i;
		for (i=0;i<B.length;i++) {
			B[i] *= a;
		}
	}
	
	static void copyVec(double[] A, double[] B) {
		int i;
		for (i=0;i<A.length;i++) {
			A[i] = B[i];
		}
		
	}
	
	static void subtractVec(double[] res, double[] A, double[] B) {
		int i;
		for (i=0;i<res.length;i++) {
			res[i] = A[i] - B[i];
		}
	}
	
	static void addVec(double[] res, double[] A, double[] B) {
		int i;
		for (i=0;i<res.length;i++) {
			res[i] = A[i] + B[i];
		}
	}
	
	static void calcMeanVarMatrix(double[][]retRes, double[][] data) {
		int i;
		double[] ret = new double[2];
		
		for (i=0;i<retRes[0].length;i++) {
			myFunc.calcMeanVar(ret, data[i]);
			retRes[0][i] = ret[0]; // mean
			retRes[1][i] = ret[1]; // var
		}
	}
	
	static void calcMeanVar(double[] ret, double[] data) {
		int j;
		
		double sum, sumsq;
		sum = sumsq = 0.0;
		
		for (j=0;j<data.length;j++) {
			sum += data[j];
			sumsq += data[j]*data[j];
		}
		
		ret[1] = sumsq/(data.length-1) - 1.0*data.length/(data.length-1) * (sum/data.length)* (sum/data.length);
		// var = sumsq/(n-1) - n/(n-1)*(sum/n)*(sum/n)
		
		ret[0] = sum/data.length;
	}
	
	static double calcTstat20191123(double[] cdfXTrans, double[] cdfY) {
		int i;
		double[]  mu = new double[2];
		double[] var = new double[2];
		
		mu[0] = mu[1] = var[0] = var[1] = 0.0;
		
		for (i=0;i<cdfXTrans.length;i++) {
			mu[0] += cdfXTrans[i];
		}
		mu[0] /= cdfXTrans.length;
		for (i=0;i<cdfXTrans.length;i++) {
			var[0] += (cdfXTrans[i]-mu[0])*(cdfXTrans[i]-mu[0]);
		}
		var[0] /= (cdfXTrans.length-1);
		
		///// now cdfY
		
		for (i=0;i<cdfY.length;i++) {
			mu[1] += cdfY[i];
		}
		mu[1] /= cdfY.length;
		for (i=0;i<cdfY.length;i++) {
			var[1] += (cdfY[i]-mu[1])*(cdfY[i]-mu[1]);
		}
		var[1] /= (cdfY.length-1);
		
		return (mu[0]-mu[1])/Math.sqrt(var[0]/cdfXTrans.length + var[1]/cdfY.length);
		
	}
	
	static void printRcode20191123() {
		int j;
		// rcode print
		
		System.out.print(String.format("\ncdfX.ecdf = ecdf(cdfX)"));
		System.out.print(String.format("\ncdfY.ecdf = ecdf(cdfY)"));
		System.out.print(String.format("\ncdfXprime.ecdf = ecdf(cdfXprime)"));
		System.out.print(String.format("\ncdfYprime.ecdf = ecdf(cdfYprime)"));	
		System.out.print(String.format("\ncdfXTrans.ecdf = ecdf(cdfXTrans)"));
		
		System.out.print(String.format("\nplot(cdfX.ecdf, verticals=TRUE, do.points=FALSE, main=\"CDF's\")"));
		System.out.print(String.format("\nplot(cdfY.ecdf, verticals=TRUE, do.points=FALSE, add=TRUE, col='red')"));
		System.out.print(String.format("\nplot(cdfXprime.ecdf, verticals=TRUE, do.points=FALSE, add=TRUE, col='blue')"));
		System.out.print(String.format("\nplot(cdfYprime.ecdf, verticals=TRUE, do.points=FALSE, add=TRUE, col='brown')"));
		System.out.print(String.format("\nplot(cdfXTrans.ecdf, verticals=TRUE, do.points=FALSE, add=TRUE, col='pink')"));

		/*
		for (j=0;j<4;j++) {
			System.out.print(String.format("\nsitewiseLoglike%d.ecdf = ecdf(sitewiseLoglike%d)",j,j));
		}
		System.out.print(String.format("\ncdfXTrans.ecdf = ecdf(cdfXTrans)"));

		System.out.print(String.format("\nplot(sitewiseLoglike0.ecdf, verticals=TRUE, do.points=FALSE, main=\"CDF's\")"));
		System.out.print(String.format("\nplot(sitewiseLoglike1.ecdf, verticals=TRUE, do.points=FALSE, add=TRUE, col='red')"));
		System.out.print(String.format("\nplot(sitewiseLoglike2.ecdf, verticals=TRUE, do.points=FALSE, add=TRUE, col='blue')"));
		System.out.print(String.format("\nplot(sitewiseLoglike3.ecdf, verticals=TRUE, do.points=FALSE, add=TRUE, col='brown')"));
		System.out.print(String.format("\nplot(cdfXTrans.ecdf, verticals=TRUE, do.points=FALSE, add=TRUE, col='pink')"));
		
		System.out.print(String.format("\n\nks.test(sitewiseLoglike0,sitewiseLoglike2)"));
		System.out.print(String.format("\nks.test(sitewiseLoglike1,sitewiseLoglike3)"));
		System.out.print(String.format("\nks.test(sitewiseLoglike1,cdfXTrans) "));
		System.out.print(String.format("\nt.test(sitewiseLoglike1,cdfXTrans)\n\n "));
		*/
		
	}
	
	static void TransformCDFX20191127(double[] cdfXTrans, double [] cdfX, double[][] cdfPrime) {
		
		// a X' + b = X
		
		int j;
		
		double sum, sumsq;
		sum = sumsq = 0.0;
		
		for (j=0;j<cdfPrime[0].length;j++) {
			sum += cdfPrime[0][j];
			sumsq += cdfPrime[0][j]*cdfPrime[0][j];
		}
		
		double varXprime = sumsq/(cdfPrime[0].length-1) - 1.0*cdfPrime[0].length/(cdfPrime[0].length-1) * (sum/cdfPrime[0].length)* (sum/cdfPrime[0].length);
		// var = sumsq/(n-1) - n/(n-1)*(sum/n)*(sum/n)
		
		double muXprime = sum/cdfPrime[0].length;
		
		sum=sumsq=0.0;
		for (j=0;j<cdfX.length;j++) {
			sum += cdfX[j];
			sumsq += cdfX[j]*cdfX[j];
		}
		double varX = sumsq/(cdfX.length-1) - 1.0*cdfX.length/(cdfX.length-1) * (sum/cdfX.length)* (sum/cdfX.length);
		double muX = sum/cdfX.length;
		
		// resize cdfXTrans
		//cdfXTrans = new double[cdfPrime[1].length];
		
		double a, b;
		a = Math.sqrt(varX/varXprime);
		b = muX - a * muXprime;
		
		for (j=0;j<cdfXTrans.length;j++) {
			cdfXTrans[j]  = a * cdfPrime[1][j] + b;
		}
	}
	
	
	static void TransformCDFX20191123(double[] cdfXTrans, double [] cdfX, double[][] cdfPrime) {
		
		// a X' + b = Y'
		
		int j;
		
		double muXprime=0.0;
		
		for (j=0;j<cdfPrime[0].length;j++) {
			muXprime += cdfPrime[0][j];
		}
		muXprime /= cdfPrime[0].length;
		
		double varXprime = 0.0;
		for (j=0;j<cdfPrime[0].length;j++) {
			varXprime += (cdfPrime[0][j]-muXprime)*(cdfPrime[0][j]-muXprime);
		}
		varXprime /= (cdfPrime[0].length-1);
		
		double muYprime = 0.0;
		for (j=0;j<cdfPrime[1].length;j++) {
			muYprime += cdfPrime[1][j];
		}
		muYprime /= cdfPrime[1].length;
		
		double varYprime = 0.0;
		for (j=0;j<cdfPrime[1].length;j++) {
			varYprime += (cdfPrime[1][j]-muYprime)*(cdfPrime[1][j]-muYprime);
		}
		varYprime /= (cdfPrime[1].length-1);

		double a, b;
		a = Math.sqrt(varYprime/varXprime);
		b = muYprime - a * muXprime;
		
		for (j=0;j<cdfXTrans.length;j++) {
			cdfXTrans[j]  = a * cdfX[j] + b;
		}

	}
	
	static void printArrayRstyle(double[] data, String tag, int L) {
		System.out.print("\n" + tag + " <- c(");
		int k;
		for (k=0;k<L;k++) {
			if (k!=0 && k%20==0) 
				System.out.print(String.format("\n"));
			System.out.print(String.format("%f",data[k]));
			if (k!=L-1)
				System.out.print(String.format(", "));
			else 
				System.out.print(String.format(")\n"));
		}
	}
	
	
	static void printArrayRstyle(FileWriter fout, double[] data, String tag) {
		try {
			//fout.write("\r\n" + tag + " <- c(");
			fout.write(tag + " <- c(");
			int k;
			for (k=0;k<data.length;k++) {
				if (k!=0 && k%20==0) 
					fout.write(String.format("\n"));
				fout.write(String.format("%f",data[k]));
				if (k!=data.length-1)
					fout.write(String.format(", "));
				else 
					fout.write(String.format(")"));
			}
		}
		catch (IOException e) {
			System.out.print(String.format("\nerror"));
		}
	}
	
	static void printArrayRstyle(int[] data, String tag, int L) {
		//System.out.print("\r\n" + tag + " <- c(");
		System.out.print(tag + " <- c(");
		int k;
		for (k=0;k<L;k++) {
			if (k!=0 && k%20==0) 
				System.out.print(String.format("\r\n"));
			System.out.print(String.format("%d",data[k]));
			if (k!=L-1)
				System.out.print(String.format(", "));
			else 
				System.out.print(String.format(")"));
		}
	}
	
	static void printArrayRstyle(int[] data, String tag) {
		//System.out.print("\r\n" + tag + " <- c(");
		System.out.print(tag + " <- c(");
		int k;
		for (k=0;k<data.length;k++) {
			if (k!=0 && k%20==0) 
				System.out.print(String.format("\r\n"));
			System.out.print(String.format("%d",data[k]));
			if (k!=data.length-1)
				System.out.print(String.format(", "));
			else 
				System.out.print(String.format(")"));
		}
	}
	
	static void printArrayRstyle(double[] data, String tag) {
		if (data==null)
			return;
		//System.out.print("\r\n" + tag + " <- c(");
		System.out.print(tag + " <- c(");
		int k;
		for (k=0;k<data.length;k++) {
			if (k!=0 && k%20==0) 
				System.out.print(String.format("\r\n"));
			System.out.print(String.format("%f",data[k]));
			if (k!=data.length-1)
				System.out.print(String.format(", "));
			else 
				System.out.print(String.format(")"));
		}
	}
	
	static void permute(int n, int[] res) 
	{
		int i,j, k, id;
		
		int[] ori = new int[n];
		for (i=0;i<n;i++) {
			ori[i] = i;
		}
		
		//Random rand = new Random(1);
		
		id = 0;
		for (i=0;i<n;i++) {
			k = myRand.nextInt(n-id);
			res[i] = ori[k];
			for (j=k;j<n-1;j++) {
				ori[j] = ori[j+1];
			}
			id++;
		}
	}


	static public int matinv( double x[], int n, int m, double space[]) {
	/* x[n*m]  ... m>=n
	*/
	   int i,j,k;
	   int[] irow = new int[space.length];
	   for (i=0;i<irow.length;i++) {
		   irow[i] = (int) space[i];
	   }
	   double ee=1.0e-30, t,t1,xmax;
	   double det=1.0;

	   for (i=0;i<n;i++) {
	      xmax = 0.;
	      for (j=i; j<n; j++)
	         if (xmax < Math.abs(x[j*m+i])) { xmax = Math.abs(x[j*m+i]); irow[i]=j; }
	      det *= xmax;
	      if (xmax < ee)   {
	         System.out.print("\nDet becomes zero at %3d!\t\n" + (i+1) );
	         //return(-1);
	      }
	      if (irow[i] != i) {
	         for (j=0;j<m;j++) {
	            t = x[i*m+j];
	            x[i*m+j] = x[irow[i]*m+j];
	            x[irow[i]*m+j] = t;
	         }
	      }
	      t = 1./x[i*m+i];
	      for (j=0;j<n;j++) {
	         if (j == i) continue;
	         t1 = t*x[j*m+i];
	         for (k=0;k<m;k++)  x[j*m+k] -= t1*x[i*m+k];
	         x[j*m+i] = -t1;
	      }
	      for (j=0;j<m;j++)  x[i*m+j] *= t;
	      x[i*m+i] = t;
	   }                            /* i  */
	   for (i=n-1; i>=0; i--) {
	      if (irow[i] == i) continue;
	      for (j=0;j<n;j++) {
	         t = x[j*m+i];
	         x[j*m+i] = x[j*m + irow[i]];
	         x[j*m + irow[i]] = t;
	      }
	   }
	   return (0);
	}

	/*
	 * Transform back eigenvectors of a balanced matrix
	 * into the eigenvectors of the original matrix
	 */
	static public void unbalance(int n,double vr[],double vi[], int[] low, int[] hi, double scale[], int offSet) {
		int i,j,k;
	    double tmp;

	    for (i = low[0]; i <= hi[0]; i++) {
	        for (j = 0; j < n; j++) {
	            vr[pos(i,j,n)] *= scale[i+offSet];
	            vi[pos(i,j,n)] *= scale[i+offSet];
	        }
	    }

	    for (i = low[0] - 1; i >= 0; i--) {
	        if ((k = (int)scale[i+offSet]) != i) {
	            for (j = 0; j < n; j++) {
	                tmp = vr[pos(i,j,n)];
	                vr[pos(i,j,n)] = vr[pos(k,j,n)];
	                vr[pos(k,j,n)] = tmp;

	                tmp = vi[pos(i,j,n)];
	                vi[pos(i,j,n)] = vi[pos(k,j,n)];
	                vi[pos(k,j,n)] = tmp;
	            }
	        }
	    }

	    for (i = hi[0] + 1; i < n; i++) {
	        if ((k = (int)scale[i+offSet]) != i) {
	            for (j = 0; j < n; j++) {
	                tmp = vr[pos(i,j,n)];
	                vr[pos(i,j,n)] = vr[pos(k,j,n)];
	                vr[pos(k,j,n)] = tmp;

	                tmp = vi[pos(i,j,n)];
	                vi[pos(i,j,n)] = vi[pos(k,j,n)];
	                vi[pos(k,j,n)] = tmp;
	            }
	        }
	    }
	}

	static class complex {
		double re, im;
		/*
		void complex() {
			re = im = 0.0;
		}
		*/
	}
	
	static public complex complexgen(double re,double im)
	// 'coml' has been changed 'complexgen' by seo because of compliation error in unix.
	{
	    complex r = new complex();

	    r.re = re;
	    r.im = im;
	    return(r);
	}
	
	static public complex cdiv (complex a,complex b)
	{
	    double ratio, den;
	    complex c = new complex();

	    if (Math.abs(b.re) <= Math.abs(b.im)) {
	        ratio = b.re / b.im;
	        den = b.im * (1 + ratio * ratio);
	        c.re = (a.re * ratio + a.im) / den;
	        c.im = (a.im * ratio - a.re) / den;
	    }
	    else {
	        ratio = b.im / b.re;
	        den = b.re * (1 + ratio * ratio);
	        c.re = (a.re + a.im * ratio) / den;
	        c.im = (a.im - a.re * ratio) / den;
	    }
	    return(c);
	}

	static public int max2(int a, int b) {
		if (a > b)
			return a;
		else
			return b;
	}
	
	static public int min2(int a, int b) {
		if (a < b)
			return a;
		else
			return b;
	}
	
	static public int realeig(int job,double mat[],int n,int[] low, int[] hi, double valr[],
      double vali[], double vr[],double vi[]) {
	
	   complex v;
	   v = new complex();
	   double p=0,q=0,r=0,s=0,t,w,x,y,z=0,ra,sa,norm,eps;
	   int niter,en,i,j,k,l,m;
	   double precision  = Math.pow((double)BASE,(double)(1-DIGITS));
	
	   eps = precision;
	   for (i=0; i<n; i++) {
	      valr[i]=0.0;
	      vali[i]=0.0;
	   }
	      /* store isolated roots and calculate norm */
	   for (norm = 0,i = 0; i < n; i++) {
	      for (j = max2(0,i-1); j < n; j++) {
	         norm += Math.abs(mat[pos(i,j,n)]);
	      }
	      if (i < low[0] || i > hi[0]) valr[i] = mat[pos(i,i,n)];
	   }
	   t = 0;
	   en = hi[0];
	
	   while (en >= low[0]) {
	      niter = 0;
	      for (;;) {
	
	       /* look for single small subdiagonal element */
	
	         for (l = en; l > low[0]; l--) {
	            s = Math.abs(mat[pos(l-1,l-1,n)]) + Math.abs(mat[pos(l,l,n)]);
	            if (s == 0) s = norm;
	            if (Math.abs(mat[pos(l,l-1,n)]) <= eps * s) break;
	         }
	
	         /* form shift */
	
	         x = mat[pos(en,en,n)];
	
	         if (l == en) {             /* one root found */
	            valr[en] = x + t;
	            if (job != 0) mat[pos(en,en,n)] = x + t;
	            en--;
	            break;
	         }
	
	         y = mat[pos(en-1,en-1,n)];
	         w = mat[pos(en,en-1,n)] * mat[pos(en-1,en,n)];
	
	         if (l == en - 1) {                /* two roots found */
	            p = (y - x) / 2;
	            q = p * p + w;
	            z = Math.sqrt(Math.abs(q));
	            x += t;
	            if (job != 0) {
	               mat[pos(en,en,n)] = x;
	               mat[pos(en-1,en-1,n)] = y + t;
	            }
	            if (q < 0) {                /* complex pair */
	               valr[en-1] = x+p;
	               vali[en-1] = z;
	               valr[en] = x+p;
	               vali[en] = -z;
	            }
	            else {                      /* real pair */
	               z = (p < 0) ? p - z : p + z;
	               valr[en-1] = x + z;
	               valr[en] = (z == 0) ? x + z : x - w / z;
	               if (job != 0) {
	                  x = mat[pos(en,en-1,n)];
	                  s = Math.abs(x) + Math.abs(z);
	                  p = x / s;
	                  q = z / s;
	                  r = Math.sqrt(p*p+q*q);
	                  p /= r;
	                  q /= r;
	                  for (j = en - 1; j < n; j++) {
	                     z = mat[pos(en-1,j,n)];
	                     mat[pos(en-1,j,n)] = q * z + p *
	                     mat[pos(en,j,n)];
	                     mat[pos(en,j,n)] = q * mat[pos(en,j,n)] - p*z;
	                  }
	                  for (i = 0; i <= en; i++) {
	                     z = mat[pos(i,en-1,n)];
	                     mat[pos(i,en-1,n)] = q * z + p * mat[pos(i,en,n)];
	                     mat[pos(i,en,n)] = q * mat[pos(i,en,n)] - p*z;
	                  }
	                  for (i = low[0]; i <= hi[0]; i++) {
	                     z = vr[pos(i,en-1,n)];
	                     vr[pos(i,en-1,n)] = q*z + p*vr[pos(i,en,n)];
	                     vr[pos(i,en,n)] = q*vr[pos(i,en,n)] - p*z;
	                  }
	               }
	            }
	            en -= 2;
	            break;
	         }
	         if (niter == MAXITER) return(-1);
	         if (niter != 0 && niter % 10 == 0) {
	            t += x;
	            for (i = low[0]; i <= en; i++) mat[pos(i,i,n)] -= x;
	            s = Math.abs(mat[pos(en,en-1,n)]) + Math.abs(mat[pos(en-1,en-2,n)]);
	            x = y = 0.75 * s;
	            w = -0.4375 * s * s;
	         }
	         niter++;
	           /* look for two consecutive small subdiagonal elements */
	         for (m = en - 2; m >= l; m--) {
	            z = mat[pos(m,m,n)];
	            r = x - z;
	            s = y - z;
	            p = (r * s - w) / mat[pos(m+1,m,n)] + mat[pos(m,m+1,n)];
	            q = mat[pos(m+1,m+1,n)] - z - r - s;
	            r = mat[pos(m+2,m+1,n)];
	            s = Math.abs(p) + Math.abs(q) + Math.abs(r);
	            p /= s;
	            q /= s;
	            r /= s;
	            if (m == l || Math.abs(mat[pos(m,m-1,n)]) * (Math.abs(q)+Math.abs(r)) <=
	                eps * (Math.abs(mat[pos(m-1,m-1,n)]) + Math.abs(z) +
	                Math.abs(mat[pos(m+1,m+1,n)])) * Math.abs(p)) break;
	         }
	         for (i = m + 2; i <= en; i++) mat[pos(i,i-2,n)] = 0;
	         for (i = m + 3; i <= en; i++) mat[pos(i,i-3,n)] = 0;
	             /* double QR step involving rows l to en and columns m to en */
	         for (k = m; k < en; k++) {
	            if (k != m) {
	               p = mat[pos(k,k-1,n)];
	               q = mat[pos(k+1,k-1,n)];
	               r = (k == en - 1) ? 0 : mat[pos(k+2,k-1,n)];
	               if ((x = Math.abs(p) + Math.abs(q) + Math.abs(r)) == 0) continue;
	               p /= x;
	               q /= x;
	               r /= x;
	            }
	            s = Math.sqrt(p*p+q*q+r*r);
	            if (p < 0) s = -s;
	            if (k != m) {
	               mat[pos(k,k-1,n)] = -s * x;
	            }
	            else if (l != m) {
	               mat[pos(k,k-1,n)] = -mat[pos(k,k-1,n)];
	            }
	            p += s;
	            x = p / s;
	            y = q / s;
	            z = r / s;
	            q /= p;
	            r /= p;
	                /* row modification */
	            int tmp_iter;
	            if (job==0)
	            	tmp_iter = en;
	            else
	            	tmp_iter = n-1;
	            for (j = k; j <= tmp_iter; j++){
	               p = mat[pos(k,j,n)] + q * mat[pos(k+1,j,n)];
	               if (k != en - 1) {
	                  p += r * mat[pos(k+2,j,n)];
	                  mat[pos(k+2,j,n)] -= p * z;
	               }
	               mat[pos(k+1,j,n)] -= p * y;
	               mat[pos(k,j,n)] -= p * x;
	            }
	            j = min2(en,k+3);
	              /* column modification */
	            int tmp_start;
	            if (job==0)
	            	tmp_start = l;
	            else
	            	tmp_start = 0;
	            for (i = tmp_start; i <= j; i++) {
	               p = x * mat[pos(i,k,n)] + y * mat[pos(i,k+1,n)];
	               if (k != en - 1) {
	                  p += z * mat[pos(i,k+2,n)];
	                  mat[pos(i,k+2,n)] -= p*r;
	               }
	               mat[pos(i,k+1,n)] -= p*q;
	               mat[pos(i,k,n)] -= p;
	            }
	            if (job!=0) {             /* accumulate transformations */
	               for (i = low[0]; i <= hi[0]; i++) {
	                  p = x * vr[pos(i,k,n)] + y * vr[pos(i,k+1,n)];
	                  if (k != en - 1) {
	                     p += z * vr[pos(i,k+2,n)];
	                     vr[pos(i,k+2,n)] -= p*r;
	                  }
	                  vr[pos(i,k+1,n)] -= p*q;
	                  vr[pos(i,k,n)] -= p;
	               }
	            }
	         }
	      }
	   }
	
	   if (job==0) return(0);
	   if (norm != 0) {
	       /* back substitute to find vectors of upper triangular form */
	      for (en = n-1; en >= 0; en--) {
	         p = valr[en];
	         if ((q = vali[en]) < 0) {            /* complex vector */
	            m = en - 1;
	            if (Math.abs(mat[pos(en,en-1,n)]) > Math.abs(mat[pos(en-1,en,n)])) {
	               mat[pos(en-1,en-1,n)] = q / mat[pos(en,en-1,n)];
	               mat[pos(en-1,en,n)] = (p - mat[pos(en,en,n)]) /
	                     mat[pos(en,en-1,n)];
	            }
	            else {
	               v = cdiv(complexgen(0.0,-mat[pos(en-1,en,n)]),
	                    complexgen(mat[pos(en-1,en-1,n)]-p,q));
	               mat[pos(en-1,en-1,n)] = v.re;
	               mat[pos(en-1,en,n)] = v.im;
	            }
	            mat[pos(en,en-1,n)] = 0;
	            mat[pos(en,en,n)] = 1;
	            for (i = en - 2; i >= 0; i--) {
	               w = mat[pos(i,i,n)] - p;
	               ra = 0;
	               sa = mat[pos(i,en,n)];
	               for (j = m; j < en; j++) {
	                  ra += mat[pos(i,j,n)] * mat[pos(j,en-1,n)];
	                  sa += mat[pos(i,j,n)] * mat[pos(j,en,n)];
	               }
	               if (vali[i] < 0) {
	                  z = w;
	                  r = ra;
	                  s = sa;
	               }
	               else {
	                  m = i;
	                  if (vali[i] == 0) {
	                     v = cdiv(complexgen(-ra,-sa),complexgen(w,q));
	                     mat[pos(i,en-1,n)] = v.re;
	                     mat[pos(i,en,n)] = v.im;
	                  }
	                  else {                      /* solve complex equations */
	                     x = mat[pos(i,i+1,n)];
	                     y = mat[pos(i+1,i,n)];
	                     v.re = (valr[i]- p)*(valr[i]-p) + vali[i]*vali[i] - q*q;
	                     v.im = (valr[i] - p)*2*q;
	                     if ((Math.abs(v.re) + Math.abs(v.im)) == 0) {
	                        v.re = eps * norm * (Math.abs(w) +
	                                Math.abs(q) + Math.abs(x) + Math.abs(y) + Math.abs(z));
	                     }
	                     v = cdiv(complexgen(x*r-z*ra+q*sa,x*s-z*sa-q*ra),v);
	                     mat[pos(i,en-1,n)] = v.re;
	                     mat[pos(i,en,n)] = v.im;
	                     if (Math.abs(x) > Math.abs(z) + Math.abs(q)) {
	                        mat[pos(i+1,en-1,n)] =
	                             (-ra - w * mat[pos(i,en-1,n)] +
	                             q * mat[pos(i,en,n)]) / x;
	                        mat[pos(i+1,en,n)] = (-sa - w * mat[pos(i,en,n)] -
	                             q * mat[pos(i,en-1,n)]) / x;
	                     }
	                     else {
	                        v = cdiv(complexgen(-r-y*mat[pos(i,en-1,n)],
	                             -s-y*mat[pos(i,en,n)]),complexgen(z,q));
	                        mat[pos(i+1,en-1,n)] = v.re;
	                        mat[pos(i+1,en,n)] = v.im;
	                     }
	                  }
	               }
	            }
	         }
	         else if (q == 0) {                             /* real vector */
	            m = en;
	            mat[pos(en,en,n)] = 1;
	            for (i = en - 1; i >= 0; i--) {
	               w = mat[pos(i,i,n)] - p;
	               r = mat[pos(i,en,n)];
	               for (j = m; j < en; j++) {
	                  r += mat[pos(i,j,n)] * mat[pos(j,en,n)];
	               }
	               if (vali[i] < 0) {
	                  z = w;
	                  s = r;
	               }
	               else {
	                  m = i;
	                  if (vali[i] == 0) {
	                     if ((t = w) == 0) t = eps * norm;
	                     mat[pos(i,en,n)] = -r / t;
	                  }
	                  else {            /* solve real equations */
	                     x = mat[pos(i,i+1,n)];
	                     y = mat[pos(i+1,i,n)];
	                     q = (valr[i] - p) * (valr[i] - p) + vali[i]*vali[i];
	                     t = (x * s - z * r) / q;
	                     mat[pos(i,en,n)] = t;
	                     if (Math.abs(x) <= Math.abs(z)) {
	                        mat[pos(i+1,en,n)] = (-s - y * t) / z;
	                     }
	                     else {
	                        mat[pos(i+1,en,n)] = (-r - w * t) / x;
	                     }
	                  }
	               }
	            }
	         }
	      }
	             /* vectors of isolated roots */
	      for (i = 0; i < n; i++) {
	         if (i < low[0] || i > hi[0]) {
	            for (j = i; j < n; j++) {
	               vr[pos(i,j,n)] = mat[pos(i,j,n)];
	            }
	         }
	      }
	       /* multiply by transformation matrix */
	
	      for (j = n-1; j >= low[0]; j--) {
	         m = min2(j,hi[0]);
	         for (i = low[0]; i <= hi[0]; i++) {
	            for (z = 0,k = low[0]; k <= m; k++) {
	               z += vr[pos(i,k,n)] * mat[pos(k,j,n)];
	            }
	            vr[pos(i,j,n)] = z;
	         }
	      }
	   }
	    /* rearrange complex eigenvectors */
	   for (j = 0; j < n; j++) {
	      if (vali[j] != 0) {
	         for (i = 0; i < n; i++) {
	            vi[pos(i,j,n)] = vr[pos(i,j+1,n)];
	            vr[pos(i,j+1,n)] = vr[pos(i,j,n)];
	            vi[pos(i,j+1,n)] = -vi[pos(i,j,n)];
	         }
	         j++;
	      }
	   }
	   return(0);
	}
	
	static int eigen(int job, double A[], int n, double rr[], double ri[],
          double vr[], double vi[], double work[], int offSet) {
	
	/* job=0: eigen values only
	       1: both eigen values and eigen vectors
	   double w[n*2]: work space
	*/
	    int i,j,k, it, istate=0;
	    double tiny=Math.sqrt(Math.pow((double)BASE,(double)(1-DIGITS))), t;
	
	    int[] low, hi;
	    low = new int[1];
	    hi = new int[1];
	    balance(A,n,low,hi,work, offSet);
	    elemhess(job,A,n,low,hi,vr,vi, work, offSet+n);
	    /*
		for (i = 0; i<n; i++) {
			System.out.print("\nvr["+i+"]["+i+"]="+vr[i*n + i]);
		}
		*/
	    if (-1 == realeig(job,A,n,low,hi,rr,ri,vr,vi)) return (-1);
	    /*
		for (i = 0; i<n; i++) {
			System.out.print("\nvr["+i+"]["+i+"]="+vr[i*n + i]);
		}
		*/
	    if (job != 0) unbalance(n,vr,vi,low,hi,work, offSet);
	    /*
		for (i = 0; i<n; i++) {
			System.out.print("\nvr["+i+"]["+i+"]="+vr[i*n + i]);
		}
	    System.exit(0);
	    */
	
	/* sort, added by Z. Yang */
	   for (i=0; i<n; i++) {
	       for (j=i+1,it=i,t=rr[i]; j<n; j++)
	           if (t<rr[j]) { t=rr[j]; it=j; }
	       rr[it]=rr[i];   rr[i]=t;
	       t=ri[it];       ri[it]=ri[i];  ri[i]=t;
	       for (k=0; k<n; k++) {
	          t=vr[k*n+it];  vr[k*n+it]=vr[k*n+i];  vr[k*n+i]=t;
	          t=vi[k*n+it];  vi[k*n+it]=vi[k*n+i];  vi[k*n+i]=t;
	       }
	       if (Math.abs(ri[i])>tiny) istate=1;
	   }
	
	    return (istate) ;
	}

	static public void elemhess(int job,double mat[],int n,int[] low,int[] hi, double vr[],
            double vi[], double work[], int workOffset) {
	
		/* work[n] */
	  int i,j,m;
	  double x,y;
	
	  for (m = low[0] + 1; m < hi[0]; m++) {
	      for (x = 0,i = m,j = m; j <= hi[0]; j++) {
	          if (Math.abs(mat[pos(j,m-1,n)]) > Math.abs(x)) {
	              x = mat[pos(j,m-1,n)];
	              i = j;
	          }
	      }
	
	      //if ((work[m + workOffset] = i) != m) {
	      work[m + workOffset] = (double) i;
		  if (i != m) {	
	          for (j = m - 1; j < n; j++) {
	             y = mat[pos(i,j,n)];
	             mat[pos(i,j,n)] = mat[pos(m,j,n)];
	             mat[pos(m,j,n)] = y;
	          }
	
	          for (j = 0; j <= hi[0]; j++) {
	             y = mat[pos(j,i,n)];
	             mat[pos(j,i,n)] = mat[pos(j,m,n)];
	             mat[pos(j,m,n)] = y;
	          }
	      }
	
	      if (x != 0) {
	          for (i = m + 1; i <= hi[0]; i++) {
	              if ((y = mat[pos(i,m-1,n)]) != 0) {
	                  y = mat[pos(i,m-1,n)] = y / x;
	
	                  for (j = m; j < n; j++) {
	                      mat[pos(i,j,n)] -= y * mat[pos(m,j,n)];
	                  }
	
	                  for (j = 0; j <= hi[0]; j++) {
	                      mat[pos(j,m,n)] += y * mat[pos(j,i,n)];
	                  }
	              }
	          }
	      }
	  }
	  if (job != 0) {
	     for (i=0; i<n; i++) {
	        for (j=0; j<n; j++) {
	           vr[pos(i,j,n)] = 0.0; vi[pos(i,j,n)] = 0.0;
	        }
	        vr[pos(i,i,n)] = 1.0;
	     }
	
	     for (m = hi[0] - 1; m > low[0]; m--) {
	        for (i = m + 1; i <= hi[0]; i++) {
	           vr[pos(i,m,n)] = mat[pos(i,m-1,n)];
	        }
	
	        
	       if ((i = (int) work[m+workOffset]) != m) {
	          for (j = m; j <= hi[0]; j++) {
	             vr[pos(m,j,n)] = vr[pos(i,j,n)];
	             vr[pos(i,j,n)] = 0.0;
	          }
	          vr[pos(i,m,n)] = 1.0;
	       }
	    }
	 }
	}

	static public int pos(int i, int j, int n)  {   
		return ((i)*(n)+(j));
	}

	static public void balance(double mat[], int n,int[] low, int[] hi, double scale[], int offSet) {
	/* Balance a matrix for calculation of eigenvalues and eigenvectors
	*/
	    double c,f,g,r,s;
	    int i,j,k,l,done;
	        /* search for rows isolating an eigenvalue and push them down */
	    for (k = n - 1; k >= 0; k--) {
	        for (j = k; j >= 0; j--) {
	            for (i = 0; i <= k; i++) {
	                if (i != j && Math.abs(mat[pos(j,i,n)]) != 0) break;
	            }
	
	            if (i > k) {
	                scale[k + offSet] = j;
	
	                if (j != k) {
	                    for (i = 0; i <= k; i++) {
	                       c = mat[pos(i,j,n)];
	                       mat[pos(i,j,n)] = mat[pos(i,k,n)];
	                       mat[pos(i,k,n)] = c;
	                    }
	
	                    for (i = 0; i < n; i++) {
	                       c = mat[pos(j,i,n)];
	                       mat[pos(j,i,n)] = mat[pos(k,i,n)];
	                       mat[pos(k,i,n)] = c;
	                    }
	                }
	                break;
	            }
	        }
	        if (j < 0) break;
	    }
	
	    /* search for columns isolating an eigenvalue and push them left */
	
	    for (l = 0; l <= k; l++) {
	        for (j = l; j <= k; j++) {
	            for (i = l; i <= k; i++) {
	                if (i != j && Math.abs(mat[pos(i,j,n)]) != 0) break;
	            }
	            if (i > k) {
	                scale[l+offSet] = j;
	                if (j != l) {
	                    for (i = 0; i <= k; i++) {
	                       c = mat[pos(i,j,n)];
	                       mat[pos(i,j,n)] = mat[pos(i,l,n)];
	                       mat[pos(i,l,n)] = c;
	                    }
	
	                    for (i = l; i < n; i++) {
	                       c = mat[pos(j,i,n)];
	                       mat[pos(j,i,n)] = mat[pos(l,i,n)];
	                       mat[pos(l,i,n)] = c;
	                    }
	                }
	
	                break;
	            }
	        }
	
	        if (j > k) break;
	    }
	
	    hi[0] = k;
	    low[0] = l;
	
	    /* balance the submatrix in rows l through k */
	
	    for (i = l; i <= k; i++) {
	        scale[i+offSet] = 1;
	    }
	
	    do {
	        for (done = 1,i = l; i <= k; i++) {
	            for (c = 0,r = 0,j = l; j <= k; j++) {
	                if (j != i) {
	                    c += Math.abs(mat[pos(j,i,n)]);
	                    r += Math.abs(mat[pos(i,j,n)]);
	                }
	            }
	
	            if (c != 0 && r != 0) {
	                g = r / BASE;
	                f = 1;
	                s = c + r;
	
	                while (c < g) {
	                    f *= BASE;
	                    c *= BASE * BASE;
	                }
	
	                g = r * BASE;
	
	                while (c >= g) {
	                    f /= BASE;
	                    c /= BASE * BASE;
	                }
	
	                if ((c + r) / f < 0.95 * s) {
	                    done = 0;
	                    g = 1 / f;
	                    scale[i+offSet] *= f;
	
	                    for (j = l; j < n; j++) {
	                        mat[pos(i,j,n)] *= g;
	                    }
	
	                    for (j = 0; j <= k; j++) {
	                        mat[pos(j,i,n)] *= f;
	                    }
	                }
	            }
	        }
	    } while (done == 0);
	}


	static public int xtoy (double x[], double y[], int n) {
		int i; for (i=0; i<n; y[i]=x[i],i++) ;  return(0); 
	}
	
	static public int ziheng_identity (double x[], int offset, int n) {
		int i,j;  
		for (i=0;i<n;i++) {
			for (j=0;j<n;j++) {
				x[offset + i*n+j]=0;
			}
			x[offset + i*n+i]=1;
		}
		return (0); 
	}
	
	static public int zero (double x[], int offSet, int n) {
		int i;
		for (i=0;i<n;i++) {
			x[offSet+i]=0;
		}
		return (0);
	}
	
	static public int PMatUVRoot_yang_brDeriv (double P[], int offSet, double t, int n, double U[], double V[], double Root[], double gammaF, double multF, int order)
	{
		// for slope estimation
		// this is modified from PMatUVRoot_yang(..)
		// to calculate 2nd derivative of branch length
		// this calculate U * Root^2 g^2 s^2 exp{Root*(g*s*t)} * V
		// instead of original P(t) = U * exp{Root*t} * V
		
	   int i,j,k;
	   double expt, uexpt;
	   double[] pP;
	
	   // if (DEBUG) removed...

	   if (t<1e-10) {
		  ziheng_identity (P, offSet, n); 
		  return(0); 
	   }
	
	   int id = 0;		   
	   double multiFactor;

	   for (k=0,zero(P,offSet, n*n); k<n; k++) {
		   multiFactor = 1.0;
		   if (order == 0) {
			   multiFactor = 1.0;
		   }
		   else if (order == 1) {
			   multiFactor = multF * gammaF*Root[k];
			   //multiFactor = Root[k];
			   //multiFactor = 1/gammaF*Root[k];
		   }
		   else if (order == 2) {
			   multiFactor = multF * multF * gammaF*gammaF*Root[k]*Root[k];
			   //multiFactor = Root[k]*Root[k];
			   //multiFactor = 1/gammaF*1/gammaF*Root[k]*Root[k];
		   }
		   else {
		   };
		   
		   for (i=0,pP=P,id=0,expt=multiFactor*Math.exp(t*Root[k]); i<n; i++) {
			   // expt=Math.exp(t*Root[k])
			   // was replaced with expt=multiFactor*Math.exp(t*Root[k])
			   // in the above for(..)
			   // compare with PMatUVRoot_yang(..)
			   for (j=0,uexpt=U[i*n+k]*expt; j<n; j++) {
				   pP[offSet + id] += uexpt*V[k*n+j];
				   id++;
			   }
		   }
	   }

////////////////////////////
	
	   // if (DEBUG) removed...


		  for (i=0;i<n*n;i++) {
			  //////here; added by seo to prevent negative prob.
			  // P[offSet + i] = Math.abs(P[offSet + i]); 
			// this was removed 20190930. With this, 1st derivative of Eq (7)
			 // (Yang 2000 Maximum Likelihood Estimation on Large Phylogenies and Analysis of
			//Adaptive Evolution in Human Influenza Virus A, J Mol Evol (2000) 51:423-432,)
			  /*
			  if (P[i]<0.0) {
				  P[i] = - P[i];
				  //cout<<endl<<"Neg-Prob detected.. P="<<P[i];
				  //cerr<<endl<<"Neg-Prob detected.. P="<<P[i];
			  }
			  */
		  }
	///////////////////////////////////////////////////////
	
	   return (0);
	}

	static public int PMatUVRoot_yang_brDeriv (double P[], int offSet, double t, int n, double U[], double V[], double Root[], double gammaF, int order)
	{
		// this is modified from PMatUVRoot_yang(..)
		// to calculate 2nd derivative of branch length
		// this calculate U * Root^2 g^2 exp{Root*(gt)} * V
		// instead of original P(t) = U * exp{Root*t} * V
		
	   int i,j,k;
	   double expt, uexpt;
	   double[] pP;
	
	   // if (DEBUG) removed...

	   if (t<1e-10) {
		  ziheng_identity (P, offSet, n); 
		  return(0); 
	   }
	
	   int id = 0;		   
	   double multiFactor;

	   for (k=0,zero(P,offSet, n*n); k<n; k++) {
		   multiFactor = 1.0;
		   if (order == 0) {
			   multiFactor = 1.0;
		   }
		   else if (order == 1) {
			   multiFactor = gammaF*Root[k];
			   //multiFactor = Root[k];
			   //multiFactor = 1/gammaF*Root[k];
		   }
		   else if (order == 2) {
			   multiFactor = gammaF*gammaF*Root[k]*Root[k];
			   //multiFactor = Root[k]*Root[k];
			   //multiFactor = 1/gammaF*1/gammaF*Root[k]*Root[k];
		   }
		   else {
		   };
		   for (i=0,pP=P,id=0,expt=multiFactor*Math.exp(t*Root[k]); i<n; i++) {
			   // expt=Math.exp(t*Root[k])
			   // was replaced with expt=multiFactor*Math.exp(t*Root[k])
			   // in the above for(..)
			   // compare with PMatUVRoot_yang(..)
			   for (j=0,uexpt=U[i*n+k]*expt; j<n; j++) {
				   pP[offSet + id] += uexpt*V[k*n+j];
				   id++;
			   }
		   }
	   }

////////////////////////////
	
	   // if (DEBUG) removed...


		  for (i=0;i<n*n;i++) {
			  //////here; added by seo to prevent negative prob.
			  // P[offSet + i] = Math.abs(P[offSet + i]); 
			// this was removed 20190930. With this, 1st derivative of Eq (7)
			 // (Yang 2000 Maximum Likelihood Estimation on Large Phylogenies and Analysis of
			//Adaptive Evolution in Human Influenza Virus A, J Mol Evol (2000) 51:423-432,)
			  /*
			  if (P[i]<0.0) {
				  P[i] = - P[i];
				  //cout<<endl<<"Neg-Prob detected.. P="<<P[i];
				  //cerr<<endl<<"Neg-Prob detected.. P="<<P[i];
			  }
			  */
		  }
	///////////////////////////////////////////////////////
	
	
	   return (0);
	}

	
	static public int PMatUVRoot_yang (double P[], int offSet, double t, int n, double U[], double V[], double Root[])
	{
		/* P(t) = U * exp{Root*t} * V
		*/
	   int i,j,k;
	   double expt, uexpt;
	   double[] pP;
	
	
	   // if (DEBUG) removed...

	   if (t<1e-10) {
		  ziheng_identity (P, offSet, n); 
		  return(0); 
	   }
	
	   int id = 0;		   
	   for (k=0,zero(P,offSet, n*n); k<n; k++) {
		   for (i=0,pP=P,id=0,expt=Math.exp(t*Root[k]); i<n; i++) {
			   for (j=0,uexpt=U[i*n+k]*expt; j<n; j++) {
				   pP[offSet + id] += uexpt*V[k*n+j];
				   id++;
			   }
		   }
	   }

////////////////////////////
	
	   // if (DEBUG) removed...

	//////here; added by seo to prevent negative prob.
		  for (i=0;i<n*n;i++) {
			  P[offSet + i] = Math.abs(P[offSet + i]);
			  /*
			  if (P[i]<0.0) {
				  P[i] = - P[i];
				  //cout<<endl<<"Neg-Prob detected.. P="<<P[i];
				  //cerr<<endl<<"Neg-Prob detected.. P="<<P[i];
			  }
			  */
		  }
	///////////////////////////////////////////////////////
	
	
	   return (0);
	}

	
	static double LnGamma (double alpha)
	{
	/* returns ln(gamma(alpha)) for alpha>0, accurate to 10 decimal places.
	   Stirling's formula is used for the central polynomial part of the procedure.
	   Pike MC & Hill ID (1966) Algorithm 291: Logarithm of the gamma function.
	   Communications of the Association for Computing Machinery, 9:684
	*/
	   double x=alpha, f=0, z;
	
	   if (x<7) {
	      f=1;  z=x-1;
	      while (++z<7)  f*=z;
	      x=z;   f=-Math.log(f);
	   }
	   z = 1/(x*x);
	   return  f + (x-0.5)*Math.log(x) - x + .918938533204673
	          + (((-.000595238095238*z+.000793650793651)*z-.002777777777778)*z
	               +.083333333333333)/x;
	}
	
	static double IncompleteGamma (double x, double alpha, double ln_gamma_alpha)
	{
	/* returns the incomplete gamma ratio I(x,alpha) where x is the upper
	           limit of the integration and alpha is the shape parameter.
	   returns (-1) if in error
	   ln_gamma_alpha = ln(Gamma(alpha)), is almost redundant.
	   (1) series expansion     if (alpha>x || x<=1)
	   (2) continued fraction   otherwise
	   RATNEST FORTRAN by
	   Bhattacharjee GP (1970) The incomplete gamma integral.  Applied Statistics,
	   19: 285-287 (AS32)
	*/
	   int i;
	   double p=alpha, g=ln_gamma_alpha;
	   /* double accurate=1e-8, overflow=1e30; */
	   double accurate=1e-10, overflow=1e60;
	   double factor, gin=0, rn=0, a=0,b=0,an=0,dif=0, term=0; //, pn[6];
	  
	   double[] pn = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0}; // added_by_seo

	   if (x==0) return (0);
	   if (x<0 || p<=0) return (-1);

	   factor=Math.exp(p*Math.log(x)-x-g);
	   if (!(x>1 && x>=p)) {
		   /* (1) series expansion */
		   gin=1;  term=1;  rn=p;
		   do {
			   rn++;
			   term*=x/rn;   gin+=term;
		   } while (term > accurate);
		   gin*=factor/p;
		   return (gin); //goto l50;
	   }
	   else {
		   
	   }

	// l30:
	   /* (2) continued fraction */
	   a=1-p;   b=a+x+1;  term=0;
	   pn[0]=1;  pn[1]=x;  pn[2]=x+1;  pn[3]=x*b;
	   gin=pn[2]/pn[3];
 
	   l32:
		 
		   do {
			   a++;  b+=2;  term++;   an=a*term;
			   for (i=0; i<2; i++) pn[i+4]=b*pn[i+2]-an*pn[i];
			   if (pn[5] == 0) {
				   //goto l35
				   for (i=0; i<4; i++) pn[i]=pn[i+2];
				   if (Math.abs(pn[4]) < overflow) continue l32;
				   for (i=0; i<4; i++) pn[i]/=overflow;
				   continue l32;
			   }
			   else {
				   rn=pn[4]/pn[5];   dif=Math.abs(gin-rn);
				   if (dif>accurate) {
					   gin=rn;
					   for (i=0; i<4; i++) pn[i]=pn[i+2];
					   if (Math.abs(pn[4]) < overflow) continue l32;
					   for (i=0; i<4; i++) pn[i]/=overflow;
					   continue l32;
				   }
				   if (dif<=accurate*rn) {
					   gin=1-factor*gin;
					   return (gin);
				   }
			   }
			   //l34:
			   gin=rn;
			   //l35:
			   for (i=0; i<4; i++) pn[i]=pn[i+2];
			   if (Math.abs(pn[4]) < overflow) continue l32;
			   for (i=0; i<4; i++) pn[i]/=overflow;
			   continue l32;
		 } while(true);
	   
	}

	static double PointNormal (double prob)
	{
	/* returns z so that Prob{x<z}=prob where x ~ N(0,1) and (1e-12)<prob<1-(1e-12)
	   returns (-9999) if in error
	   Odeh RE & Evans JO (1974) The percentage points of the normal distribution.
	   Applied Statistics 22: 96-97 (AS70)

	   Newer methods:
	     Wichura MJ (1988) Algorithm AS 241: the percentage points of the
	       normal distribution.  37: 477-484.
	     Beasley JD & Springer SG  (1977).  Algorithm AS 111: the percentage
	       points of the normal distribution.  26: 118-121.

	*/
	   double a0=-.322232431088, a1=-1, a2=-.342242088547, a3=-.0204231210245;
	   double a4=-.453642210148e-4, b0=.0993484626060, b1=.588581570495;
	   double b2=.531103462366, b3=.103537752850, b4=.0038560700634;
	   double y, z=0, p=prob, p1;

	   p1 = (p<0.5 ? p : 1-p);
	   if (p1<1e-20) z=999;
	   else {
	      y = Math.sqrt (Math.log(1/(p1*p1)));
	      z = y + ((((y*a4+a3)*y+a2)*y+a1)*y+a0) / ((((y*b4+b3)*y+b2)*y+b1)*y+b0);
	   }
	   return (p<0.5 ? -z : z);
	}
	
	static double PointChi2 (double prob, double v)
	{
	/* returns z so that Prob{x<z}=prob where x is Chi2 distributed with df=v
	   returns -1 if in error.   0.000002<prob<0.999998
	   RATNEST FORTRAN by
	       Best DJ & Roberts DE (1975) The percentage points of the
	       Chi2 distribution.  Applied Statistics 24: 385-388.  (AS91)
	   Converted into C by Ziheng Yang, Oct. 1993.
	*/
	   double e=.5e-6, aa=.6931471805, p=prob, g, small=1e-6;
	   double xx, c, ch, a=0,q=0,p1=0,p2=0,t=0,x=0,b=0,s1,s2,s3,s4,s5,s6;

	   if (p<small)   return(0);
	   if (p>1-small) return(9999);
	   if (v<=0)      return (-1);

	   g = LnGamma (v/2);
	   xx=v/2;   c=xx-1;
	   if (v >= -1.24*Math.log(p)) {
		   //goto l1;
		   if (v>.32) {
			   //l3
			   x=PointNormal (p);
			   p1=0.222222/v;   ch=v*Math.pow((x*Math.sqrt(p1)+1-p1), 3.0);
			   if (ch>2.2*v+6)  ch=-2*(Math.log(1-p)-c*Math.log(.5*ch)+g);
			   //do l4;
		   }
		   else {
			   ch=0.4;   a=Math.log(1-p);
			   do {
				   q=ch;  p1=1+ch*(4.67+ch);  p2=ch*(6.73+ch*(6.66+ch));
				   t=-0.5+(4.67+2*ch)/p1 - (6.73+ch*(13.32+3*ch))/p2;
				   ch-=(1-Math.exp(a+g+.5*ch+c*aa)*p2/p1)/t;
			   } while(Math.abs(q/ch-1)-.01 > 0);
			   //do l4;
		   }
			   
	   }
	   else {
		   ch=Math.pow((p*xx*Math.exp(g+xx*aa)), 1/xx);
		   if (ch-e<0) return (ch);
		   //do l4
	   }
		
	   //l4:
	   do {
		   q=ch;   p1=.5*ch;
		   if ((t=IncompleteGamma (p1, xx, g))<0) {
		      System.out.print ("\nerr IncompleteGamma");
		      return (-1);
		   }
		   p2=p-t;
		   t=p2*Math.exp(xx*aa+g+p1-c*Math.log(ch));
		   b=t/ch;  a=0.5*t-b*c;
	
		   s1=(210+a*(140+a*(105+a*(84+a*(70+60*a))))) / 420;
		   s2=(420+a*(735+a*(966+a*(1141+1278*a))))/2520;
		   s3=(210+a*(462+a*(707+932*a)))/2520;
		   s4=(252+a*(672+1182*a)+c*(294+a*(889+1740*a)))/5040;
		   s5=(84+264*a+c*(175+606*a))/2520;
		   s6=(120+c*(346+127*c))/5040;
		   ch+=t*(1+0.5*t*s1-b*c*(s1-b*(s2-b*(s3-b*(s4-b*(s5-b*s6))))));
	   } while (Math.abs(q/ch-1) > e);

	   return (ch);
	}

	////////////////////////////////////////////////////
	///////////////////////////////////////////////////
	
	static  double PointGamma(double prob, double alpha, double beta) {
		return PointChi2(prob,2.0*(alpha))/(2.0*(beta));
	}
	
	
	static int DiscreteGamma (double freqK[], double rK[], double alfa, double beta, int K, int median)
	{
	
	/* discretization of gamma distribution with equal proportions in each
	   category
	   #define FOR(i,n) for(i=0; i<n; i++)
	
	*/
	   int i;
	   double t, factor=alfa/beta*K, lnga1;
	
	   if (median != 0) {
	      for (i=0;i<K;i++) 
	    	  rK[i]=PointGamma((i*2.+1)/(2.*K), alfa, beta);
	      for(i=0,t=0; i<K; i++) t+=rK[i];
	      for (i=0;i<K;i++) 
	    	  rK[i]*=factor/t;
	      
	   }
	   else {
	      lnga1=LnGamma(alfa+1);
	      for (i=0; i<K-1; i++)
	         freqK[i]=PointGamma((i+1.0)/K, alfa, beta);
	      for (i=0; i<K-1; i++)
	         freqK[i]=IncompleteGamma(freqK[i]*beta, alfa+1, lnga1);
	      rK[0] = freqK[0]*factor;
	      rK[K-1] = (1-freqK[K-2])*factor;
	      for (i=1; i<K-1; i++)  rK[i] = (freqK[i]-freqK[i-1])*factor;
	   }
	   for (i=0; i<K; i++) freqK[i]=1.0/K;
	
	   return (0);
	}
	
	static int fillTermParsInfo(char c)
	{
		/// DNA model
		switch (c) {
		case 'A': return 0;
		case 'C': return 1;
		case 'T': return 2;
		case 'G': return 3;
		/**/
		case 'R': return 4; // A, G
		case 'Y': return 5;  // C, T
		case '-': return 6;
		case '?': return 6;		
		case 'N': return 7;
		case '.': return 8;
		case 'S': return 9; //G, C
		case 'W': return 10; // A, T
		case 'K': return 11; //G, T
		case 'M': return 12; //A, C
		case 'B': return 13; //C,G,T
		case 'D': return 14; //A,G,T
		case 'H': return 15; //A,C,T
		case 'V': return 16; //A,C,G
		case 'U': return 17; 
		
		default: 
			System.err.print("\n Invalid nuc " + c + " ... in fillTermParsInfo(..)"); 
			System.exit(0);
			return -1;
		}
	}
	
	static boolean isMeaningful(char c) {
		
		if (c == '-' || c=='?' || c == '.') {
			return false;
		}
		else // invalid AA has been already checked in TreeML::fillTermLikelihood(char c, double[] v, int pos, double a, int[] ii)
			return true;
	}
	
	static void printAlphabetDataFile(String[] taxaNameList, char[][] alphabetData, String fileName) { 
		try {
			FileWriter fout = new FileWriter(fileName);
			fout.write(String.format("%d %d", taxaNameList.length, alphabetData[0].length));
			int i, j;
			for (i=0;i<taxaNameList.length;i++) {
				fout.write(String.format("\n%s   ", taxaNameList[i]));
				for (j=0;j<alphabetData[i].length;j++) {
					fout.write(String.format("%c", alphabetData[i][j]));
				}
			}
			fout.write(String.format("\n\n"));
			fout.close();
		}
		catch (IOException e) {
			System.out.print(String.format("\n%s error", fileName));
		}
	}
	
	static void simulation20200421_saveSeqToFile(char[][] chData, String[] taxaNameList, int[] taxaIncluded, String fileName) {

	}
	
	static void simulation20200421_extractTopo(String fileName, String[] topoSave, int idx ) {

	}
	
	static double simulation20200421_extractBP(String topo, boolean t12) {
		return 0.0;

	}
	
	static void matrixTranspose(double[][] Result, double[][] A) {
		int i, j;
		if (Result.length != A[0].length || Result[0].length != A.length) {
			System.err.print(String.format("\nSomething wrong in matrixTranspose(..)"));
			System.exit(0);
		}
		
		for (i=0;i<Result.length;i++) {
			for (j=0;j<Result[0].length;j++) {
				Result[i][j] = A[j][i];
			}
		}
	}
	
	static void matrixMult(double[][] Result, double[][] A, double[][] B) {
		int i,j,k;
		for (i=0;i<Result.length;i++) {
			for (j=0;j<Result[i].length;j++) {
				Result[i][j] = 0.0;
				for (k=0;k<A[i].length;k++) {
					Result[i][j] += A[i][k]*B[k][j];
				}
			}
		}
	}
	
	static void matrixVectorMult(double[] Result, double[][] A, double[] b) {
		int i, k, n;
		n = Result.length;
		for (i=0;i<n;i++) {
			Result[i] = 0.0;
			for (k=0;k<A[i].length;k++) {
				Result[i] += A[i][k]*b[k];
			}
		}
	}
	
	static void matrixInverse(double[][] Result, double[][] A) {
		int i,j,k, n;
		double val, val2;
		
		n = A.length;
		double[][] iden = new double[n][n];
		//double[][] tmpA =  new double[n][n];
		for (i=0;i<n;i++) {
			for (j=i;j<n;j++) {
				if (i==j) {
					iden[i][j] = 1.0;
				}
				else {
					iden[i][j] = iden[j][i] = 0.0;
				}
				Result[i][j] = A[i][j];
				Result[j][i] = A[j][i];
			}
		}
		
		for (j=0;j<n;j++) {
			val = Result[j][j];
			if (Math.abs(val)<myFunc.EPSILON) {
				System.err.print(String.format("\nMatrix Inverse is numerically unstable"));
				System.exit(0);
			}
			for (k=0;k<n;k++) {
				Result[j][k] /= val;
				iden[j][k] /= val;
			}
			for (i=j+1;i<n;i++) {
				val2 = Result[i][j];
				for (k=0;k<n;k++)  {
					Result[i][k] = Result[j][k]*val2-Result[i][k];
					iden[i][k] = iden[j][k]*val2- iden[i][k];
				}
			}
		}
		
		for (j=n-1;j>=0;j--) {
			for (i=j-1;i>=0;i--) {
				val2 = Result[i][j];
				for (k=0;k<n;k++)  {
					Result[i][k] = Result[i][k]- Result[j][k]*val2;
					iden[i][k] = iden[i][k] - iden[j][k]*val2;
				}

			}
		}
		
		for (i=0;i<n;i++) {
			for (j=i;j<n;j++) {
				Result[i][j] = iden[i][j];
				Result[j][i] = iden[j][i];
			}
		}
	}
	
	static public String BuildNJTree(double[][] dist, String[] taxaNames) {
		// Algorithm of Felsenstein's book
		// pairwise distance should be symmetric
		// Negative distances are fixed after reconstruction. 
		
		// this code was copied from 
		// MyLib27\bootlike20181123\tree.cpp
		// not checked yet after copying.
		
		int num_taxa = dist.length;
		
		int i,j,k;
		
		String str;
		
		double brL1, brL2;
		brL1 = brL2 = 0.0;
		
		boolean debug = false; // true; // 
		
		double[][] Dij,OldDij;
		Dij = new double[dist.length][dist[0].length];
		OldDij = new double[dist.length][dist[0].length];		
		
		for (i=0;i<dist.length;i++) {
			for (j=0;j<dist[i].length;j++) {
				Dij[i][j] = OldDij[i][j] = dist[i][j];
			}
		}	
		
		double[] Ui = new double[num_taxa];
		boolean[] valid = new boolean[num_taxa];
		for (i=0;i<num_taxa;i++) 
			valid[i] = true;

		int num_group = num_taxa;
		
		String[] partialTopo = new String[num_taxa];
		for (i=0;i<num_taxa;i++) 
			partialTopo[i] = taxaNames[i];
			
		double minimum,d;
		int idxa, idxb;
		
		int temp_id = 0; // for debugging
		
		do {
			for (i = 0; i<num_taxa; i++) {
				if (valid[i]) {
					Ui[i] = 0.0;
					for (j = 0; j<num_taxa; j++) {
						if (valid[j]) Ui[i] += Dij[i][j];
					}
					Ui[i] /= (num_group - 2);
				}
			}
			minimum = 2.0e100;
			idxa = -1; idxb = -1;

			for (i = 0; i<num_taxa; i++) {
				if (valid[i]) {
					for (j = 0; j<num_taxa; j++) {
						if (valid[j] && i != j) {
							d = Dij[i][j] - Ui[i] - Ui[j];
							//cout<<endl<<"##("<<i<<","<<j<<") : "<<d; // here
							if (minimum > d) {
								minimum = d;
								idxa = i;
								idxb = j;
							}
						}
					}

				}
			}

			// change order of left and right subtree
			if (partialTopo[idxa].compareTo(partialTopo[idxb]) > 0) { // if partialTopo[idxb] precedes
				int tmp = idxa;
				idxa = idxb;
				idxb = tmp;
			}

			brL1 = 0.5*Dij[idxa][idxb] + 0.5*(Ui[idxa] - Ui[idxb]);
			brL2 = 0.5*Dij[idxa][idxb] + 0.5*(Ui[idxb] - Ui[idxa]);

			if (brL1 < BRANCH_LENGTH_LOWER_LIMIT) {
				brL1 = BRANCH_LENGTH_LOWER_LIMIT;
			}
			if (brL2 < BRANCH_LENGTH_LOWER_LIMIT) {
				brL2 = BRANCH_LENGTH_LOWER_LIMIT;
			}

			//cout<<endl<<"("<<idxa<<","<<idxb<<") produces smallest"; // here
		
			if (debug) {
				//cout << endl << "## temp_id=" << temp_id << ", " << partialTopo[idxa] << " and " << partialTopo[idxb] << " merged";
				temp_id++;
			}

			str = String.format(":%.15f,", brL1);
			partialTopo[idxa] = "(" + partialTopo[idxa] + str + partialTopo[idxb];
			str = String.format(":%.15f", brL2);
			partialTopo[idxa] = partialTopo[idxa] + str + ")";
			partialTopo[idxb] = "";

			if (debug) {
				; //cout << endl << "## " << partialTopo[idxa];
			}

			if (idxa == -1 || idxb == -1) { // for debugging
				//cout << "minimum = " << minimum;
				for (i = 0; i<num_taxa; i++) {
					if (valid[i]) {
						for (j = 0; j<num_taxa; j++) {
							if (valid[j] && i != j) {
								d = Dij[i][j] - Ui[i] - Ui[j];
								//cout << endl << "d=" << d;
								if (minimum > d) {
									minimum = d;
									idxa = i;
									idxb = j;
								}
							}
						}
					}
				}
			}

			// saved merged node to idxa_th element...
			for (k = 0; k<num_taxa; k++) {
				if (valid[k]) {
					Dij[k][idxa] = 0.5*(OldDij[idxa][k] + OldDij[idxb][k] - OldDij[idxa][idxb]);
					Dij[idxa][k] = Dij[k][idxa];
				}
			}
			Dij[idxa][idxa] = 0.0;

			OldDij = Dij;

			valid[idxb] = false;

			num_group--;

		} while (num_group > 3);

		k = 0;
		double s12, s13, s23;
		s12 = s13 = s23 = 0.0;
		for (i = 0; i<num_taxa; i++) {
			for (j = i + 1; j<num_taxa; j++) {
				if (valid[i] == true && valid[j] == true) {
					if (k == 0) {
						s12 = Dij[i][j];
						k++;
					}
					else if (k == 1) {
						s13 = Dij[i][j];
						k++;
					}
					else if (k == 2) {
						s23 = Dij[i][j];
						k++;
					}
				}
			}
		}

		String NJTree = "(";
		k = 0;
		for (i = 0; i<partialTopo.length; i++) {
			if (partialTopo[i] != "") {
				if (k == 0) {
					d = 0.5*(s12 + s13 - s23);
					if (d < BRANCH_LENGTH_LOWER_LIMIT) {
						d = BRANCH_LENGTH_LOWER_LIMIT;
					}
					str = String.format(":%.15f", d);
					NJTree += partialTopo[i] + str + ",";
					k++;
				}
				else if (k == 1) {
					d = 0.5*(s12 + s23 - s13);
					if (d < BRANCH_LENGTH_LOWER_LIMIT) {
						d = BRANCH_LENGTH_LOWER_LIMIT;
					}
					str = String.format(":%.15f", d);
					NJTree += partialTopo[i] + str + ",";
					k++;
				}
				else if (k == 2) {
					d = 0.5*(s13 + s23 - s12);
					if (d < BRANCH_LENGTH_LOWER_LIMIT) {
						d = BRANCH_LENGTH_LOWER_LIMIT;
					}
					str = String.format(":%.15f", d);
					NJTree += partialTopo[i] + str + ");";
					k++;
				}
			}
		}
		return NJTree;
	}
	
	static public int[] doubleArraySort(double[] data) {
		int[] idx;
		double[] datatmp;
		
		idx = new int[data.length];
		datatmp = new double[data.length];
		int i, j;

		for (i=0;i<data.length;i++) {
			datatmp[i] = data[i];
			idx[i] = i;
		}

		double d;
		int k;
		
		for (i=0;i<datatmp.length-1;i++) {
			for (j=i;j<datatmp.length;j++) {
				if (datatmp[i] > datatmp[j]) { //ascending
				//if (datatmp[i] < datatmp[j]) { //descending
					d = datatmp[i];
					datatmp[i] = datatmp[j];
					datatmp[j] = d;
					k = idx[i];
					idx[i] = idx[j];
					idx[j] = k;
				}
			}
		}
		return idx;
	}
	
	static public int[] doubleArraySortDescend(double[] data) {
		int[] idx;
		double[] datatmp;
		
		idx = new int[data.length];
		datatmp = new double[data.length];
		int i, j;

		for (i=0;i<data.length;i++) {
			datatmp[i] = data[i];
			idx[i] = i;
		}

		double d;
		int k;
		
		for (i=0;i<datatmp.length-1;i++) {
			for (j=i;j<datatmp.length;j++) {
				//if (datatmp[i] > datatmp[j]) { //ascending
				if (datatmp[i] < datatmp[j]) { //descending
					d = datatmp[i];
					datatmp[i] = datatmp[j];
					datatmp[j] = d;
					k = idx[i];
					idx[i] = idx[j];
					idx[j] = k;
				}
			}
		}
		return idx;
	}
	
	static public void saveGapInfo(boolean[][] gapInfo, char[][] alphabetData) {
		int i,j;
		char c;
		
		for (i=0;i<alphabetData.length;i++) {
			for (j=0;j<alphabetData[i].length;j++) {
				c = alphabetData[i][j];
				if ( c== '-' || c== '?' )
					gapInfo[i][j] = true;
				else
					gapInfo[i][j] = false;
			}
		}
	}
	
	static public void copyGapInfo(char[][] alphabetData, boolean[][] gapInfo) {
		int i,j;
		
		for (i=0;i<gapInfo.length;i++) {
			for (j=0;j<gapInfo[i].length;j++) {
				if ( gapInfo[i][j] )
					alphabetData[i][j] = '-';
			}
		}
	}
	
	static void print(String str) {
		
		ArrayList<String> strList = new ArrayList<String>();
		strList.add("running reorderBrIdx()...");
		
		int i;
		for (i=0;i<strList.size();i++) {
			if (str.contains(strList.get(i)))
				return;
		}
		
		System.out.print(str);
	}
	
	static void errPrint(String str) {
		System.err.print(str);
	}
}





